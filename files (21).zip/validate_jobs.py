#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
D-CAS 직무 마스터 검증 스크립트
사용: python3 validate_jobs.py dcas-jobs-batch1.json dcas-jobs-batch2.json

사람이 볼 것만 골라냅니다. 통과 건은 출력하지 않습니다.
결과: review_queue.csv (검수 필요 건만)
"""
import json, sys, csv, collections

# NCS 대분류별로 나올 수 있는 ISCO 대분류(첫 자리) 화이트리스트
# 0=군인 1=관리자 2=전문가 3=기술공 4=사무 5=서비스판매 6=농림어업
# 7=기능원 8=조작원 9=단순노무
ALLOWED = {
 "01": set("124"),      "02": set("1234"),   "03": set("1234"),
 "04": set("1234"),     "05": set("02345"),  "06": set("235"),
 "07": set("12345"),    "08": set("123457"),  "09": set("1345789"),
 "10": set("12345"),    "11": set("123459"),  "12": set("12345"),
 "13": set("123579"),    "14": set("1237893"), "15": set("23789"),
 "16": set("23789"),    "17": set("2378"),   "18": set("123789"),
 "19": set("2378"),     "20": set("2378"),   "21": set("23789"),
 "22": set("23789"),    "23": set("23789"),  "24": set("1236789"),
}

VALID_INTEREST = set("BACSLO")
VALID_ENTRY = {"direct", "bridge", "retool"}
MIN_JOBS_PER_MIDDLE = 8

def load(paths):
    jobs = []
    for p in paths:
        with open(p, encoding="utf-8") as f:
            jobs += json.load(f)["jobs"]
    return jobs

def validate(jobs):
    issues = []          # (심각도, 직무명, 항목, 내용)
    seen_names = collections.Counter(j["label_ko"] for j in jobs)

    for j in jobs:
        name = j["label_ko"]
        isco = str(j.get("isco_code", ""))
        maj  = j["ncs"]["major"]

        # 1. ISCO 형식
        if not (isco.isdigit() and len(isco) == 4):
            issues.append(("ERROR", name, "isco_format",
                           f"4자리 숫자가 아님: '{isco}'"))
            continue

        # 2. NCS 대분류 ↔ ISCO 대분류 정합성
        if maj in ALLOWED and isco[0] not in ALLOWED[maj]:
            issues.append(("REVIEW", name, "isco_mismatch",
                           f"NCS {maj} 계열에 ISCO {isco[0]}xxx 는 이례적 "
                           f"(허용: {''.join(sorted(ALLOWED[maj]))})"))

        # 3. 흥미 코드
        ic = j.get("interest_code", "")
        if len(ic) != 3 or not set(ic) <= VALID_INTEREST or len(set(ic)) != 3:
            issues.append(("ERROR", name, "interest_code",
                           f"BACSLO 중 서로 다른 3자여야 함: '{ic}'"))

        # 4. 진입난이도
        if j.get("entry_level") not in VALID_ENTRY:
            issues.append(("ERROR", name, "entry_level",
                           f"허용값 아님: '{j.get('entry_level')}'"))

        # 5. PASS 값 범위
        for k, v in j.get("pass_profile", {}).items():
            if not isinstance(v, int) or not (0 <= v <= 100):
                issues.append(("ERROR", name, "pass_range",
                               f"{k}={v} (0~100 정수여야 함)"))

        # 6. 직무명 중복
        if seen_names[name] > 1:
            issues.append(("REVIEW", name, "duplicate_name",
                           f"같은 이름이 {seen_names[name]}건"))

    # 7. 같은 ISCO 코드가 서로 다른 NCS 대분류에 흩어진 경우
    by_isco = collections.defaultdict(set)
    for j in jobs:
        by_isco[j["isco_code"]].add(j["ncs"]["major"])
    for isco, majors in by_isco.items():
        if len(majors) > 2:
            issues.append(("REVIEW", f"[ISCO {isco}]", "isco_scattered",
                           f"{len(majors)}개 대분류에 분산: {sorted(majors)}"))

    # 8. 중분류별 사분면 성립 가능성
    by_mid = collections.defaultdict(list)
    for j in jobs:
        by_mid[(j["ncs"]["middle"], j["ncs"]["middle_name"])].append(j)
    for (code, nm), rows in by_mid.items():
        if len(rows) < MIN_JOBS_PER_MIDDLE:
            issues.append(("ERROR", f"[중분류 {code} {nm}]", "too_few_jobs",
                           f"{len(rows)}건 — 사분면 성립 불가(최소 {MIN_JOBS_PER_MIDDLE})"))
        # 진입난이도가 한쪽으로만 몰리면 '지금 갈 수 있는 길'이 항상 빈칸
        lv = collections.Counter(r["entry_level"] for r in rows)
        if lv.get("direct", 0) == 0:
            issues.append(("REVIEW", f"[중분류 {code} {nm}]", "no_direct",
                           "direct 0건 — '지금 갈 수 있는 길'이 항상 빈칸"))
        # 흥미 1순위가 2종 이하면 특정 유형 검사자에게 추천 불가
        it = {r["interest_code"][0] for r in rows}
        if len(it) <= 2:
            issues.append(("REVIEW", f"[중분류 {code} {nm}]", "interest_narrow",
                           f"흥미 1순위 {len(it)}종({''.join(sorted(it))}) — 다양성 부족"))
    return issues

def main():
    paths = sys.argv[1:] or ["dcas-jobs-batch1.json", "dcas-jobs-batch2.json"]
    jobs = load(paths)
    issues = validate(jobs)

    errors  = [i for i in issues if i[0] == "ERROR"]
    reviews = [i for i in issues if i[0] == "REVIEW"]

    print(f"검사 대상 {len(jobs)}건")
    print(f"  자동 통과   {len(jobs) - len({i[1] for i in issues}):>4}건")
    print(f"  ERROR      {len(errors):>4}건  ← 반드시 고쳐야 함")
    print(f"  REVIEW     {len(reviews):>4}건  ← 사람 또는 API 판정")
    print()
    for sev, name, kind, msg in errors + reviews:
        print(f"[{sev:6s}] {name:28s} {kind:16s} {msg}")

    with open("review_queue.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["severity", "target", "check", "detail", "판정", "수정코드"])
        for row in errors + reviews:
            w.writerow(list(row) + ["", ""])
    print(f"\n→ review_queue.csv 생성 ({len(issues)}행)")

if __name__ == "__main__":
    main()
