# D-CAS 글로벌 직무 마스터 설계

## 0. 문제 정의

현재 상태: NCS 대분류 24 · 중분류 61은 들어가 있으나 그 아래 **세부 직무 마스터가 비어 있음**.
- 교육 중분류 선택 시 직무 3개만 조회됨 (학습·진로 상담 / 교육콘텐츠 개발 / 중등교과 교사)
- 3개로는 2×2 사분면(최우선/성장 설계/재고 필요/후순위)이 성립 불가 → 한 칸 몰림
- 해외 배포 시 NCS는 한국 전용 코드라 그대로 쓸 수 없음

목표: **국제 표준을 축(canonical)으로, NCS는 한국 표시 레이어**로 재배치.

---

## 1. 4레이어 아키텍처

```
[L1] ISCO-08          국제 뼈대 (ILO)         10 → 43 → 130 → 436 unit group
        ↓ 1:N
[L2] ESCO occupation  직무 실체 + 다국어 라벨   3,039개 / 28개 언어
        ↓ crosswalk (N:M)
[L3] O*NET-SOC        인지·흥미 속성 공급원     900+ 직업 / ~500 지표
        ↓ 계산
[L4] D-CAS job        PASS 4축 요구 + 흥미 6유형 + 진입난이도
        ↕ display crosswalk
     NCS 24/61 (KR) · ESCO(EU) · SOC(US) — 국가별 표시용
```

**왜 이 순서인가**
- ISCO-08은 각국 분류가 매핑되는 허브 → 한 번 붙이면 국가 확장이 매핑 테이블 추가로 끝남
- ESCO는 직무명을 28개 언어로 이미 갖고 있음 → 번역 비용 0
- O*NET은 CC BY 4.0이고 PostgreSQL 로딩용 SQL 파일을 그대로 배포 → 속성값을 손으로 안 채워도 됨
- NCS는 `display_mapping` 한 줄로 남음 (한국 채용공고·자격증 연동은 유지)

---

## 2. PASS 4축 산출 공식

O*NET Abilities(중요도 IM 척도 1–5)를 PASS 축으로 집계한다.
가중 평균 후 전체 직업 분포에서 z → 0–100 스케일.

| PASS 축 | O*NET Ability 요소 | 가중치 |
|---|---|---|
| **Planning** (계획) | Problem Sensitivity, Deductive Reasoning, Inductive Reasoning, Fluency of Ideas, Originality, Category Flexibility | .20/.20/.20/.15/.15/.10 |
| **Attention** (주의) | Selective Attention, Time Sharing, Perceptual Speed, Speed of Closure | .35/.25/.25/.15 |
| **Simultaneous** (동시처리) | Visualization, Spatial Orientation, Flexibility of Closure, Mathematical Reasoning | .35/.20/.25/.20 |
| **Successive** (순차처리) | Information Ordering, Memorization, Written Comprehension, Oral Comprehension, Number Facility | .30/.25/.20/.15/.10 |

```
raw_axis = Σ(IM_element × w_element)
score_axis = 50 + 10 × z(raw_axis over all SOC)   →  clip 0–100
```

검증 포인트: 문수백 교수 자문으로 요소 배정 1회 리뷰 필요. 특히
Mathematical Reasoning을 Simultaneous에 둘지 Planning에 둘지는 이론적 논쟁 여지 있음.

---

## 3. 활동흥미 6유형 매핑

D-CAS 6유형은 RIASEC과 구조적으로 대응되므로 O*NET Interests를 직결한다.
(상표 회피는 **표시 라벨**에서만 이뤄지고, 내부 계산은 공개 데이터 사용)

| D-CAS 코드 | 표시명 | O*NET Interest |
|---|---|---|
| B | 제작·실행형 | Realistic |
| A | 분석·탐구형 | Investigative |
| C | 표현·창작형 | Artistic |
| S | 관계·지원형 | Social |
| L | 주도·설득형 | Enterprising |
| O | 관리·정밀형 | Conventional |

각 직무는 O*NET 흥미 점수 상위 3개를 순서대로 저장 (`interest_code` 예: `SAL`).

---

## 4. 진입난이도

O*NET Job Zone(4단계 프레임워크로 개편됨)을 그대로 승계.

| Job Zone | D-CAS entry_level | 리포트 표기 |
|---|---|---|
| 1–2 | `direct` | 지금 갈 수 있는 길 |
| 3 | `bridge` | 한 걸음 남은 길 |
| 4 | `retool` | 구조가 다른 길 |

---

## 5. 사분면 재설계 (현재 버그 수정 포함)

### 5.1 상대 순위 기반 배치
절대 임계값 폐기. **선택 영역 내부** 백분위로 자른다.

```
cog_fit    = 1 - Σ|user_PASS - job_PASS| / 400      # 0–1
int_fit    = 흥미 코드 일치 가중합 (1순위 .5 / 2순위 .3 / 3순위 .2)
cog_rank   = percentile(cog_fit, within selected 중분류)
int_rank   = percentile(int_fit, within selected 중분류)

quadrant = cog_rank >= .5 ? (int_rank >= .5 ? '최우선' : '재고 필요')
                          : (int_rank >= .5 ? '성장 설계' : '후순위')
```

### 5.2 top1 강조는 사분면과 분리
```
is_area_top = (rank(total_fit) == 1)   // 사분면 무관, 항상 1건
```
현재 코드는 최우선 칸에 있을 때만 주황 강조가 걸려 안내문("절대 점수가
낮아도 영역 내 1위는 항상 존재")과 모순됨.

### 5.3 콜아웃 조건부 분기
```
비어있지 않은 사분면 중 우선순위: 재고 필요 > 성장 설계 > 최우선 > 후순위
→ 해당 사분면 문구 출력. 전 칸 후순위인 경우 전용 문구 사용.
```

### 5.4 최소 표본 가드
```
직무 수 < 8 → 같은 대분류 내 다른 중분류에서 보충
직무 수 < 4 → 사분면 대신 단순 순위 리스트로 폴백
```

---

## 6. 구축 파이프라인

| 단계 | 작업 | 산출 |
|---|---|---|
| 1 | O*NET DB(PostgreSQL SQL) 적재 | `onet_*` 원본 테이블 |
| 2 | ESCO 다국어 덤프 적재 | `esco_occupation`, `esco_label(28 lang)` |
| 3 | ESCO→ISCO 조인(ESCO에 내장) | L1–L2 연결 완료 |
| 4 | SOC↔ISCO 크로스워크 적용 | O*NET 속성을 ESCO 직무에 상속 |
| 5 | §2·§3 공식 실행 | PASS 4축 + 흥미코드 산출 |
| 6 | NCS 61 중분류 ↔ ISCO 매핑표 작성 | **유일한 수작업 (약 61행)** |
| 7 | 중분류별 직무 수 검증 | 8개 미만 중분류 리스트업 → 보강 |

수작업은 6단계 61행뿐. 나머지는 전부 스크립트.

---

## 7. 라이선스 표기 (필수)

- **O*NET**: CC BY 4.0. 미국 노동부 표기 필요. 값을 가공했으므로 변경 내역
  안내 링크를 함께 두는 것이 권장됨
- **ESCO**: 유럽위원회. ISCO 라벨 번역본 사용 시 ILO 원저작 고지 포함
- **ISCO-08**: ILO 원저작물

리포트 하단 또는 `/legal/data-sources` 페이지에 3건 일괄 표기.

---

## 8. 실행 순서 제안

1. **이번 주**: §5.1–5.4 렌더링 수정 + 교육 영역 시드 33건 투입 → 화면 정상화
2. **2주차**: O*NET·ESCO 적재, §2·§3 파이프라인 구현
3. **3주차**: NCS 61행 매핑표 작성, 전 영역 자동 생성
4. **4주차**: 문수백 교수 PASS 축 배정 검증 → 가중치 확정
