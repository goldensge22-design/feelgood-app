# 개발자 수정 가이드 — 기존 결과지에 반영하는 법

파일 경로는 프로젝트마다 다르므로, **찾는 방법(grep 문자열)** 으로 표기했습니다.
전체 재작성 없이 기존 결과지를 부분 수정하는 방식입니다.

---

## 수정 1. 콜아웃 하드코딩 제거 (가장 급함)

**증상**: 재고 필요 칸이 비어 있는데도 "재고 필요 칸에 있는 직무를 눈여겨보세요"가 출력됨.
스크린샷 08 페이지에서 재현됨.

**찾기**
```bash
grep -rn "재고 필요 칸에 있는 직무를" src/
```

**고치기** — 그 문자열이 있는 컴포넌트에서
```tsx
// BEFORE — 항상 출력
<Callout>재고 필요 칸에 있는 직무를 눈여겨보세요. …</Callout>

// AFTER
import { pickCalloutKey } from '@/lib/quadrant';
const calloutKey = pickCalloutKey(scoredJobs);
<Callout>{t(`page08.callout.${calloutKey}`)}</Callout>
```

---

## 수정 2. 영역 내 1위 주황 강조

**증상**: 안내문은 "영역 내 1위는 항상 존재하며 주황색으로 강조됩니다"인데
후순위 칸에 있으면 강조가 안 걸림.

**찾기**
```bash
grep -rn "isTop\|highlight\|영역 내 1위" src/
```

**고치기** — 강조 조건에서 사분면 판정을 떼어냅니다.
```tsx
// BEFORE
className={job.quadrant === 'top' ? 'text-orange-500 font-bold' : ''}

// AFTER
className={job.isAreaTop ? 'text-orange-500 font-bold' : ''}
```
`isAreaTop`은 `buildQuadrants()`가 사분면과 무관하게 정확히 1건에 부여합니다.

---

## 수정 3. 사분면 배치를 상대 순위로

**찾기**
```bash
grep -rn "quadrant\|사분면\|>= 0.5\|> 50" src/
```

**고치기** — 기존 절대 임계값 분기를 통째로 `quadrant.ts`로 교체.
```tsx
import { buildQuadrants, shouldFallbackToList, groupByEntry } from '@/lib/quadrant';

const scored = buildQuadrants(jobsInSelectedMiddle, userProfile);
if (shouldFallbackToList(scored.length)) {
  return <RankListView jobs={scored} />;   // 8건 미만이면 사분면 대신 순위 리스트
}
const { hasDirect } = groupByEntry(scored);
```

---

## 수정 4. 다국어 오류 (스크린샷의 한/영 혼재)

**증상**: 페이지 제목은 "Custom Job Recommendations"인데 본문은 한국어.
사분면 라벨, 콜아웃, 직무명이 전부 한국어로 남음.

**원인**: 제목만 i18n을 타고, 나머지는 JSX에 한국어가 박혀 있음.

**찾기** — JSX 안의 한글 리터럴을 전부 뽑습니다.
```bash
grep -rnP '>[^<]*[가-힣]+[^<]*<' src/components/report/ | grep -v 't('
```

**고치기**
1. `report-i18n.json`을 `src/locales/report.json`으로 배치
2. 위에서 뽑힌 한글 리터럴을 `t('page08.quadrant.top')` 형태로 교체
3. 언어 결정은 검사자 설정값을 따르게 (브라우저 로케일 아님)

```tsx
const lang = testResult.locale ?? 'ko';        // 검사 발급 시점의 언어
const t = (key: string, vars?: Record<string, string|number>) => {
  let s = key.split('.').reduce((o, k) => o?.[k], strings)?.[lang]
       ?? key.split('.').reduce((o, k) => o?.[k], strings)?.['en']   // 폴백
       ?? key;
  if (vars) Object.entries(vars).forEach(([k, v]) => { s = s.replaceAll(`{${k}}`, String(v)); });
  return s;
};
```

**주의** — 폴백은 `ko`가 아니라 `en`으로 두세요. 번역 누락 시 한국어가 튀어나오면
해외 검사자에게 지금과 같은 혼재 화면이 다시 생깁니다.

---

## 수정 5. 직무명 다국어

직무 마스터가 아직 `label_ko` 뿐입니다. 스키마를 이렇게 바꿉니다.

```json
// BEFORE
{ "label_ko": "백엔드 개발자" }

// AFTER
{ "labelKey": "job.2512.backend_developer",
  "labels": { "ko": "백엔드 개발자", "en": "Backend Developer" } }
```

**당장 급하면** — ISCO 코드로 ESCO 다국어 라벨을 끌어오면 28개 언어가 한 번에 붙습니다.
그 전까지는 `labels.en`이 없을 때 `labels.ko`를 쓰되, 화면에 언어 배지를 달아
번역 미완료임을 드러내는 편이 혼재보다 낫습니다.

---

## 수정 6. 검증 스크립트 붙이기

`validate_jobs.py`를 CI 또는 시드 투입 전에 실행합니다.

```bash
python3 validate_jobs.py dcas-jobs-batch1.json dcas-jobs-batch2.json
# ERROR 1건 이상이면 배포 중단
```

지금 기준 ERROR 0건 / REVIEW 15건이며, REVIEW는 배포를 막지 않습니다.
`review_queue.csv`의 `판정`·`수정코드` 칸을 채워가며 처리하면 됩니다.

---

## 반영 순서

| 순서 | 작업 | 소요 | 효과 |
|---|---|---|---|
| 1 | 수정 1·2 | 30분 | 콜아웃·강조 모순 즉시 해소 |
| 2 | 수정 3 + 시드 387건 투입 | 반나절 | 사분면 정상 작동 |
| 3 | 수정 4 | 1일 | 한/영 혼재 해소 |
| 4 | 수정 5 | 2일 | 해외 검사자 직무명 정상화 |
| 5 | 수정 6 | 1시간 | 재발 방지 |

10월 검사 전까지는 1~3번만 끝나도 화면은 정상입니다.
