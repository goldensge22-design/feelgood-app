/**
 * D-CAS 08 맞춤 직무 추천 — 사분면 배치 로직 (교체용)
 *
 * 기존 버그 3건 수정:
 *  (1) 절대 임계값 → 영역 내 상대 백분위
 *  (2) top1 주황 강조가 '최우선' 칸에서만 걸리던 문제 → 사분면과 분리
 *  (3) 콜아웃 하드코딩('재고 필요'가 비어도 출력) → 채워진 칸 기준 분기
 */

export type Quadrant = 'top' | 'grow' | 'rethink' | 'later';
export type EntryLevel = 'direct' | 'bridge' | 'retool';

export interface Job {
  id: number;
  labelKey: string;              // i18n 키. 하드코딩 한국어 금지
  passProfile: { planning: number; attention: number; simultaneous: number; successive: number };
  interestCode: string;          // 예: 'ASO'
  entryLevel: EntryLevel;
}

export interface UserProfile {
  planning: number; attention: number; simultaneous: number; successive: number;
  interestRank: string[];        // 흥미 상위 순서, 예: ['A','O','B']
}

export interface ScoredJob extends Job {
  cogFit: number;                // 0~1
  intFit: number;                // 0~1
  totalFit: number;
  cogRank: number;               // 영역 내 백분위 0~1
  intRank: number;
  quadrant: Quadrant;
  isAreaTop: boolean;            // ★ 사분면과 무관하게 영역 내 1위 1건
}

const AXES = ['planning', 'attention', 'simultaneous', 'successive'] as const;
const INTEREST_WEIGHT = [0.5, 0.3, 0.2];

function cognitiveFit(job: Job, user: UserProfile): number {
  const diff = AXES.reduce((sum, ax) => sum + Math.abs(user[ax] - job.passProfile[ax]), 0);
  return Math.max(0, 1 - diff / 400);
}

function interestFit(job: Job, user: UserProfile): number {
  let score = 0;
  job.interestCode.split('').forEach((code, i) => {
    const pos = user.interestRank.indexOf(code);
    if (pos >= 0 && pos < 3) score += INTEREST_WEIGHT[i] * INTEREST_WEIGHT[pos] * 4;
  });
  return Math.min(1, score);
}

/** 영역 내 백분위. 동점은 같은 값을 받는다. */
function percentileRanks(values: number[]): number[] {
  const sorted = [...values].sort((a, b) => a - b);
  return values.map(v => {
    const below = sorted.filter(x => x < v).length;
    const equal = sorted.filter(x => x === v).length;
    return (below + equal / 2) / values.length;
  });
}

export function buildQuadrants(jobs: Job[], user: UserProfile): ScoredJob[] {
  const cogs = jobs.map(j => cognitiveFit(j, user));
  const ints = jobs.map(j => interestFit(j, user));
  const cogRanks = percentileRanks(cogs);
  const intRanks = percentileRanks(ints);

  const scored: ScoredJob[] = jobs.map((j, i) => {
    const cogHigh = cogRanks[i] >= 0.5;
    const intHigh = intRanks[i] >= 0.5;
    return {
      ...j,
      cogFit: cogs[i],
      intFit: ints[i],
      totalFit: cogs[i] * 0.5 + ints[i] * 0.5,
      cogRank: cogRanks[i],
      intRank: intRanks[i],
      quadrant: cogHigh ? (intHigh ? 'top' : 'rethink') : (intHigh ? 'grow' : 'later'),
      isAreaTop: false,
    };
  });

  // (2) 영역 내 1위는 어느 사분면에 있든 항상 1건 강조
  if (scored.length > 0) {
    let best = 0;
    scored.forEach((s, i) => { if (s.totalFit > scored[best].totalFit) best = i; });
    scored[best].isAreaTop = true;
  }
  return scored;
}

/**
 * (3) 콜아웃 선택. 비어 있는 칸을 가리키지 않는다.
 * 반환값은 i18n 키. 렌더러는 page08.callout[key] 를 현재 언어로 출력.
 */
export function pickCalloutKey(scored: ScoredJob[]): 'rethink' | 'grow' | 'top' | 'all_later' {
  const has = (q: Quadrant) => scored.some(s => s.quadrant === q);
  if (has('rethink')) return 'rethink';
  if (has('grow')) return 'grow';
  if (has('top')) return 'top';
  return 'all_later';
}

/** (4) 최소 표본 가드. 8건 미만이면 사분면 대신 순위 리스트로 폴백. */
export function shouldFallbackToList(jobCount: number): boolean {
  return jobCount < 8;
}

/** 진입난이도 그룹. direct가 0건이면 no_direct 안내 후 bridge부터 노출. */
export function groupByEntry(scored: ScoredJob[]) {
  const g: Record<EntryLevel, ScoredJob[]> = { direct: [], bridge: [], retool: [] };
  scored.forEach(s => g[s.entryLevel].push(s));
  (Object.keys(g) as EntryLevel[]).forEach(k =>
    g[k].sort((a, b) => b.totalFit - a.totalFit)
  );
  return { groups: g, hasDirect: g.direct.length > 0 };
}
