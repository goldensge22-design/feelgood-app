-- D-CAS 글로벌 직무 마스터 스키마
-- PostgreSQL / Kysely 대상

-- =========================================================
-- L1. ISCO-08 국제 뼈대
-- =========================================================
CREATE TABLE isco_group (
  code          VARCHAR(4) PRIMARY KEY,       -- '2','23','233','2330'
  level         SMALLINT   NOT NULL,          -- 1~4
  parent_code   VARCHAR(4) REFERENCES isco_group(code),
  label_en      TEXT       NOT NULL,
  label_ko      TEXT,
  skill_level   SMALLINT                      -- ISCO skill level 1~4
);
CREATE INDEX idx_isco_parent ON isco_group(parent_code);

-- =========================================================
-- L2/L4. 직무 본체 (ESCO 기반, D-CAS 속성 포함)
-- =========================================================
CREATE TABLE job (
  id                BIGSERIAL PRIMARY KEY,
  esco_uri          TEXT UNIQUE,              -- ESCO 원본 URI
  isco_code         VARCHAR(4) NOT NULL REFERENCES isco_group(code),
  onet_soc_code     VARCHAR(10),              -- 속성 상속 출처

  -- PASS 4축 요구 프로파일 (0~100, §2 공식 산출)
  pass_planning     SMALLINT NOT NULL,
  pass_attention    SMALLINT NOT NULL,
  pass_simultaneous SMALLINT NOT NULL,
  pass_successive   SMALLINT NOT NULL,

  -- 활동흥미 6유형: 상위 3개 순서대로 (B/A/C/S/L/O)
  interest_code     VARCHAR(3) NOT NULL,
  interest_scores   JSONB      NOT NULL,      -- {"B":12,"A":68,...}

  entry_level       VARCHAR(8) NOT NULL       -- direct | bridge | retool
                    CHECK (entry_level IN ('direct','bridge','retool')),
  job_zone          SMALLINT,

  attr_source       VARCHAR(16) NOT NULL DEFAULT 'onet',  -- onet | expert | manual
  attr_confidence   NUMERIC(3,2) DEFAULT 1.0, -- 크로스워크 신뢰도
  is_active         BOOLEAN NOT NULL DEFAULT true,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_job_isco ON job(isco_code);

-- =========================================================
-- 다국어 라벨 (ESCO 28개 언어 그대로 적재)
-- =========================================================
CREATE TABLE job_label (
  job_id      BIGINT NOT NULL REFERENCES job(id) ON DELETE CASCADE,
  lang        VARCHAR(5) NOT NULL,            -- 'ko','en','ja','zh-CN',...
  preferred   TEXT NOT NULL,
  alt_terms   TEXT[],
  description TEXT,
  PRIMARY KEY (job_id, lang)
);

-- =========================================================
-- 국가별 표시 분류 크로스워크 (NCS 등)
-- =========================================================
CREATE TABLE taxonomy_node (
  id          BIGSERIAL PRIMARY KEY,
  scheme      VARCHAR(16) NOT NULL,           -- 'NCS','ESCO_UI','SOC'
  code        VARCHAR(16) NOT NULL,           -- NCS '04','0401'
  level       SMALLINT    NOT NULL,           -- 1=대분류 2=중분류
  parent_id   BIGINT REFERENCES taxonomy_node(id),
  label       TEXT NOT NULL,
  lang        VARCHAR(5) NOT NULL DEFAULT 'ko',
  UNIQUE (scheme, code)
);

CREATE TABLE job_taxonomy_map (
  job_id      BIGINT NOT NULL REFERENCES job(id) ON DELETE CASCADE,
  node_id     BIGINT NOT NULL REFERENCES taxonomy_node(id) ON DELETE CASCADE,
  is_primary  BOOLEAN NOT NULL DEFAULT true,
  PRIMARY KEY (job_id, node_id)
);
CREATE INDEX idx_jtm_node ON job_taxonomy_map(node_id);

-- =========================================================
-- 커버리지 검증 뷰 — 직무 8개 미만 중분류 탐지
-- =========================================================
CREATE VIEW v_taxonomy_coverage AS
SELECT n.scheme, n.code, n.label,
       COUNT(m.job_id) AS job_count,
       CASE WHEN COUNT(m.job_id) >= 8  THEN 'ok'
            WHEN COUNT(m.job_id) >= 4  THEN 'thin'
            ELSE 'blocked' END AS status
FROM taxonomy_node n
LEFT JOIN job_taxonomy_map m ON m.node_id = n.id
LEFT JOIN job j ON j.id = m.job_id AND j.is_active
WHERE n.level = 2
GROUP BY n.scheme, n.code, n.label
ORDER BY job_count ASC;
