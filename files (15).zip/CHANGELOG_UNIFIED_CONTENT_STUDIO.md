# 활동지 · 교안 통합 화면 — 변경 요약

## 무엇을 합쳤나
기존에 따로 있던 세 화면을 `/teacher/content-studio` 한 화면 + 탭 3개로 통합했습니다.

| 예전 | 이제 |
|---|---|
| AI 콘텐츠 제작소 (`/teacher/content-studio`) | "새로 만들기" 탭 |
| 콘텐츠 보관함 (`/teacher/content-studio/library`) | "보관함" 탭 (기본 탭) |
| (위저드 2단계에 묻혀있던) 원본 400개 라이브러리 검색 | "라이브러리 둘러보기" 탭 |

진입 시 기본으로 **보관함** 탭이 열려서, 선생님이 이미 만들어둔 교안·활동지를 먼저 보고 바로 다운로드해서 쓸 수 있습니다. 새로 만들고 싶으면 "새로 만들기" 탭에서, 원본 프로그램 자체를 먼저 훑어보고 싶으면 "라이브러리 둘러보기" 탭에서 시작하면 됩니다.

## 탭 간 연결
- **보관함 → 새로 만들기**: 저장된 항목의 "같은 훈련법으로 새로 만들기" 버튼을 누르면, 그 항목의 원본 훈련법(programId)이 자동으로 채워진 채 "새로 만들기" 탭으로 이동합니다.
- **라이브러리 둘러보기 → 새로 만들기**: 검색 결과에서 프로그램 카드를 클릭하면 바로 "새로 만들기" 탭으로 넘어가 그 프로그램으로 생성을 시작합니다.

## 새로 생긴 딥링크 파라미터 (관리자 페이지 연동용)
`/teacher/content-studio`가 아래 쿼리 파라미터를 읽습니다.

- `?tab=library|create|browse` — 열릴 탭 지정
- `?studentId=123` — "새로 만들기" 탭에서 해당 학생을 자동 선택
- `?programId=...&programName=...` — "새로 만들기" 탭에서 해당 훈련법을 자동 선택

예: 관리자 페이지 회원 목록의 메모박스 버튼에서 `/teacher/content-studio?tab=create&studentId=1234` 로 링크하면, 그 학생이 선택된 채로 바로 훈련법 선택 단계부터 시작됩니다.

## 파일 변경
새 파일:
- `features/content-studio/ContentStudioHub.tsx` — 탭 상태 + 딥링크 파라미터 처리, 탭 간 핸드오프
- `features/content-studio/tabs/LibraryTab.tsx` — 예전 `library/page.tsx`의 목록 로직 이전 + 재사용 버튼 추가
- `features/content-studio/tabs/BrowseTab.tsx` — `StepProgramSearch`를 감싸는 얇은 래퍼
- `features/content-studio/tabs/CreateTab.tsx` — 예전 `content-studio/page.tsx`의 위저드 로직 이전 + `initialProgramId`/`initialStudentId` prop 추가

수정된 파일:
- `app/teacher/content-studio/page.tsx` — `ContentStudioHub`를 렌더링하는 얇은 셸로 교체 (Suspense로 감쌈)
- `app/teacher/content-studio/library/page.tsx` — 목록 화면 대신 `/teacher/content-studio?tab=library`로 리다이렉트만 함 (기존 링크 호환)
- `features/teacher-dashboard/TeacherNav.tsx` — "AI 콘텐츠 제작소"/"콘텐츠 보관함" 두 메뉴를 "활동지 · 교안" 하나로 병합
- `app/teacher/page.tsx` — 대시보드 바로가기 카드도 하나로 병합
- `app/globals.css` — 탭 바 스타일(`kp-cs-tabs` 등) 추가, 기존 토큰/색상 변수 재사용

## 검증
- `npx tsc --noEmit` — 신규/수정 파일 타입 오류 없음 (기존 무관한 테스트 파일 오류 1건만 존재, 이번 변경 이전부터 있던 것)
- `npx next build` — 성공, `/teacher/content-studio`, `/teacher/content-studio/library`(리다이렉트) 정상 빌드

## 이번 작업에 포함되지 않은 것
- 스크린샷에 보이는 **관리자 페이지(회원 목록, 메모박스 UI)** 자체와 **kpass_teacher_bugfix_demo_v9.html**(GitHub Pages)은 이번에 업로드된 프로젝트(kpass-home-mvp)에 포함되어 있지 않아 수정하지 못했습니다. 그 화면들의 소스 파일을 주시면, 메모박스에 위에서 만든 딥링크(`/teacher/content-studio?tab=create&studentId=...`)를 연결하는 작업을 이어서 진행할 수 있습니다.
- `admin/content-engine`(교육법·활동지 유형 관리) 화면은 이번 통합 대상이 아니라 그대로 두었습니다 — 교사가 쓰는 콘텐츠가 아니라 운영자가 옵션을 관리하는 별도 화면이라 판단했습니다.
