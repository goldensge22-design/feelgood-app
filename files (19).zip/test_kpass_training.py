#!/usr/bin/env python3
"""
K-PASS 인지훈련 / 인지+정서훈련 화면 자동 UI 테스트
사용법: python3 test_kpass_training.py [파일경로]
"""
import sys, pathlib
from playwright.sync_api import sync_playwright

FILE = sys.argv[1] if len(sys.argv) > 1 else "kpass-training-fixed.html"
errs, res = [], []

def check(label, cond, detail=""):
    ok = bool(cond)
    res.append(ok)
    print(("PASS " if ok else "FAIL ") + label + (("  -- " + detail) if (detail and not ok) else ""))

def run():
    uri = pathlib.Path(FILE).resolve().as_uri() + "?demo=1"
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": 390, "height": 844})
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.goto(uri); pg.wait_for_timeout(400)

        check("페이지 로드 시 JS 에러 없음", not errs, "; ".join(errs))
        check("성장 나무 4개 렌더", pg.locator(".kp-tree").count() == 4)
        check("주간 계획 7일 전부 렌더", pg.locator(".kp-day").count() == 7)
        rest = pg.locator(".kp-day.is-rest").count()
        check("쉬는 날 1일, 나머지 6일은 영역 배정됨", rest == 1,
              f"rest={rest}")
        labels = pg.locator(".kp-day .lbl").all_inner_texts()
        check("'준비중' 같은 빈 라벨 없음", all(l.strip() and l.strip() != "준비중" for l in labels), str(labels))

        # 결과지 연동: 최약 영역이 우선 배정되었는지 (데모: 순차처리 SS 83)
        weak_days = [l for l in labels if l.strip() == "순차처리"]
        check("최약 영역(순차처리)이 3일 배정", len(weak_days) == 3, str(labels))

        # 오늘 카드
        check("오늘의 훈련 카드에 시작 버튼 존재", pg.locator('[data-start="cog"]').count() == 1)
        check("'왜 오늘 이 훈련인가' 근거 배지 노출", pg.locator(".kp-badge-why").count() >= 1)

        # 부모 코칭이 그날 영역 카드에서 나오는지 (필드 누락 표시가 없어야 함)
        check("부모 코칭 필드 누락 없음", pg.locator("#card-coaching-cog .kp-missing").count() == 0)

        # 상세 진입 → 1-2 검증
        pg.locator('[data-start="cog"]').click(); pg.wait_for_timeout(300)
        check("상세 진입 후 JS 에러 없음", not errs, "; ".join(errs))
        body = pg.locator("#activity-body")
        check("진행 절차 단계 렌더됨(설명만 있지 않음)", pg.locator("#activity-body .kp-steps li").count() >= 3)
        check("준비물 칩 렌더됨", pg.locator("#activity-body .kp-chip").count() >= 2)
        for label in ["훈련 목표", "예시", "난이도 조절", "관찰 포인트"]:
            check(f"상세에 '{label}' 항목 존재", label in body.inner_text())
        check("타이머 표시가 소요시간과 일치", pg.locator("#timer-val").inner_text() != "00:00")

        # 타이머
        pg.locator("#t-toggle").click(); pg.wait_for_timeout(1200)
        check("타이머 카운트다운 동작", pg.locator("#timer-val").inner_text() != "00:00")
        pg.locator("#t-reset").click()

        # 난이도 피드백
        pg.locator('[data-fb="HARD"]').click()
        check("난이도 피드백 선택 반영", pg.locator('[data-fb="HARD"]').get_attribute("aria-pressed") == "true")

        # 뒤로 = 종료가 아니라 직전 화면
        pg.locator("#btn-activity-back").click(); pg.wait_for_timeout(300)
        check("돌아가기 시 인지훈련 화면으로 복귀", pg.locator("#page-cog").is_visible())

        # 인지+정서
        pg.locator('[data-go="emo"]').click(); pg.wait_for_timeout(300)
        check("인지+정서 화면 진입", pg.locator("#page-emo").is_visible())
        check("인지+정서 오늘 카드 존재", pg.locator('[data-start="emo"]').count() == 1)
        check("정서 배정 기준 안내 노출", "정서" in pg.locator("#card-emo-basis").inner_text())
        pg.locator('[data-start="emo"]').click(); pg.wait_for_timeout(300)
        check("인지+정서 상세도 절차 렌더", pg.locator("#activity-body .kp-steps li").count() >= 3)
        pg.locator("#btn-activity-back").click(); pg.wait_for_timeout(250)

        # 주간 계획에서 특정 요일 미리보기
        pg.locator('[data-go="cog"]').click(); pg.wait_for_timeout(250)
        pg.locator('.kp-day:not(.is-rest)').first.click(); pg.wait_for_timeout(300)
        check("요일 탭에서 그날 훈련 미리보기 진입", pg.locator("#page-activity").is_visible())
        pg.locator("#btn-activity-back").click(); pg.wait_for_timeout(250)


        # 주간 계획 탭 (빈 화면 회귀 방지)
        pg.locator('[data-go="week"]').click(); pg.wait_for_timeout(300)
        check("주간 계획 탭이 비어있지 않음", len(pg.locator("#week-body").inner_text().strip()) > 40)
        check("주간 계획에 7일 카드 렌더", pg.locator("#week-body .kp-card").count() >= 8)
        pg.locator('#week-body [data-day]').first.click(); pg.wait_for_timeout(300)
        check("주간 계획에서 미리보기 진입", pg.locator("#page-activity").is_visible())
        pg.locator("#btn-activity-back").click(); pg.wait_for_timeout(250)

        # 더 하고 싶어요 (복습)
        pg.locator('[data-go="cog"]').click(); pg.wait_for_timeout(250)
        pg.locator("#btn-more").click(); pg.wait_for_timeout(300)
        check("더 하고 싶어요 → 복습 활동 진입", pg.locator("#page-activity").is_visible())
        check("복습 진입 후 JS 에러 없음", not errs, "; ".join(errs))
        pg.locator("#btn-activity-back").click(); pg.wait_for_timeout(250)

        # 다국어 + RTL
        for code, probe in [("th", "ltr"), ("ru", "ltr"), ("ar", "rtl"), ("ko", "ltr")]:
            pg.locator(f'[data-lang="{code}"]').click(); pg.wait_for_timeout(250)
            d = pg.evaluate("document.documentElement.dir")
            check(f"{code} 전환 시 dir={probe}", d == probe, f"got {d}")
        check("언어 전환 후 JS 에러 없음", not errs, "; ".join(errs))

        # 회귀: 화면에 중복된 시작 버튼 없어야 함
        check("현재 화면에 시작 버튼 중복 없음", pg.locator('.kp-page.is-active [data-start]').count() <= 1)


        # --- 회귀: 9/2 감사에서 발견된 6건 ---
        pg.goto(uri); pg.wait_for_timeout(400)
        pg.locator('[data-start="cog"]').click(); pg.wait_for_timeout(200)
        pg.locator("#t-toggle").click(); pg.wait_for_timeout(400)
        pg.locator('[data-go="emo"]').click(); pg.wait_for_timeout(1500)
        check("화면 이탈 시 타이머 정지", pg.evaluate("S.timer.run") is False)
        pg.locator('[data-go="cog"]').click(); pg.wait_for_timeout(150)
        pg.locator('[data-start="cog"]').click(); pg.wait_for_timeout(200)
        pg.locator("#t-toggle").click(); pg.wait_for_timeout(300)
        pg.locator('[data-lang="en"]').click(); pg.wait_for_timeout(200)
        pg.locator("#t-toggle").click(); pg.wait_for_timeout(3000)
        mm, ss_ = pg.locator("#timer-val").inner_text().split(":")
        elapsed = 20*60 - (int(mm)*60 + int(ss_))
        check("언어 전환 후 타이머 중복 가속 없음", 2 <= elapsed <= 5, f"3초에 {elapsed}초 감소")
        pg.locator('[data-lang="ko"]').click(); pg.wait_for_timeout(200)

        pg.goto(uri); pg.wait_for_timeout(400)
        pg.evaluate("S.library.forEach(r=>{r.i18n={en:{titleKo:'ENGLISH TITLE'}}}); renderCog();")
        pg.locator('[data-lang="en"]').click(); pg.wait_for_timeout(300)
        check("라이브러리 다국어 필드 반영", "ENGLISH TITLE" in pg.locator("#cog-today").inner_text())
        pg.locator('[data-lang="ko"]').click(); pg.wait_for_timeout(200)

        pg.goto(uri); pg.wait_for_timeout(400)
        pg.evaluate("S.plan.days[todayIndex()]={domain:null,type:'rest'}; renderCog();")
        pg.wait_for_timeout(200)
        check("쉬는 날 빈 코칭 카드 미노출", pg.locator("#card-coaching-cog").bounding_box() is None)
        pg.locator("#btn-more").click(); pg.wait_for_timeout(300)
        check("쉬는 날에도 복습 진입 가능", pg.locator("#page-activity").is_visible())

        pg.goto(uri); pg.wait_for_timeout(400)
        pg.locator('[data-go="emo"]').click(); pg.wait_for_timeout(150)
        pg.locator('[data-go="week"]').click(); pg.wait_for_timeout(150)
        pg.locator("#btn-back").click(); pg.wait_for_timeout(200)
        check("뒤로 1회 → 직전 화면", pg.evaluate("S.page") == "emo")
        check("뒤로 이후에도 이력 유지", pg.evaluate("S.history") == ["cog"])

        pg.goto(uri); pg.wait_for_timeout(400)
        pg.evaluate("S.profile.scores={}; renderBanners();")
        pg.wait_for_timeout(150)
        check("표준점수 누락 시 경고 배너", "표준점수" in pg.locator("#global-banners").inner_text())

        pg.goto(uri); pg.wait_for_timeout(400)
        pg.evaluate("S.library.forEach(r=>{r.titleKo='<img src=x onerror=window.__x=1>';}); renderCog();")
        pg.wait_for_timeout(300)
        check("라이브러리 내용 HTML 이스케이프", not pg.evaluate("!!window.__x"))
        pg.goto(uri); pg.wait_for_timeout(400)

        b.close()
    print("\n%d/%d passed" % (sum(res), len(res)))
    return 0 if all(res) else 1

if __name__ == "__main__":
    sys.exit(run())
