# 인지훈련 / 인지+정서훈련 수정 적용 안내 (2026-09-02)

대상 파일: `kpass-training-fixed.html`
교체 대상: 기존 인지훈련 플래너 화면 (`kpass-home-demo-v2.html` 계열)

> 설계를 변경하지 말고 구현만 진행합니다. 새로운 구조를 만들지 말고 기존 설계를 유지해 주세요.
> 기능 누락, API 오류, DB 오류, 화면 연결 오류만 수정 대상입니다.

---

## 1. 이번 수정으로 해결한 것

| 항목 | 증상 | 수정 |
|---|---|---|
| 9/02 1-1 | 첫 화면 훈련 내용이 학생과 무관하게 고정 | 화면의 모든 훈련 콘텐츠를 결과지 프로파일 + 라이브러리 API 응답에서만 생성. HTML/JS 안에 훈련 내용이 존재하지 않음 |
| 9/02 1-2 | 훈련 진입 후 설명 한 줄만 나옴 | 목표·준비물·진행절차·예시·난이도조절·관찰포인트·부모스크립트 전부 렌더링. 값이 없으면 빈칸이 아니라 어떤 필드가 비었는지 빨간 글씨로 표시 |
| 추가 | 이번 주 흐름이 오늘 외 전부 "준비중" | 7일 전체 배정 생성. 요일 탭 → 그날 훈련 미리보기 |
| 추가 | 연령대 "만 8~10세" 하드코딩 | 생년월일과 검사일에서 자동 산출 |
| 추가 | 성장 나무 레벨 출처 불명 | 표준점수 구간(하 ≤85 / 중 86~119 / 상 ≥120)으로 시딩 후 XP 누적 |
| 추가 | 부모 코칭 질문이 그날 영역과 불일치 | 그날 배정 영역의 라이브러리 레코드에서 가져옴 |
| 추가 | 난이도 표기 충돌 (Lv.2 / 4단계) | `레벨 N` 단일 표기로 통일 |
| 추가 | 완료 시 수행 기록 없음 | 타이머 실제 소요시간 + 난이도 피드백(쉬움/적당/어려움)을 로그 API로 전송 |
| 7/30-2, 8/2-1-3 | 돌아가기 누르면 종료됨 | 직전 화면 복귀 + 헤더/하단에 Home AI 홈 버튼 상시 노출 |
| 8/5 | 인지+정서훈련 동일 문제 | 동일 엔진 적용. 별도 화면으로 분리 |
| 7/06 | 언어 추가 | 태국어·러시아어·아랍어 추가, 아랍어 RTL 지원 |
| — | 주간 계획 탭 빈 화면 | 7일 카드 렌더 |
| — | "잘 모르겠어요 / 더 하고 싶어요" 무동작 | Home AI 상담 연결 / 한 단계 아래 복습 활동 연결 |

---

## 2. 개발자가 손댈 곳은 파일 상단 `CFG` 한 곳입니다

```js
var CFG = {
  api: { profile, library, progress, plan, log },  // 엔드포인트
  homeAiPath: '/students/{studentId}/home-ai',      // 복귀 경로
  fieldMap: { ... },                                // 라이브러리 키 이름 매핑
  ssBands: { lowMax: 85, midMax: 119 },
  weekPlan: { slots:6, weakest:3, second:2, strength:1, restDayIndex:6 },
  emotionBasis: 'PLANNING_LINKED'                   // ★ 확정 필요
};
```

`pass_training_library_400.json`의 실제 키 이름이 다르면 **`fieldMap`만 고치면 됩니다.**
후보 키를 배열로 여러 개 적어두면 순서대로 찾아 처음 발견된 값을 씁니다.

---

## 3. 필요한 API (5개)

### 3-1. `GET /api/students/{studentId}/profile`
```json
{
  "studentId": 1234,
  "name": "홍길동",
  "resultId": "KP-2026-000123",
  "profileCode": "P2-A2-M1-S1",
  "birthDate": "2017-04-10",
  "testedAt": "2026-08-20",
  "scores": {
    "PLANNING":     { "ss": 128 },
    "ATTENTION":    { "ss": 121 },
    "SIMULTANEOUS": { "ss": 104 },
    "SUCCESSIVE":   { "ss": 83  }
  },
  "emotion": null
}
```
`ss`는 **표준점수**입니다(백분위 아님). 화면의 상/중/하 판정과 시작 레벨이 여기서 나옵니다.

> **8/05 1-1 항목과 직결됩니다.** K-PASS/D-CAS 채점 완료 시점에 `pass_result` / `pass_profile`에
> 실제 점수를 insert 하는 경로가 아직 없으면 이 API가 학생별로 다른 값을 돌려줄 수 없습니다.
> 운영 DB에서 `pass_result.student_id` 매핑과 학생별 `resultId` 분기를 먼저 점검해 주세요.

### 3-2. `GET /api/training-library?ageBand=8-10&domains=PLANNING,ATTENTION,SIMULTANEOUS,SUCCESSIVE,EMOTIONAL`
`pass_training_library_400.json` 레코드 배열을 그대로 반환합니다.
배열 또는 `{ items: [...] }` / `{ programs: [...] }` 형태 모두 처리합니다.

화면이 사용하는 필드(= 없으면 화면에 빨간 글씨로 표시되는 필드):
`programId, passDomain, level, ageMin, ageMax, durationMin, titleKo, objective, materials[], steps[], example, difficultyAdjustment, observationPoints, parentQuestion, parentPraise, lifeMission, evidenceCode`

다국어는 레코드 안에 넣어 주세요:
```json
"i18n": { "en": { "titleKo": "...", "objective": "..." }, "th": {...}, "ru": {...}, "ar": {...} }
```
번역이 없으면 한국어로 폴백합니다. **UI 문구만 5개 언어이고 훈련 콘텐츠 번역은 라이브러리 몫입니다.**

### 3-3. `GET /api/students/{studentId}/progress`
```json
{
  "domains": {
    "PLANNING":   { "xp": 240, "level": 3, "streak": 4 },
    "SUCCESSIVE": { "xp": 60,  "level": 1, "streak": 0 }
  },
  "completedDayIndexes": [0, 1]
}
```
`user_domain_progress` 테이블(영역별 xp / level / streak)이 필요합니다. 없으면 결과지 시딩 레벨만 표시되고
새로고침 시 XP가 초기화됩니다 (현재 증상).

### 3-4. `GET /api/students/{studentId}/weekly-plan` (선택)
`{ "days": [ {"domain":"SUCCESSIVE","type":"weakness"}, ... 7개 ... ] }`
`WeeklyPlannerService` 응답을 그대로 넘기면 됩니다.
**응답이 없거나 7일이 아니면** 클라이언트가 같은 규칙으로 계산하고 화면에 안내 배너를 띄웁니다.

### 3-5. `POST /api/students/{studentId}/training-logs`
```json
{
  "studentId": 1234, "resultId": "KP-2026-000123",
  "programId": "PLN-810-L2-3", "domain": "SUCCESSIVE", "level": 1,
  "date": "2026-09-02", "durationSec": 1180,
  "difficultyFeedback": "HARD", "completed": true
}
```
`difficultyFeedback`(EASY / OK / HARD)은 **다음 회차 난이도 조정 입력값**입니다.
`LibraryRecommendationService`에서 이 값을 읽도록 연결해 주세요.

---

## 4. 실패 시 동작

프로파일이나 라이브러리를 못 받으면 **고정 콘텐츠로 대체하지 않고** 오류 배너와 HTTP 상태를 그대로 노출합니다.
9/02 1-1이 재발하면 화면에서 바로 원인이 보입니다.

`?demo=1`은 서버 없이 화면 구조만 확인하는 미리보기입니다. 훈련 내용은 전부 자리표시자이고
"실제 검사 결과가 아님" 배너가 항상 뜹니다. 운영 배포 시 `loadDemo()` 블록은 삭제해도 됩니다.

---

## 5. URL 파라미터

| 파라미터 | 용도 |
|---|---|
| `studentId` | 필수. 결과지에서 넘겨주세요 |
| `returnTo` | 돌아가기·Home AI 홈이 이동할 주소. 없으면 `CFG.homeAiPath` |
| `lang` | `ko` `en` `th` `ru` `ar` |
| `demo=1` | 미리보기 |

예: `/training?studentId=1234&returnTo=%2Fstudents%2F1234%2Fhome-ai&lang=ko`

---

## 6. Next.js(kpass-home-mvp) 이관 시

이 파일은 단일 HTML입니다. React 컴포넌트로 옮길 때 그대로 대응됩니다.

```
app/students/[studentId]/training/page.tsx        ← page-cog
app/students/[studentId]/training/emotional/...   ← page-emo
components/TrainingActivity.tsx                   ← renderActivity()
lib/weeklyPlan.ts                                 ← buildPlan()
lib/programSelect.ts                              ← selectProgram()
```

`selectProgram()`은 학생ID + 영역 + 날짜 해시로 결정적으로 고릅니다.
새로고침해도 같은 훈련이 나오고 학생마다 다릅니다. 서버로 옮겨도 같은 시드를 쓰면 결과가 동일합니다.

---

## 7. 테스트

`test_kpass_training.py` (Playwright, 45개 항목)

```bash
pip install playwright && playwright install chromium
python3 test_kpass_training.py kpass-training-fixed.html
```

"준비중 라벨 없음", "설명만 나오지 않음", "돌아가기 시 종료되지 않음" 같은 이번 수정 항목이
회귀 테스트로 들어가 있습니다. 코드 수정 후 이 스크립트를 먼저 돌려 주세요.

---

## 7-1. 배포 전 자체 감사에서 수정한 6건 (참고)

파일 인수인계 전 브라우저 실측으로 아래를 잡아 회귀 테스트에 넣어두었습니다.

1. 훈련 화면을 벗어나도 타이머 인터벌이 계속 돌던 문제
2. 언어 전환·재진입 시 인터벌이 중복 생성되어 타이머가 2배속으로 가던 문제
3. 라이브러리 레코드의 `i18n` 번역 필드가 한 번도 적용되지 않던 문제 (항상 한국어 폴백)
4. 쉬는 날에 빈 부모 코칭 카드가 남고 "더 하고 싶어요"가 동작하지 않던 문제
5. 뒤로가기 이력 스택이 손상되어 두 번째 뒤로가기부터 화면을 건너뛰던 문제
6. 표준점수가 없는 영역이 있어도 경고 없이 주간 배정이 생성되던 문제
   → 이제 경고 배너가 뜹니다. **3장의 profile API가 미완성이면 이 배너가 보입니다.**

라이브러리 내용은 전부 HTML 이스케이프 처리되어 있습니다 (스크립트 주입 테스트 통과).

---

## 8. 확정이 필요한 항목 (본사 결정 사항)

1. **정서 영역 배정 기준** — `CFG.emotionBasis`. 현재 계획력 연동(임시). 부모 성향 검사 결과를 쓸지 확정 필요.
   확정 전까지 인지+정서 화면에 임시 설정 안내가 표시됩니다.
2. **주간 슬롯 배분** — 현재 약점3 / 차약2 / 강점1 + 휴식1. 이 배분이면 4개 영역 중 한 영역은
   그 주에 배정되지 않습니다. 문수백 교수님 검토 필요.
3. **라이브러리 필드명** — `fieldMap` 후보 키가 실제 JSON과 맞는지 확인.
4. **정서 영역 enum/마이그레이션** — `pass_domain`에 `EMOTIONAL` 추가 여부 (7/02 EMO-810 설계 기준).
