/**
 * D-CAS 청소년 리포트 — 개인화 엔진 (한국어 temperament+strength만, 1차)
 *
 * ★★★ 스코프 안내 ★★★
 * - 한국어(ko) temperament·strength 섹션만 다룹니다.
 * - 영어(en) 미러링은 아직 안 했습니다 — 같은 패턴을 그대로 복제하면 되지만
 *   이번 패스에는 포함하지 않았습니다.
 * - dept·credit·jobs·maturity·learning·mission·selfcheck·parent·admissions·
 *   expert 등 나머지 12개 섹션은 미착수입니다.
 */
(function (global) {

  function byId(id) { return document.getElementById(id); }
  function setText(id, text) { const el = byId(id); if (el) el.textContent = text; }
  function setHTML(id, html) { const el = byId(id); if (el) el.innerHTML = html; }
  function hasBatchim(str) {
    const ch = str.charCodeAt(str.length - 1);
    if (ch < 0xAC00 || ch > 0xD7A3) return false;
    return (ch - 0xAC00) % 28 !== 0;
  }

  function applyIdentity(PROFILE) {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
    const toFix = [];
    let node;
    while ((node = walker.nextNode())) {
      if (/\{\{(GIVEN|FULLNAME_EN|GIVEN_EN)\}\}/.test(node.nodeValue)) toFix.push(node);
    }
    toFix.forEach(function (n) {
      n.nodeValue = n.nodeValue
        .replace(/\{\{GIVEN\}\}/g, PROFILE.fullName) // 청소년 리포트는 항상 "풀네임 님" 표기(성인용과 다름)
        .replace(/\{\{FULLNAME_EN\}\}/g, PROFILE.fullNameEn || PROFILE.fullName)
        .replace(/\{\{GIVEN_EN\}\}/g, PROFILE.fullNameEn || PROFILE.fullName);
    });
    if (/\{\{(GIVEN|FULLNAME_EN|GIVEN_EN)\}\}/.test(document.title)) {
      document.title = document.title
        .replace(/\{\{GIVEN\}\}/g, PROFILE.fullName)
        .replace(/\{\{FULLNAME_EN\}\}/g, PROFILE.fullNameEn || PROFILE.fullName)
        .replace(/\{\{GIVEN_EN\}\}/g, PROFILE.fullNameEn || PROFILE.fullName);
    }
    // t-meta — 언어별로 형식이 다름
    const genderLabel = PROFILE.genderKey === 'F' ? '여' : '남';
    const dateStr = PROFILE.testDate.y + '.' + String(PROFILE.testDate.m).padStart(2, '0') + '.' + String(PROFILE.testDate.d).padStart(2, '0');
    if (typeof currentLang !== 'undefined' && currentLang === 'ko') {
      setText('t-meta', genderLabel + ' · 만 ' + PROFILE.ageYears + '세 (' + PROFILE.gradeLabel + ') · 청소년 진로적성 트랙 · ' + dateStr);
    } else if (typeof currentLang !== 'undefined' && currentLang === 'en') {
      const genderEn = PROFILE.genderKey === 'F' ? 'Female' : 'Male';
      const dateEn = String(PROFILE.testDate.m).padStart(2,'0') + '/' + String(PROFILE.testDate.d).padStart(2,'0') + '/' + PROFILE.testDate.y;
      setText('t-meta', genderEn + ' · Age ' + PROFILE.ageYears + ' (' + (PROFILE.gradeLabelEn || PROFILE.gradeLabel) + ') · Teen Career-Aptitude Track · ' + dateEn);
    }
  }

  function applyScores(PROFILE) {
    const s = PROFILE.scores;
    const isEn = (typeof currentLang !== 'undefined' && currentLang === 'en');
    const sfx = isEn ? '-en' : '';
    const AXIS_LABEL = isEn
      ? { P: 'Planning', A: 'Attention', S: 'Simultaneous', Q: 'Successive' }
      : { P: '계획력', A: '주의력', S: '동시처리', Q: '순차처리' };
    ['P', 'A', 'S', 'Q'].forEach(function (k) {
      const el = byId('pf-radar-' + k + sfx);
      if (el) el.textContent = AXIS_LABEL[k] + ' ' + s[k] + '%';
      const bar = byId('pf-bar-' + k + sfx);
      if (bar) bar.style.width = s[k] + '%';
      setText('pf-barval-' + k + sfx, s[k] + '%');
    });
    const poly = byId('pf-radarpoly' + sfx);
    if (poly) {
      const RADAR_ANGLES = { P: 0, S: 90, Q: 180, A: 270 };
      const pts = ['P', 'S', 'Q', 'A'].map(function (k) {
        const norm = Math.max(0, Math.min(1, (s[k]) / 100));
        const r = 20 + norm * 75;
        const rad = (RADAR_ANGLES[k] * Math.PI) / 180;
        const x = 150 + r * Math.sin(rad), y = 150 - r * Math.cos(rad);
        return x.toFixed(1) + ',' + y.toFixed(1);
      }).join(' ');
      poly.setAttribute('points', pts);
    }
  }

  function applyCombo(PROFILE) {
    const isEn = (typeof currentLang !== 'undefined' && currentLang === 'en');
    const bank = isEn ? global.DCasTeenComboBankEn : global.DCasTeenComboBank;
    if (typeof bank === 'undefined') return;
    const g = bank.getCombo(PROFILE.scores);
    const combo = g.combo;
    const nameForVars = isEn ? (PROFILE.fullNameEn || PROFILE.fullName) : PROFILE.fullName;
    const vars = { weak: g.weakAxisLabel, name: nameForVars };
    const sfx = isEn ? '-en' : '';
    setText('pf-herotag' + sfx, (isEn ? 'Cognitive Compass · ' : '인지 나침반 · ') + combo.code);
    setText('pf-herotype' + sfx, combo.heroType);
    setText('pf-oneliner' + sfx, bank.fill(combo.oneliner, vars));
    setHTML('pf-chips' + sfx, combo.chips.map(function (c) { return '<span class="chip">' + c + '</span>'; }).join(''));
    const figureCard = byId('pf-figurecard' + sfx);
    if (figureCard && combo.figure) {
      const josaKo = hasBatchim(combo.figure.name) ? '은' : '는';
      const heading = isEn ? '🌟 A Kindred Spirit' : '🌟 이런 인물과 닮은 점이 있어요';
      const body = isEn
        ? combo.figure.name + ' ' + bank.fill(combo.figure.why, { name: nameForVars })
        : combo.figure.name + josaKo + ' ' + bank.fill(combo.figure.why, { name: nameForVars });
      figureCard.innerHTML = '<h4>' + heading + '</h4><p>' + body + '</p>';
    }
    // 강점 키워드 매핑표 — 4축 전체를 강점축 우선 정렬로 재구성
    const s = PROFILE.scores;
    const ranked = [{k:'P',v:s.P},{k:'A',v:s.A},{k:'S',v:s.S},{k:'Q',v:s.Q}].sort(function(a,b){return b.v-a.v;});
    const AXIS_LABEL = bank.AXIS_LABEL;
    const strengthTable = byId('pf-strengthtable' + sfx);
    if (strengthTable) {
      const KW_STRONG = isEn
        ? { P:'Strategic execution · Initiative', A:'Sustained focus', S:'Integrative thinking · Systems view', Q:'Procedural rigor · Attention to detail' }
        : { P:'전략적 실행력·주도성', A:'몰입 지속력', S:'통합적 사고·시스템 이해', Q:'절차적 정교함·꼼꼼함' };
      const growLabel = isEn ? ' (growing)' : ' (보완중)';
      strengthTable.innerHTML = ranked.map(function (r, i) {
        const suffix = (i === ranked.length - 1) ? growLabel : '';
        const kw = (i <= 1) ? KW_STRONG[r.k] : bank.WEAK_KW[r.k];
        return '<tr><td>' + AXIS_LABEL[r.k] + ' ' + r.v + '%' + suffix + '</td><td>' + kw + '</td><td>-</td></tr>';
      }).join('');
    }
  }

  function levelLabel(v) {
    if (v >= 70) return '상';
    if (v >= 50) return '중';
    return '하';
  }

  function applyEfficiency(PROFILE) {
    const isEn = (typeof currentLang !== 'undefined' && currentLang === 'en');
    const bank = isEn ? global.DCasTeenPatternBankEn : global.DCasTeenPatternBank;
    if (typeof bank === 'undefined') return;
    const s = PROFILE.scores;
    const patterns = bank.pickFourPatterns(s);
    const sfx = isEn ? '-en' : '';
    const container = byId('pf-eff-cards' + sfx);
    if (container) {
      const hintLabel = isEn ? 'Sound familiar?' : '이런 경험 있나요?';
      const whyLabel = isEn ? 'Why it happens' : '왜 그럴까';
      container.innerHTML = patterns.map(function (p) {
        return '<div class="diag-card"><h4>' + p.title + '</h4>' +
          '<p class="sym"><b>' + hintLabel + '</b> ' + p.sym + '</p>' +
          '<p class="rx"><b>' + whyLabel + '</b> ' + p.rx + '</p></div>';
      }).join('');
    }
  }

  function applyOpinionAndEmotional(PROFILE) {
    if (typeof DCasTeenComboBank === 'undefined') return;
    const isEn = (typeof currentLang !== 'undefined' && currentLang === 'en');
    const bank = isEn ? global.DCasTeenComboBankEn : DCasTeenComboBank;
    if (typeof bank === 'undefined') return;
    const s = PROFILE.scores;
    const ranked = [{k:'P',v:s.P},{k:'A',v:s.A},{k:'S',v:s.S},{k:'Q',v:s.Q}].sort(function(a,b){return b.v-a.v;});
    const top2 = ranked.slice(0,2), weak = ranked[3];
    const AXIS_LABEL = bank.AXIS_LABEL;
    const sfx = isEn ? '-en' : '';
    const nameForText = isEn ? (PROFILE.fullNameEn || PROFILE.fullName) : PROFILE.fullName;

    // 04 검사자총평
    const opinionCard = isEn ? byId('pf-opinion-en') : document.querySelector('#opinion .card p');
    if (opinionCard) {
      if (isEn) {
        opinionCard.textContent = nameForText + ' shows high accuracy in ' + AXIS_LABEL[top2[0].k].toLowerCase() + ' processing and ' + AXIS_LABEL[top2[1].k].toLowerCase() + ', indicating strong ability to judge situations holistically and translate that into execution strategy. ' + AXIS_LABEL[weak.k] + ' is comparatively lower, so patience may be needed for repetitive, procedure-heavy tasks. This is an area that can keep improving with training up to around age 25, so step-by-step checklists paired with short, repeated procedural practice are recommended. Overall, this is a cognitive profile with a clear strength combination — well suited to self-directed, project-based learning and career environments.';
      } else {
        const top2Str = AXIS_LABEL[top2[0].k] + (hasBatchim(AXIS_LABEL[top2[0].k]) ? '과' : '와') + ' ' + AXIS_LABEL[top2[1].k];
        const weakLabel = AXIS_LABEL[weak.k];
        opinionCard.textContent = nameForText + ' 님은 ' + top2Str + '의 정답률이 높게 나타나, 상황을 종합적으로 판단하고 이를 실행 전략으로 옮기는 능력이 뛰어난 학습자입니다. 다만 ' + weakLabel + (hasBatchim(weakLabel) ? '이' : '가') + ' 상대적으로 낮아, 반복·절차 중심 과제에서 인내가 필요할 수 있습니다. 이는 훈련을 통해 25세까지도 꾸준히 개선될 수 있는 영역이므로, 단계형 체크리스트와 짧고 반복적인 절차 훈련을 병행할 것을 권장합니다. 전반적으로 강점 조합이 뚜렷한 인지 프로파일로, 자기주도적 프로젝트형 학습·진로 환경에서 강점이 극대화될 유형입니다.';
      }
    }

    // 05 정서적 지지
    if (isEn) {
      setHTML('pf-emo-title-en', 'Everyone has strengths.<br>' + nameForText + ' already has clear, proven ones.');
      const statChips = document.querySelectorAll('#pf-emo-stats-en .stat-chip');
      if (statChips[0]) { statChips[0].querySelector('b').textContent = s[top2[0].k] + '%'; statChips[0].querySelector('span').textContent = AXIS_LABEL[top2[0].k] + ' accuracy'; }
      if (statChips[1]) { statChips[1].querySelector('b').textContent = s[top2[1].k] + '%'; statChips[1].querySelector('span').textContent = AXIS_LABEL[top2[1].k] + ' accuracy'; }
    } else {
      setHTML('pf-emo-title', '누구에게나 강점은 있어요.<br>' + nameForText + ' 님에게는 이미 확실한 강점이 있어요.');
      const statChips = document.querySelectorAll('#emotional .stat-chip');
      if (statChips[0]) { statChips[0].querySelector('b').textContent = s[top2[0].k] + '%'; statChips[0].querySelector('span').textContent = AXIS_LABEL[top2[0].k] + ' 정답률'; }
      if (statChips[1]) { statChips[1].querySelector('b').textContent = s[top2[1].k] + '%'; statChips[1].querySelector('span').textContent = AXIS_LABEL[top2[1].k] + ' 정답률'; }
      setText('pf-emo-mission1-hint', (function(){ const t=top2.map(function(r){return AXIS_LABEL[r.k];}).join('·'); return t+(hasBatchim(t)?'을':'를')+' 발휘했던 순간'; })());
      setText('pf-emo-mission2-hint', top2.map(function(r){return AXIS_LABEL[r.k];}).join('·'));
    }
  }

  function applyMatrixDeptCreditJobs(PROFILE) {
    if (typeof DCasTeenDeptEngine === 'undefined' || typeof window.DCAS_MAJOR_REQUIREMENTS === 'undefined') return;
    const engine = DCasTeenDeptEngine;
    const reqs = window.DCAS_MAJOR_REQUIREMENTS;
    const s = PROFILE.scores;
    const isEn = (typeof currentLang !== 'undefined' && currentLang === 'en');
    const sfx = isEn ? '-en' : '';
    const AXIS_LABEL = isEn ? { P:'Planning', A:'Attention', S:'Simultaneous', Q:'Successive' } : { P: '계획력', A: '주의력', S: '동시처리', Q: '순차처리' };
    const nameForText = isEn ? (PROFILE.fullNameEn || PROFILE.fullName) : PROFILE.fullName;

    // 06 계열매트릭스
    const catRanked = engine.rankCategories(s, reqs);
    const matrixTable = byId('pf-matrix-table' + sfx);
    if (matrixTable) {
      matrixTable.innerHTML = catRanked.map(function (c, i) {
        const isTop = i < 2;
        const reasonBank = isEn ? engine.CATEGORY_REASON_EN : engine.CATEGORY_REASON;
        const reason = isTop ? reasonBank[c.category].high : reasonBank[c.category].low;
        const label = isEn ? engine.CATEGORY_LABEL_EN[c.category] : c.category;
        return '<tr><td>' + label + '</td><td><div class="fit-bar-row"><div class="fit-bar-track"><div class="fit-bar-fill' + (isTop ? ' top' : '') + '" style="width:' + c.fit + '%"></div></div><span class="pct' + (isTop ? ' top' : '') + '">' + c.fit + '%</span></div></td><td>' + reason + '</td></tr>';
      }).join('');
    }
    const ranked = [{k:'P',v:s.P},{k:'A',v:s.A},{k:'S',v:s.S},{k:'Q',v:s.Q}].sort(function(a,b){return b.v-a.v;});
    const top2Label = AXIS_LABEL[ranked[0].k] + '×' + AXIS_LABEL[ranked[1].k];
    if (isEn) {
      setText('pf-matrix-combotag-en', '🔗 This result reflects the [' + top2Label + '] strength combination from the Efficiency Diagnosis (section 03)');
      setHTML('pf-matrix-explain-en', 'Each field\'s weighting of the 4 cognitive domains is multiplied by ' + nameForText + '\'s accuracy rates and normalized. For example, ' + engine.CATEGORY_LABEL_EN[catRanked[0].category] + ' weights ' + top2Label + ' heavily, aligning well with ' + nameForText + '\'s strengths.');
    } else {
      setText('pf-matrix-combotag', '🔗 이 결과는 03번 학습효율진단의 [' + top2Label + '] 강점 조합이 그대로 반영됐어요');
      setHTML('pf-matrix-explain', '각 계열이 실제 학업·직무에서 요구하는 4개 인지영역의 가중치와, ' + nameForText + ' 님의 정답률을 곱해 정규화한 값이에요. 예를 들어 ' + catRanked[0].category + ' 계열은 ' + top2Label + ' 비중이 높아 ' + nameForText + ' 님의 강점과 잘 맞물려요.');
    }

    // 07 추천학과 TOP5
    const topMajors = engine.rankMajors(s, reqs, 5);
    const deptContainer = byId('pf-dept-cards' + sfx);
    if (deptContainer) {
      deptContainer.innerHTML = topMajors.map(function (m, i) {
        const majorTop2 = Object.keys(m.reqVec).map(function(k){return {k:k,v:m.reqVec[k]};}).sort(function(a,b){return b.v-a.v;}).slice(0,2).map(function(x){return AXIS_LABEL[x.k];}).join(isEn?' & ':'·');
        const rankLabel = isEn ? 'RANK ' + (i+1) + ' · Fit ' + m.fit + '%' : 'RANK ' + (i+1) + ' · 적합도 ' + m.fit + '%';
        const desc = isEn
          ? 'This major emphasizes ' + majorTop2 + ', which overlaps significantly with ' + nameForText + '\'s cognitive profile.'
          : majorTop2 + '을 요구하는 이 학과는, ' + nameForText + ' 님의 인지 프로파일과 겹치는 부분이 커요.';
        return '<div class="dept-card"><div class="rank">' + rankLabel + '</div><h4>' + m.name + '</h4><p>' + desc + '</p></div>';
      }).join('');
    }

    // 08 선택과목 가이드
    const topCat = catRanked[0].category;
    const guideBank = isEn ? engine.SUBJECT_GUIDE_EN : engine.SUBJECT_GUIDE;
    const guide = guideBank[topCat] || guideBank['공학'];
    const creditTable = byId('pf-credit-table' + sfx);
    if (creditTable) {
      creditTable.innerHTML = guide.map(function (g) {
        return '<tr><td>' + g.area + '</td><td>' + g.subjects + '</td><td>' + g.reason + '</td></tr>';
      }).join('');
    }

    // 09 직업미리보기
    const jobBank = isEn ? engine.JOB_PREVIEW_EN : engine.JOB_PREVIEW;
    const jobGroups = jobBank[topCat] || jobBank['공학'];
    const jobContainer = byId('pf-jobpreview-cards' + sfx);
    if (jobContainer) {
      jobContainer.innerHTML = jobGroups.map(function (g) {
        return '<div class="card"><h4 style="margin:0 0 6px;font-size:13.5px;color:var(--navy);">' + g.group + '</h4>' +
          '<div class="job-strip">' + g.pills.map(function (p) { return '<span class="job-pill">' + p + '</span>'; }).join('') + '</div></div>';
      }).join('');
    }
  }

  function applyParentAndExpert(PROFILE) {
    const s = PROFILE.scores;
    const isEn = (typeof currentLang !== 'undefined' && currentLang === 'en');
    const sfx = isEn ? '-en' : '';
    const ranked = [{k:'P',v:s.P},{k:'A',v:s.A},{k:'S',v:s.S},{k:'Q',v:s.Q}].sort(function(a,b){return b.v-a.v;});
    const weak = ranked[3];
    const AXIS_LABEL = isEn ? { P:'Planning', A:'Attention', S:'Simultaneous', Q:'Successive' } : { P: '계획력', A: '주의력', S: '동시처리', Q: '순차처리' };
    const weakLabel = AXIS_LABEL[weak.k];
    const nameForText = isEn ? (PROFILE.fullNameEn || PROFILE.fullName) : PROFILE.fullName;

    // 11 부모님과 함께
    if (isEn) {
      const AXIS_SUFFIX_EN = { P:'', A:'', S:' processing', Q:' processing' };
      const strongStr = (AXIS_LABEL[ranked[0].k]+AXIS_SUFFIX_EN[ranked[0].k]) + ' and ' + (AXIS_LABEL[ranked[1].k]+AXIS_SUFFIX_EN[ranked[1].k]);
      const weakStrFull = weakLabel + AXIS_SUFFIX_EN[weak.k];
      setText('pf-parent-summary-en', nameForText + ' has a notably strong ability in ' + strongStr.toLowerCase() + '. Where a bit more conscious training helps is ' + weakStrFull.toLowerCase() + '. This isn\'t a deficiency — it\'s simply where things stand right now, and it\'s an area that can keep improving steadily with training into the mid-20s. The more often you help ' + nameForText + ' put moments of using a strength into words, the easier it becomes to work on the growth areas too.');
    } else {
      const top2Str = AXIS_LABEL[ranked[0].k] + (hasBatchim(AXIS_LABEL[ranked[0].k]) ? '과' : '와') + ' ' + AXIS_LABEL[ranked[1].k];
      setText('pf-parent-summary', nameForText + ' 님은 ' + top2Str + '을 발휘하는 힘이 뚜렷하게 강해요. 다만 ' + weakLabel + (hasBatchim(weakLabel)?'이':'가') + ' 상대적으로 낮아, 관련 활동에서는 조금 더 의식적인 훈련이 도움이 됩니다. 이는 부족함이 아니라 지금 시점의 특성이며, 훈련을 통해 20대 중반까지도 꾸준히 개선될 수 있는 영역이에요. 아이가 스스로 강점을 발휘한 경험을 자주 언어화해줄수록, 약점 보완도 훨씬 수월해집니다.');
    }

    // 13 전문가 데이터
    const dominant = s.S >= s.Q ? 'S' : 'Q';
    const diff = Math.abs(s.S - s.Q);
    if (isEn) {
      const dominantLabel = dominant === 'S' ? 'right-brain dominant (simultaneous-processing dominant)' : 'left-brain dominant (successive-processing dominant)';
      const dominantDesc = dominant === 'S' ? 'Integrating information as a whole shows relatively higher accuracy than processing it step by step.' : 'Processing information step by step shows relatively higher accuracy than integrating it all at once.';
      setHTML('pf-expert-braintype-en', nameForText + '\'s brain type is <b>' + dominantLabel + '</b>. The accuracy gap between successive and simultaneous processing is ' + (diff>=20?'large':'moderate') + ', indicating a ' + (dominant==='S'?'simultaneous':'successive') + '-processing-dominant learner.');
      const table = byId('pf-expert-table-en');
      if (table) {
        const order = ['P','A','S','Q'];
        table.querySelectorAll('tr').forEach(function (row, i) {
          const k = order[i]; if (!k) return;
          const tds = row.querySelectorAll('td');
          if (tds[3]) tds[3].textContent = s[k] + '%';
          const judge = row.querySelector('.judge');
          if (judge) {
            const level = s[k] >= 70 ? 'high' : (s[k] >= 45 ? 'mid' : 'low');
            judge.className = 'judge ' + level;
            judge.textContent = level === 'high' ? 'Relatively high' : (level === 'mid' ? 'Average range' : 'Relatively low');
          }
        });
      }
      const dsCompare = byId('pf-expert-dscompare-en');
      if (dsCompare) {
        const circles = dsCompare.querySelectorAll('.ds-circle b');
        const mid = dsCompare.querySelector('.ds-mid b');
        if (circles[0]) circles[0].textContent = s.Q + '%';
        if (circles[1]) circles[1].textContent = s.S + '%';
        if (mid) mid.textContent = diff + 'pp';
      }
      setHTML('pf-expert-dstext-en', 'The accuracy gap between successive and simultaneous processing is ' + diff + ' percentage points, indicating a <b>' + (dominant==='S'?'simultaneous':'successive') + '-processing-dominant learner</b>. ' + dominantDesc);
    } else {
      const dominantLabel = dominant === 'S' ? '우뇌우세형(동시처리 우세)' : '좌뇌우세형(순차처리 우세)';
      const dominantDesc = dominant === 'S' ? '정보를 순서대로 처리하기보다 전체를 통합적으로 파악하는 방식' : '전체를 한번에 보기보다 순서대로 차근차근 처리하는 방식';
      setHTML('pf-expert-braintype', nameForText + ' 님의 두뇌유형은 <b>' + dominantLabel + '</b>입니다. 순차처리와 동시처리의 정답률 차이가 ' + (diff >= 20 ? '크게' : '다소') + ' 나타나, ' + (dominant==='S'?'동시':'순차') + '처리 우세형 학습자로 판단됩니다.');
      const table = byId('pf-expert-table');
      if (table) {
        const order = ['P','A','S','Q'];
        table.querySelectorAll('tr').forEach(function (row, i) {
          const k = order[i]; if (!k) return;
          const tds = row.querySelectorAll('td');
          if (tds[3]) tds[3].textContent = s[k] + '%';
          const judge = row.querySelector('.judge');
          if (judge) {
            const level = s[k] >= 70 ? 'high' : (s[k] >= 45 ? 'mid' : 'low');
            judge.className = 'judge ' + level;
            judge.textContent = level === 'high' ? '상대적 높음' : (level === 'mid' ? '평균적 수준' : '상대적 낮음');
          }
        });
      }
      const dsCompare = byId('pf-expert-dscompare');
      if (dsCompare) {
        const circles = dsCompare.querySelectorAll('.ds-circle b');
        const mid = dsCompare.querySelector('.ds-mid b');
        if (circles[0]) circles[0].textContent = s.Q + '%';
        if (circles[1]) circles[1].textContent = s.S + '%';
        if (mid) mid.textContent = diff + '%p';
      }
      setHTML('pf-expert-dstext', '순차처리와 동시처리의 정답률 차이가 ' + diff + '%p로 ' + (diff>=20?'크게':'다소') + ' 나타나, <b>' + (dominant==='S'?'동시':'순차') + '처리 우세형 학습자</b>로 판단됩니다. ' + dominantDesc + '에서 상대적으로 더 높은 정확도를 보였어요.');
    }
  }

  function applyMissionSelfcheck(PROFILE) {
    const isEn = (typeof currentLang !== 'undefined' && currentLang === 'en');
    const bank = isEn ? global.DCasTeenMissionBankEn : global.DCasTeenMissionBank;
    if (typeof bank === 'undefined') return;
    const s = PROFILE.scores;
    const d = bank.pickAxisData(s);
    const sfx = isEn ? '-en' : '';

    // 09 미션보드
    if (isEn) {
      const strongLabel = d.strong2Keys.map(function (k) { return bank.AXIS_LABEL[k]; }).join(' and ');
      const weakLabel = bank.AXIS_LABEL[d.weakKey];
      setText('pf-mission-intro-en', 'Using ' + strongLabel.toLowerCase() + ' strengths as leverage to progressively train ' + weakLabel.toLowerCase() + '.');
    } else {
      const strongLabel = d.strong2Keys.map(function (k) { return bank.AXIS_LABEL[k]; }).join('·');
      const weakLabel = bank.AXIS_LABEL[d.weakKey];
      setText('pf-mission-intro', strongLabel + ' 강점을 지렛대 삼아, ' + weakLabel + '을(를) 단계적으로 훈련하는 미션이에요.');
    }
    const missions = bank.buildMissions(s);
    const diffLabel = isEn ? { low:'Easy', mid:'Medium', high:'Hard' } : { low: '난이도 하', mid: '난이도 중', high: '난이도 상' };
    const missionEl = byId('pf-mission-cards' + sfx);
    if (missionEl) {
      missionEl.innerHTML = missions.map(function (m) {
        return '<div class="mission-card"><span class="diff ' + m.diff + '">' + diffLabel[m.diff] + '</span><h4>' + m.title + '</h4><p>' + m.desc + '</p><span class="xp">+' + m.xp + ' XP</span> <span class="link-skill">· ' + m.skill + '</span></div>';
      }).join('');
    }

    // 10 성장포인트 체크리스트
    const items = bank.buildSelfcheckItems(s);
    const checkEl = byId('pf-selfcheck-items' + sfx);
    if (checkEl) {
      checkEl.innerHTML = items.map(function (it, i) {
        return '<div class="check-item"><input type="checkbox" id="sc' + sfx + i + '"' + (i===0?' checked':'') + '><label for="sc' + sfx + i + '">' + it.text + '<span class="scale">' + it.scale + '</span></label></div>';
      }).join('');
    }
  }

  function applyAdmissions(PROFILE) {
    if (typeof DCasTeenAdmissionsBank === 'undefined') return;
    const bank = DCasTeenAdmissionsBank;
    const s = PROFILE.scores;
    const isEn = (typeof currentLang !== 'undefined' && currentLang === 'en');
    const sfx = isEn ? '-en' : '';
    const ranked = [{k:'P',v:s.P},{k:'A',v:s.A},{k:'S',v:s.S},{k:'Q',v:s.Q}].sort(function(a,b){return b.v-a.v;});
    const strong2Keys = [ranked[0].k, ranked[1].k];
    const weakKey = ranked[3].k;
    const AXIS_LABEL = isEn ? { P:'Planning', A:'Attention', S:'Simultaneous', Q:'Successive' } : bank.AXIS_LABEL;

    const tracksRanked = bank.rankTracks(s, isEn ? bank.TRACK_EN : undefined);
    if (isEn) {
      setText('pf-adm-combotag-en', '🔗 Efficiency Diagnosis [' + AXIS_LABEL[strong2Keys[0]] + ' × ' + AXIS_LABEL[strong2Keys[1]] + '] pattern — this strength matters most for ' + tracksRanked[0].track.name);
    } else {
      setText('pf-adm-combotag', '🔗 학습효율진단 [' + AXIS_LABEL[strong2Keys[0]] + '×' + AXIS_LABEL[strong2Keys[1]] + '] 조합 — ' + tracksRanked[0].track.name + ' 선택 시 이 강점이 특히 중요해요');
    }
    const tracksEl = byId('pf-adm-tracks' + sfx);
    if (tracksEl) {
      tracksEl.innerHTML = tracksRanked.map(function (t, i) {
        const rankLabel = isEn
          ? (i === 0 ? '#1' : (i === 1 ? '#2' : (i === tracksRanked.length - 1 ? 'Note' : '#'+(i+1))))
          : (i === 0 ? '1위' : (i === 1 ? '2위' : (i === tracksRanked.length - 1 ? '참고' : (i+1)+'위')));
        return '<div class="track-card"' + (i>0?' style="margin-top:8px;"':'') + '><div class="pctbox">' + rankLabel + '</div><div class="txt"><h4>' + t.track.name + '</h4><p>' + t.track.whyFit + ' (' + t.track.note + ')</p></div></div>';
      }).join('');
    }

    const guide = isEn ? bank.buildInterviewGuideEn(s, strong2Keys, weakKey) : bank.buildInterviewGuide(s, strong2Keys, weakKey);
    const interviewEl = byId('pf-adm-interview' + sfx);
    if (interviewEl) {
      interviewEl.innerHTML = guide.map(function (g) {
        return '<div class="interview-card"><div class="q2">' + g.q + '</div><p class="a2">' + g.a + '</p></div>';
      }).join('');
    }
  }

  function applyFaq(PROFILE) {
    const s = PROFILE.scores;
    const isEn = (typeof currentLang !== 'undefined' && currentLang === 'en');
    const ranked = [{k:'P',v:s.P},{k:'A',v:s.A},{k:'S',v:s.S},{k:'Q',v:s.Q}].sort(function(a,b){return a.v-b.v;});
    const weakKey = ranked[0].k;
    if (isEn) {
      const AXIS_LABEL_EN = { P:'Planning', A:'Attention', S:'Simultaneous', Q:'Successive' };
      const AXIS_SUFFIX_EN = { P:'', A:'', S:' processing', Q:' processing' };
      const weakLabel = AXIS_LABEL_EN[weakKey] + AXIS_SUFFIX_EN[weakKey];
      setText('pf-faq-q1-en', 'I\'m worried ' + weakLabel.toLowerCase() + ' came out low. Will it stay that way?');
      setText('pf-faq-a1-en', 'No. ' + weakLabel + ' can keep improving with training well into the early 20s. Working through the mission board\'s related missions little by little can meaningfully improve it.');
    } else {
      const AXIS_LABEL = { P: '계획력', A: '주의력', S: '동시처리', Q: '순차처리' };
      const weakLabel = AXIS_LABEL[weakKey];
      setText('pf-faq-q1', weakLabel + (hasBatchim(weakLabel)?'이':'가') + ' 낮게 나온 게 걱정돼요. 계속 낮은 채로 남을까요?');
      setText('pf-faq-a1', '아니에요. ' + weakLabel + '는 훈련을 통해 20대 초반까지도 꾸준히 개선될 수 있는 영역이에요. 미션보드의 관련 미션을 조금씩 쌓아가면 충분히 좋아질 수 있어요.');
    }
  }

  const BRAINSCI = {
    P: { region: '전두엽(prefrontal cortex)', desc: '목표 설정·자기조절·시간관리를 담당하며, 실제로 계획을 세우고 실행해보는 경험을 반복할수록 더 단단해져요.' },
    A: { region: '전두엽·망상활성계(reticular activating system)', desc: '필요한 자극에 선택적으로 집중하고 방해 자극을 억제하는 기능을 담당하며, 짧은 몰입을 반복할수록 지속 시간이 늘어나요.' },
    S: { region: '후두-두정엽(occipito-parietal) 연합영역', desc: '흩어진 정보를 하나의 전체 형태로 통합하는 기능을 담당하며, 마인드맵처럼 전체 구조를 그려보는 활동으로 강화돼요.' },
    Q: { region: '측두엽 언어영역과 연결된 작업기억(working memory)', desc: '언어·청각 정보를 순서대로 기억하는 기능과 관련이 깊은데, 이 기능은 학습·훈련을 통해 20대 중반까지도 꾸준히 발달하는 것으로 알려져 있어요.' },
  };

  function applyLearning(PROFILE) {
    const s = PROFILE.scores;
    const ranked = [{k:'P',v:s.P},{k:'A',v:s.A},{k:'S',v:s.S},{k:'Q',v:s.Q}].sort(function(a,b){return b.v-a.v;});
    const strong2 = [ranked[0].k, ranked[1].k], weak2 = [ranked[2].k, ranked[3].k];
    const AXIS_LABEL = { P: '계획력', A: '주의력', S: '동시처리', Q: '순차처리' };
    const strongStr = strong2.map(function(k){return AXIS_LABEL[k];}).join('·');
    const weakStr = weak2.map(function(k){return AXIS_LABEL[k];}).join('·');
    setText('pf-learning-intro', strongStr + ' 강점을 살리고, ' + weakStr + (hasBatchim(weakStr)?'은':'는') + ' 짧고 구조화된 루틴으로 보완해요.');

    const topAxis = ranked[0].k, weakAxis = ranked[3].k;
    const topB = BRAINSCI[topAxis], weakB = BRAINSCI[weakAxis];
    setHTML('pf-learning-brainsci', AXIS_LABEL[topAxis] + (hasBatchim(AXIS_LABEL[topAxis])?'은':'는') + ' ' + topB.region + '과 밀접히 연관돼요. 이 영역은 ' + topB.desc + ' ' +
      AXIS_LABEL[weakAxis] + (hasBatchim(AXIS_LABEL[weakAxis])?'은':'는') + ' ' + weakB.region + '과 관련이 깊은데, ' + weakB.desc + ' 즉 지금의 낮은 ' + AXIS_LABEL[weakAxis] + ' 점수는 고정된 한계가 아니라, 짧고 반복적인 훈련으로 충분히 개선 가능한 영역이라는 뜻이에요.');
  }

  function render(PROFILE) {
    applyIdentity(PROFILE);
    applyScores(PROFILE);
    applyCombo(PROFILE);
    applyEfficiency(PROFILE);
    applyOpinionAndEmotional(PROFILE);
    applyMatrixDeptCreditJobs(PROFILE);
    applyParentAndExpert(PROFILE);
    applyMissionSelfcheck(PROFILE);
    applyAdmissions(PROFILE);
    applyFaq(PROFILE);
    applyLearning(PROFILE);
  }

  global.DCasTeenEngine = { render: render };

})(typeof window !== 'undefined' ? window : globalThis);
