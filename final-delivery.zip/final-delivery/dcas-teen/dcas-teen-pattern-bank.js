/**
 * D-CAS 청소년 리포트 — 축 2개 조합별 "학습 정체 패턴" 콘텐츠 뱅크
 * 03번(효율진단) 섹션 전용. 6개 축 조합(P-A, P-S, P-Q, A-S, A-Q, S-Q) 전부 준비.
 * ★ 1차 초안 — 문수백 교수님 감수 권장.
 */
(function (global) {
  const AXIS_LABEL = { P: '계획력', A: '주의력', S: '동시처리', Q: '순차처리' };

  const PATTERN = {
    PQ: {
      title: '설계는 완벽한데, 마감 직전 디테일이 무너지는 패턴',
      sym: '프로젝트 기획서는 훌륭한데 막상 제출물은 순서가 꼬여있거나, 수학 문제를 풀 전략은 잘 세우는데 계산 마지막 단계에서 실수가 잦다.',
      rx: '계획력이 전체 전략을 짜는 반면, 순차처리는 그 전략을 순서대로 실행·검증하는 역할이에요. 설계와 실행 검증 사이에 격차가 있으면, 좋은 계획이 완성도 낮은 결과물로 이어져요. → 절차 체크카드(학습방안 섹션)로 "설계"와 "실행"을 분리해 각각 점검하세요.',
    },
    AS: {
      title: '"알면서 틀리는" 실수가 반복되는 패턴',
      sym: '지문을 읽고 전체 맥락은 바로 파악하는데, 정작 시험에서는 세부 조건(단위, 부호, 예외 조항)을 놓쳐 틀린다.',
      rx: '동시처리는 전체를 빠르게 통합하지만, 그 과정에서 세부 정보 하나하나를 오래 붙잡고 확인하는 주의력이 상대적으로 낮으면 "큰 그림은 맞는데 디테일에서 새는" 현상이 생겨요. → 문제를 다 풀고 "이 문제가 요구하는 조건 3가지"를 손가락으로 짚어 다시 확인하는 습관을 들이세요.',
    },
    SQ: {
      title: '개념은 이해하는데 규칙 적용에서 막히는 패턴',
      sym: '문법의 "전체 원리"는 금방 이해하는데 막상 활용 순서(시제 일치, 어순)에서 틀리거나, 연산 개념은 아는데 순서를 지켜야 하는 복합계산에서 꼬인다.',
      rx: '동시처리(개념 통합)와 순차처리(규칙의 순서 적용)는 서로 다른 인지 경로예요. 개념 이해가 곧 규칙 적용 능력을 보장하지 않아요. → "개념 이해 후 바로 문제풀이"가 아니라, 개념 이해 → 순서형 규칙만 따로 뽑아 반복 훈련 → 문제풀이, 3단계로 나누세요.',
    },
    AQ: {
      title: '반복 절차 과제에서 가장 크게 흔들리는 조합',
      sym: '단순 반복 연산이나 암기형 과제를 오래 붙들지 못하고, 중간에 순서를 잊어버리거나 흥미를 잃는다.',
      rx: '두 축 모두 상대적으로 낮은 구간이면, 순서를 유지하면서 오래 집중하는 과제에서 이중으로 부담이 걸려요. → 미션보드의 순차훈련 미션을 "짧고 자주"(10분 이내) 방식으로 접근하고, 절대 한 번에 길게 몰아서 하지 마세요.',
    },
    PA: {
      title: '목표는 세우는데, 그 상태를 오래 못 지키는 패턴',
      sym: '계획을 세울 땐 의욕이 넘치는데, 며칠 지나면 그 계획을 지키는 것 자체가 흐지부지된다.',
      rx: '계획력(설계)과 주의력(지속) 사이에 격차가 있으면, 계획은 좋은데 실행이 오래 못 가는 현상이 생겨요. → 하루 목표를 "25분 단위"로 잘게 쪼개서, 계획을 지키는 감각 자체를 자주 연습하세요.',
    },
    PS: {
      title: '큰 그림은 잘 그리는데, 세부 계획에서 막히는 패턴',
      sym: '전체 방향이나 아이디어는 빠르게 떠오르는데, 그걸 구체적인 실행 단계로 쪼개려면 막막해진다.',
      rx: '동시처리(전체 통합)가 계획력(순서화)보다 앞서면, 좋은 아이디어가 구체적 계획으로 잘 안 옮겨져요. → 아이디어가 떠오르면 바로 "첫 번째로 할 일 1개"만 정해서 시작하는 연습을 하세요.',
    },
  };

  function pairKey(k1, k2) {
    const ORDER = { P: 0, A: 1, S: 2, Q: 3 };
    return [k1, k2].sort(function (a, b) { return ORDER[a] - ORDER[b]; }).join('');
  }

  // 4개 패턴 선택 규칙: (1위×2위) + (약점축 × 나머지 3개 축 각각)
  function pickFourPatterns(scores) {
    const ranked = [
      { k: 'P', v: scores.P }, { k: 'A', v: scores.A },
      { k: 'S', v: scores.S }, { k: 'Q', v: scores.Q },
    ].sort(function (a, b) { return b.v - a.v; });
    const weakKey = ranked[3].k;
    const others = ranked.slice(0, 3).map(function (r) { return r.k; });
    const pairs = [pairKey(ranked[0].k, ranked[1].k)];
    others.forEach(function (k) {
      if (k !== ranked[0].k || k === weakKey) return; // 최상위축은 이미 1번에 포함되므로 중복 방지용 가드(사실상 미사용)
    });
    // 약점축 vs 나머지 3개 축
    others.forEach(function (k) {
      const pk = pairKey(weakKey, k);
      if (pairs.indexOf(pk) === -1) pairs.push(pk);
    });
    return pairs.slice(0, 4).map(function (pk) { return PATTERN[pk]; }).filter(Boolean);
  }

  global.DCasTeenPatternBank = { PATTERN: PATTERN, pairKey: pairKey, pickFourPatterns: pickFourPatterns, AXIS_LABEL: AXIS_LABEL };
})(typeof window !== 'undefined' ? window : globalThis);
