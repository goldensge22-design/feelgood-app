/**
 * D-CAS Teen report — 7-combo content bank (English)
 * Mirrors dcas-teen-combo-bank.js exactly in structure. Same axis logic
 * (pickComboKey, BALANCE_THRESHOLD) — only the copy differs.
 * ★ First draft — needs review before production use.
 */
(function (global) {
  const AXIS_LABEL = { P: 'Planning', A: 'Attention', S: 'Simultaneous', Q: 'Successive' };
  const BALANCE_THRESHOLD = 20;

  function pickComboKey(scores) {
    const ranked = [
      { k: 'P', v: scores.P }, { k: 'A', v: scores.A },
      { k: 'S', v: scores.S }, { k: 'Q', v: scores.Q },
    ].sort(function (a, b) { return b.v - a.v; });
    if (ranked[0].v - ranked[3].v < BALANCE_THRESHOLD) return 'BAL';
    const ORDER = { P: 0, A: 1, S: 2, Q: 3 };
    const top2 = [ranked[0].k, ranked[1].k].sort(function (a, b) { return ORDER[a] - ORDER[b]; });
    return top2.join('');
  }

  const COMBO = {
    PQ: {
      code: 'Left-Brain 2-P', heroType: 'The Logical Architect',
      oneliner: 'Successive processing and planning are both strong, giving you the ability to follow a study plan step by step with precision. {weak} is comparatively lower, so activities that require synthesizing many ideas at once take a bit more conscious effort.',
      chips: ['#SuccessiveStrength', '#StrongPlanning', '#ProceduralPrecision', '#SynthesisNeedsWork'],
      figure: { name: 'Linus Torvalds', why: 'is known for managing an enormously complex system through thousands of precise rules and procedures. Like {name}, the ability to "finish with precision by following the sequence" is a core talent for completing large projects.' },
      strengthKw: { P: 'Strategic execution · Initiative', Q: 'Procedural rigor · Attention to detail' },
    },
    PA: {
      code: 'COGNITIVE ID · P-A', heroType: 'The Goal-Focused Learner',
      oneliner: 'Planning and attention are both strong, giving you the ability to set a goal and stay immersed without wavering until it\'s done. {weak} is comparatively lower, so situations that require synthesizing scattered information at once may take a bit more time.',
      chips: ['#StrongPlanning', '#SustainedFocus', '#GoalOriented', '#SynthesisNeedsWork'],
      figure: { name: 'Marie Curie', why: 'is known for repeating the same experimental method for years without losing sight of the goal. Like {name}, the ability to "set a plan and stay immersed until the end" is a core talent for completing long-term projects.' },
      strengthKw: { P: 'Strategic execution · Initiative', A: 'Sustained focus' },
    },
    PS: {
      code: 'Right-Brain 3-C', heroType: 'The Immersive Idea Architect',
      oneliner: 'Simultaneous processing and planning are both strong, giving a fast ability to grasp the whole picture and turn it into an action plan. {weak} is comparatively lower, so following detailed step-by-step procedures takes a bit more conscious effort.',
      chips: ['#IntuitiveJudgment', '#StrongPlanning', '#CreativeProblemSolving', '#ProcessNeedsWork'],
      figure: { name: 'Thomas Edison', why: 'revised his plans through thousands of failures, staying immersed until he finished the job. Like {name}, the ability to "picture the whole first, then plan and execute" is a core talent for turning ideas into real results in any field.' },
      strengthKw: { P: 'Strategic execution · Initiative', S: 'Integrative thinking · Systems view' },
    },
    AS: {
      code: 'COGNITIVE ID · A-S', heroType: 'The Immersive Explorer',
      oneliner: 'Attention and simultaneous processing are both strong, giving you the ability to quickly read a situation while also diving deep into subjects that interest you. {weak} is comparatively lower, so activities requiring a fixed step-by-step order take a bit more attention.',
      chips: ['#SustainedFocus', '#IntuitiveThinking', '#QuickSituationalRead', '#ProcessNeedsWork'],
      figure: { name: 'Jean-Henri Fabre', why: 'observed a single insect for years while also documenting its entire surrounding environment. Like {name}, the ability to "dive deep without losing sight of the whole" is a core talent for exploration and research.' },
      strengthKw: { A: 'Sustained focus', S: 'Integrative thinking · Systems view' },
    },
    AQ: {
      code: 'COGNITIVE ID · A-Q', heroType: 'The Precision Learner',
      oneliner: 'Attention and successive processing are both strong, giving you the ability to follow a fixed procedure precisely and repeat it without tiring. {weak} is comparatively lower, so activities requiring you to synthesize many ideas at once may take extra time.',
      chips: ['#SustainedFocus', '#ProceduralPrecision', '#ConsistentRepetition', '#SynthesisNeedsWork'],
      figure: { name: 'Han Seok-bong', why: 'is famous for repeating the fixed stroke order of calligraphy countless times without ever breaking it, reaching mastery. Like {name}, the ability to "repeat precisely over a long time" is a core talent for subjects that demand precision.' },
      strengthKw: { A: 'Sustained focus', Q: 'Procedural rigor · Attention to detail' },
    },
    SQ: {
      code: 'COGNITIVE ID · S-Q', heroType: 'The Structured Storyteller',
      oneliner: 'Simultaneous and successive processing are both strong, giving you the ability to picture the whole and then unfold it in a logical sequence. {weak} is comparatively lower, so conscious management helps with the stamina to push a goal through to the end.',
      chips: ['#IntuitiveThinking', '#StructuredComposition', '#LogicalFlow', '#StaminaNeedsWork'],
      figure: { name: 'Walt Disney', why: 'pinned storyboard panels on a wall to see the whole picture, then rearranged the sequence until the story worked. Like {name}, the ability to "lay everything out and then arrange the order" is a core talent for communicating complex ideas persuasively.' },
      strengthKw: { S: 'Integrative thinking · Systems view', Q: 'Procedural rigor · Attention to detail' },
    },
    BAL: {
      code: 'COGNITIVE ID · BAL', heroType: 'The Balanced All-Rounder',
      oneliner: 'All four cognitive abilities are evenly developed, giving you the flexibility to respond to any situation without being locked into one way of doing things.',
      chips: ['#EvenAbilities', '#Versatile', '#FlexibleThinking', '#SituationalAdaptability'],
      figure: { name: 'Leonardo da Vinci', why: 'is known for doing art, anatomical observation, and mechanical design all at once. The ability to not be confined to just one thing is a core talent for students who move across multiple fields.' },
      strengthKw: { P: 'Strategic execution', A: 'Sustained focus', S: 'Integrative thinking', Q: 'Procedural rigor' },
    },
  };

  const WEAK_KW = {
    P: 'Growing strategic planning', A: 'Growing sustained focus',
    S: 'Growing integrative thinking', Q: 'Growing procedural rigor',
  };

  function pickWeakAxis(scores) {
    return [{k:'P',v:scores.P},{k:'A',v:scores.A},{k:'S',v:scores.S},{k:'Q',v:scores.Q}]
      .sort(function(a,b){return a.v-b.v;})[0].k;
  }
  function fill(str, vars) {
    return Object.keys(vars).reduce(function (s, k) {
      return s.replace(new RegExp('\\{' + k + '\\}', 'g'), vars[k]);
    }, str);
  }
  function getCombo(scores) {
    const key = pickComboKey(scores);
    return { key: key, combo: COMBO[key], weakAxisKey: pickWeakAxis(scores), weakAxisLabel: AXIS_LABEL[pickWeakAxis(scores)] };
  }

  global.DCasTeenComboBankEn = { COMBO: COMBO, WEAK_KW: WEAK_KW, pickComboKey: pickComboKey, getCombo: getCombo, fill: fill, AXIS_LABEL: AXIS_LABEL };
})(typeof window !== 'undefined' ? window : globalThis);
