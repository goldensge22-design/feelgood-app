/**
 * K-PASS 결과지 — 통합 개인화 엔진
 *
 * 이 파일 하나가 다음 두 가지를 전부 담당합니다.
 *   (1) 점수 4개 → 숫자·그래프·표 전부 자동 계산 (콘텐츠 저작 아님, 순수 계산)
 *   (2) 점수 4개 → 상위 2축 조합(7가지) 기준 문장 선택 (모듈형 콘텐츠, 1차 초안)
 *
 * ★★★ 반드시 읽어주세요 ★★★
 * (2)는 81유형 전체를 새로 쓴 게 아니라 "상위 2축 조합 7가지"로 묶은 것입니다.
 * 같은 조합이면 같은 문장이 나갑니다 — 이전보다는 훨씬 나아지지만, 81명 전원에게
 * 완전히 다른 리포트를 주는 수준은 아직 아닙니다. 정식 서비스 적용 전 아래를 확인하세요.
 *   - 문장 내용의 정확성 (문수백 교수님 감수)
 *   - BALANCE_THRESHOLD, CRITICAL_VALUES 등 임계값 (기존 kpass-score-engine.js와 동일 경고)
 *   - 저학년(5~7세) 대상 어휘 난이도
 *
 * ===== 검수 프로그램과의 연결 =====
 * verify-personalization.js가 이 파일을 테스트하려면, 리포트가 아래 "PROFILE 계약"을
 * 지켜야 합니다.
 *
 *   const PROFILE = window.__TEST_PROFILE__ || DEFAULT_PROFILE;
 *
 * 즉 window.__TEST_PROFILE__ 이 있으면 그걸 쓰고, 없으면(=사람이 그냥 열어본 경우)
 * 기존 예시(송서우) 값을 씁니다. 검수 프로그램은 이 값을 바꿔가며 여러 번 로드해서
 * 결과가 실제로 달라지는지 확인합니다. 앞으로 D-CAS 등 다른 리포트를 동적화할 때도
 * 이 계약(window.__TEST_PROFILE__)을 동일하게 지켜주세요 — 그래야 검수 프로그램을
 * 그대로 재사용할 수 있습니다.
 */

(function (global) {

/* 한국어 조사 처리 — 받침 유무에 따라 은/는, 이/가 자동 선택 */
function hasBatchim(str){
  const ch = str.charCodeAt(str.length-1);
  if (ch < 0xAC00 || ch > 0xD7A3) return false; // 한글 아니면 무시(받침 없음 취급)
  return (ch - 0xAC00) % 28 !== 0;
}
function josa(word, pair){ // pair: '은는' | '이가' | '을를' | '와과'
  const map = { '은는':['은','는'], '이가':['이','가'], '을를':['을','를'], '와과':['와','과'] };
  const [withB, withoutB] = map[pair];
  return word + (hasBatchim(word) ? withB : withoutB);
}

/* =====================================================================
   1) 점수 → 숫자 계산 (kpass-score-engine.js와 동일 로직, 통합본이라 재수록)
   ===================================================================== */
function erf(x) {
  const a1=0.254829592,a2=-0.284496736,a3=1.421413741,a4=-1.453152027,a5=1.061405429,p=0.3275911;
  const sign = x<0?-1:1; x=Math.abs(x);
  const t=1/(1+p*x);
  const y=1-(((((a5*t+a4)*t)+a3)*t+a2)*t+a1)*t*Math.exp(-x*x);
  return sign*y;
}
function scoreToPercentileTop(score){ // "또래 상위 X%" 표기용 (100-백분위)
  const z=(score-100)/15;
  const pct = (0.5*(1+erf(z/Math.SQRT2)))*100;
  return Math.max(0.1, Math.round((100-pct)*10)/10);
}
function scoreToPercentileRank(score){ // "또래 상위 X%ile" 그 자체(순차처리 37%ile류)
  const z=(score-100)/15;
  return Math.round((0.5*(1+erf(z/Math.SQRT2)))*100);
}
function barWidthPct(score){ return Math.max(0,Math.min(100,(score-40)/160*100)); }
function classifyLevel(score){ if(score>=120) return 'H'; if(score<=85) return 'L'; return 'M'; }
function isNormativeStrong(score){ return score>115; }

/* 개인내적(자기 자신 대비) 강/약 — CRITICAL_VALUES는 송서우 예시값을 그대로 가져온
   임시값입니다. 문수백 교수 감수 전 배포 금지. */
const CRITICAL_VALUES = { P:9, A:9, S:7, Q:7 };
function personalDelta(scores){
  const mean = (scores.P+scores.A+scores.S+scores.Q)/4;
  const out = {};
  ['P','A','S','Q'].forEach(function(k){
    const diff = scores[k]-mean;
    out[k] = { diff: Math.round(diff), abs: Math.round(Math.abs(diff)),
               status: Math.abs(diff)<CRITICAL_VALUES[k] ? 'FLAT' : (diff>0?'PS':'PW') };
  });
  return { mean: Math.round(mean), byAxis: out };
}

/* ===== 인지 나침반 SVG 좌표 (viewBox 0 0 300 300, 중심 150,150) ===== */
function compassPoint(score, angleDeg){
  const norm = Math.max(0, Math.min(1, (score-55)/95));
  const r = 20 + norm*80;
  const rad = angleDeg*Math.PI/180;
  return { x: 150 + r*Math.sin(rad), y: 150 - r*Math.cos(rad) };
}
const COMPASS_ANGLES = { P:0, S:90, Q:180, A:270 }; // 상=계획 우=동시 하=순차 좌=주의 (원본 레이아웃 유지)
function compassPolygon(scores){
  return ['P','S','Q','A'].map(function(k){
    const p = compassPoint(scores[k], COMPASS_ANGLES[k]);
    return p.x.toFixed(1)+','+p.y.toFixed(1);
  }).join(' ');
}

/* =====================================================================
   2) 상위 2축 조합 판정 (kpass-figure-render.js와 동일 규칙 재사용)
   ===================================================================== */
const BALANCE_THRESHOLD = 15; // ★ 임시값. 실 데이터 분포로 재확인 필요.
function pickComboKey(scores){
  const ranked = [
    {k:'P',v:scores.P},{k:'A',v:scores.A},{k:'S',v:scores.S},{k:'Q',v:scores.Q}
  ].sort(function(a,b){ return b.v-a.v; });
  if (ranked[0].v - ranked[3].v < BALANCE_THRESHOLD) return 'BAL';
  const ORDER = {P:0,A:1,S:2,Q:3};
  const top2 = [ranked[0].k, ranked[1].k].sort(function(a,b){ return ORDER[a]-ORDER[b]; });
  return top2.join('');
}
const AXIS_LABEL = { P:'계획력', A:'주의력', S:'동시처리', Q:'순차처리' };

/* =====================================================================
   3) 조합별 콘텐츠 뱅크 — ★ 1차 초안. 문수백 교수 감수 전 배포 금지 ★
   =====================================================================
   각 조합은 두 강점 축을 중심으로 쓰여 있습니다. 낮은 축(들)에 대한 서술은
   조합과 무관하게 별도 함수(weakAxisBlock)에서 공통 처리합니다 — 특정
   조합에 "너는 이게 약해"라는 문장을 고정으로 붙이지 않기 위해서입니다.
*/
const COMBO_CONTENT = {
  PA: {
    heroType: '전략 실행가형',
    heroTags: ['#강한계획력', '#몰입주의력', '#끝까지완수'],
    oneliner: '목표를 스스로 세우고, 그 목표에서 눈을 떼지 않는 끈질긴 실행가예요.',
    homeai: '오늘도 세운 계획을 끝까지 밀어붙일 준비가 됐네요! 작은 목표 하나부터 시작해볼까요?',
    temperament: '계획을 세우는 힘과 한번 집중하면 끝까지 파고드는 힘이 함께 강해요. "생각만 하는 아이"가 아니라 "계획하고 끝까지 실행하는 아이"에 가깝습니다.',
    opinionLead: '{name} 님은 계획력과 주의력이 또래 대비 최상위권으로 나타나, 목표를 세우고 몰입해서 실행하는 능력이 매우 뛰어난 아동입니다.',
    figureAnchor: '이순신', // 역사적 인물 섹션과 통일 (kpass-historical-figures.json 참고)
    careerTags: ['프로젝트 매니저', '연구원', '스포츠 감독·코치', '변호사', '엔지니어'],
    careerDesc: '목표를 세우고 끝까지 몰입해서 완수하는 힘이 필요한 분야에서 특히 두각을 나타낼 수 있어요.'
  },
  PS: {
    heroType: '비전 설계가형',
    heroTags: ['#강한계획력', '#직관적사고', '#구조설계'],
    oneliner: '전체 그림을 한눈에 그리고, 그걸 실현할 순서를 세우는 균형 잡힌 설계자예요.',
    homeai: '머릿속에 그려둔 큰 그림이 있나요? 오늘은 그걸 작은 단계로 나눠볼까요?',
    temperament: '동시처리 능력이 또래보다 우수해, 부분보다 전체의 분위기와 의미를 먼저 파악하는 경향이 있어요. 여기에 계획력까지 강해, 떠오른 아이디어를 실행 단계로 옮기는 힘까지 갖추고 있습니다.',
    opinionLead: '{name} 님은 계획력과 동시처리 능력이 또래 대비 우수하게 나타나, 전체 상황을 파악하고 이를 구체적인 계획으로 옮기는 힘이 뛰어난 아동입니다.',
    figureAnchor: '장영실',
    careerTags: ['크리에이티브 디렉터', '공간·건축 디자이너', '콘텐츠 기획 PD', '스타트업 창업가', '제품 디자이너'],
    careerDesc: '직관적 창의성과 강한 계획력이 결합된 유형은, 창의적 기획을 실제 결과물로 완성해내는 분야에서 특히 두각을 나타낼 수 있어요.'
  },
  PQ: {
    heroType: '체계적 완성가형',
    heroTags: ['#강한계획력', '#꾸준한실행', '#차근차근'],
    oneliner: '큰 목표를 작은 단계로 쪼개고, 순서대로 끝까지 쌓아 올리는 뚝심 있는 완성가예요.',
    homeai: '오늘 할 일을 순서대로 하나씩 적어볼까요? {name}는 그 순서를 끝까지 지킬 수 있어요!',
    temperament: '전체 계획을 먼저 세우고, 정해진 순서를 흐트러뜨리지 않고 끝까지 밀고 나가는 힘이 강해요. 시작한 일을 중간에 놓지 않는 꾸준함이 돋보입니다.',
    opinionLead: '{name} 님은 계획력과 순차처리 능력이 또래 대비 우수하게 나타나, 목표를 세우고 순서에 따라 꾸준히 완성해내는 힘이 뛰어난 아동입니다.',
    figureAnchor: '정약용',
    careerTags: ['회계사·세무사', '연구원', '건축 시공관리', '데이터 분석가', '출판 편집자'],
    careerDesc: '정해진 절차를 정확히 지키면서 큰 목표를 향해 꾸준히 나아가는 분야에서 강점이 발휘돼요.'
  },
  AS: {
    heroType: '몰입 탐구가형',
    heroTags: ['#몰입주의력', '#직관적사고', '#세밀한관찰'],
    oneliner: '전체 분위기를 빠르게 읽으면서도, 관심 있는 대상은 깊이 파고드는 탐구가예요.',
    homeai: '오늘 유독 궁금한 게 있나요? {name}는 한번 빠지면 끝까지 파고드는 힘이 있어요!',
    temperament: '동시처리 능력이 또래보다 우수해 전체 상황을 빠르게 파악하고, 여기에 몰입력까지 더해져 관심 있는 것에는 깊이 파고드는 집중력을 보여요.',
    opinionLead: '{name} 님은 주의력과 동시처리 능력이 또래 대비 우수하게 나타나, 상황을 빠르게 파악하고 관심 분야에 깊이 몰입하는 힘이 뛰어난 아동입니다.',
    figureAnchor: '신사임당',
    careerTags: ['일러스트레이터·화가', '수의사', '요리사·파티시에', '큐레이터', '탐사보도 기자'],
    careerDesc: '전체를 보는 눈과 깊은 몰입이 함께 필요한, 관찰과 표현이 만나는 분야에서 강점이 발휘돼요.'
  },
  AQ: {
    heroType: '정밀 반복가형',
    heroTags: ['#몰입주의력', '#정확한순서', '#꾸준한반복'],
    oneliner: '정해진 순서를 정확하게 지키며, 지치지 않고 반복해내는 성실한 실행가예요.',
    homeai: '오늘의 순서표를 하나씩 지켜볼까요? {name}는 끝까지 집중해서 해낼 수 있어요!',
    temperament: '순서를 정확히 따르는 힘과, 지루할 수 있는 반복을 오래 견디는 몰입력이 함께 강해요. 정확성과 꾸준함이 필요한 활동에서 진가가 나옵니다.',
    opinionLead: '{name} 님은 주의력과 순차처리 능력이 또래 대비 우수하게 나타나, 정해진 절차를 정확하고 꾸준하게 수행하는 힘이 뛰어난 아동입니다.',
    figureAnchor: '한석봉',
    careerTags: ['약사', '항공기 정비사', '프로그래머', '의료기사', '공예가'],
    careerDesc: '정확한 순서와 오랜 집중이 함께 필요한, 정밀함이 요구되는 분야에서 강점이 발휘돼요.'
  },
  SQ: {
    heroType: '이야기 구성가형',
    heroTags: ['#직관적사고', '#체계적구성', '#균형잡힌사고'],
    oneliner: '전체 그림을 떠올리고, 그걸 앞뒤가 맞는 순서로 풀어내는 이야기꾼이에요.',
    homeai: '머릿속에 떠오른 이야기가 있나요? {name}는 그걸 순서대로 잘 풀어낼 수 있어요!',
    temperament: '동시처리와 순차처리가 함께 강해, 전체 그림을 한눈에 그리면서도 그걸 논리적인 순서로 풀어내는 균형이 돋보여요.',
    opinionLead: '{name} 님은 동시처리와 순차처리 능력이 또래 대비 우수하게 나타나, 전체를 조망하면서도 논리적으로 풀어내는 힘이 뛰어난 아동입니다.',
    figureAnchor: '방정환',
    careerTags: ['작가·시나리오 작가', '영상 편집자', '애니메이터', '다큐멘터리 PD', '게임 기획자'],
    careerDesc: '전체 구상과 순서 있는 전개가 함께 필요한, 이야기를 만들어내는 분야에서 강점이 발휘돼요.'
  },
  BAL: {
    heroType: '균형 잡힌 만능형',
    heroTags: ['#고른능력', '#다재다능', '#유연한사고'],
    oneliner: '어느 한쪽에 치우치지 않고, 상황에 맞게 여러 방식을 두루 쓸 수 있는 균형가예요.',
    homeai: '오늘은 뭘 해도 골고루 잘 해낼 수 있어요! {name}는 어떤 미션이든 도전해볼까요?',
    temperament: '네 가지 인지 능력이 고르게 발달해 있어, 어느 한 가지 방식에 갇히지 않고 상황에 맞는 방법을 유연하게 골라 쓸 수 있어요.',
    opinionLead: '{name} 님은 네 가지 인지 영역이 또래 대비 고르게 나타나, 다양한 상황에 유연하게 대응할 수 있는 아동입니다.',
    figureAnchor: '세종대왕',
    careerTags: ['제너럴리스트 매니저', '컨설턴트', '교사', '기획자', 'PD'],
    careerDesc: '한 가지 방식에 치우치지 않고 여러 역할을 두루 소화해야 하는 분야에서 강점이 발휘돼요.'
  }
};

/* 낮은 축(들) 공통 처리 — 조합과 무관, 어떤 축이든 같은 톤으로 서술 */
const WEAK_AXIS_BLOCK = {
  P: { name:'계획력', tip:'큰 일을 시작하기 전에 "어떤 순서로 할지" 한 줄로 먼저 적어보는 연습이 도움이 돼요.' },
  A: { name:'주의력', tip:'긴 활동은 짧게 끊어서, 중간에 작은 성취감을 자주 느끼게 해주는 방식이 잘 맞아요.' },
  S: { name:'동시처리', tip:'전체 그림을 먼저 보여주고 시작하면, 부분을 이해하는 데도 도움이 돼요.' },
  Q: { name:'순차처리', tip:'요리 레시피처럼 순서가 분명한 활동을 놀이처럼 반복해보면 좋아요.' }
};
function pickWeakAxis(scores){
  const ranked = [{k:'P',v:scores.P},{k:'A',v:scores.A},{k:'S',v:scores.S},{k:'Q',v:scores.Q}]
    .sort(function(a,b){ return a.v-b.v; });
  return ranked[0].k;
}

/* =====================================================================
   4) PROFILE → 화면에 필요한 모든 값 조립
   ===================================================================== */
function buildDerived(profile){
  const s = profile.scores; // {P,A,S,Q}
  const comboKey = pickComboKey(s);
  const combo = COMBO_CONTENT[comboKey];
  const weakKey = pickWeakAxis(s);
  const weak = WEAK_AXIS_BLOCK[weakKey];
  const pDelta = personalDelta(s);
  const ranked = [{k:'P',v:s.P},{k:'A',v:s.A},{k:'S',v:s.S},{k:'Q',v:s.Q}]
    .sort(function(a,b){ return b.v-a.v; });

  return {
    comboKey: comboKey,
    combo: combo,
    weakAxis: weak,
    weakAxisKey: weakKey,
    ranked: ranked,
    personal: pDelta,
    perAxis: ['P','A','S','Q'].reduce(function(acc,k){
      acc[k] = {
        score: s[k],
        level: classifyLevel(s[k]),
        topPct: scoreToPercentileTop(s[k]),
        rankPct: scoreToPercentileRank(s[k]),
        barWidth: barWidthPct(s[k]),
        normStrong: isNormativeStrong(s[k]),
        personalStatus: pDelta.byAxis[k].status,
        personalDiff: pDelta.byAxis[k].diff
      };
      return acc;
    }, {}),
    compassPolygon: compassPolygon(s),
    strongCount: ['P','A','S','Q'].filter(function(k){ return isNormativeStrong(s[k]); }).length
  };
}

/* =====================================================================
   5) DOM 적용 — id 기반. 실제 배포 파일의 id 네이밍에 맞춰 조정하세요.
   ===================================================================== */
function applyPersonalization(profile){
  const d = buildDerived(profile);
  const name = profile.name;
  function byId(id){ return (typeof document!=='undefined') ? document.getElementById(id) : null; }
  function setText(id, text){ const el=byId(id); if(el) el.textContent = text; }
  function setHTML(id, html){ const el=byId(id); if(el) el.innerHTML = html; }

  // --- 신원 ---
  if (typeof document!=='undefined') document.title = name+' 님의 K-PASS 결과지';
  setHTML('pf-childchip', '<b>'+name+'</b> <span>· '+profile.gender+' · '+profile.age+' · '+profile.testDate+'</span>');
  setText('pf-heroname', name+' · '+profile.gender+' · '+profile.age);
  setText('pf-summarydesc', name+'의 검사 결과를 한눈에 볼 수 있는 요약 화면입니다.');

  // --- 히어로 카드 ---
  setText('pf-herotype', d.combo.heroType);
  setText('pf-herooneliner', d.combo.oneliner);
  setHTML('heroTags', d.combo.heroTags.map(function(t){return '<span>'+t+'</span>';}).join(''));
  setHTML('coverTags', d.combo.heroTags.map(function(t){return '<span>'+t+'</span>';}).join(''));
  setText('coverTitle', name+' 프로파일');
  setText('coverMeta', profile.gender+' · '+profile.age+' · 검사일 '+profile.testDate);

  // --- 인지 나침반 ---
  const poly = byId('pf-compasspoly');
  if (poly) poly.setAttribute('points', d.compassPolygon);
  ['P','A','S','Q'].forEach(function(k){
    const a = d.perAxis[k];
    const sub = a.normStrong ? '또래 상위 '+a.topPct+'%' : '또래 평균 수준';
    setHTML('pf-legend-'+k, '<b>'+AXIS_LABEL[k]+' '+a.score+'</b>'+sub);
  });

  // --- homeAI 한마디 ---
  setText('pf-homeai', d.combo.homeai.replace(/\{name\}(는|은)/g, function(m,p1){ return josa(name,'은는'); }).replace(/\{name\}/g, name));

  // --- 기질특성 ---
  setText('pf-temperament', d.combo.temperament);

  // --- 역사적 인물 (kpass-figure-render.js + kpass-historical-figures.json 연동 지점) ---
  if (typeof global.renderFigureSection === 'function' && global.FIGURE_DATA) {
    setHTML('pf-figuresection', global.renderFigureSection(
      { P:s_(profile,'P'), A:s_(profile,'A'), S:s_(profile,'S'), Seq:s_(profile,'Q') },
      global.FIGURE_DATA
    ));
  }

  // --- 재능 매트릭스 (또래 대비) ---
  ['P','A','S','Q'].forEach(function(k){
    const a = d.perAxis[k];
    const fill = byId('pf-matrixfill-'+k);
    if (fill){ fill.style.width = a.barWidth+'%'; fill.querySelector('span') && (fill.querySelector('span').textContent = a.score); }
    setHTML('pf-matrixstatus-'+k,
      a.normStrong
        ? (a.personalStatus==='PS' ? '<b class="up">이중강점</b>상위 '+a.topPct+'%' : '<b class="up">규준강점</b>상위 '+a.topPct+'%')
        : '<b class="midc">평균권</b>상위 '+a.topPct+'%');
  });
  setText('pf-strongcount', d.strongCount+'/4');
  setHTML('pf-strongcountdesc', '4개 인지 영역 중 <b style="color:var(--ink);">'+d.strongCount+'개 영역('+Math.round(d.strongCount/4*100)+'%)</b>이 또래 대비 강점 구간이에요.');

  // --- 13번 전문가 페이지: 하위척도별 지수 ---
  // ★ 95%CI는 하위척도별 신뢰도 계수(SEM)가 있어야 정확히 계산됩니다.
  //   그 값이 없어 지금은 "확인필요"로 표시합니다 — 기술 매뉴얼 원본 수치로 교체 필요.
  const EVAL_TEXT = {
    H: ['매우 우수합니다.', '우수합니다.'],   // [강한 H(>=130), 일반 H]
    M: '평균적인 수준입니다.',
    L: '보완이 필요한 수준입니다.'
  };
  ['P','A','S','Q'].forEach(function(k){
    const a = d.perAxis[k];
    setText('pf-exp-num-'+k, String(a.score));
    setText('pf-exp-sub-'+k, '95%CI 확인필요 · 백분위 '+a.rankPct.toFixed(1));
    const marker = byId('pf-exp-marker-'+k);
    if (marker){ marker.style.left = a.barWidth+'%'; marker.textContent = String(a.score); }
    const catEl = byId('pf-exp-cat-'+k);
    if (catEl){
      catEl.className = 'cat ' + (a.level==='H'?'ns':a.level==='L'?'weak':'mid');
      catEl.textContent = a.level==='H'?'규준적 강':a.level==='L'?'규준적 약':'평균 수준';
    }
    let evalStr;
    if (a.level==='H') evalStr = '또래 대비 '+(a.score>=130?EVAL_TEXT.H[0]:EVAL_TEXT.H[1]);
    else if (a.level==='L') evalStr = '또래 대비 '+EVAL_TEXT.L;
    else evalStr = '또래와 비교해 '+EVAL_TEXT.M;
    setText('pf-exp-eval-'+k, evalStr);
  });

  // --- 규준적 강/약 표 ---
  const normRows = ['P','A','S','Q'].map(function(k){
    const a = d.perAxis[k];
    const diff = a.score-100;
    const badgeClass = a.level==='H'?'ns':a.level==='L'?'weak':'flat';
    const badgeText = a.level==='H'?'규준적 강 (NS)':a.level==='L'?'규준적 약 (NW)':'평균 범위';
    return '<tr><td style="font-weight:700;">'+AXIS_LABEL[k]+'</td><td style="font-family:var(--font-mono)">'+a.score+
      '</td><td style="color:var(--ink-faint)">평균 대비 '+(diff>=0?'+':'')+diff+
      '</td><td><span class="badge '+badgeClass+'">'+badgeText+'</span></td></tr>';
  }).join('');
  setHTML('pf-normtable', normRows);
  const strongAxes = d.ranked.filter(function(r){ return d.perAxis[r.k].level==='H'; }).map(function(r){ return AXIS_LABEL[r.k]; });
  const flatAxes = d.ranked.filter(function(r){ return d.perAxis[r.k].level==='M'; }).map(function(r){ return AXIS_LABEL[r.k]; });
  const weakAxes = d.ranked.filter(function(r){ return d.perAxis[r.k].level==='L'; }).map(function(r){ return AXIS_LABEL[r.k]; });
  let normSummary = '';
  if (strongAxes.length) normSummary += strongAxes.join('·')+' '+(strongAxes.length>1?'영역이':'영역이')+' 또래 아동 전체 집단 대비 상대적으로 높은 집단(규준적 강)에 속하는 것으로 나타났습니다. ';
  if (flatAxes.length) normSummary += flatAxes.join('·')+'는 또래와 비슷한 평균적 수준입니다. ';
  if (weakAxes.length) normSummary += weakAxes.join('·')+'는 또래 대비 상대적으로 낮은 집단(규준적 약)에 속합니다.';
  setText('pf-normsummary', normSummary.trim());

  // --- 개인내적 강약분석 ---
  setText('pf-personalmean', String(d.personal.mean));
  setText('pf-meanlegend', name+'의 4개 능력 평균('+d.personal.mean+'점)');
  setText('pf-internalintro-name1', name);
  setHTML('pf-internalintro', '막대가 길수록, '+name+' <b style="color:var(--ink)">자신의 다른 능력들과 비교했을 때</b> 더 두드러진 영역이에요. 점선은 "한 축만의 평균"이 아니라, <b style="color:var(--ink)">계획력·주의력·동시처리·순차처리 4개 점수를 합쳐 나눈 '+name+' 개인의 평균('+d.personal.mean+'점)</b>이며, 4개 막대 모두 이 하나의 기준선과 비교합니다.');
  const meanBarPos = barWidthPct(d.personal.mean); // 평균점을 막대 스케일(40~200) 위 위치로 환산
  ['P','A','S','Q'].forEach(function(k){
    const a = d.perAxis[k];
    setHTML('pf-internalfill-'+k, '<span class="fill-score" id="pf-internalscore-'+k+'">'+a.score+'</span>');
    byId('pf-internalfill-'+k).style.width = a.barWidth+'%';
    byId('pf-internalfill-'+k).style.background = a.personalStatus==='PS' ? 'var(--'+({P:'p',A:'a',S:'s',Q:'su'})[k]+'-color)' : (a.personalStatus==='PW' ? 'var(--accent)' : 'var(--ink-faint)');
    const meanLine = byId('pf-meanline-'+k);
    if (meanLine) meanLine.style.left = meanBarPos+'%';
    setText('pf-internalmeanval-'+k, String(d.personal.mean));
    const rankInGroup = d.ranked.findIndex(function(r){ return r.k===k; });
    const statusMap = { PS: rankInGroup===0 ? '▲ 가장 큰 강점' : '▲ 강점', PW:'▼ 보완 포인트', FLAT:'● 평균과 비슷' };
    const subText = a.personalDiff>=0 ? '평균보다 +'+a.personalDiff+'점 높아요' : (a.personalStatus==='FLAT' ? '평균보다 '+a.personalDiff+'점, 차이 적음' : '평균보다 '+a.personalDiff+'점 낮아요');
    setHTML('pf-internalstatus-'+k, '<span class="stat-lbl '+(a.personalStatus==='PS'?'up':a.personalStatus==='PW'?'down':'mid')+'">'+statusMap[a.personalStatus]+'</span><span class="stat-sub">'+subText+'</span>');
  });
  const topTwoNames = d.ranked.slice(0,2).map(function(r){ return AXIS_LABEL[r.k]; }).join('·');
  const flatOnes = d.ranked.filter(function(r){ return d.personal.byAxis[r.k].status==='FLAT'; }).map(function(r){ return AXIS_LABEL[r.k]; });
  const isFullyFlat = flatOnes.length===4;
  let internalSummaryText;
  if (isFullyFlat) {
    internalSummaryText = josa(name,'은는')+' 4개 인지 영역이 자기 자신 안에서도 서로 뚜렷한 차이 없이 고르게 나타나요. 특별히 두드러지는 축 없이 상황에 맞게 골고루 쓸 수 있는 프로파일이에요.';
  } else {
    const flatWord = flatOnes.join('·');
    internalSummaryText = '정리하면, '+josa(name,'은는')+' <b style="color:var(--ink)">'+topTwoNames+'</b>'+(hasBatchim(topTwoNames)?'이':'가')+' 자기 안에서 가장 두드러진 강점이고, <b style="color:var(--ink)">'+d.weakAxis.name+'</b>'+(hasBatchim(d.weakAxis.name)?'은':'는')+' 상대적으로 보완이 필요한 영역이에요.'+(flatOnes.length?' '+flatWord+(hasBatchim(flatWord)?'은':'는')+' 평균과 비슷한 수준으로, 특별히 강하지도 약하지도 않아요.':'');
  }
  setHTML('pf-internalsummary', internalSummaryText);

  // --- 검사자 총평 ---
  setText('pf-opinionlead', d.combo.opinionLead.replace(/\{name\}/g, name));
  setText('pf-opiniontail', '다만 '+josa(d.weakAxis.name,'은는')+' 다른 영역 대비 상대적으로 낮게 나타나, 관련 활동에서 다소 인내심이 필요할 수 있습니다. 이는 훈련을 통해 충분히 향상될 수 있는 영역이므로, 가정과 기관에서 꾸준히 관련 활동을 병행해주실 것을 권장합니다. 전반적으로 강점이 뚜렷한 아동으로, 강점을 발휘할 수 있는 경험을 자주 제공해주시길 바랍니다.');

  // --- 진로 적성 ---
  setText('pf-careerdesc', d.combo.careerDesc);
  setHTML('pf-careertags', d.combo.careerTags.map(function(t){return '<span>'+t+'</span>';}).join(''));

  // --- 성장포인트 (약점축 공통 처리) ---
  setText('pf-growthdesc', josa(d.weakAxis.name,'은는')+' 또래 평균 수준('+d.perAxis[d.weakAxisKey].rankPct+'%ile)으로, 다른 강점 영역에 비해 상대적으로 낮게 나타났어요. 이는 부족함이 아니라, '+name+'의 다른 강점을 더 완성도 있게 만들어줄 다음 성장 지점이에요.');
  setText('pf-growthtitle', d.weakAxis.name+' — 약점이 아니라 "다음 성장 지점"이에요.');

  // --- 뇌과학 근거 문단 (축 이름만 치환. ★ 전전두엽 설명 자체는 계획력 전용이라
  //     top축이 계획력이 아닐 경우 뇌 영역 설명이 부정확할 수 있음 — 감수 필요) ---
  const topAxisName = AXIS_LABEL[d.ranked[0].k];
  setText('pf-brainsci-topaxis', topAxisName);
  setText('pf-brainsci-topaxis2', topAxisName);
  setText('pf-brainsci-weakaxis', d.weakAxis.name);
  document.querySelectorAll('.pf-name').forEach(function(el){ el.textContent = name; });

  // --- 담임 선생님께 전달 메시지 ---
  const top2Str = AXIS_LABEL[d.ranked[0].k]+'·'+AXIS_LABEL[d.ranked[1].k];
  setText('pf-teachermsg', '"안녕하세요 선생님, '+name+' K-PASS 검사 결과를 공유드려요. '+
    top2Str+(hasBatchim(top2Str)?'이':'가')+' 강점이라 목표를 스스로 세우면 몰입을 잘하는 편이고, '+
    d.weakAxis.name+' 관련 활동은 조금 지루해할 수 있다고 해요. 참고해주시면 도움이 될 것 같습니다. 감사합니다!"');

  return d; // 검수 도구가 계산값을 직접 검증할 수 있도록 반환
}

function s_(profile,key){ return profile.scores[key]; }

/* kpass-figure-render.js가 전역 classifyLevel()을 그대로 호출하므로 호환용으로 노출 */
global.classifyLevel = classifyLevel;

/* export */
global.KPassEngine = {
  buildDerived: buildDerived,
  applyPersonalization: applyPersonalization,
  pickComboKey: pickComboKey,
  classifyLevel: classifyLevel,
  AXIS_LABEL: AXIS_LABEL,
  COMBO_CONTENT: COMBO_CONTENT
};

})(typeof window !== 'undefined' ? window : globalThis);
