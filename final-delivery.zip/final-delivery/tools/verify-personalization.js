#!/usr/bin/env node
/**
 * verify-personalization.js — 리포트 개인화 검수 프로그램
 *
 * 원리: 서로 다른 프로필 N개를 주입해서 리포트를 N번 렌더링하고,
 * "달라져야 할 텍스트인데 그대로인 곳"을 자동으로 찾아낸다.
 *
 * ===== 대상 리포트가 지켜야 하는 계약 (PROFILE 계약) =====
 * 리포트의 <script>는 아래 패턴으로 프로필을 읽어야 합니다.
 *
 *   const PROFILE = window.__TEST_PROFILE__ || DEFAULT_PROFILE;
 *
 * 이 계약이 없는 리포트는 애초에 "동적화가 안 된 것"이라, 이 도구를 돌려도
 * 항상 100% 동일하게 나옵니다 — 그건 도구 고장이 아니라 정확한 진단입니다.
 * (K-PASS report.kpass.final.html은 이미 이 계약을 지키도록 수정됨.)
 *
 * ===== 사용법 =====
 *   node verify-personalization.js <리포트.html> <프로필들.json>
 *
 * 프로필들.json은 프로필 객체의 배열이어야 합니다. 최소 2개, 권장 3개 이상
 * (서로 다른 이름 + 서로 다른 점수 조합 + 성별/나이도 다르게).
 *
 * ===== 판정 로직 =====
 * 1. 각 프로필로 리포트를 한 번씩 렌더링한다 (jsdom, 실제 스크립트 실행).
 * 2. 화면에 보이는 모든 텍스트 노드를 우리가 추적 가능한 "블록" 단위로 모은다
 *    (id가 있으면 id 기준, 없으면 섹션 내 순번 기준).
 * 3. 같은 블록의 텍스트가 프로필 전체에서 100% 동일하면 "의심 후보"에 올린다.
 * 4. 의심 후보 중, 아래 조건 중 하나라도 맞으면 "확정 하드코딩 가능성 높음"으로
 *    승격한다 — 숫자를 포함하거나, 어느 한 프로필의 이름/나이/성별 문자열을
 *    포함하거나, "%" 기호를 포함하는 경우. 이런 텍스트가 프로필을 바꿔도
 *    그대로라는 건 거의 확실히 버그다.
 * 5. 그 외 의심 후보(숫자·이름 없는 일반 조언 문구 등)는 "정적 텍스트일 수
 *    있음 — 검토 권장"으로 낮은 우선순위에 둔다. 원래도 모두에게 같은 말이
 *    맞는 문구(예: 일반 육아 팁)일 수 있기 때문이다.
 */

const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

const RESET = '\x1b[0m', RED = '\x1b[31m', GRN = '\x1b[32m', YEL = '\x1b[33m', DIM = '\x1b[2m', BOLD='\x1b[1m';

function usage() {
  console.log('사용법: node verify-personalization.js <리포트.html> <프로필들.json>');
  process.exit(1);
}

const [,, htmlArg, profilesArg] = process.argv;
if (!htmlArg || !profilesArg) usage();

const htmlPath = path.resolve(htmlArg);
const profilesPath = path.resolve(profilesArg);

if (!fs.existsSync(htmlPath)) { console.error(RED+'파일 없음: '+htmlPath+RESET); process.exit(1); }
if (!fs.existsSync(profilesPath)) { console.error(RED+'파일 없음: '+profilesPath+RESET); process.exit(1); }

const html = fs.readFileSync(htmlPath, 'utf8');
const profiles = JSON.parse(fs.readFileSync(profilesPath, 'utf8'));

if (!Array.isArray(profiles) || profiles.length < 2) {
  console.error(RED+'프로필 파일은 최소 2개 이상의 객체를 담은 배열이어야 합니다.'+RESET);
  process.exit(1);
}

const dir = path.dirname(htmlPath);

/* ---------- 리포트 1회 렌더링 ---------- */
async function renderWithProfile(profile) {
  const injectedScript = `<script>window.__TEST_PROFILE__ = ${JSON.stringify(profile)};</script>`;
  // 첫 <script 태그 앞에 프로필을 주입 — 리포트의 스크립트가 실행되기 전에
  // window.__TEST_PROFILE__이 이미 있어야 하므로 반드시 첫 script보다 앞.
  const idx = html.indexOf('<script');
  const injected = idx === -1 ? html : html.slice(0, idx) + injectedScript + html.slice(idx);

  const dom = new JSDOM(injected, {
    runScripts: 'dangerously',
    resources: 'usable',
    url: 'file://' + dir + '/' + path.basename(htmlPath),
    pretendToBeVisual: true,
  });

  const errors = [];
  dom.window.onerror = (msg, src, line) => { errors.push(`${msg} (line ${line})`); };

  await new Promise(r => setTimeout(r, 500)); // 스크립트 초기 렌더 대기

  return { dom, errors };
}

/* ---------- 텍스트 블록 추출 ----------
   id가 있는 요소는 id로, 없으면 "부모경로 + 형제순번"으로 안정적인 키를 만든다.
   너무 깊이 들어가면(예: <b> 안의 <span>) 같은 문장이 여러 조각으로 쪼개져
   노이즈가 커지므로, "자식에 블록 레벨 요소가 없는 노드"까지만 내려간다. */
function isLeafish(el) {
  const blockTags = new Set(['DIV','SECTION','TABLE','TBODY','TR','UL','OL','P']);
  for (const child of el.children) {
    if (blockTags.has(child.tagName)) return false;
  }
  return true;
}

function collectBlocks(doc) {
  const blocks = {};
  const skipTags = new Set(['SCRIPT','STYLE','NOSCRIPT']);
  function key(el, idx) {
    if (el.id) return '#' + el.id;
    const parentKey = el.parentElement ? (el.parentElement.id ? '#'+el.parentElement.id : el.parentElement.tagName) : 'root';
    return parentKey + '>' + el.tagName + ':' + idx;
  }
  function walk(el) {
    if (!el || skipTags.has(el.tagName)) return;
    if (isLeafish(el)) {
      const text = (el.textContent || '').trim().replace(/\s+/g, ' ');
      if (text.length >= 2) {
        blocks[key(el, Array.prototype.indexOf.call(el.parentElement ? el.parentElement.children : [], el))] = text;
      }
      return; // 리프 블록이면 더 안 내려감
    }
    Array.from(el.children).forEach(walk);
  }
  walk(doc.body);
  return blocks;
}

/* ---------- 의심스러운 고정 텍스트인지 판단 ---------- */
function looksPersonalizable(text, allProfiles) {
  if (/\d/.test(text)) return true;           // 숫자 포함 (점수, 나이, %ile 등)
  if (text.includes('%')) return true;
  for (const p of allProfiles) {
    if (p.name && text.includes(p.name)) return true;
    if (p.gender && text.includes(p.gender)) return true;
  }
  return false;
}

(async () => {
  console.log('\n' + '─'.repeat(64));
  console.log(' 검수 대상: ' + path.basename(htmlPath));
  console.log(' 테스트 프로필: ' + profiles.length + '개');
  profiles.forEach((p,i)=> console.log('   '+(i+1)+'. '+(p.name||'(이름없음)')+' '+JSON.stringify(p.scores||p)));
  console.log('─'.repeat(64));

  const renders = [];
  for (const profile of profiles) {
    const { dom, errors } = await renderWithProfile(profile);
    if (errors.length) {
      console.log(RED+`\n[JS 오류] 프로필 "${profile.name||'?'}" 렌더링 중 오류 발생:`+RESET);
      errors.forEach(e => console.log('  '+e));
    }
    renders.push({ profile, blocks: collectBlocks(dom.window.document) });
  }

  // 계약 미준수 감지: 모든 렌더 결과의 body 전체 텍스트가 완전히 동일하면
  // 애초에 PROFILE 계약이 구현 안 된 것.
  const fullTexts = renders.map(r => Object.values(r.blocks).join('|'));
  const allIdentical = fullTexts.every(t => t === fullTexts[0]);
  if (allIdentical) {
    console.log(YEL+'\n⚠ 모든 프로필의 렌더링 결과가 완전히 동일합니다.'+RESET);
    console.log('  이건 이 리포트가 아직 window.__TEST_PROFILE__ 계약을 구현하지');
    console.log('  않았다는 뜻일 가능성이 높습니다 (즉 "전부 하드코딩" 상태).');
    console.log('  개발자가 프로필 주입 로직을 넣은 뒤 다시 실행해 주세요.\n');
  }

  // 모든 렌더에 공통으로 존재하는 블록 키만 비교 대상으로 삼는다.
  const allKeys = new Set(Object.keys(renders[0].blocks));
  renders.slice(1).forEach(r => {
    for (const k of Array.from(allKeys)) if (!(k in r.blocks)) allKeys.delete(k);
  });

  const confirmed = []; // 확정 하드코딩 의심
  const maybe = [];     // 정적 텍스트일 수 있음

  for (const k of allKeys) {
    const texts = renders.map(r => r.blocks[k]);
    const allSame = texts.every(t => t === texts[0]);
    if (!allSame) continue; // 프로필마다 다르면 정상 — 통과
    const sample = texts[0];
    if (looksPersonalizable(sample, profiles)) {
      confirmed.push({ key: k, text: sample });
    } else {
      maybe.push({ key: k, text: sample });
    }
  }

  console.log('\n' + '─'.repeat(64));
  console.log(' 결과');
  console.log('─'.repeat(64));
  console.log(`검사한 블록 수: ${allKeys.size}`);
  console.log(RED+`확정 하드코딩 의심: ${confirmed.length}건`+RESET+DIM+' (숫자/이름/%가 있는데 프로필 바꿔도 그대로)'+RESET);
  console.log(YEL+`정적 텍스트 후보: ${maybe.length}건`+RESET+DIM+' (원래 공통 문구일 수 있음 — 검토 권장)'+RESET);

  if (confirmed.length) {
    console.log('\n' + BOLD + '=== 확정 하드코딩 의심 목록 ===' + RESET);
    confirmed.forEach((c,i) => {
      console.log(`\n${RED}[${i+1}] ${c.key}${RESET}`);
      console.log('  ' + (c.text.length > 140 ? c.text.slice(0,140)+'…' : c.text));
    });
  }

  // JSON 리포트도 같이 저장 — CI에서 파싱하거나 다음 실행과 비교할 때 사용
  const reportPath = htmlPath.replace(/\.html$/, '') + '.verify-report.json';
  fs.writeFileSync(reportPath, JSON.stringify({
    target: htmlPath,
    profiles: profiles.map(p => p.name || p),
    blocksChecked: allKeys.size,
    confirmed,
    maybe,
    allIdentical,
  }, null, 2), 'utf8');
  console.log('\n상세 결과 저장: ' + reportPath);

  console.log('\n' + '─'.repeat(64));
  if (allIdentical) {
    console.log(YEL + '판정: 검수 불가 — PROFILE 계약 미구현' + RESET);
    process.exitCode = 2;
  } else if (confirmed.length > 0) {
    console.log(RED + `판정: 실패 — 개인화 안 된 항목 ${confirmed.length}건 발견` + RESET);
    process.exitCode = 1;
  } else {
    console.log(GRN + '판정: 통과 — 확정 하드코딩 의심 항목 없음' + RESET);
    process.exitCode = 0;
  }
  console.log('─'.repeat(64) + '\n');
})();
