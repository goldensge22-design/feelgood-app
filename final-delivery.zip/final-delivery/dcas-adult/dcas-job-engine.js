/**
 * D-CAS 직무매칭 런타임 엔진 (3단계)
 *
 * dcas-career-zero-cost-design.md에서 설계한 구조 그대로입니다.
 *   - 직무 요구벡터(dcas-jobs-master.json)는 1회성 콘텐츠 — 이미 만들어져 있음
 *   - 이 파일은 런타임에 점수 vs 요구벡터를 계산만 함 — AI 호출 없음
 *
 * ★★★ 스코프 안내 ★★★
 * 지금은 "컴퓨터공학과 → 정보기술(SW) NCS 중분류" 매핑 1개만 연결했습니다.
 * 나머지 47개 학과는 같은 방식으로 매핑 테이블만 채우면 됩니다 — 아래
 * MAJOR_TO_NCS_MIDDLE 객체에 항목을 추가하세요. 매핑 기준(어떤 학과가 어떤
 * NCS 중분류에 대응하는지)은 진로 전문가 검토를 권장합니다.
 *
 * ★ fit% 계산 공식은 1차안입니다. 유클리드 거리 기반이며, 기존 리포트의
 * 예시 숫자(89%, 85%...)와 정확히 일치하지 않을 수 있습니다 — 그 예시는
 * 손으로 쓴 샘플이라 실제 계산식과 애초에 연결돼 있지 않았습니다. 공식
 * 자체가 타당한지는 검증 필요합니다.
 */
(function (global) {

  const MAJOR_TO_NCS_MIDDLE = {
    '컴퓨터공학과': '정보기술(SW)',
    // 나머지 47개 학과는 여기에 추가하세요. 예:
    // '기계공학과': '기계',
    // '경영학과': '경영·회계·사무',
  };

  const AXIS_LABEL = { P: '계획력', A: '주의력', S: '동시처리', Q: '순차처리' };
  const AXIS_TO_JOBKEY = { P: 'planning', A: 'attention', S: 'simultaneous', Q: 'successive' };

  /* ===== fit% 계산 — 유클리드 거리 기반, 0~100 스케일로 환산 ===== */
  function computeFit(userScores, jobProfile) {
    let sq = 0;
    ['P', 'A', 'S', 'Q'].forEach(function (k) {
      const diff = userScores[k] - jobProfile[AXIS_TO_JOBKEY[k]];
      sq += diff * diff;
    });
    const dist = Math.sqrt(sq);
    // 최대 가능 거리(각 축 100점 차이 기준)로 정규화
    const maxDist = Math.sqrt(4 * 100 * 100);
    const fit = Math.round(100 - (dist / maxDist) * 100);
    return Math.max(0, Math.min(100, fit));
  }

  /* ===== 근거 문장 생성 — 문장 조각 조합. AI 아님 ===== */
  function topAxes(profile, n) {
    return ['planning', 'attention', 'simultaneous', 'successive']
      .map(function (k) { return { k: k, v: profile[k] }; })
      .sort(function (a, b) { return b.v - a.v; })
      .slice(0, n)
      .map(function (x) { return Object.keys(AXIS_TO_JOBKEY).find(function (ak) { return AXIS_TO_JOBKEY[ak] === x.k; }); });
  }
  function buildReasonText(userScores, job) {
    const jobTop2 = topAxes(job.pass_profile, 2);
    const label = jobTop2.map(function (k) { return AXIS_LABEL[k] + ' ' + userScores[k] + '%'; }).join('×');
    return '이 직무가 요구하는 핵심 축은 ' + jobTop2.map(function (k) { return AXIS_LABEL[k]; }).join('·') +
      '이에요. 회원님의 ' + label + ' 조합과 맞닿아 있어요.';
  }

  /* ===== 학과 선택 → 순위 매긴 직무 배열 (1회 계산, 이후 재사용) ===== */
  function rankJobsForMajor(userScores, majorName, JOB_POOL) {
    const ncsMiddle = MAJOR_TO_NCS_MIDDLE[majorName];
    if (!ncsMiddle) return null; // 매핑 안 된 학과 — 2단계에서 채워야 함
    const pool = JOB_POOL.filter(function (j) { return j.ncs.middle_name === ncsMiddle; });
    const scored = pool.map(function (j) {
      return {
        job: j,
        fit: computeFit(userScores, j.pass_profile),
        reason: buildReasonText(userScores, j),
      };
    }).sort(function (a, b) { return b.fit - a.fit; });
    return scored;
  }

  global.DCasJobEngine = {
    MAJOR_TO_NCS_MIDDLE: MAJOR_TO_NCS_MIDDLE,
    computeFit: computeFit,
    rankJobsForMajor: rankJobsForMajor,
    buildReasonText: buildReasonText,
  };

})(typeof window !== 'undefined' ? window : globalThis);
