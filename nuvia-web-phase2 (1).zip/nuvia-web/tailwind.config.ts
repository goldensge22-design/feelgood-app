import type { Config } from "tailwindcss";

// FeelGood 브랜드 컬러 (§22 "세련된 EdTech / Cognitive Analytics" 방향)
const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          blue: "#2E75CC",
          blueDeep: "#2856D6",
          orange: "#F4A418",
          orangeDeep: "#F5820A",
        },
        ink: "#1A2233",
        surface: "#F7F8FB",
      },
      borderRadius: {
        card: "14px",
      },
    },
  },
  plugins: [],
};
export default config;
