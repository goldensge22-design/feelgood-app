#!/usr/bin/env node
// 독립 실행 테스트 버전 — 새 세션/새 개발자가 이 저장소만 받아서
// `npm install && npm run verify` 한 줄로 build → server 기동 → 전체 테스트(unit+E2E)
// → server 종료 → 결과 요약까지 끝낼 수 있게 하는 진입점이다.
// 이 저장소 밖의 어떤 맥락(과거 대화 등)도 필요하지 않다 — NUVIA_ADAPTER_MODE 기본값(mock)만으로 동작.

import { spawn } from "node:child_process";
import process from "node:process";

const PORT = process.env.VERIFY_PORT ?? "3100";
const BASE_URL = `http://localhost:${PORT}`;
const READY_TIMEOUT_MS = 30_000;

function run(command, args, opts = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { stdio: "inherit", ...opts });
    child.on("exit", (code) => (code === 0 ? resolve() : reject(new Error(`${command} ${args.join(" ")} exited with ${code}`))));
    child.on("error", reject);
  });
}

async function waitForServer(url, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const res = await fetch(url);
      if (res.status) return true; // 어떤 응답이든 오면(200이든 4xx든) 서버가 살아있는 것
    } catch {
      // 아직 준비 안 됨 — 재시도
    }
    await new Promise((r) => setTimeout(r, 500));
  }
  throw new Error(`서버가 ${timeoutMs}ms 안에 준비되지 않았습니다 (${url})`);
}

async function main() {
  console.log("=== [1/5] Type check ===");
  await run("npx", ["tsc", "--noEmit", "-p", "tsconfig.json"]);

  console.log("\n=== [2/5] Unit tests (순수 로직) ===");
  await run("node", [
    "--import", "tsx", "--test",
    "src/domain/__tests__/*.test.ts",
    "src/adapters/mock/__tests__/*.test.ts",
  ], { shell: true });

  console.log("\n=== [3/5] Production build ===");
  await run("npx", ["next", "build"]);

  console.log(`\n=== [4/5] E2E tests (실제 서버, port ${PORT}) ===`);
  const server = spawn("npx", ["next", "start", "-p", PORT], { stdio: "inherit", detached: true });
  let e2eError = null;
  try {
    await waitForServer(`${BASE_URL}/my-nuvia`, READY_TIMEOUT_MS);
    await run("node", ["--import", "tsx", "--test", "e2e/*.test.ts"], {
      shell: true,
      env: { ...process.env, E2E_BASE_URL: BASE_URL },
    });
  } catch (err) {
    e2eError = err;
  } finally {
    try {
      process.kill(-server.pid, "SIGKILL"); // 프로세스 그룹 전체 종료(npx가 띄운 하위 서버까지)
    } catch {
      server.kill("SIGKILL");
    }
  }
  if (e2eError) throw e2eError;

  console.log("\n=== [5/5] 전체 통과 ===");
  console.log("tsc --noEmit: OK");
  console.log("unit tests: OK");
  console.log("production build: OK");
  console.log("E2E tests: OK");
  process.exit(0);
}

main().catch((err) => {
  console.error("\n검증 실패:", err.message);
  process.exit(1);
});
