# INTEGRATION READINESS — Increment 5A

**STATUS: INCREMENT 5A — INTEGRATION READY / FROZEN**

기준: PHASE 1 v1.1 / MY NUVIA Homepage v1.2 Clean Frozen / Unified Growth Module v1.2 Frozen / Increment 1~4

**이 단계에서 하지 않은 것 (명시적 범위 외)**: 실제 운영 DB write, 기존 회원 DB 구조 변경, Branch 원본 metric 재계산, Growth Connection 실제 판정, Class Aggregate 실제 계산, 새로운 인증 시스템 생성. 아래 모든 real adapter는 **"연결 가능한 형태로 준비"**된 상태이며, 실제 엔드포인트가 없으면 `.env` 미설정으로 즉시 실패하도록 설계했다(조용히 mock으로 새지 않음).

---

## 1. Adapter Registry 구조

```
src/adapters/
  types.ts                 — 데이터 adapter 인터페이스 (Identity/Assessment/ProgramStatus/…)
  session-types.ts          — 세션/Viewer Context/Deep Link 인터페이스 (신규, Increment 5A)
  errors.ts                 — AdapterError, withAdapterTimeout, toAdapterError (신규)
  registry.ts                — mock ↔ real 전환 지점 (신규)
  mock/*.mock.ts             — 기존 mock 구현체 (Increment 1~4)
  real/
    config.ts                — .env 필수값 lazy 검증
    http.ts                  — 인증된 fetch + 타임아웃 + 에러 정규화 공통 유틸
    *.real.ts                 — 실제 계약 stub 구현체 (신규)
```

`getDomainAdapterBundle(mode?)`가 `NUVIA_ADAPTER_MODE` 환경변수를 읽어 `UnifiedGrowthModule`의 생성자 기본값을 통째로 mock↔real로 바꾼다. Domain/Application Layer 코드는 이 스위치를 전혀 모른다 — `unified-growth-module.ts`는 여전히 `assessmentAdapterMock`이 아니라 `AssessmentAdapter` 인터페이스만 참조한다.

## 2. mock ↔ real 전환 방법

1. `.env`에 `NUVIA_ADAPTER_MODE=real` 설정
2. `.env.example`의 `FEELGOOD_*_BASE_URL`, `FEELGOOD_SERVICE_API_KEY`, `FEELGOOD_DEEP_LINK_VERIFY_SECRET` 값을 실제 서버 팀에게 받은 값으로 채움
3. 앱 재시작 — `getDomainAdapterBundle()`이 `real/*.real.ts` 구현체를 반환하기 시작한다
4. 코드 변경 없음. `UnifiedGrowthModule`, API 라우트, 모든 `/my-nuvia/*`·`/admin/nuvia-growth/*` 페이지는 그대로 동작한다

**되돌리기**: `NUVIA_ADAPTER_MODE`를 지우거나 `mock`으로 바꾸면 즉시 mock으로 복귀한다.

**부분 전환**도 가능하다(예: Assessment만 실제 서버에 붙이고 나머지는 mock 유지) — `registry.ts`의 `getDomainAdapterBundle()`을 직접 수정해 필드별로 mock/real을 섞어 반환하면 된다. 현재는 all-or-nothing으로 구성되어 있으나 구조상 필드 단위 교체를 막지 않는다.

**세션 계열(AuthSessionAdapter/RelationshipScopeAdapter/DeepLinkTokenAdapter)은 이번 단계에서 real 전용으로만 준비했다.** 현재 mock 세션은 `src/lib/viewer-context.ts`의 `deriveViewerContext()`(계정 고정 매핑)가 담당하며, 이 함수를 `AuthSessionAdapter`/`RelationshipScopeAdapter` 계약에 맞춰 정식으로 mock adapter화하는 작업은 **Increment 5B 범위**로 남겨둔다(`getSessionAdapterBundle("mock")`은 현재 에러를 던진다 — 의도된 동작).

## 3. Real Contract별 요구 사항

각 항목: **역할 / 엔드포인트 계약 / 에러 의미 / 샘플 응답**.

### (1) AuthSessionAdapter — `src/adapters/session-types.ts`, `real/auth-session-adapter.real.ts`
기존 K-PASS/D-CAS 로그인 세션을 검증만 한다. 새 로그인 시스템을 만들지 않는다.

```
POST {FEELGOOD_AUTH_BASE_URL}/session/verify
요청: { cookie_header?: string, authorization_header?: string }
```
```json
// 200
{ "account_id": "acc-parent-01", "expires_in_seconds": 3600 }
```
```json
// 401 — 미인증(adapter가 null로 정규화, 에러 아님)
{ "error": "unauthorized" }
```

### (2) IdentityAdapter — `real/identity-adapter.real.ts`
local key(kpass/dcas/kids/history/planner/admin) → canonical `learner_id`.

```
GET {FEELGOOD_IDENTITY_BASE_URL}/resolve?system=kpass&key=u-1001
```
```json
// 200
{ "learner_id": "learner-0001" }
```
```json
// 404 — 매핑 없음 (AdapterError kind: "not_found"로 전파, 이 앱이 임의 생성하지 않음)
{ "error": "not_found" }
```

### (3) RelationshipScopeAdapter — `real/relationship-scope-adapter.real.ts`
account_id → viewer_role + relationship_scope(direct/class/institution, PATCH 2 구조 그대로).

```
GET {FEELGOOD_RELATIONSHIP_SCOPE_BASE_URL}/accounts/{account_id}/scope
```
```json
// 200 — 부모(direct)
{
  "viewer_role": "parent",
  "relationship_scope": { "type": "direct", "learner_ids": ["learner-0001", "learner-0002"] }
}
```
```json
// 200 — 교사(class)
{
  "viewer_role": "teacher",
  "relationship_scope": { "type": "class", "scope_id": "class-9-2" }
}
```

### (4) AssessmentAdapter — `real/assessment-adapter.real.ts`
K-PASS/D-CAS 최근 검사 프로파일. `cognitive_domains`는 고정 4개가 아니라 배열(PATCH 1).

```
GET {FEELGOOD_ASSESSMENT_BASE_URL}/learners/{learner_id}/latest-profile
```
```json
// 200
{
  "assessment_id": "a-001",
  "assessment_profile_version": "v3",
  "assessed_at": "2026-03-10",
  "cognitive_domains": [
    { "domain_key": "planning", "display_name": "Planning", "score": 62 },
    { "domain_key": "attention", "display_name": "Attention", "score": 58 }
  ],
  "strengths": ["Planning"],
  "support_areas": ["Attention"],
  "report_url": "https://kpass.feel-good.io/reports/a-001"
}
```
```json
// 404 — 검사 이력 없음 (adapter가 null로 변환, Empty State 처리, 에러 아님)
```

### ProgramStatusAdapter — `real/program-status-adapter.real.ts`
`program_status`만 다룬다. `growth_data_status`는 절대 이 adapter가 채우지 않는다(§28).

```
GET {FEELGOOD_PROGRAM_STATUS_BASE_URL}/learners/{learner_id}/programs/active
```
```json
// 200
[
  {
    "program_id": "PLANNER",
    "program_status": "active",
    "growth_data_status": "insufficient",
    "last_activity_at": "2026-09-08",
    "launch_url": "https://planner.feel-good.io/launch",
    "info_url": "https://planner.feel-good.io/intro"
  }
]
```

### (5) Branch Growth Adapter — KIDS/HISTORY/PLANNER
`trend`(원본)와 `display_direction`(Branch 해석)은 반드시 분리되어 와야 한다(PATCH 4) — Unified Growth Module이 trend만 보고 자체 판정하지 않는다.

```
GET {FEELGOOD_KIDS_BASE_URL}/learners/{learner_id}/growth-summary
```
```json
// 200
{
  "growth_data_status": "sufficient",
  "metrics": {
    "accuracy": { "trend": "up", "display_direction": "improving", "observation": "최근 정확도 상승 경향" }
  },
  "updated_at": "2026-09-09"
}
```

PLANNER는 추가로 `task_breakdown_observation`(Growth Score 아님, 관찰정보):
```json
{
  "growth_data_status": "insufficient",
  "metrics": {},
  "updated_at": "2026-09-08",
  "task_breakdown_observation": { "text": "최근 큰 과제를 단계로 나누는 시도가 관찰됨", "observed_at": "2026-09-07" }
}
```

### VisibilityPolicyAdapter — `real/visibility-policy-adapter.real.ts`
검사/프로그램/성장/Insight가 공유하는 유일한 권한 판단 지점(§26 SSOT).

```
POST {FEELGOOD_VISIBILITY_POLICY_BASE_URL}/filter
요청: { viewer: ViewerContext, subject_learner_id, domain, payload }
```
```json
// 200
{ "payload": { /* 필터링된 동일 shape */ }, "policy_version": "2026-09-01" }
```

**Increment 6 확인사항(코드 변경 아님 — 실제 서버 연동 전 서버팀과 확인 필요):**
이 앱의 mock Policy 로직(`src/domain/visibility-policy.ts`)은 `domain` 값 `assessment`/`program`/`growth`/`insight` **네 가지를 동일한 `POST /filter` contract**(요청 shape: `{viewer, subject_learner_id, domain, payload}`, 응답 shape: `{payload, policy_version}`)로 처리하도록 설계되어 있다. 실제 Visibility Policy 서비스도 이 네 domain을 **하나의 동일한 계약**으로 받아 처리할 수 있는지 — 즉 domain별로 별도 엔드포인트나 다른 요청/응답 shape를 요구하지 않는지 — STEP 0에서 서버팀에 확인해야 한다. 다르다면 `VisibilityPolicyAdapter` 인터페이스 자체(domain 파라미터 처리 방식)를 재검토해야 하므로, real 연동 착수 전 확인이 필요하다.

### (7) DeepLinkTokenAdapter — `real/deep-link-token-adapter.real.ts`
결과지 Deep Link 토큰 검증 전용(발급은 기존 결과지 시스템). 실패 사유는 세분화해 노출하지 않는다(§9).

```
POST {FEELGOOD_AUTH_BASE_URL}/deep-link/verify
요청: { token: "..." }
```
```json
// 200
{ "learner_id": "learner-0001", "assessment_id": "a-001", "issued_at": "2026-09-10T01:00:00Z", "expires_at": "2026-09-10T01:10:00Z" }
```
```json
// 401/404/410 — 위조/형식오류/만료 (adapter가 모두 null로 정규화)
```

토큰 payload 스키마(발급 시스템이 서명할 필드) — `src/types/deep-link.ts`:
```ts
{ learner_id, assessment_id, purpose: "assessment_report_deep_link", iat, exp }
```

## 4. API 오류 처리 규칙 (item 9)

`src/adapters/errors.ts`의 `AdapterErrorKind` 6종을 모든 real adapter가 공통으로 사용한다.

| kind | 의미 | Domain Layer 처리 |
|---|---|---|
| `unauthorized` | 세션/토큰 무효 | **그대로 던진다** — 화면 전체를 401로 처리, partial-data로 감추지 않는다 |
| `invalid_config` | `.env` 누락 등 배포 설정 오류 | **그대로 던진다** — 개발자가 즉시 알아채야 함 |
| `not_found` | 대상 없음(검사 이력 없음 등) | `null`/빈 배열로 정규화 — **에러 아님**, Empty State로 표시 |
| `timeout` | 응답 지연 | fallback 값으로 흡수, `partial_errors`에 기록 — 해당 섹션만 "일시적으로 불러오지 못했습니다" |
| `upstream_error` | 실제 서버 5xx | 위와 동일하게 partial-data 처리 |
| `network_error` | 연결 실패 자체 | 위와 동일하게 partial-data 처리 |

`UnifiedGrowthModule.getOverview()`/`getTimeline()`/`getInsights()`는 이제 `Promise.all` 대신 `loadWithFallback()`을 통해 각 소스를 독립적으로 처리한다 — 예를 들어 PLANNER 서버가 타임아웃 나도 검사 프로파일과 KIDS/HISTORY는 정상 렌더된다. `OverviewResponse.partial_errors`(옵션 필드)에 실패한 소스 목록이 담기고, `src/components/PartialErrorBanner.tsx`가 이를 Home 화면에 표시한다.

## 5. 실제 서버팀에 전달할 API 체크리스트

- [ ] `POST /session/verify` — 기존 로그인 세션 검증 (신규 로그인 시스템 아님, 기존 세션 그대로 검증만)
- [ ] `GET /accounts/{account_id}/scope` — viewer_role + relationship_scope(direct/class/institution) 반환
- [ ] `GET /resolve?system=&key=` — local key → canonical learner_id 매핑, 없으면 404
- [ ] `GET /learners/{learner_id}/latest-profile` — K-PASS/D-CAS 최근 검사, `cognitive_domains` 배열 형태
- [ ] `GET /learners/{learner_id}/profile-history` — (Increment 5B 추가) 재검사 이력 전체(assessed_at 오름차순, 이전 프로파일 삭제 금지) — Epoch 구분에 사용
- [ ] `GET /learners/{learner_id}/programs/active` , `GET /learners/{learner_id}/programs/{program_id}` — `program_status`만(growth_data_status 포함 금지 — 그건 아래 3개 API 책임)
- [ ] `GET /classes/{class_id}/roster` — (Increment 5B 추가) 학급 명단, `learner_ids: string[]`만 — 표시용 이름/개인정보 없음
- [ ] `GET /learners/{learner_id}/growth-summary` × 3 (KIDS/HISTORY/PLANNER) — `trend`와 `display_direction` 분리 필수, `metrics`는 승인된 summary만(재계산 금지). **(Increment 5B)** 가능하면 `observation_count`/`window`(관찰 기간)도 함께 제공 — Growth Connection Engine의 MINIMUM DATA/SAME PERIOD 판정에 사용(없으면 항상 INSUFFICIENT_DATA로 안전하게 처리됨)
- [ ] `POST /filter` — Visibility Policy SSOT, `policy_version` 포함. **(Increment 6 확인사항) `domain` = assessment/program/growth/insight 네 가지 전부를 동일한 요청/응답 shape 하나로 처리 가능한지 확인** — domain별로 다른 엔드포인트나 shape가 필요하면 이 앱의 adapter 계약을 다시 설계해야 함
- [ ] `POST /deep-link/verify` — 결과지 Deep Link 토큰 검증, 실패 사유 구분 없이 401/404/410만
- [ ] 모든 엔드포인트: `Authorization: Bearer {FEELGOOD_SERVICE_API_KEY}` 헤더 인증, 5xx/4xx 표준 상태 코드 사용(본 앱이 상태 코드로 에러 종류를 판별함)
- [ ] STEP 0 확인 필요 사항(문서 결함 아님, 서버 확인 필요): K-PASS/D-CAS 계정 DB 동일 learner 매핑 여부, 부모-자녀 관계 저장 key, PLANNER v1.3 event envelope와 CORE 대조, Branch별 minimum observation 기준, 결과지 Deep Link 토큰 서명 알고리즘/키 배포 방식

## 6. `.env` 체크리스트

`.env.example` 참고. `NUVIA_ADAPTER_MODE=mock`이면 전부 비워도 기존 mock 동작 그대로 유지된다.

## 7. 5A FINAL PATCH — 세션 계열 mock adapter 정식화 (완료)

이전 버전에서 남겨두었던 gap을 닫았다.

- `MockAuthSessionAdapter`(`src/adapters/mock/auth-session-adapter.mock.ts`), `MockRelationshipScopeAdapter`(`relationship-scope-adapter.mock.ts`), `MockDeepLinkTokenAdapter`(`deep-link-token-adapter.mock.ts`)를 각각 real과 **동일한 interface**(`src/adapters/session-types.ts`)로 구현했다.
- `deriveViewerContext()`의 고정 매핑 테이블은 삭제하지 않고 `MockRelationshipScopeAdapter` 내부로 그대로 옮겼다 — 데이터는 보존, 위치만 격리.
- `src/adapters/viewer-context-resolver.ts`(mode-agnostic, `real/`에서 이동)가 `AuthSessionAdapter + RelationshipScopeAdapter`를 합성해 `ViewerContext`를 만든다.
- `src/lib/resolve-viewer-context.ts`가 Server Component/Route Handler 양쪽에서 쓰는 유일한 진입점이다. **모든 페이지·API 라우트가 `resolveViewerContext()`/`resolveViewerContextFromRequest()`만 호출하며, `NUVIA_ADAPTER_MODE` 값은 전혀 모른다.**
- "로그인 스위치"는 `?as=` 쿼리 파라미터에서 `/dev/login?as=parent|learner|teacher` route(쿠키 설정)로 이동했다 — real 모드에서는 이 라우트가 400을 반환해 자연히 비활성화된다(새 인증 시스템이 아니라 mock 전용 개발 편의 기능임을 명시).

**검증**: `NUVIA_ADAPTER_MODE=mock`(기본값)과 `real`을 바꿔도 `src/app/**`(페이지/라우트)는 단 한 줄도 수정할 필요가 없다 — 차이는 전부 `src/adapters/registry.ts` 안에서 흡수된다.

## 8. Increment 5B에서 추가된 것 (완료)

- **Growth Connection Engine 실제 판정**(`src/domain/growth-connection-engine.ts`), 도메인 태그(`src/config/growth-domain-tags.ts`), minimum observation config(`src/config/observation-thresholds.ts` — 기본 전부 `null`, 미확정이면 항상 `INSUFFICIENT_DATA`)
- **Visibility Policy 실제 role별 축소**(`src/domain/visibility-policy.ts`) — learner/teacher는 전체, parent는 대표 metric 1개, institution은 상태값만
- **Class Aggregate 실제 집계**(roster 기반, 고정 숫자 아님) + `ClassRosterAdapter`(신규 real/mock 계약)
- **Epoch 처리**: `AssessmentAdapter.getProfileHistory()` 추가, `TimelineResponse.epochs` 신설, 재검사 전/후를 하나의 성장선으로 합치지 않음
- **Deep Link 전체 흐름**: `/report/deep-link` route(token 검증 → 로그인 확인 → relationship_scope 확인 → learner 선택 → 이동), URL에는 opaque token만 존재
- **실제 세션 기반 subject_learner_id 유지**: 5A의 쿠키 메커니즘(`selected-learner.ts` + `/my-nuvia/select-learner`)이 계속 이 역할을 수행하며, Deep Link 흐름도 동일한 쿠키 설정 경로를 재사용(새 저장소를 만들지 않음)
- **Partial Failure 유지**: `loadWithFallback` 패턴을 `getConnections`/`getClassSummary`(신규 `safeFetch`)까지 확장
- 테스트 35건 전부 통과(`npm test`) — 상세는 `TEST_CASES.md` 참고

## 9. 남은 것

- 실제 서버 연결 후 STEP 0 항목 확정(Branch별 minimum observation 실제 값 포함)
- 운영 DB write 경로 일체(이 앱은 계속 read-only)
- 실제 HTTP 서버 기반 E2E 테스트(현재는 순수 함수/모듈 단위 테스트까지 — `TEST_CASES.md` "커버되지 않은 것" 참고)

## 10. Increment 5B FINAL PATCH (완료)

1. **Deep Link 로그인 리다이렉트 mode 분기** — `src/lib/login-redirect.ts`(`resolveLoginUrl()`). mock은 `/dev/login`, real은 `.env`의 `FEELGOOD_LOGIN_URL_TEMPLATE`(`{return_to}` 자리표시자) 사용. 이 앱은 로그인 UI를 만들지 않고 기존 FeelGood 로그인 URL로만 이동시킨다.
2. **Visibility Policy — insight 도메인 실제 축소** — `InsightCard`에 `student_reflection_text`/`atomic_behavior_log`(학생 전용) 필드 추가, `applyVisibilityPolicy`가 learner를 제외한 모든 role에 allow-list(observation/interpretation/actions)만 적용.
3. **`buildClassStrategy()` 고정 해석 제거** — `tallyNeedsObservationByMetricKey()` 신설, `time_prediction_accuracy`가 실제 최다 근거일 때만 시간예측 문구, 그 외에는 일반 자기관리 관찰 문구.

`npm test` 42건 전부 통과.

## 11. Increment 6 FINAL PATCH (완료)

1. **pre-assessment epoch 분리** — `computeEpochAssignment()`가 `{epoch_index: number | null, phase: "pre_assessment" | "assessment_epoch"}` 반환. 첫 검사 이전 이벤트는 `epoch_index: null`로 분리되며 첫 검사 이후 epoch 0과 절대 합쳐지지 않는다(`src/types/timeline.ts`, `src/domain/unified-growth-module.ts`, `src/components/growth/GrowthTimeline.tsx`).
2. **부모 대표 metric 선택 로직** — `GrowthSummary.primary_metric_key`(Branch 명시) 신설, 없으면 `src/config/growth-metric-priority.ts`(Branch별 우선순위)로 fallback, 둘 다 없으면 임의 선택 없이 빈 metrics 반환(`src/domain/visibility-policy.ts`의 `pickPrimaryMetric()`). KIDS/HISTORY/PLANNER mock fixture에 `primary_metric_key` 명시.
3. **(확인사항만, 코드 변경 아님)** §3 VisibilityPolicyAdapter 절과 API 체크리스트(§5)에 "real Policy 서비스가 assessment/program/growth/insight 4개 domain을 동일 contract로 처리 가능한지 STEP 0에서 확인" 항목 추가.

`npm test` 48건 전부 통과(Increment 5B 42건 + Increment 6 FINAL PATCH 6건).

**STATUS: INCREMENT 6 — APPROVED FOR REAL SERVER INTEGRATION**
