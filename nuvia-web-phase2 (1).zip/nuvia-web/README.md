# NUVIA UNIFIED GROWTH — PHASE 2 (Increment 1~6, FINAL PATCH 완료)

기준: PHASE 1 v1.1 — APPROVED FOR BUILD / MY NUVIA Homepage v1.2 Clean Frozen / Unified Growth Module v1.2 Frozen

**STATUS: INCREMENT 6 — APPROVED FOR REAL SERVER INTEGRATION**

## Increment 6 FINAL PATCH

1. **pre-assessment epoch 분리** — `computeEpochAssignment()`가 `{epoch_index: number | null, phase: "pre_assessment" | "assessment_epoch"}`를 반환. 첫 검사 이전 활동은 `epoch_index: null`로 명확히 분리되며 더 이상 epoch 0과 섞이지 않는다. `GrowthTimeline` UI도 "검사 이전" 섹션을 별도로 렌더링.
2. **부모 대표 metric 선택 로직** — `GrowthSummary`에 `primary_metric_key`(Branch 명시) 추가, 없으면 `src/config/growth-metric-priority.ts`(Branch별 `summary_metric_priority`)로 fallback, 둘 다 없으면 임의 선택 없이 "요약 가능한 대표 지표가 아직 없습니다" 상태 반환. `Object.keys()` 순서 의존 로직 제거.
3. **(확인사항만)** `INTEGRATION_READINESS.md`에 real Visibility Policy 서비스가 assessment/program/growth/insight 4개 domain을 동일 contract로 처리 가능한지 서버팀 확인 항목 추가(코드 변경 아님).

## 독립 실행 테스트 버전 (Claude 새 세션/다른 개발자용)

이 저장소는 이 대화의 다른 맥락 없이 그 자체로 완결됩니다. 필요한 건 Node.js뿐입니다(추가 설정·API 키·`.env` 불필요 — 기본값이 mock 모드).

```bash
npm install
npm run verify
```

`npm run verify` 한 줄이 순서대로 실행합니다: **타입체크 → 순수 로직 단위 테스트(48건) → 프로덕션 빌드 → 서버 기동 → 실제 HTTP E2E 테스트(21건) → 서버 자동 종료**. 전부 통과하면 exit code 0, 어느 하나라도 실패하면 해당 단계에서 exit code 1로 멈춥니다. 서버는 테스트 종료 후 자동으로 정리되어 프로세스가 남지 않습니다.

개발 서버만 띄워서 브라우저로 직접 확인하고 싶다면(아래 "실행" 절 참고): `npm run dev` 후 `/dev/login?as=parent`부터 시작하세요.

## Increment 6 — End-to-End Integration & QA

- 상세는 `INCREMENT6_QA.md` 참고 — 실제 `next build` + `next start` 서버 대상 HTTP 레벨 E2E 테스트 21건(`e2e/smoke.test.ts`, `npm run test:e2e`)
- **버그 1건 발견 및 수정**: `/my-nuvia` Home 페이지에 교사 가드가 빠져 있던 것을 E2E 테스트가 잡아냄(순수 단위 테스트로는 발견 불가능했던 종류의 버그)
- 모바일 반응형·브라우저 인터랙션·real 모드 등 자동화되지 않은 항목은 `INCREMENT6_QA.md`에 수동 QA 체크리스트로 명시

## Increment 5A — Integration Readiness / FROZEN, Increment 5B — 실제 판정 로직

- 상세는 `INTEGRATION_READINESS.md`(mock↔real 전환, adapter 계약, .env 체크리스트) 및 `TEST_CASES.md`(35개 테스트) 참고
- `npm test`로 Growth Connection Engine/Visibility Policy/Class Aggregate/Deep Link/Epoch/Partial Failure 전부 검증 가능
- `NUVIA_ADAPTER_MODE=mock|real` 전환만으로 `src/app/**` 코드 수정 없이 세션·데이터 어댑터가 통째로 바뀐다

## Increment 3 → 4 전환 전 패치 (2 MAJOR + 2 MINOR)

1. **[MAJOR] learner 선택 유지** — `src/lib/selected-learner.ts`(쿠키), `src/lib/resolve-subject-learner.ts`(공용 우선순위 로직: 쿼리 > 쿠키 > ViewerContext 기본값 > 첫 허용 항목), `src/app/my-nuvia/select-learner/route.ts`(서버측 검증 후 쿠키 반영). 모든 `/my-nuvia/*` 페이지가 동일 로직을 사용하도록 통일. 실제 구현에서는 쿠키 대신 서버 세션의 selected learner 필드를 사용한다는 점을 주석으로 명시.
2. **[MAJOR] 부모 Growth View 요약 제한** — `src/app/my-nuvia/growth/page.tsx`를 `viewer_role`로 분기: parent는 `ProfileView + MyGrowthPreview(요약) + Timeline + Connection + SupportTipPanel`만, 학생용 상세 `TrainView/ThinkView/ManageView`(Metric Grid)와 `MetacognitionView`는 학생 본인에게만 노출.
3. **[MINOR] `/my-nuvia/growth` teacher guard** — `TeacherScopeNotice` 추가, 교사는 기존 Admin(Increment 4) 이용 안내.
4. **[MINOR] ProgramCard URL 책임 분리** — `ProgramState`에 `launch_url`(active 전용)과 `info_url`(inactive/expired 전용)을 분리(`src/types/program.ts`, mock adapter, `ProgramCard.tsx`). 프로그램별 고정 intro URL도 `COPY`에 추가해 아예 상태 데이터가 없는 경우에도 실행 URL과 혼동되지 않도록 함.

## Increment 4 — 교사 Admin (`/admin/nuvia-growth/*`)

§17 그대로 반영: **기존 Admin 내부에 추가되는 메뉴**라는 전제이며, 별도 로그인/사이트를 만들지 않는다. 이 레포에서는 그 삽입 지점을 시연하기 위해 `/admin/nuvia-growth/*` 라우트 + 얇은 셸 레이아웃으로 표현했다(레이아웃 상단에 "기존 Admin > NUVIA Growth (데모용 독립 셸)" 표시).

- `src/app/admin/nuvia-growth/layout.tsx` — STUDENTS/COGNITION/TRAINING/THINKING/SELF-MANAGEMENT/GROWTH/CLASS INSIGHT 7메뉴 네비게이션
- `src/lib/admin-guard.tsx` — `viewer_role !== "teacher"`면 범위 안내만 표시
- `src/lib/mock-class-roster.ts` — 학급 roster mock + `isStudentInClass()` 멤버십 검증(랭킹 아님, 단순 목록)
- **개인 View**: `students/page.tsx`(로스터 목록, 정렬 없음) → `growth/page.tsx?learner_id=`(학생 1인의 전체 상세 — 학생 본인 화면과 동일한 컴포넌트 재사용, roster 소속 검증 통과해야 접근 가능)
- **학급 집계 View**: `cognition/`, `training/`, `thinking/`, `self-management/`(각각 `DistributionBar`로 분포만 표시, 개인 식별자 없음), `class-insight/`(참여 안정성 + `suggested_class_strategy`, 랭킹 없음)
- `src/domain/unified-growth-module.ts` — `getClassSummary(classId)` 추가(Class Aggregate API 응답과 Admin UI가 동일 로직 사용), `ClassSummary`에 `training_distribution` 필드 신설(기존 §12/§28 스펙의 TRAINING 메뉴 요건 충족을 위한 추가 필드 — 기존 필드는 변경 없음)
- API 라우트 `unified-growth/class/{class_id}/summary`도 동일하게 `getClassSummary()`로 위임하도록 리팩터
- **role-view API 접근 통제 보강**: 교사가 role-view로 조회하는 `learner_id`가 자신의 class roster에 속하는지 검증하도록 수정(기존에는 teacher 역할이면 무조건 허용되던 gap을 닫음)

`npx tsc --noEmit` Increment 1~4 전체 통과 확인 (exit code 0).

## 이번 증분들에 포함하지 않은 것 (Increment 1~4 시점 — 이후 Increment 5A/5B에서 해결된 항목은 표시)

- ~~실제 로그인 세션 연동~~ → **Increment 5A에서 해결** (`resolveViewerContext()` + mock/real 세션 adapter)
- 모바일 반응형 세부 조정 (아직 미해결)
- ~~Growth Connection Engine의 실제 SAME DOMAIN/SAME PERIOD/MINIMUM DATA 판정 로직~~ → **Increment 5B에서 해결**
- ~~결과지 Deep Link 실제 URL/토큰 처리~~ → **Increment 5B에서 해결**
- ~~Class Aggregate 데이터의 실제 집계 파이프라인~~ → **Increment 5B에서 해결**
- 실제 K-PASS/D-CAS/KIDS/HISTORY/PLANNER/기존 Assessment·자녀관리·교사 Admin **서버 연동 자체**(STEP 0 확인 후 — mock↔real 전환 구조는 준비됨, 실제 엔드포인트 연결만 남음)

## 실행

```bash
npm install
npm run dev
npm test          # Increment 5B 순수 로직 테스트 35건

# 1) 먼저 mock 계정으로 로그인(쿠키 설정)
# http://localhost:3000/dev/login?as=parent
# http://localhost:3000/dev/login?as=learner
# http://localhost:3000/dev/login?as=teacher

# 2) 학생/보호자
# http://localhost:3000/my-nuvia
# http://localhost:3000/my-nuvia/growth
# http://localhost:3000/my-nuvia/insights
# http://localhost:3000/my-nuvia/assessments
# http://localhost:3000/my-nuvia/programs
# http://localhost:3000/my-nuvia/account

# 교사 Admin (먼저 ?as=teacher로 로그인)
# http://localhost:3000/admin/nuvia-growth
```

데모 로그인(mock 전용): `/dev/login?as=parent|learner|teacher`가 세션 쿠키를 설정합니다 — `NUVIA_ADAPTER_MODE=real`에서는 이 라우트가 400을 반환하며 자연히 비활성화됩니다. API 라우트는 브라우저와 동일하게 쿠키/Authorization 헤더에서 세션을 읽습니다(`x-mock-account-id` 헤더 방식은 5A FINAL PATCH에서 제거됨).

---

## 이전 Increment 요약

### Increment 1 상세
- **레이어 분리**: UI → Application(Next.js Route/Page) → Domain(`UnifiedGrowthModule`) → Adapter(mock) → (실서버는 STEP 0 이후)
- **Viewer Context**: 서버에서만 생성, `subject_learner_id` 변경 검증(`isLearnerAllowed`)
- **Adapter 7종 인터페이스 + mock 구현체**
- **Unified Growth API 5종**
- **PATCH 1~4 전부 반영**: cognitive_domains 확장 구조 / relationship_scope(direct·class·institution) / Class Aggregate API / trend·display_direction 분리
- **Empty State 고정 문구 카탈로그**

### Increment 2 상세
- `UnifiedGrowthModule.getTimeline()`
- `ProfileView`/`TrainView`/`ThinkView`/`ManageView`(공통 `GrowthMetricGrid`)
- `MetacognitionView`, `GrowthTimeline`, `GrowthConnectionPanel`, `TrainThinkManageTabs`

### Increment 3 상세
- `src/app/my-nuvia/layout.tsx` 공통 네비게이션
- `viewer_role` 분기(학생 Home / 부모 `ParentNuviaShell`)
- `/my-nuvia/insights`, `/my-nuvia/assessments`(placeholder), `/my-nuvia/programs`, `/my-nuvia/account`(placeholder)
- `SupportTipPanel`, `ProgramGrid`, `StudentOverviewPanel` 공유 컴포넌트 추출
