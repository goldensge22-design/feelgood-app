// Increment 6 — 실제 Next.js 프로덕션 서버(next start)를 상대로 하는 HTTP 레벨 E2E 테스트.
// 사전조건: `npm run build && npx next start -p 3100` 실행 중이어야 한다.
import { test } from "node:test";
import assert from "node:assert/strict";

const BASE = process.env.E2E_BASE_URL ?? "http://localhost:3100";

function getCookie(setCookieHeader: string | null, name: string): string | null {
  if (!setCookieHeader) return null;
  const match = setCookieHeader.split(",").find((c) => c.trim().startsWith(`${name}=`));
  if (!match) return null;
  return match.trim().split(";")[0].split("=")[1];
}

test("E2E-1: 비로그인 상태로 /my-nuvia 접근 → SignedOutNotice(로그인 필요) 렌더", async () => {
  const res = await fetch(`${BASE}/my-nuvia`, { redirect: "manual" });
  assert.equal(res.status, 200); // 리다이렉트가 아니라 페이지 자체에서 안내(현재 아키텍처)
  const html = await res.text();
  assert.match(html, /로그인이 필요합니다/);
});

test("E2E-2: /dev/login?as=parent → 쿠키 설정 + /my-nuvia로 302 리다이렉트", async () => {
  const res = await fetch(`${BASE}/dev/login?as=parent`, { redirect: "manual" });
  assert.equal(res.status, 307); // Next.js NextResponse.redirect 기본 307
  const location = res.headers.get("location");
  assert.match(location ?? "", /\/my-nuvia$/);
  const cookie = getCookie(res.headers.get("set-cookie"), "nuvia_mock_account");
  assert.equal(cookie, "acc-parent-01");
});

test("E2E-3: 로그인 쿠키를 가지고 /my-nuvia 접근 → 부모 IA(ParentNuviaShell) 렌더, OVERVIEW/PROFILE/GROWTH/SUPPORT/PROGRAMS 탭 존재", async () => {
  const res = await fetch(`${BASE}/my-nuvia`, { headers: { cookie: "nuvia_mock_account=acc-parent-01" } });
  assert.equal(res.status, 200);
  const html = await res.text();
  assert.match(html, /MY NUVIA/);
  for (const tab of ["OVERVIEW", "PROFILE", "GROWTH", "SUPPORT", "PROGRAMS"]) {
    assert.match(html, new RegExp(tab));
  }
});

test("E2E-4: 학생 계정으로 /my-nuvia/growth 접근 → 상세 Metric Grid(TRAIN/THINK/MANAGE 탭) 렌더", async () => {
  const res = await fetch(`${BASE}/my-nuvia/growth`, { headers: { cookie: "nuvia_mock_account=acc-learner-01" } });
  assert.equal(res.status, 200);
  const html = await res.text();
  assert.match(html, /Unified Growth Dashboard/);
  assert.match(html, />TRAIN</);
  assert.match(html, />MANAGE</);
});

test("E2E-5: 부모 계정으로 /my-nuvia/growth 접근 → 요약(MY GROWTH) 렌더, 상세 tab 라벨은 없어야 함", async () => {
  const res = await fetch(`${BASE}/my-nuvia/growth`, { headers: { cookie: "nuvia_mock_account=acc-parent-01" } });
  assert.equal(res.status, 200);
  const html = await res.text();
  assert.match(html, /MY GROWTH/);
  assert.doesNotMatch(html, /class="[^"]*rounded-full bg-brand-blueDeep[^"]*">\s*TRAIN\s*</); // TrainThinkManageTabs 버튼 없음
});

test("E2E-6: 교사 계정으로 /my-nuvia 접근 → TeacherScopeNotice(범위 밖 안내)", async () => {
  const res = await fetch(`${BASE}/my-nuvia`, { headers: { cookie: "nuvia_mock_account=acc-teacher-01" } });
  assert.equal(res.status, 200);
  const html = await res.text();
  assert.match(html, /학생·보호자용 MY NUVIA/);
});

test("E2E-7: 학생/보호자 계정으로 /admin/nuvia-growth/students 접근 → AdminScopeNotice(교사 전용 안내)", async () => {
  const res = await fetch(`${BASE}/admin/nuvia-growth/students`, { headers: { cookie: "nuvia_mock_account=acc-learner-01" } });
  assert.equal(res.status, 200);
  const html = await res.text();
  assert.match(html, /교사 Admin 전용/);
});

test("E2E-8: 교사 계정으로 /admin/nuvia-growth/students 접근 → 학급 roster(학생 A/B) 렌더", async () => {
  const res = await fetch(`${BASE}/admin/nuvia-growth/students`, { headers: { cookie: "nuvia_mock_account=acc-teacher-01" } });
  assert.equal(res.status, 200);
  const html = await res.text();
  assert.match(html, /학생 A/);
  assert.match(html, /학생 B/);
});

test("E2E-9: API — 인증 없이 /api/unified-growth/{id}/overview 호출 → 401", async () => {
  const res = await fetch(`${BASE}/api/unified-growth/learner-0001/overview`);
  assert.equal(res.status, 401);
});

test("E2E-10: API — 부모 계정으로 자신의 자녀(learner-0001) overview 조회 → 200 + 실제 데이터", async () => {
  const res = await fetch(`${BASE}/api/unified-growth/learner-0001/overview`, {
    headers: { cookie: "nuvia_mock_account=acc-parent-01" },
  });
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.equal(body.profile_summary.assessment_id, "a-001");
  assert.ok(Array.isArray(body.active_programs));
});

test("E2E-11: API — 부모 계정으로 등록되지 않은 learner_id 조회 → 403", async () => {
  const res = await fetch(`${BASE}/api/unified-growth/learner-9999/overview`, {
    headers: { cookie: "nuvia_mock_account=acc-parent-01" },
  });
  assert.equal(res.status, 403);
});

test("E2E-12: API — 부모 계정으로 Visibility Policy가 growth_preview를 실제로 축소했는지 확인(대표 metric 1개)", async () => {
  const res = await fetch(`${BASE}/api/unified-growth/learner-0001/overview`, {
    headers: { cookie: "nuvia_mock_account=acc-parent-01" },
  });
  const body = await res.json();
  const trainMetricCount = Object.keys(body.growth_preview.train.metrics).length;
  assert.ok(trainMetricCount <= 1, `parent는 대표 metric 1개 이하여야 함 (실제: ${trainMetricCount})`);
});

test("E2E-13: API — 학생 계정으로 같은 learner의 overview 조회 → 축소되지 않은 전체 metric", async () => {
  const res = await fetch(`${BASE}/api/unified-growth/learner-0001/overview`, {
    headers: { cookie: "nuvia_mock_account=acc-learner-01" },
  });
  const body = await res.json();
  const trainMetricCount = Object.keys(body.growth_preview.train.metrics).length;
  assert.equal(trainMetricCount, 2); // accuracy + strategy
});

test("E2E-14: API — 교사 계정으로 자기 학급 Class Aggregate 조회 → 200, 학생 식별자 없는 집계", async () => {
  const res = await fetch(`${BASE}/api/unified-growth/class/class-9-2/summary`, {
    headers: { cookie: "nuvia_mock_account=acc-teacher-01" },
  });
  assert.equal(res.status, 200);
  const body = await res.json();
  assert.ok(Array.isArray(body.cognitive_distribution.labels));
  assert.equal(JSON.stringify(body).includes("learner-0001"), false); // 응답 어디에도 개인 식별자 없음
});

test("E2E-15: API — 학생/보호자 계정으로 Class Aggregate 조회 → 403", async () => {
  const res = await fetch(`${BASE}/api/unified-growth/class/class-9-2/summary`, {
    headers: { cookie: "nuvia_mock_account=acc-parent-01" },
  });
  assert.equal(res.status, 403);
});

test("E2E-16: Deep Link — 유효 토큰, 비로그인 상태 → /dev/login?redirect=... 로 리다이렉트(mock 모드)", async () => {
  // mock adapter의 issueMockDeepLinkToken 포맷을 그대로 재현
  const payload = { learner_id: "learner-0001", assessment_id: "a-001", purpose: "assessment_report_deep_link", iat: Math.floor(Date.now() / 1000), exp: Math.floor(Date.now() / 1000) + 600 };
  const token = "mocklink." + Buffer.from(JSON.stringify(payload)).toString("base64url");

  const res = await fetch(`${BASE}/report/deep-link?token=${token}`, { redirect: "manual" });
  assert.equal(res.status, 307);
  const location = res.headers.get("location") ?? "";
  assert.match(location, /\/dev\/login\?redirect=/);
});

test("E2E-17: Deep Link — 유효 토큰 + 로그인 상태 + 허용된 learner → /my-nuvia/growth 이동 + learner 선택 쿠키 설정", async () => {
  const payload = { learner_id: "learner-0001", assessment_id: "a-001", purpose: "assessment_report_deep_link", iat: Math.floor(Date.now() / 1000), exp: Math.floor(Date.now() / 1000) + 600 };
  const token = "mocklink." + Buffer.from(JSON.stringify(payload)).toString("base64url");

  const res = await fetch(`${BASE}/report/deep-link?token=${token}`, {
    redirect: "manual",
    headers: { cookie: "nuvia_mock_account=acc-parent-01" },
  });
  assert.equal(res.status, 307);
  assert.match(res.headers.get("location") ?? "", /\/my-nuvia\/growth$/);
  const learnerCookie = getCookie(res.headers.get("set-cookie"), "nuvia_selected_learner");
  assert.equal(learnerCookie, "learner-0001");
});

test("E2E-18: Deep Link — 유효 토큰이지만 계정에 없는 learner → /report/deep-link/forbidden", async () => {
  const payload = { learner_id: "learner-9999", assessment_id: "a-999", purpose: "assessment_report_deep_link", iat: Math.floor(Date.now() / 1000), exp: Math.floor(Date.now() / 1000) + 600 };
  const token = "mocklink." + Buffer.from(JSON.stringify(payload)).toString("base64url");

  const res = await fetch(`${BASE}/report/deep-link?token=${token}`, {
    redirect: "manual",
    headers: { cookie: "nuvia_mock_account=acc-parent-01" },
  });
  assert.equal(res.status, 307);
  assert.match(res.headers.get("location") ?? "", /\/report\/deep-link\/forbidden$/);
});

test("E2E-19: Deep Link — 만료된 토큰 → /report/deep-link/invalid", async () => {
  const payload = { learner_id: "learner-0001", assessment_id: "a-001", purpose: "assessment_report_deep_link", iat: Math.floor(Date.now() / 1000) - 1200, exp: Math.floor(Date.now() / 1000) - 600 };
  const token = "mocklink." + Buffer.from(JSON.stringify(payload)).toString("base64url");

  const res = await fetch(`${BASE}/report/deep-link?token=${token}`, { redirect: "manual" });
  assert.equal(res.status, 307);
  assert.match(res.headers.get("location") ?? "", /\/report\/deep-link\/invalid$/);
});

test("E2E-20: Deep Link — token 파라미터 자체가 없음 → invalid", async () => {
  const res = await fetch(`${BASE}/report/deep-link`, { redirect: "manual" });
  assert.equal(res.status, 307);
  assert.match(res.headers.get("location") ?? "", /\/report\/deep-link\/invalid$/);
});

test("E2E-21: learner 선택 유지 — select-learner로 자녀 B 선택 후 /my-nuvia/growth 재방문해도 쿠키가 유지된 learner를 사용", async () => {
  const selectRes = await fetch(`${BASE}/my-nuvia/select-learner?learner_id=learner-0002&redirect=/my-nuvia`, {
    redirect: "manual",
    headers: { cookie: "nuvia_mock_account=acc-parent-01" },
  });
  assert.equal(selectRes.status, 307);
  const learnerCookie = getCookie(selectRes.headers.get("set-cookie"), "nuvia_selected_learner");
  assert.equal(learnerCookie, "learner-0002");

  // 쿼리 없이 재방문 — 쿠키만으로 learner-0002가 유지되는지 확인
  const res = await fetch(`${BASE}/api/unified-growth/learner-0002/overview`, {
    headers: { cookie: "nuvia_mock_account=acc-parent-01" },
  });
  assert.equal(res.status, 200);
});
