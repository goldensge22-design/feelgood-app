# Increment 5B — TEST CASES

실행: `npm test` (Node 내장 테스트 러너 + `tsx`, 별도 테스트 프레임워크 설치 없음)

```
tests 48
pass 48
fail 0
```

## -1. Increment 6 FINAL PATCH 추가 테스트

### PATCH 1 — pre-assessment epoch 분리 (`epoch.test.ts`, TC-EPOCH-1~6)

| ID | 조건 | 기대 결과 |
|---|---|---|
| TC-EPOCH-1 | 첫 검사 이전 activity | `phase: "pre_assessment"`, `epoch_index: null` |
| TC-EPOCH-2 | 첫 검사 이후 ~ 재검사 전 activity | `phase: "assessment_epoch"`, `epoch_index: 0` |
| TC-EPOCH-3 | 재검사 당일 activity | `epoch_index: 1` (새 epoch에 포함) |
| TC-EPOCH-4 | 재검사 이후 activity | `epoch_index: 1` — pre_assessment/epoch 0과 섞이지 않음 |
| TC-EPOCH-5 | 검사 이력이 전혀 없음 | `phase: "pre_assessment"`, `epoch_index: null` (더 이상 epoch 0으로 넣지 않음 — 이전 동작에서 변경됨) |
| TC-EPOCH-6 | 첫 검사 이전/이후/재검사 이후 3개 이벤트 | 3개 모두 서로 다른 `phase:epoch_index` 조합 — `Set` 크기 3으로 확인 |

`GrowthTimeline` 컴포넌트도 `phase === "pre_assessment"`인 이벤트를 별도 섹션("검사 이전")으로 렌더링하고, `epochs` 순회 루프는 `phase === "assessment_epoch"`인 이벤트만 필터링하도록 수정됨(코드 리뷰로 확인 — UI 자체는 E2E 스모크 테스트 범위 밖).

### PATCH 2 — 부모 대표 metric 선택 (`primary-metric.test.ts`, TC-PM-1~5)

| ID | 조건 | 기대 결과 |
|---|---|---|
| TC-PM-1 | `primary_metric_key` 있음 (`a`), priority는 `b`가 먼저 | priority 무시하고 `a` 선택 |
| TC-PM-2 | `primary_metric_key` 없음, priority(`b,a,c`) 중 `b`는 데이터 없고 `a`는 있음 | priority 순서상 존재하는 첫 metric `a` 선택 |
| TC-PM-3 | `primary_metric_key` 없음 + priority에 해당하는 metric도 전혀 없음 | **임의 선택하지 않고 `metrics: {}`** |
| TC-PM-4 | `primary_metric_key`가 지정됐지만 실제 데이터에 없음(유효하지 않음) | priority로 fallback |
| TC-PM-5 | 대표 지표 없음 | `growth_data_status`/`updated_at` 등 나머지 필드는 그대로 유지 |

기존 TC-VIS-3(parent 대표 metric 1개 축소 확인)는 수정 없이 그대로 통과 — `Object.keys()` 첫 번째 항목이 우연히 새 priority 순서와 같아서(`accuracy`가 KIDS priority 1순위) 회귀 없이 자연스럽게 넘어감.

---

## 0. 5B FINAL PATCH 추가 테스트

| ID | 파일 | 검증 |
|---|---|---|
| TC-VIS-7~10 | `visibility-policy.test.ts` | insight 도메인: learner는 `student_reflection_text`/`atomic_behavior_log` 전체 노출, parent/teacher/institution은 allow-list(observation/interpretation/actions)만 남고 사적 필드 제거 |
| TC-CA-4~6, TC-CA-9 | `class-aggregate.test.ts` | `buildClassStrategy`가 metric 근거 없이는 일반 문구만 반환, `time_prediction_accuracy`가 실제 최다 근거일 때만 시간예측 문구 반환, 다른 metric이 최다면 일반 문구 유지 |

Deep Link 로그인 리다이렉트(mock→`/dev/login`, real→`FEELGOOD_LOGIN_URL_TEMPLATE`)는 `resolveLoginUrl()`이 `getAdapterMode()`에 의존하는 순수하지 않은 함수라 별도 unit test 대신 코드 경로 검토로 확인했다 — mock 모드에서는 기존 TC-DL 테스트들이 여전히 유효하다(모드 분기 지점 자체는 바뀌지 않음).

---

아래는 카테고리별 테스트 케이스입니다. 자동 실행되는 것은 파일 경로와 테스트 ID를, 실제 서버/브라우저가 있어야 끝까지 재현되는 것(Deep Link의 로그인 리다이렉트 등)은 **시나리오 워크스루**로 별도 표시했습니다.

---

## 1. Growth Connection Engine — `src/domain/__tests__/growth-connection-engine.test.ts`

| ID | 조건 | 기대 결과 |
|---|---|---|
| TC-GCE-1 | 실제 프로덕션 기본값(`observation-thresholds.ts` 전부 `null`) 그대로, 5조건 중 나머지가 다 충족돼도 threshold만 미확정 | `INSUFFICIENT_DATA` — **임의 숫자로 통과시키지 않는다는 요구사항의 핵심 검증** |
| TC-GCE-2 | SAME DOMAIN 미충족(같은 domain에 기여하는 Branch가 1개뿐) | 해당 domain은 결과에서 아예 제외(빈 배열) |
| TC-GCE-3 | VALID METRIC 미충족(태그 미등록 metric만 존재) | 결과에서 제외 |
| TC-GCE-4 | threshold를 5로 주입, 모든 조건 충족 + 방향(`display_direction`) 일치 | `CONSISTENT_PATTERN` |
| TC-GCE-5 | threshold를 3으로 주입, 조건 충족하지만 방향 불일치 | `OBSERVED_TOGETHER` |
| TC-GCE-6 | threshold는 충족 기준 이상으로 주입했으나 한 소스의 `observation_count`가 기준 미만 | `INSUFFICIENT_DATA` (MINIMUM DATA 실패) |
| TC-GCE-7 | 한 소스에 `window`(관찰 기간)가 없음 | `INSUFFICIENT_DATA` (SAME PERIOD 판정 불가) |
| TC-GCE-8 | (화이트박스) `mergePeriod`에 겹치지 않는 두 구간 입력 | `null` 반환 |

**인과 해석 금지 확인**: `displayText()`가 만드는 3가지 문구(`INSUFFICIENT_DATA`/`OBSERVED_TOGETHER`/`CONSISTENT_PATTERN`) 어디에도 "때문에", "덕분에", "영향으로" 등 인과 접속 표현이 없습니다 — 코드 리뷰로 확인, 별도 assertion은 없음(문구가 3개로 고정되어 있어 회귀 시 코드 diff에서 바로 드러남).

---

## 2. Visibility Policy — `src/domain/__tests__/visibility-policy.test.ts`

| ID | role | 기대 결과 |
|---|---|---|
| TC-VIS-1 | learner | `growth_preview` 전체 metric 그대로 노출 |
| TC-VIS-2 | teacher | 개인 View 기준 전체 상세 그대로(§17) |
| TC-VIS-3 | parent | domain당 대표 metric **1개**로 축소, `metacognition`은 `prediction_vs_actual`만 유지·나머지 `null`, `growth_data_status`/`task_breakdown_observation`은 유지 |
| TC-VIS-4 | institution | metric 자체 노출 없음(빈 객체), `growth_data_status`(집계용 상태값)만 유지 |
| TC-VIS-5 | 임의 role | `domain !== "growth"`면 그대로 통과 |
| TC-VIS-6 | parent | `growth` 도메인이어도 payload가 GrowthPreview 모양이 아니면(예: `GrowthConnection[]`) 그대로 통과 — 다른 payload를 잘못 축소하지 않음 |

---

## 3. Class Aggregate — `src/domain/__tests__/class-aggregate.test.ts`

| ID | 검증 대상 | 기대 결과 |
|---|---|---|
| TC-CA-1 | `tallyLabels(["Attention","Planning","Attention"])` | Attention count=2, Planning count=1 |
| TC-CA-2 | `tallyLabels([])` | 빈 분포 |
| TC-CA-3 | `tallyDirections(...)` 2명 학생, "improving" 2회 | "개선 경향" count=2, **반환 객체 키는 `labels`/`counts`뿐 — 학생 식별자 없음을 구조적으로 확인** |
| TC-CA-4 | `buildClassStrategy` 최빈값 "관찰 필요" | 시간예측 관련 고정 문구 반환 |
| TC-CA-5 | `buildClassStrategy` 빈 분포 | 빈 배열(제안 없음) |
| TC-CA-6 | `buildClassStrategy` 출력 문구 | `/\d+등|1위|랭킹|순위/` 정규식 불일치 확인 — **학생 개인 순위 표현이 없음을 검증** |

### 시나리오 워크스루 (통합, 자동 테스트 아님)
`UnifiedGrowthModule.getClassSummary("class-9-2")` 실행 시 실제 흐름:
1. `ClassRosterAdapter.getRosterLearnerIds("class-9-2")` → `["learner-0001", "learner-0002"]`
2. 각 learner에 대해 assessment/program/kids/history/planner를 병렬 조회 (learner-0001은 HISTORY 미사용 → `no_data`로 자연 처리)
3. `cognitive_distribution`은 두 학생의 `support_areas`를 합쳐 집계 → learner-0001("Attention") + learner-0002("Planning") = `{labels:["Attention","Planning"], counts:[1,1]}`
4. `training_distribution`/`thinking_distribution`/`self_management_distribution`은 각 Branch의 `display_direction`을 집계
5. 응답 어디에도 `learner_id`나 이름이 없음 — `ClassSummary` 타입 자체에 그런 필드가 없어 컴파일 타임에 보장됨

---

## 4. Deep Link — `src/adapters/mock/__tests__/deep-link-token-adapter.test.ts`

| ID | 케이스 | 기대 결과 |
|---|---|---|
| TC-DL-1 | **정상**: 유효한 서명·미만료 토큰 | `learner_id`/`assessment_id` 정확히 반환 |
| TC-DL-2 | **만료**: `exp`가 과거 | `null` (사유 구분 없음) |
| TC-DL-3 | **형식오류**: prefix 없는 임의 문자열 | `null` |
| TC-DL-4 | **형식오류**: base64url은 되지만 JSON 아님 | `null` |
| TC-DL-5 | **권한없음**: 토큰은 유효하지만 `relationship_scope`에 없는 learner | `isLearnerAllowed()` → `false` (→ route에서 `/report/deep-link/forbidden`) |
| TC-DL-6 | **정상**: `relationship_scope`에 등록된 learner | `isLearnerAllowed()` → `true` (→ `/my-nuvia/growth`로 진행) |

### 시나리오 워크스루 (전체 흐름, `src/app/report/deep-link/route.ts`)
```
GET /report/deep-link?token=<opaque>
  1) token 없음 또는 verify() 실패           → /report/deep-link/invalid (TC-DL-2/3/4로 커버)
  2) resolveViewerContextFromRequest() null  → /dev/login?redirect=<원래 deep-link URL 그대로>
                                                 (로그인 후 동일 URL로 자동 복귀 — 재사용 가능한 token이므로 안전)
  3) relationship_scope 불허                 → /report/deep-link/forbidden (TC-DL-5로 커버)
  4) 허용                                     → SELECTED_LEARNER_COOKIE 설정 후
                                                 learner/parent: /my-nuvia/growth
                                                 teacher: /admin/nuvia-growth/growth?learner_id=...
```
**민감 데이터 노출 확인**: 이 흐름에서 URL에 등장하는 값은 `token`(opaque), 로그인 리다이렉트용 `redirect`(같은 앱 내부 경로), `as`(mock 전용)뿐입니다. 검사 점수·강점/지원영역 등은 verify() 응답 바디에만 있고 URL에 나타나지 않습니다.

---

## 5. Epoch — `src/domain/__tests__/epoch.test.ts`

| ID | occurred_at | 기대 epoch_index |
|---|---|---|
| TC-EPOCH-1 | 첫 검사(2025-09-01) 이전 활동(2025-12-01) *(주: 실제로는 검사 이후지만 다음 검사 이전 — 표 아래 주석 참고)* | 0 |
| TC-EPOCH-2 | 재검사 당일(2026-03-10) | 1 |
| TC-EPOCH-3 | 재검사 이후(2026-09-01) | 1 (이전 epoch 0과 합쳐지지 않음) |
| TC-EPOCH-4 | 검사 이력이 전혀 없음 | 0 (단일 암묵적 epoch) |
| TC-EPOCH-5 | epoch 0 시점과 epoch 1 시점 비교 | 서로 다른 index — 연속 성장선으로 합쳐지지 않음을 직접 확인 |

> TC-EPOCH-1의 기준 fixture는 `assessments = [{assessed_at:"2025-09-01"}, {assessed_at:"2026-03-10"}]`이며, `"2025-12-01"`은 첫 검사 이후·재검사 이전이므로 epoch 0(v2 구간)에 속합니다.

### 시나리오 워크스루 (UI, `GrowthTimeline` 컴포넌트)
`learner-0001`은 mock에서 검사 이력 2건(v2 2025-09-01, v3 2026-03-10)을 가지므로 `/my-nuvia/growth` 진입 시 Timeline이 "Epoch 1"/"Epoch 2" 두 구간으로 분리되어 렌더링되고, PLANNER의 `last_activity_at="2026-09-08"` 이벤트는 Epoch 2(v3 이후)에만 나타납니다 — v2 구간과 시각적으로 이어지지 않습니다.

---

## 6. Partial Failure — `src/domain/__tests__/partial-failure.test.ts`

| ID | 실패 소스 | AdapterError.kind | 기대 결과 |
|---|---|---|---|
| TC-PF-1 | PLANNER만 실패 | `timeout` | 나머지(assessment/kids/history) 정상 반환, `partial_errors`에 `{source:"planner", kind:"timeout"}` 기록 |
| TC-PF-2 | assessment 실패 | `unauthorized` | **흡수하지 않고 그대로 throw** — 전체 요청 실패(세션 무효를 partial-data로 감추지 않음) |
| TC-PF-3 | programs 실패 | `invalid_config` | **흡수하지 않고 그대로 throw** — 배포 설정 오류는 즉시 드러나야 함 |
| TC-PF-4 | assessment + programs 동시 실패 | `not_found` / `network_error` | 각각 독립적으로 `partial_errors`에 기록, 나머지 필드는 fallback 값으로 정상 렌더 |

### 시나리오 워크스루 (UI)
`OverviewResponse.partial_errors`가 채워지면 `src/components/PartialErrorBanner.tsx`가 Home 화면 상단에 "OO을 일시적으로 불러오지 못했습니다. 나머지 정보는 정상적으로 표시됩니다." 배너를 띄우고, 나머지 카드(Profile/Program/Growth Preview 등)는 그대로 렌더됩니다. Class Aggregate(`getClassSummary`)도 동일 원칙을 별도 `safeFetch()`로 적용받아, 학생 1명의 API 실패가 학급 집계 전체를 막지 않습니다(자동 테스트는 TC-CA 쪽 순수 함수 테스트로 간접 커버, 통합 경로는 §3 워크스루 참고).

---

## 커버되지 않은 것 (명시)

- 실제 HTTP 서버를 띄운 상태에서의 E2E 테스트(Next.js dev 서버 + 브라우저) — 이번 단계는 unit-level 순수 함수/모듈 테스트까지입니다.
- `/dev/login` 리다이렉트 루프의 실제 브라우저 왕복(쿠키 저장/재요청)은 코드 경로상 보장되나 자동화된 브라우저 테스트는 없습니다.
- 실제 FeelGood 서버가 없는 상태이므로 `real/*.real.ts` adapter들의 실제 HTTP 응답 파싱은 테스트되지 않았습니다(계약만 문서화 — `INTEGRATION_READINESS.md` 참고).
