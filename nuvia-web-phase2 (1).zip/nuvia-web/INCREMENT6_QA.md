# Increment 6 — End-to-End Integration & QA

기준: `INCREMENT 5B — APPROVED FOR E2E`

## 실행 방법

**독립 실행(권장)** — 한 줄로 build/server/test/cleanup까지 전부:
```bash
npm run verify
```

**수동 단계별**:
```bash
npm run build
npx next start -p 3100 &     # 별도 터미널/백그라운드
npm run test:e2e             # E2E_BASE_URL 환경변수로 다른 포트/호스트 지정 가능
```

## 결과

```
npm run build   → 22개 라우트 전부 컴파일 성공(정적 9 + 동적 13)
npx tsc --noEmit → exit code 0
npm test         → 48/48 pass (순수 로직 단위 테스트, Increment 5B + 6 FINAL PATCH)
npm run test:e2e → 21/21 pass (실제 next start 서버 대상 HTTP 레벨)
```

## 발견 및 수정한 버그 1건

**`/my-nuvia` Home 페이지에 교사(teacher) 가드 누락.**

- 증상: E2E-6("교사 계정으로 `/my-nuvia` 접근 → TeacherScopeNotice 안내")이 실패 — 실제로는 "조회할 대상자가 없습니다" 문구가 렌더됨(teacher의 `relationship_scope.learner_ids`가 `undefined`라 빈 배열로 처리되어 우연히 에러 없이 통과했을 뿐, 의도한 안내 화면이 아니었음).
- 원인: Increment 3에서 `/my-nuvia/growth`, `/insights`, `/assessments`, `/programs`, `/account` 5개 페이지에는 `if (viewer.viewer_role === "teacher") return <TeacherScopeNotice .../>;`를 추가했지만, 정작 Home 페이지 본체(`/my-nuvia/page.tsx`)에는 이 가드를 빠뜨렸다 — 순수 함수 단위 테스트(Increment 5B)는 페이지 컴포넌트 자체를 렌더링하지 않으므로 이 누락을 잡지 못했고, **실제 서버를 띄워 HTTP 레벨로 확인한 Increment 6에서 처음 발견됨.**
- 수정: `src/app/my-nuvia/page.tsx`에 동일한 가드 추가. 다른 5개 페이지와 패턴 일치 확인(아래 표).
- 재발 방지: 이번에 6개 페이지 전부의 가드 순서(`SignedOutNotice` → `TeacherScopeNotice` → 본문)를 재점검해 통일했다.

| 페이지 | SignedOutNotice | TeacherScopeNotice |
|---|---|---|
| `/my-nuvia` | ✅ | ✅ (이번에 추가) |
| `/my-nuvia/growth` | ✅ | ✅ |
| `/my-nuvia/insights` | ✅ | ✅ |
| `/my-nuvia/assessments` | ✅ | ✅ |
| `/my-nuvia/programs` | ✅ | ✅ |
| `/my-nuvia/account` | ✅ | ✅ |

## E2E 테스트 커버리지 (`e2e/smoke.test.ts`, 21건)

| 구간 | 테스트 |
|---|---|
| 인증/역할 분기 | E2E-1(비로그인) · E2E-2(mock 로그인 쿠키) · E2E-3(부모 IA 5탭) · E2E-4(학생 상세 Metric Grid) · E2E-5(부모 요약만) · E2E-6(교사→학생 페이지 차단) · E2E-7(학생→Admin 차단) · E2E-8(교사 roster) |
| API 인증/인가 | E2E-9(401) · E2E-10(정상 200) · E2E-11(다른 learner 403) |
| Visibility Policy(HTTP 레벨 실동작 확인) | E2E-12(parent 대표 metric 1개로 축소) · E2E-13(learner 전체 metric) |
| Class Aggregate | E2E-14(교사 200 + 개인 식별자 없음) · E2E-15(학생/부모 403) |
| Deep Link 전체 흐름 | E2E-16(비로그인→`/dev/login`) · E2E-17(정상→`/my-nuvia/growth`+쿠키) · E2E-18(권한없음→forbidden) · E2E-19(만료→invalid) · E2E-20(token 없음→invalid) |
| learner 선택 유지 | E2E-21(select-learner 쿠키가 이후 API 호출에도 유지) |

## 커버되지 않은 것 (다음 단계 또는 수동 QA 필요)

- **모바일 반응형** — 이번 E2E는 HTML 응답 검증까지만이고 실제 뷰포트 렌더링/터치 인터랙션은 확인하지 않음(브라우저 기반 도구 필요, 예: Playwright)
- **real 모드 E2E** — `.env`에 실제 FeelGood 엔드포인트가 없어 `NUVIA_ADAPTER_MODE=real`로는 실행 불가. 실서버 연결 후 동일한 `e2e/smoke.test.ts`를 `NUVIA_ADAPTER_MODE=real E2E_BASE_URL=...`로 재실행하는 것을 권장(테스트 자체는 mode에 의존하지 않는 사용자 흐름 기준이라 그대로 재사용 가능)
- **Deep Link의 real 모드 로그인 리다이렉트**(`FEELGOOD_LOGIN_URL_TEMPLATE`)는 실제 템플릿 값이 없어 검증 불가 — STEP 0 이후 확인 필요
- **동시성/부하 테스트** — 없음
- **브라우저 실사용 시나리오**(클릭 흐름, 폼 제출, JS 인터랙션인 `TrainThinkManageTabs`/`LearnerSelector` 등 클라이언트 컴포넌트의 실제 동작)는 HTML 정적 검증까지만 하고 hydration 이후 동작은 확인하지 않음

## 수동 QA 체크리스트 (권장, 브라우저에서 직접)

- [ ] `/dev/login?as=parent` → `LearnerSelector`로 자녀 A/B 전환 시 화면이 즉시 갱신되는가
- [ ] `/my-nuvia/growth`(학생)에서 `TrainThinkManageTabs` 클릭 시 탭 전환이 매끄러운가
- [ ] 모바일 너비(375px)에서 nav/카드 레이아웃이 깨지지 않는가
- [ ] `PartialErrorBanner`가 실제로 한 소스 실패 시에만 뜨고 나머지 카드는 정상 렌더되는가(mock adapter에 일부러 에러를 주입해 확인)
- [ ] 교사 Admin의 `DistributionBar` 색상/수치가 실제 학생 데이터 변경에 따라 바뀌는가
