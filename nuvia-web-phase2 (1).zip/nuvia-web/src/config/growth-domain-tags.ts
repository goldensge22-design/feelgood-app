// §12 Growth Connection 필수조건 중 SAME DOMAIN/VALID METRIC의 근거 테이블.
// "사전 정의된 연관 cognitive_domain/behaviour tag" — 인과 주장이 아니라 순수 분류표다.
// 여기 없는 metric은 VALID METRIC 조건을 만족하지 못해 Connection 후보에서 제외된다.

import { KidsMetricKey, HistoryMetricKey, PlannerMetricKey } from "../types/growth";

export interface DomainTag {
  domain_key: string;
  display_label: string;
}

export const KIDS_DOMAIN_TAGS: Partial<Record<KidsMetricKey, DomainTag>> = {
  strategy: { domain_key: "planning_stepwise", display_label: "계획 및 단계화" },
};

export const HISTORY_DOMAIN_TAGS: Partial<Record<HistoryMetricKey, DomainTag>> = {
  evidence: { domain_key: "evidence_based_reasoning", display_label: "근거 기반 판단" },
  comparison: { domain_key: "planning_stepwise", display_label: "계획 및 단계화" },
};

export const PLANNER_DOMAIN_TAGS: Partial<Record<PlannerMetricKey, DomainTag>> = {
  plan_order_consistency: { domain_key: "planning_stepwise", display_label: "계획 및 단계화" },
  time_prediction_accuracy: { domain_key: "time_estimation", display_label: "시간 예측" },
};
