// PATCH 2 — "summary_metric_priority" — Branch가 명시적으로 선언하는 대표 metric 우선순위.
// Unified Growth Module은 이 목록을 그대로 참조만 할 뿐, 어떤 metric이 더 중요한지
// 스스로 판단하지 않는다. primary_metric_key가 없는 개별 응답에서만 fallback으로 쓰인다.
// 실제로는 각 Branch(K-PASS/D-CAS 아님, KIDS/HISTORY/PLANNER) 팀이 정의해야 하는 값이며,
// 여기 적힌 순서는 STEP 0 이전 임시값이다.

import { KidsMetricKey, HistoryMetricKey, PlannerMetricKey } from "../types/growth";

export const KIDS_METRIC_PRIORITY: readonly KidsMetricKey[] = [
  "accuracy",
  "strategy",
  "difficulty",
  "latency",
  "error_pattern",
  "adherence",
];

export const HISTORY_METRIC_PRIORITY: readonly HistoryMetricKey[] = [
  "evidence",
  "cause_effect",
  "chronology",
  "perspective",
  "comparison",
  "decision",
];

export const PLANNER_METRIC_PRIORITY: readonly PlannerMetricKey[] = [
  "time_prediction_accuracy",
  "start_accuracy",
  "planning_accuracy",
  "focus_stability",
  "completion_reliability",
  "recovery_skill",
  "plan_order_consistency",
  "metacognitive_accuracy",
];
