// §28 "Branch별 minimum observation 기준" — STEP 0 확인 전까지 임의 숫자를 만들지 않는다.
// 모든 domain의 기준을 null(미확정)로 시작한다. null인 domain은 Growth Connection Engine이
// 항상 INSUFFICIENT_DATA를 반환한다 — 실제 관찰 횟수가 아무리 많아도 마찬가지다.
//
// 실제 기준이 STEP 0에서 확정되면 이 배열의 minimum_observations 값만 채우면 된다
// (엔진 로직은 변경할 필요 없음).

export interface ObservationThresholdConfig {
  domain_key: string;
  minimum_observations: number | null;
}

export const OBSERVATION_THRESHOLDS: ObservationThresholdConfig[] = [
  { domain_key: "planning_stepwise", minimum_observations: null },
  { domain_key: "time_estimation", minimum_observations: null },
  { domain_key: "evidence_based_reasoning", minimum_observations: null },
];

export function getMinimumObservations(domainKey: string): number | null {
  const found = OBSERVATION_THRESHOLDS.find((t) => t.domain_key === domainKey);
  return found ? found.minimum_observations : null; // 등록되지 않은 domain도 미확정과 동일하게 취급
}
