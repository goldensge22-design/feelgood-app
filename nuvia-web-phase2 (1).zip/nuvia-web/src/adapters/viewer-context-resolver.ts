import { ViewerContextResolver, AuthSessionAdapter, RelationshipScopeAdapter } from "./session-types";
import { ViewerContext } from "../types/viewer-context";

/**
 * (1)+(3) ViewerContext 조립 절차 — mock/real 어느 쪽이든 동일하게 사용된다.
 * AuthSessionAdapter(누가 로그인했는가) + RelationshipScopeAdapter(무엇을 볼 수 있는가)를
 * 합성할 뿐, 어느 구현체가 주입됐는지는 모른다(mode-agnostic).
 * subject_learner_id는 이 단계에서 확정하지 않는다(§29 — 선택은 별도 절차에서 검증 후 채워짐).
 */
export function createViewerContextResolver(
  auth: AuthSessionAdapter,
  relationshipScope: RelationshipScopeAdapter
): ViewerContextResolver {
  return {
    async resolve(request) {
      const session = await auth.resolveAccountId(request);
      if (!session) return null;

      const { viewer_role, relationship_scope } = await relationshipScope.resolveScope(session.account_id);

      const ctx: ViewerContext = {
        account_id: session.account_id,
        viewer_role,
        subject_learner_id: null,
        relationship_scope,
      };
      return ctx;
    },
  };
}
