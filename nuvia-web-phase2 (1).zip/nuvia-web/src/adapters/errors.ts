// Integration Readiness — 모든 Adapter(mock/real 공통)가 던지는 에러는 이 타입으로 통일한다.
// Domain Layer는 AdapterError.kind만 보고 partial-data 처리 여부를 결정한다(§9 처리 규칙).

export type AdapterErrorKind =
  | "unauthorized"     // 세션/토큰 만료 또는 권한 없음 — 재로그인/403 유도
  | "timeout"          // 응답 지연 — 해당 영역만 Empty/일시적 오류로 표시, 나머지는 정상 렌더
  | "not_found"        // 대상 learner/assessment/program 없음 — Empty State로 처리(에러 아님)
  | "upstream_error"   // 실제 FeelGood 서버 5xx 등 — 해당 영역만 "일시적으로 불러올 수 없습니다"
  | "network_error"    // 연결 자체 실패
  | "invalid_config";  // .env 미설정 등 — 개발/배포 설정 문제, 즉시 실패해야 함(개발자용 에러)

export class AdapterError extends Error {
  readonly kind: AdapterErrorKind;
  readonly adapter: string; // 어떤 adapter에서 발생했는지 (로깅/모니터링용)
  readonly cause?: unknown;

  constructor(kind: AdapterErrorKind, adapter: string, message: string, cause?: unknown) {
    super(message);
    this.name = "AdapterError";
    this.kind = kind;
    this.adapter = adapter;
    this.cause = cause;
  }
}

/** 실제 서버 호출에 타임아웃을 강제한다. 각 real adapter가 공통으로 사용. */
export async function withAdapterTimeout<T>(
  adapterName: string,
  promise: Promise<T>,
  timeoutMs: number
): Promise<T> {
  let timer: ReturnType<typeof setTimeout>;
  const timeout = new Promise<never>((_, reject) => {
    timer = setTimeout(() => reject(new AdapterError("timeout", adapterName, `${adapterName} timed out after ${timeoutMs}ms`)), timeoutMs);
  });
  try {
    return await Promise.race([promise, timeout]);
  } finally {
    clearTimeout(timer!);
  }
}

/** fetch Response를 AdapterError로 정규화한다. real adapter 구현체가 공통으로 사용. */
export function toAdapterError(adapterName: string, status: number, body?: unknown): AdapterError {
  if (status === 401 || status === 403) return new AdapterError("unauthorized", adapterName, `${adapterName} unauthorized (${status})`, body);
  if (status === 404) return new AdapterError("not_found", adapterName, `${adapterName} not found`, body);
  if (status >= 500) return new AdapterError("upstream_error", adapterName, `${adapterName} upstream error (${status})`, body);
  return new AdapterError("upstream_error", adapterName, `${adapterName} unexpected status (${status})`, body);
}
