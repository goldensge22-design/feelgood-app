import { KidsGrowthAdapter } from "../types";
import { fetchAdapterJson } from "./http";
import { adapterConfig } from "./config";

const NAME = "KidsGrowthAdapter(real)";

/**
 * 실제 계약: NUVIA KIDS가 이미 계산한 승인된 summary metric만 그대로 읽는다 — 이
 * adapter/Domain Layer는 원본 데이터를 재계산하지 않는다(§7, read-only 원칙).
 * trend(원본)와 display_direction(Branch 해석)은 반드시 분리되어 와야 한다(PATCH 4) —
 * Unified Growth Module이 trend만 보고 자체 판정하지 않는다.
 *
 * 기대 엔드포인트: GET {FEELGOOD_KIDS_BASE_URL}/learners/{learner_id}/growth-summary
 * 응답 200: GrowthSummary<KidsMetricKey> (src/types/growth.ts)
 */
export const kidsGrowthAdapterReal: KidsGrowthAdapter = {
  async getTrainSummary(learnerId) {
    return fetchAdapterJson(NAME, `${adapterConfig.kids.baseUrl(NAME)}/learners/${learnerId}/growth-summary`);
  },
};
