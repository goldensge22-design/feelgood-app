import { RelationshipScopeAdapter } from "../session-types";
import { fetchAdapterJson } from "./http";
import { adapterConfig } from "./config";

const NAME = "RelationshipScopeAdapter(real)";

/**
 * 실제 계약: account_id로 viewer_role과 relationship_scope를 조회한다.
 * 부모-자녀/교사-class/기관 관계의 실제 저장 구조는 기존 시스템마다 다를 수 있으므로,
 * 이 adapter 뒤에서 기존 자녀관리 DB·교사 Admin 학급 배정 테이블·기관 소속 테이블을
 * 하나의 스키마로 합쳐 응답하는 책임은 서버팀에 있다(이 앱은 재구현하지 않는다, §18).
 *
 * 기대 엔드포인트: GET {FEELGOOD_RELATIONSHIP_SCOPE_BASE_URL}/accounts/{account_id}/scope
 * 응답 200 예시는 INTEGRATION_READINESS.md 참고.
 */
export const relationshipScopeAdapterReal: RelationshipScopeAdapter = {
  async resolveScope(accountId) {
    return fetchAdapterJson(NAME, `${adapterConfig.relationshipScope.baseUrl(NAME)}/accounts/${accountId}/scope`);
  },
};
