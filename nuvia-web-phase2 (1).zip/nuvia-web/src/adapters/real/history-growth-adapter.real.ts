import { HistoryGrowthAdapter } from "../types";
import { fetchAdapterJson } from "./http";
import { adapterConfig } from "./config";

const NAME = "HistoryGrowthAdapter(real)";

/**
 * 실제 계약: NUVIA HISTORY의 사고력 dimension별 승인된 summary metric만 읽는다.
 * 역사 지식 점수와 인지기능을 동일시하지 않는다(§8) — 이 매핑 책임은 HISTORY 서버에 있다.
 *
 * 기대 엔드포인트: GET {FEELGOOD_HISTORY_BASE_URL}/learners/{learner_id}/growth-summary
 * 응답 200: GrowthSummary<HistoryMetricKey> (src/types/growth.ts)
 */
export const historyGrowthAdapterReal: HistoryGrowthAdapter = {
  async getThinkSummary(learnerId) {
    return fetchAdapterJson(NAME, `${adapterConfig.history.baseUrl(NAME)}/learners/${learnerId}/growth-summary`);
  },
};
