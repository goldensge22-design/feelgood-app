import { AdapterError, toAdapterError, withAdapterTimeout } from "../errors";
import { adapterConfig } from "./config";

/** 모든 real adapter가 공유하는 인증된 fetch + 타임아웃 + 에러 정규화. */
export async function fetchAdapterJson<T>(
  adapterName: string,
  url: string,
  init?: RequestInit
): Promise<T> {
  const apiKey = adapterConfig.serviceApiKey(adapterName);

  const doFetch = fetch(url, {
    ...init,
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${apiKey}`,
      ...(init?.headers ?? {}),
    },
  });

  let res: Response;
  try {
    res = await withAdapterTimeout(adapterName, doFetch, adapterConfig.timeoutMs);
  } catch (err) {
    if (err instanceof AdapterError) throw err;
    throw new AdapterError("network_error", adapterName, `${adapterName} network failure`, err);
  }

  if (!res.ok) {
    let body: unknown;
    try {
      body = await res.json();
    } catch {
      body = undefined;
    }
    throw toAdapterError(adapterName, res.status, body);
  }

  return (await res.json()) as T;
}
