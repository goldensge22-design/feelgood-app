// (8) 실제 서버 연결 전 .env 항목 — 여기서 읽는 값이 그대로 .env 체크리스트가 된다.
// mock 모드에서는 이 값들이 없어도 동작한다 — real adapter가 실제로 호출될 때만 검증한다.
import { AdapterError } from "../errors";

function requireEnv(name: string, adapterName: string): string {
  const value = process.env[name];
  if (!value) {
    throw new AdapterError(
      "invalid_config",
      adapterName,
      `Missing required env var ${name}. See INTEGRATION_READINESS.md §.env 체크리스트.`
    );
  }
  return value;
}

export const adapterConfig = {
  timeoutMs: Number(process.env.NUVIA_ADAPTER_TIMEOUT_MS ?? 5000),

  auth: {
    baseUrl: (adapterName: string) => requireEnv("FEELGOOD_AUTH_BASE_URL", adapterName),
  },
  relationshipScope: {
    baseUrl: (adapterName: string) => requireEnv("FEELGOOD_RELATIONSHIP_SCOPE_BASE_URL", adapterName),
  },
  identity: {
    baseUrl: (adapterName: string) => requireEnv("FEELGOOD_IDENTITY_BASE_URL", adapterName),
  },
  assessment: {
    baseUrl: (adapterName: string) => requireEnv("FEELGOOD_ASSESSMENT_BASE_URL", adapterName),
  },
  programStatus: {
    baseUrl: (adapterName: string) => requireEnv("FEELGOOD_PROGRAM_STATUS_BASE_URL", adapterName),
  },
  classRoster: {
    baseUrl: (adapterName: string) => requireEnv("FEELGOOD_CLASS_ROSTER_BASE_URL", adapterName),
  },
  kids: { baseUrl: (adapterName: string) => requireEnv("FEELGOOD_KIDS_BASE_URL", adapterName) },
  history: { baseUrl: (adapterName: string) => requireEnv("FEELGOOD_HISTORY_BASE_URL", adapterName) },
  planner: { baseUrl: (adapterName: string) => requireEnv("FEELGOOD_PLANNER_BASE_URL", adapterName) },
  visibilityPolicy: {
    baseUrl: (adapterName: string) => requireEnv("FEELGOOD_VISIBILITY_POLICY_BASE_URL", adapterName),
  },
  deepLink: {
    // 검증용 공개키/시크릿 — 서명 알고리즘은 실제 발급 시스템과 사전 합의 필요(§7).
    verificationSecret: (adapterName: string) => requireEnv("FEELGOOD_DEEP_LINK_VERIFY_SECRET", adapterName),
  },
  login: {
    // {return_to} 자리표시자를 포함한 기존 FeelGood 로그인 URL 템플릿(§18 신규 로그인 시스템 금지).
    urlTemplate: (adapterName: string) => requireEnv("FEELGOOD_LOGIN_URL_TEMPLATE", adapterName),
  },
  // 서비스-투-서비스 인증. 어댑터별로 다른 값을 쓸 수도 있으나 prototype에서는 공용 1개로 시작.
  serviceApiKey: (adapterName: string) => requireEnv("FEELGOOD_SERVICE_API_KEY", adapterName),
};
