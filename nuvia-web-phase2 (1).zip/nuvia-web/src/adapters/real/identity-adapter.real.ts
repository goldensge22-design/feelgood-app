import { IdentityAdapter } from "../types";
import { fetchAdapterJson } from "./http";
import { adapterConfig } from "./config";

const NAME = "IdentityAdapter(real)";

/**
 * 실제 계약: K-PASS/D-CAS/KIDS/HISTORY/PLANNER/교사 Admin의 local key를 canonical
 * learner_id로 변환한다(§33/§24 Identity Mapping Layer). 매핑이 아직 없는 local key는
 * not_found로 응답해야 한다(이 앱이 임의로 learner_id를 생성하지 않는다).
 *
 * 기대 엔드포인트: GET {FEELGOOD_IDENTITY_BASE_URL}/resolve?system={system}&key={key}
 * 응답 200: { learner_id: string }
 * 응답 404: 매핑 없음 — AdapterError(kind: "not_found")로 전파됨(fetchAdapterJson이 처리)
 */
export const identityAdapterReal: IdentityAdapter = {
  async resolveLearnerId({ system, key }) {
    const { learner_id } = await fetchAdapterJson<{ learner_id: string }>(
      NAME,
      `${adapterConfig.identity.baseUrl(NAME)}/resolve?system=${system}&key=${encodeURIComponent(key)}`
    );
    return learner_id;
  },
};
