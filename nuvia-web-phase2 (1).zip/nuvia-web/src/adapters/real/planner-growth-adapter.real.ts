import { PlannerGrowthAdapter } from "../types";
import { fetchAdapterJson } from "./http";
import { adapterConfig } from "./config";

const NAME = "PlannerGrowthAdapter(real)";

/**
 * 실제 계약: NUVIA PLANNER v1.3 event envelope 기준 승인된 metric만 읽는다(§28 개발 전
 * 확인 필요 — "PLANNER v1.3의 최종 event envelope와 CORE 대조"는 STEP 0 항목).
 * task_breakdown_observation은 검증 전이므로 Growth Score가 아니라 관찰정보로만 온다(§9) —
 * 이 필드를 metrics에 합치지 않는다(PATCH 2 원칙 유지).
 *
 * 기대 엔드포인트: GET {FEELGOOD_PLANNER_BASE_URL}/learners/{learner_id}/growth-summary
 * 응답 200: PlannerGrowthSummary (src/types/growth.ts)
 */
export const plannerGrowthAdapterReal: PlannerGrowthAdapter = {
  async getManageSummary(learnerId) {
    return fetchAdapterJson(NAME, `${adapterConfig.planner.baseUrl(NAME)}/learners/${learnerId}/growth-summary`);
  },
};
