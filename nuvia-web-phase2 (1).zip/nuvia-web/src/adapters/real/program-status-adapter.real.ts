import { ProgramStatusAdapter } from "../types";
import { fetchAdapterJson } from "./http";
import { adapterConfig } from "./config";

const NAME = "ProgramStatusAdapter(real)";

/**
 * 실제 계약: program_status(이용권/사용 가능 여부)만 다룬다. growth_data_status는 이
 * adapter가 아니라 각 Branch Growth Adapter 응답에서 온다 — 절대 하나의 boolean으로
 * 합치지 않는다(§28).
 *
 * 기대 엔드포인트:
 *  GET {FEELGOOD_PROGRAM_STATUS_BASE_URL}/learners/{learner_id}/programs/{program_id}
 *  GET {FEELGOOD_PROGRAM_STATUS_BASE_URL}/learners/{learner_id}/programs/active
 * 응답 200: ProgramState[] 또는 ProgramState (src/types/program.ts) — info_url/launch_url 분리 유지(PATCH 4).
 */
export const programStatusAdapterReal: ProgramStatusAdapter = {
  async getProgramStatus(learnerId, programId) {
    return fetchAdapterJson(
      NAME,
      `${adapterConfig.programStatus.baseUrl(NAME)}/learners/${learnerId}/programs/${programId}`
    );
  },
  async getActivePrograms(learnerId) {
    return fetchAdapterJson(NAME, `${adapterConfig.programStatus.baseUrl(NAME)}/learners/${learnerId}/programs/active`);
  },
};
