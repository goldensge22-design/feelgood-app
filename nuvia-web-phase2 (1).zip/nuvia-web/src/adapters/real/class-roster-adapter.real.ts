import { ClassRosterAdapter } from "../types";
import { fetchAdapterJson } from "./http";
import { adapterConfig } from "./config";

const NAME = "ClassRosterAdapter(real)";

/**
 * 실제 계약: 교사 Admin의 학급 명단 — 표시용 이름/개인정보 없이 learner_id 목록만 받는다.
 * 기대 엔드포인트: GET {FEELGOOD_CLASS_ROSTER_BASE_URL}/classes/{class_id}/roster
 * 응답 200: { learner_ids: string[] }
 */
export const classRosterAdapterReal: ClassRosterAdapter = {
  async getRosterLearnerIds(classId) {
    const { learner_ids } = await fetchAdapterJson<{ learner_ids: string[] }>(
      NAME,
      `${adapterConfig.classRoster.baseUrl(NAME)}/classes/${classId}/roster`
    );
    return learner_ids;
  },
};
