import { AssessmentAdapter } from "../types";
import { AdapterError } from "../errors";
import { fetchAdapterJson } from "./http";
import { adapterConfig } from "./config";

const NAME = "AssessmentAdapter(real)";

/**
 * 실제 계약: K-PASS/D-CAS의 최근 공식 검사 프로파일을 읽기 전용으로 조회한다.
 * cognitive_domains는 하드코딩된 4개 축이 아니라 배열이어야 한다(PATCH 1) — canonical
 * domain_key 목록은 K-PASS/D-CAS API Technical Specification에서 확정.
 *
 * 기대 엔드포인트: GET {FEELGOOD_ASSESSMENT_BASE_URL}/learners/{learner_id}/latest-profile
 * 응답 200: AssessmentProfile (src/types/assessment.ts)
 * 응답 404: 검사 이력 없음 — 이 adapter는 null로 변환해 반환한다(Empty State로 처리, 에러 아님).
 */
export const assessmentAdapterReal: AssessmentAdapter = {
  async getLatestProfile(learnerId) {
    try {
      return await fetchAdapterJson(NAME, `${adapterConfig.assessment.baseUrl(NAME)}/learners/${learnerId}/latest-profile`);
    } catch (err) {
      if (err instanceof AdapterError && err.kind === "not_found") return null;
      throw err;
    }
  },
  /**
   * 기대 엔드포인트: GET {FEELGOOD_ASSESSMENT_BASE_URL}/learners/{learner_id}/profile-history
   * 응답 200: AssessmentProfile[] (assessed_at 오름차순) — 없으면 빈 배열.
   */
  async getProfileHistory(learnerId) {
    try {
      return await fetchAdapterJson(NAME, `${adapterConfig.assessment.baseUrl(NAME)}/learners/${learnerId}/profile-history`);
    } catch (err) {
      if (err instanceof AdapterError && err.kind === "not_found") return [];
      throw err;
    }
  },
};
