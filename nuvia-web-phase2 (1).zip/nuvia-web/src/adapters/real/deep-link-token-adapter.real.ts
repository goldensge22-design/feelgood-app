import { DeepLinkTokenAdapter } from "../session-types";
import { fetchAdapterJson } from "./http";
import { adapterConfig } from "./config";
import { AdapterError } from "../errors";

const NAME = "DeepLinkTokenAdapter(real)";

/**
 * 실제 계약: 결과지 발급 시스템이 서명한 토큰을 검증만 한다(이 앱은 발급하지 않는다).
 * 서명 알고리즘/키 배포 방식은 발급 시스템과 사전 합의가 필요하므로, prototype에서는
 * 검증 자체를 기존 발급 시스템의 verify 엔드포인트에 위임한다(로컬에서 서명 검증 로직을
 * 새로 구현하지 않음 — 키 관리 책임을 이 앱이 지지 않도록).
 *
 * 기대 엔드포인트: POST {FEELGOOD_AUTH_BASE_URL}/deep-link/verify
 * 요청: { token: string }
 * 응답 200: { learner_id, assessment_id, issued_at, expires_at }
 * 응답 401/404/410: 위조/형식오류/만료 — 모두 null로 정규화(§9, 사유를 구분해 노출하지 않음)
 */
export const deepLinkTokenAdapterReal: DeepLinkTokenAdapter = {
  async verify(token) {
    try {
      return await fetchAdapterJson(NAME, `${adapterConfig.auth.baseUrl(NAME)}/deep-link/verify`, {
        method: "POST",
        body: JSON.stringify({ token }),
      });
    } catch (err) {
      if (err instanceof AdapterError && (err.kind === "unauthorized" || err.kind === "not_found")) return null;
      throw err;
    }
  },
};
