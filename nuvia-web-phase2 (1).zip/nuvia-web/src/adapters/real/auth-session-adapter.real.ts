import { AuthSessionAdapter } from "../session-types";
import { fetchAdapterJson } from "./http";
import { adapterConfig } from "./config";

const NAME = "AuthSessionAdapter(real)";

/**
 * 실제 계약: 기존 K-PASS/D-CAS 세션 검증 엔드포인트에 쿠키/Authorization을 그대로 전달해
 * 세션 유효성만 확인한다 — 새 로그인 로직을 만들지 않는다(§18).
 *
 * 기대 엔드포인트: POST {FEELGOOD_AUTH_BASE_URL}/session/verify
 * 요청: { cookie_header?: string, authorization_header?: string }
 * 응답 200: { account_id: string, expires_in_seconds: number }
 * 응답 401: 세션 없음/만료 — 이 adapter는 null을 반환(에러 아님)
 */
export const authSessionAdapterReal: AuthSessionAdapter = {
  async resolveAccountId({ cookieHeader, authorizationHeader }) {
    if (!cookieHeader && !authorizationHeader) return null;

    try {
      return await fetchAdapterJson<{ account_id: string; expires_in_seconds: number }>(
        NAME,
        `${adapterConfig.auth.baseUrl(NAME)}/session/verify`,
        {
          method: "POST",
          body: JSON.stringify({ cookie_header: cookieHeader, authorization_header: authorizationHeader }),
        }
      );
    } catch (err) {
      // unauthorized/not_found는 "미인증"으로 취급 — 그 외(timeout/network/upstream)는 그대로 던져
      // 상위에서 "일시적으로 로그인 상태를 확인할 수 없습니다"로 구분 표시할 수 있게 한다.
      if (isAdapterErrorKind(err, "unauthorized") || isAdapterErrorKind(err, "not_found")) return null;
      throw err;
    }
  },
};

function isAdapterErrorKind(err: unknown, kind: string): boolean {
  return typeof err === "object" && err !== null && "kind" in err && (err as { kind: string }).kind === kind;
}
