import { VisibilityPolicyAdapter } from "../types";
import { fetchAdapterJson } from "./http";
import { adapterConfig } from "./config";

const NAME = "VisibilityPolicyAdapter(real)";

/**
 * 실제 계약: §26/§35 Visibility Policy SSOT를 호출하는 유일한 지점. 검사/프로그램/성장/
 * Insight가 각자 권한 로직을 재구현하지 않도록, 이 adapter가 모든 도메인에 대해 동일한
 * 정책 서비스를 호출한다. 응답에는 policy_version이 포함되어야 한다(§26, 재현성 로깅용).
 *
 * 기대 엔드포인트: POST {FEELGOOD_VISIBILITY_POLICY_BASE_URL}/filter
 * 요청: { viewer: ViewerContext, subject_learner_id: string, domain: string, payload: unknown }
 * 응답 200: { payload: unknown, policy_version: string }
 */
export const visibilityPolicyAdapterReal: VisibilityPolicyAdapter = {
  async filter(viewer, subjectLearnerId, domain, payload) {
    const res = await fetchAdapterJson<{ payload: unknown; policy_version: string }>(
      NAME,
      `${adapterConfig.visibilityPolicy.baseUrl(NAME)}/filter`,
      {
        method: "POST",
        body: JSON.stringify({ viewer, subject_learner_id: subjectLearnerId, domain, payload }),
      }
    );
    // policy_version은 내부 로그로만 남긴다(§26) — 응답 payload에 섞어 UI로 흘려보내지 않는다.
    return res.payload as typeof payload;
  },
};
