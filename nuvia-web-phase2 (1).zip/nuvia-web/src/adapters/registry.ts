// (6) Adapter Registry / DI — NUVIA_ADAPTER_MODE 환경변수로 mock ↔ real 전체를 한 번에
// 교체한다. Domain Layer와 Application Layer는 이 레지스트리가 반환한 인터페이스 구현체만
// 알고, mock/real 구분 자체를 모른다(§3 "mock ↔ 실제 구현 교체 가능한 단일 지점").

import {
  IdentityAdapter,
  AssessmentAdapter,
  ProgramStatusAdapter,
  KidsGrowthAdapter,
  HistoryGrowthAdapter,
  PlannerGrowthAdapter,
  VisibilityPolicyAdapter,
  ClassRosterAdapter,
} from "./types";
import { AuthSessionAdapter, RelationshipScopeAdapter, DeepLinkTokenAdapter } from "./session-types";

import { identityAdapterMock } from "./mock/identity-adapter.mock";
import { assessmentAdapterMock } from "./mock/assessment-adapter.mock";
import { programStatusAdapterMock } from "./mock/program-status-adapter.mock";
import { kidsGrowthAdapterMock } from "./mock/kids-growth-adapter.mock";
import { historyGrowthAdapterMock } from "./mock/history-growth-adapter.mock";
import { plannerGrowthAdapterMock } from "./mock/planner-growth-adapter.mock";
import { visibilityPolicyAdapterMock } from "./mock/visibility-policy-adapter.mock";

import { identityAdapterReal } from "./real/identity-adapter.real";
import { assessmentAdapterReal } from "./real/assessment-adapter.real";
import { programStatusAdapterReal } from "./real/program-status-adapter.real";
import { kidsGrowthAdapterReal } from "./real/kids-growth-adapter.real";
import { historyGrowthAdapterReal } from "./real/history-growth-adapter.real";
import { plannerGrowthAdapterReal } from "./real/planner-growth-adapter.real";
import { visibilityPolicyAdapterReal } from "./real/visibility-policy-adapter.real";
import { authSessionAdapterReal } from "./real/auth-session-adapter.real";
import { relationshipScopeAdapterReal } from "./real/relationship-scope-adapter.real";
import { deepLinkTokenAdapterReal } from "./real/deep-link-token-adapter.real";
import { mockAuthSessionAdapter } from "./mock/auth-session-adapter.mock";
import { mockRelationshipScopeAdapter } from "./mock/relationship-scope-adapter.mock";
import { mockDeepLinkTokenAdapter } from "./mock/deep-link-token-adapter.mock";
import { classRosterAdapterReal } from "./real/class-roster-adapter.real";
import { classRosterAdapterMock } from "./mock/class-roster-adapter.mock";

export type AdapterMode = "mock" | "real";

export function getAdapterMode(): AdapterMode {
  // 아직 명시하지 않으면 mock — 실제 서버 미연동 상태에서 앱이 조용히 real을 타지 않도록 안전측 기본값.
  return process.env.NUVIA_ADAPTER_MODE === "real" ? "real" : "mock";
}

export interface DomainAdapterBundle {
  identity: IdentityAdapter;
  assessment: AssessmentAdapter;
  programStatus: ProgramStatusAdapter;
  kids: KidsGrowthAdapter;
  history: HistoryGrowthAdapter;
  planner: PlannerGrowthAdapter;
  visibilityPolicy: VisibilityPolicyAdapter;
  classRoster: ClassRosterAdapter;
}

/** Domain Layer(UnifiedGrowthModule)가 쓰는 데이터 adapter 묶음. */
export function getDomainAdapterBundle(mode: AdapterMode = getAdapterMode()): DomainAdapterBundle {
  if (mode === "real") {
    return {
      identity: identityAdapterReal,
      assessment: assessmentAdapterReal,
      programStatus: programStatusAdapterReal,
      kids: kidsGrowthAdapterReal,
      history: historyGrowthAdapterReal,
      planner: plannerGrowthAdapterReal,
      visibilityPolicy: visibilityPolicyAdapterReal,
      classRoster: classRosterAdapterReal,
    };
  }
  return {
    identity: identityAdapterMock,
    assessment: assessmentAdapterMock,
    programStatus: programStatusAdapterMock,
    kids: kidsGrowthAdapterMock,
    history: historyGrowthAdapterMock,
    planner: plannerGrowthAdapterMock,
    visibilityPolicy: visibilityPolicyAdapterMock,
    classRoster: classRosterAdapterMock,
  };
}

export interface SessionAdapterBundle {
  authSession: AuthSessionAdapter;
  relationshipScope: RelationshipScopeAdapter;
  deepLinkToken: DeepLinkTokenAdapter;
}

/** Application Layer(로그인 세션/Deep Link)가 쓰는 adapter 묶음. mock/real 모두 동일 interface. */
export function getSessionAdapterBundle(mode: AdapterMode = getAdapterMode()): SessionAdapterBundle {
  if (mode === "real") {
    return {
      authSession: authSessionAdapterReal,
      relationshipScope: relationshipScopeAdapterReal,
      deepLinkToken: deepLinkTokenAdapterReal,
    };
  }
  return {
    authSession: mockAuthSessionAdapter,
    relationshipScope: mockRelationshipScopeAdapter,
    deepLinkToken: mockDeepLinkTokenAdapter,
  };
}
