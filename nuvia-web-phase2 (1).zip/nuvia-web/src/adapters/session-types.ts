// Integration Readiness — 로그인 세션 / Viewer Context 파생 / Deep Link 관련 real contract.
// 기존 adapters/types.ts(검사·프로그램·성장 데이터)와 관심사를 분리한다.

import { ViewerContext, ViewerRole, RelationshipScope } from "../types/viewer-context";

/**
 * (1) AuthSessionAdapter — 기존 K-PASS/D-CAS 로그인 세션에서 "누가 로그인했는가"만 얻는다.
 * viewer_role/relationship_scope 판단은 이 adapter의 책임이 아니다(§25 Viewer Context는
 * 세션에서 "파생"되지만, 파생 로직 자체는 RelationshipScopeAdapter가 담당하도록 분리해
 * 인증(누구인지)과 인가(무엇을 볼 수 있는지)를 섞지 않는다).
 *
 * 실서버 계약: 기존 K-PASS/D-CAS가 발급한 세션 쿠키 또는 SSO 토큰을 그대로 검증한다 —
 * 이 adapter가 새 로그인 방식을 만들지 않는다(§18 "신규 로그인 시스템 생성 금지").
 */
export interface AuthSessionAdapter {
  /** 요청의 쿠키/Authorization 헤더에서 기존 세션을 검증하고 account_id만 반환한다. */
  resolveAccountId(request: { cookieHeader: string | null; authorizationHeader: string | null }): Promise<{
    account_id: string;
    /** 세션이 만료되기까지 남은 시간(초). 클라이언트 캐싱/재검증 판단에 사용. */
    expires_in_seconds: number;
  } | null>; // null = 미인증
}

/**
 * (3) RelationshipScopeAdapter — account_id로부터 viewer_role과 relationship_scope를 판단한다.
 * PATCH 2(Increment 1) 구조를 그대로 real contract로 승격: direct(부모/본인)는 learner_ids를
 * 세션에 직접 담고, class/institution은 scope_id만 담아 대규모 관계를 서버측 멤버십 테이블로
 * 위임한다 — 세션 payload 크기를 소수 관계로 제한한다.
 */
export interface RelationshipScopeAdapter {
  resolveScope(accountId: string): Promise<{
    viewer_role: ViewerRole;
    relationship_scope: RelationshipScope;
  }>;
}

/** AuthSessionAdapter + RelationshipScopeAdapter를 합성해 ViewerContext를 만드는 표준 절차. */
export interface ViewerContextResolver {
  resolve(request: { cookieHeader: string | null; authorizationHeader: string | null }): Promise<ViewerContext | null>;
}

/**
 * (7) DeepLinkTokenAdapter — 결과지(§9)에서 MY NUVIA로 진입하는 Deep Link/QR용 토큰.
 * 민감한 검사 데이터 자체는 URL에 노출하지 않고, 서명된 토큰만 전달한다(§9 "URL 파라미터로
 * 노출하지 않는다"). 토큰 payload 스키마는 src/types/deep-link.ts 참고.
 */
export interface DeepLinkTokenAdapter {
  /** 결과지 발급 시점에 서버가 토큰을 생성한다(이 앱은 발급하지 않고 검증만 한다고 가정). */
  verify(token: string): Promise<{
    learner_id: string;
    assessment_id: string;
    issued_at: string;
    expires_at: string;
  } | null>; // null = 만료/위조/형식 오류 — 모두 동일하게 "유효하지 않은 링크"로 처리
}
