import { test } from "node:test";
import assert from "node:assert/strict";
import { mockDeepLinkTokenAdapter, issueMockDeepLinkToken } from "../deep-link-token-adapter.mock";
import { isLearnerAllowed } from "../../../lib/viewer-context";
import { ViewerContext } from "../../../types/viewer-context";

const now = Math.floor(Date.now() / 1000);

test("TC-DL-1 (정상): 유효한 토큰은 learner_id/assessment_id를 정확히 반환", async () => {
  const token = issueMockDeepLinkToken({
    learner_id: "learner-0001",
    assessment_id: "a-001",
    iat: now,
    exp: now + 600, // 10분 뒤 만료
  });

  const result = await mockDeepLinkTokenAdapter.verify(token);
  assert.ok(result);
  assert.equal(result?.learner_id, "learner-0001");
  assert.equal(result?.assessment_id, "a-001");
});

test("TC-DL-2 (만료): exp가 과거인 토큰은 null(사유를 구분해 노출하지 않음)", async () => {
  const token = issueMockDeepLinkToken({
    learner_id: "learner-0001",
    assessment_id: "a-001",
    iat: now - 1200,
    exp: now - 600, // 10분 전 만료됨
  });

  const result = await mockDeepLinkTokenAdapter.verify(token);
  assert.equal(result, null);
});

test("TC-DL-3 (형식오류): prefix가 없는 임의 문자열은 null", async () => {
  const result = await mockDeepLinkTokenAdapter.verify("not-a-real-token");
  assert.equal(result, null);
});

test("TC-DL-4 (형식오류): base64url 디코딩은 되지만 JSON이 아니면 null", async () => {
  const garbled = "mocklink." + Buffer.from("not json").toString("base64url");
  const result = await mockDeepLinkTokenAdapter.verify(garbled);
  assert.equal(result, null);
});

test("TC-DL-5 (권한없음, relationship_scope 확인 단계): 토큰은 유효해도 세션의 relationship_scope가 다른 learner면 거부되어야 한다", async () => {
  const token = issueMockDeepLinkToken({ learner_id: "learner-9999", assessment_id: "a-999", iat: now, exp: now + 600 });
  const verified = await mockDeepLinkTokenAdapter.verify(token);
  assert.ok(verified);

  // /report/deep-link route가 3단계에서 쓰는 것과 동일한 검증 함수 — 부모 계정(자녀 A/B만 허용)이
  // 등록되지 않은 learner_id를 담은 토큰으로 접근하면 거부되어야 한다(→ /report/deep-link/forbidden).
  const parentViewer: ViewerContext = {
    account_id: "acc-parent-01",
    viewer_role: "parent",
    subject_learner_id: null,
    relationship_scope: { type: "direct", learner_ids: ["learner-0001", "learner-0002"] },
  };
  assert.equal(isLearnerAllowed(parentViewer, verified!.learner_id), false);
});

test("TC-DL-6 (정상, relationship_scope 확인 단계): 등록된 learner_id면 허용", async () => {
  const token = issueMockDeepLinkToken({ learner_id: "learner-0001", assessment_id: "a-001", iat: now, exp: now + 600 });
  const verified = await mockDeepLinkTokenAdapter.verify(token);
  const parentViewer: ViewerContext = {
    account_id: "acc-parent-01",
    viewer_role: "parent",
    subject_learner_id: null,
    relationship_scope: { type: "direct", learner_ids: ["learner-0001", "learner-0002"] },
  };
  assert.equal(isLearnerAllowed(parentViewer, verified!.learner_id), true);
});
