import { DeepLinkTokenAdapter } from "../session-types";
import { DeepLinkTokenPayload } from "../../types/deep-link";

// real/deep-link-token-adapter.real.ts와 동일한 DeepLinkTokenAdapter contract를 구현한다.
// 실제 서명 검증 대신, 발급 시스템이 만들 payload를 base64url로 인코딩한 형태를 그대로
// "서명된 토큰"처럼 다룬다 — 구조(만료 판정 등)를 검증하기 위한 mock이며 실제 서명 방식은
// FEELGOOD_DEEP_LINK_VERIFY_SECRET 확정 후 real adapter에서 구현한다.
const PREFIX = "mocklink.";

export function issueMockDeepLinkToken(payload: Omit<DeepLinkTokenPayload, "purpose">): string {
  const full: DeepLinkTokenPayload = { ...payload, purpose: "assessment_report_deep_link" };
  return PREFIX + Buffer.from(JSON.stringify(full)).toString("base64url");
}

export const mockDeepLinkTokenAdapter: DeepLinkTokenAdapter = {
  async verify(token) {
    if (!token.startsWith(PREFIX)) return null; // malformed

    let payload: DeepLinkTokenPayload;
    try {
      payload = JSON.parse(Buffer.from(token.slice(PREFIX.length), "base64url").toString());
    } catch {
      return null; // malformed
    }

    if (payload.purpose !== "assessment_report_deep_link") return null;
    if (payload.exp * 1000 < Date.now()) return null; // expired

    return {
      learner_id: payload.learner_id,
      assessment_id: payload.assessment_id,
      issued_at: new Date(payload.iat * 1000).toISOString(),
      expires_at: new Date(payload.exp * 1000).toISOString(),
    };
  },
};
