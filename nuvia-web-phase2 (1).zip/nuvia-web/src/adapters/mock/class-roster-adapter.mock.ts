import { ClassRosterAdapter } from "../types";
import { getClassRoster } from "../../lib/mock-class-roster";

export const classRosterAdapterMock: ClassRosterAdapter = {
  async getRosterLearnerIds(classId) {
    return getClassRoster(classId).map((s) => s.learner_id);
  },
};
