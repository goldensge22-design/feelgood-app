// real adapter는 실제 fetch로 cookie/authorization 헤더를 그대로 원 서버에 전달하지만,
// mock adapter는 그 헤더 문자열을 직접 파싱해야 한다 — Node 표준 파서에 기대지 않고
// 이 파일 하나로 그 책임을 격리한다.
export function parseCookie(cookieHeader: string | null, name: string): string | null {
  if (!cookieHeader) return null;
  const match = cookieHeader
    .split(";")
    .map((p) => p.trim())
    .find((p) => p.startsWith(`${name}=`));
  return match ? decodeURIComponent(match.slice(name.length + 1)) : null;
}
