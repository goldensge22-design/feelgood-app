import { HistoryGrowthAdapter } from "../types";
import { GrowthSummary, HistoryMetricKey } from "../../types/growth";

const SUMMARIES: Record<string, GrowthSummary<HistoryMetricKey>> = {
  // Growth Connection Engine(§12) 테스트 fixture — 방향이 다른 metric도 섞어 OBSERVED_TOGETHER 케이스를 만든다
  "learner-0002": {
    growth_data_status: "sufficient",
    primary_metric_key: "evidence", // Branch가 명시한 대표 지표(PATCH 2)
    metrics: {
      comparison: {
        trend: "flat",
        display_direction: "needs_observation",
        observation: "비교 판단 과제에서 아직 뚜렷한 방향이 나타나지 않음",
        observation_count: 3,
        window: { from: "2026-08-01", to: "2026-09-05" },
      },
      evidence: {
        trend: "up",
        display_direction: "improving",
        observation: "근거를 먼저 확인한 뒤 판단하는 행동이 더 자주 나타남",
        observation_count: 4,
        window: { from: "2026-08-01", to: "2026-09-05" },
      },
    },
    updated_at: "2026-09-05",
  },
};
// learner-0001은 HISTORY 미사용 상태 — Empty State로 처리 (no_data)

export const historyGrowthAdapterMock: HistoryGrowthAdapter = {
  async getThinkSummary(learnerId) {
    return SUMMARIES[learnerId] ?? { growth_data_status: "no_data", metrics: {}, updated_at: new Date().toISOString() };
  },
};
