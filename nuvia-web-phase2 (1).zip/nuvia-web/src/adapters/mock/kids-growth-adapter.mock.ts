import { KidsGrowthAdapter } from "../types";
import { GrowthSummary, KidsMetricKey } from "../../types/growth";

const SUMMARIES: Record<string, GrowthSummary<KidsMetricKey>> = {
  "learner-0001": {
    growth_data_status: "sufficient",
    primary_metric_key: "accuracy", // Branch가 명시한 대표 지표(PATCH 2)
    metrics: {
      accuracy: { trend: "up", display_direction: "improving", observation: "최근 정확도 상승 경향" },
      strategy: {
        trend: "up",
        display_direction: "improving",
        observation: "단계적 전략 사용이 더 자주 관찰됨",
        observation_count: 4,
        window: { from: "2026-08-15", to: "2026-09-09" },
      },
    },
    updated_at: "2026-09-09",
  },
  // Growth Connection Engine(§12) 테스트 fixture — PLANNER/HISTORY와 겹치는 domain·기간을 가진 학생
  "learner-0002": {
    growth_data_status: "sufficient",
    primary_metric_key: "strategy",
    metrics: {
      strategy: {
        trend: "up",
        display_direction: "improving",
        observation: "학습 미션에서 단계적 전략 사용이 관찰됨",
        observation_count: 6,
        window: { from: "2026-08-15", to: "2026-09-09" },
      },
    },
    updated_at: "2026-09-09",
  },
};

export const kidsGrowthAdapterMock: KidsGrowthAdapter = {
  async getTrainSummary(learnerId) {
    return SUMMARIES[learnerId] ?? { growth_data_status: "no_data", metrics: {}, updated_at: new Date().toISOString() };
  },
};
