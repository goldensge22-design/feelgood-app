import { AssessmentAdapter } from "../types";
import { AssessmentProfile } from "../../types/assessment";

// Epoch(§20) 테스트를 위해 learner-0001은 재검사 이력 2건을 갖는다 — 이전 프로파일(v2)을
// 삭제하지 않고 그대로 보존한다는 원칙(§6/§8)을 그대로 반영한다.
const HISTORY: Record<string, AssessmentProfile[]> = {
  "learner-0001": [
    {
      assessment_id: "a-000",
      assessment_profile_version: "v2",
      assessed_at: "2025-09-01",
      cognitive_domains: [
        { domain_key: "planning", display_name: "Planning", score: 54 },
        { domain_key: "attention", display_name: "Attention", score: 50 },
      ],
      strengths: [],
      support_areas: ["Planning", "Attention"],
      report_url: "/reports/a-000",
    },
    {
      assessment_id: "a-001",
      assessment_profile_version: "v3",
      assessed_at: "2026-03-10",
      cognitive_domains: [
        { domain_key: "planning", display_name: "Planning", score: 62 },
        { domain_key: "attention", display_name: "Attention", score: 58 },
        { domain_key: "sequential_processing", display_name: "순차처리", score: 65 },
        { domain_key: "simultaneous_processing", display_name: "Simultaneous", score: 60 },
      ],
      strengths: ["Planning"],
      support_areas: ["Attention"],
      report_url: "/reports/a-001",
    },
  ],
  "learner-0002": [
    {
      assessment_id: "a-010",
      assessment_profile_version: "v3",
      assessed_at: "2026-05-20",
      cognitive_domains: [
        { domain_key: "planning", display_name: "Planning", score: 59 },
        { domain_key: "attention", display_name: "Attention", score: 64 },
      ],
      strengths: ["Attention"],
      support_areas: ["Planning"],
      report_url: "/reports/a-010",
    },
  ],
};

export const assessmentAdapterMock: AssessmentAdapter = {
  async getLatestProfile(learnerId) {
    const list = HISTORY[learnerId];
    return list && list.length > 0 ? list[list.length - 1] : null;
  },
  async getProfileHistory(learnerId) {
    return HISTORY[learnerId] ?? [];
  },
};
