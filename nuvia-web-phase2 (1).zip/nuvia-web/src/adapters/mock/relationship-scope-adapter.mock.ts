import { RelationshipScopeAdapter } from "../session-types";

// real/relationship-scope-adapter.real.ts와 동일한 RelationshipScopeAdapter contract를
// 구현한다. 기존 deriveViewerContext()의 MOCK_SESSION_BY_ACCOUNT 테이블을 그대로 옮겨왔다
// (5A FINAL PATCH — mock 세션 고정 매핑을 mock adapter 내부로 격리).
const SCOPE_BY_ACCOUNT: Record<string, Awaited<ReturnType<RelationshipScopeAdapter["resolveScope"]>>> = {
  "acc-parent-01": {
    viewer_role: "parent",
    relationship_scope: { type: "direct", learner_ids: ["learner-0001", "learner-0002"] },
  },
  "acc-learner-01": {
    viewer_role: "learner",
    relationship_scope: { type: "direct", learner_ids: ["learner-0001"] },
  },
  "acc-teacher-01": {
    viewer_role: "teacher",
    relationship_scope: { type: "class", scope_id: "class-9-2" },
  },
};

export const mockRelationshipScopeAdapter: RelationshipScopeAdapter = {
  async resolveScope(accountId) {
    const found = SCOPE_BY_ACCOUNT[accountId];
    if (!found) {
      // real 서버라면 404에 해당 — mock에서는 institution 소속도 관계도 없는 것으로 처리
      return { viewer_role: "learner", relationship_scope: { type: "direct", learner_ids: [] } };
    }
    return found;
  },
};
