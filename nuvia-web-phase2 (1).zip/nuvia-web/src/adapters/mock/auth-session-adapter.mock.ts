import { AuthSessionAdapter } from "../session-types";
import { parseCookie } from "./cookie-util";

// real/auth-session-adapter.real.ts와 동일한 AuthSessionAdapter contract를 구현한다.
// 실제 서버 대신 nuvia_mock_account 쿠키(값 = account_id)로 "로그인 상태"를 흉내낸다.
// 이 쿠키는 /dev/login 라우트가 검증 후 심어준다 — 클라이언트가 임의 값을 넣어도
// ACCOUNT_TABLE에 없는 값이면 미인증으로 처리된다(§25 "클라이언트가 임의 지정 불가" 원칙 유지).
export const MOCK_SESSION_COOKIE = "nuvia_mock_account";

const KNOWN_ACCOUNTS = new Set(["acc-parent-01", "acc-learner-01", "acc-teacher-01"]);

export const mockAuthSessionAdapter: AuthSessionAdapter = {
  async resolveAccountId({ cookieHeader }) {
    const accountId = parseCookie(cookieHeader, MOCK_SESSION_COOKIE);
    if (!accountId || !KNOWN_ACCOUNTS.has(accountId)) return null;
    return { account_id: accountId, expires_in_seconds: 3600 };
  },
};
