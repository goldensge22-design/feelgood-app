import { PlannerGrowthAdapter } from "../types";
import { PlannerGrowthSummary } from "../../types/growth";

const SUMMARIES: Record<string, PlannerGrowthSummary> = {
  "learner-0001": {
    growth_data_status: "insufficient", // program_status=active와 별개 (§28 정상 상태 예시)
    metrics: {},
    updated_at: "2026-09-08",
    task_breakdown_observation: { text: "최근 큰 과제를 단계로 나누는 시도가 관찰됨", observed_at: "2026-09-07" },
  },
  // Growth Connection Engine(§12) 테스트 fixture
  "learner-0002": {
    growth_data_status: "sufficient",
    primary_metric_key: "time_prediction_accuracy", // Branch가 명시한 대표 지표(PATCH 2)
    metrics: {
      plan_order_consistency: {
        trend: "up",
        display_direction: "improving",
        observation: "계획한 순서대로 진행하는 빈도가 늘어남",
        observation_count: 5,
        window: { from: "2026-08-20", to: "2026-09-09" },
      },
      time_prediction_accuracy: {
        trend: "up",
        display_direction: "improving",
        observation: "예상 시간과 실제 시간의 차이가 줄어드는 경향",
        observation_count: 5,
        window: { from: "2026-08-20", to: "2026-09-09" },
      },
    },
    updated_at: "2026-09-09",
  },
};

export const plannerGrowthAdapterMock: PlannerGrowthAdapter = {
  async getManageSummary(learnerId) {
    return (
      SUMMARIES[learnerId] ?? { growth_data_status: "no_data", metrics: {}, updated_at: new Date().toISOString() }
    );
  },
};
