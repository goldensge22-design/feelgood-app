import { ProgramStatusAdapter } from "../types";
import { ProgramState, ProgramId } from "../../types/program";

const PROGRAM_STATES: Record<string, ProgramState[]> = {
  "learner-0001": [
    {
      program_id: "PLANNER",
      program_status: "active",
      growth_data_status: "insufficient", // active + insufficient — 정상 상태(§28)
      last_activity_at: "2026-09-08",
      launch_url: "/programs/planner/launch",
      info_url: "/programs/planner/intro",
    },
    {
      program_id: "KIDS",
      program_status: "active",
      growth_data_status: "sufficient",
      last_activity_at: "2026-09-09",
      launch_url: "/programs/kids/launch",
      info_url: "/programs/kids/intro",
    },
  ],
  "learner-0002": [
    {
      program_id: "KIDS",
      program_status: "active",
      growth_data_status: "sufficient",
      last_activity_at: "2026-09-09",
      launch_url: "/programs/kids/launch",
      info_url: "/programs/kids/intro",
    },
    {
      program_id: "PLANNER",
      program_status: "active",
      growth_data_status: "sufficient",
      last_activity_at: "2026-09-09",
      launch_url: "/programs/planner/launch",
      info_url: "/programs/planner/intro",
    },
    {
      program_id: "HISTORY",
      program_status: "active",
      growth_data_status: "sufficient",
      last_activity_at: "2026-09-05",
      launch_url: "/programs/history/launch",
      info_url: "/programs/history/intro",
    },
  ],
};

export const programStatusAdapterMock: ProgramStatusAdapter = {
  async getProgramStatus(learnerId, programId: ProgramId) {
    const list = PROGRAM_STATES[learnerId] ?? [];
    const found = list.find((p) => p.program_id === programId);
    return (
      found ?? {
        program_id: programId,
        program_status: "inactive",
        growth_data_status: "no_data",
        last_activity_at: null,
        launch_url: `/programs/${programId.toLowerCase()}/launch`, // inactive 상태에서는 CTA가 이 값을 사용하지 않는다
        info_url: `/programs/${programId.toLowerCase()}/intro`,
      }
    );
  },
  async getActivePrograms(learnerId) {
    return (PROGRAM_STATES[learnerId] ?? []).filter((p) => p.program_status === "active");
  },
};
