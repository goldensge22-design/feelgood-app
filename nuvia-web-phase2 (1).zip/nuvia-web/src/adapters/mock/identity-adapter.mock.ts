import { IdentityAdapter } from "../types";

// STEP 0 Implementation Prerequisite: 실제 K-PASS/D-CAS/Branch local key 매핑 테이블은
// 실제 FeelGood 서버 확인 후 연결한다. 지금은 local key === learner_id로 가정한 고정 mock.
const LOCAL_KEY_MAP: Record<string, string> = {
  "kpass:u-1001": "learner-0001",
  "dcas:u-1001": "learner-0001",
  "kids:child-A": "learner-0001",
  "history:child-A": "learner-0001",
  "planner:child-A": "learner-0001",
};

export const identityAdapterMock: IdentityAdapter = {
  async resolveLearnerId({ system, key }) {
    const mapped = LOCAL_KEY_MAP[`${system}:${key}`];
    if (!mapped) {
      throw new Error(`Identity Mapping Layer: unmapped local key ${system}:${key} (STEP 0 필요)`);
    }
    return mapped;
  },
};
