import { VisibilityPolicyAdapter } from "../types";
import { applyVisibilityPolicy } from "../../domain/visibility-policy";

// §26 Visibility Policy SSOT의 단일 진입점(mock). 실제 role별 축소 로직은
// src/domain/visibility-policy.ts(순수 함수, 단위 테스트 대상)에 있다 — 각 View가
// 개별적으로 권한 로직을 재구현하지 않는다.
export const visibilityPolicyAdapterMock: VisibilityPolicyAdapter = {
  async filter(viewer, _subjectLearnerId, domain, payload) {
    return applyVisibilityPolicy(viewer.viewer_role, domain, payload);
  },
};
