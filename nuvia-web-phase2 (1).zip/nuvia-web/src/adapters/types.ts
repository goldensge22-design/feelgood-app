// PHASE 1 §7 — Adapter Interface. UI/Application Layer는 이 인터페이스를 직접 import하지 않는다.
// Domain Layer(Unified Growth Module)에서만 호출된다. 실제 FeelGood 서버 연동 전에는
// mock 구현체를 주입하되 시그니처는 고정한다.

import { AssessmentProfile } from "../types/assessment";
import { ProgramState, ProgramId } from "../types/program";
import { GrowthSummary, KidsMetricKey, HistoryMetricKey, PlannerGrowthSummary } from "../types/growth";
import { ViewerContext } from "../types/viewer-context";

export interface IdentityAdapter {
  resolveLearnerId(localKey: {
    system: "kpass" | "dcas" | "kids" | "history" | "planner" | "admin";
    key: string;
  }): Promise<string>; // canonical learner_id
}

export interface AssessmentAdapter {
  getLatestProfile(learnerId: string): Promise<AssessmentProfile | null>;
  /** 재검사 이력 전체(assessed_at 오름차순). Epoch 구분(§20 재검사 처리)에 사용 — 이전 프로파일을
   *  삭제하지 않고 그대로 유지한다는 원칙을 그대로 반영한다. */
  getProfileHistory(learnerId: string): Promise<AssessmentProfile[]>;
}

export interface ProgramStatusAdapter {
  getProgramStatus(learnerId: string, programId: ProgramId): Promise<ProgramState>;
  getActivePrograms(learnerId: string): Promise<ProgramState[]>;
}

export interface KidsGrowthAdapter {
  getTrainSummary(learnerId: string): Promise<GrowthSummary<KidsMetricKey>>;
}

export interface HistoryGrowthAdapter {
  getThinkSummary(learnerId: string): Promise<GrowthSummary<HistoryMetricKey>>;
}

export interface PlannerGrowthAdapter {
  getManageSummary(learnerId: string): Promise<PlannerGrowthSummary>;
}

export interface VisibilityPolicyAdapter {
  filter<T>(
    viewer: ViewerContext,
    subjectLearnerId: string,
    domain: "assessment" | "program" | "growth" | "insight",
    payload: T
  ): Promise<T>;
}

/** §17 Class View 집계에 필요한 학급 명단 — 표시용 이름 없이 learner_id만 반환한다
 *  (개인 식별 정보는 Class Aggregate 계산에 사용하지 않는다). */
export interface ClassRosterAdapter {
  getRosterLearnerIds(classId: string): Promise<string[]>;
}
