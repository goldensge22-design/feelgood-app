import { ViewerContext } from "@/types/viewer-context";
import { isLearnerAllowed } from "@/lib/viewer-context";
import { getSelectedLearnerIdFromCookie } from "@/lib/selected-learner";

// 모든 /my-nuvia/* 페이지가 동일한 우선순위로 subject_learner_id를 결정하도록 공용화.
// 우선순위: 쿼리(명시적 전환/Deep Link) > 쿠키(직전 선택 유지) > Viewer Context 기본값 > 허용 목록 첫 항목.
export function resolveSubjectLearnerId(viewer: ViewerContext, queryLearnerId?: string): string | null {
  const allowedLearnerIds = viewer.relationship_scope.learner_ids ?? [];

  if (queryLearnerId && isLearnerAllowed(viewer, queryLearnerId)) return queryLearnerId;

  const cookieLearnerId = getSelectedLearnerIdFromCookie();
  if (cookieLearnerId && isLearnerAllowed(viewer, cookieLearnerId)) return cookieLearnerId;

  if (viewer.subject_learner_id && isLearnerAllowed(viewer, viewer.subject_learner_id)) {
    return viewer.subject_learner_id;
  }

  return allowedLearnerIds[0] ?? null;
}
