import { headers } from "next/headers";
import type { NextRequest } from "next/server";
import { getSessionAdapterBundle } from "@/adapters/registry";
import { createViewerContextResolver } from "@/adapters/viewer-context-resolver";
import { ViewerContext } from "@/types/viewer-context";

// 5A FINAL PATCH — 모든 페이지/라우트가 이 함수 하나만 호출한다.
// NUVIA_ADAPTER_MODE=mock|real 전환은 registry.getSessionAdapterBundle() 안에서만
// 일어나므로, 이 파일과 호출부는 mock/real 여부를 전혀 몰라도 된다.
function getResolver() {
  const bundle = getSessionAdapterBundle();
  return createViewerContextResolver(bundle.authSession, bundle.relationshipScope);
}

/** Server Component(페이지)용 — 현재 요청의 쿠키/Authorization을 next/headers로 읽는다. */
export async function resolveViewerContext(): Promise<ViewerContext | null> {
  const h = headers();
  return getResolver().resolve({ cookieHeader: h.get("cookie"), authorizationHeader: h.get("authorization") });
}

/** Route Handler(API)용 — NextRequest에서 직접 읽는다. */
export async function resolveViewerContextFromRequest(req: NextRequest): Promise<ViewerContext | null> {
  return getResolver().resolve({
    cookieHeader: req.headers.get("cookie"),
    authorizationHeader: req.headers.get("authorization"),
  });
}
