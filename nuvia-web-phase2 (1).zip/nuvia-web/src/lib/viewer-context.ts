import { ViewerContext } from "../types/viewer-context";

// 5A FINAL PATCH — 이 파일은 더 이상 mock 세션을 직접 만들지 않는다(그 책임은
// src/adapters/mock/auth-session-adapter.mock.ts + relationship-scope-adapter.mock.ts로
// 이동했다). 여기 남는 것은 mock/real 어느 쪽에서 만든 ViewerContext든 동일하게 쓰는
// 순수 검증 유틸 하나뿐이다.

/** subject_learner_id 변경 요청의 서버측 검증 (§5 생성/검증 규칙, PATCH 2 반영) */
export function isLearnerAllowed(viewer: ViewerContext, learnerId: string): boolean {
  const scope = viewer.relationship_scope;
  if (scope.type === "direct") {
    return !!scope.learner_ids?.includes(learnerId);
  }
  // class/institution: 실제로는 scope_id 기준 서버측 멤버십 테이블 조회 (STEP 0 이후 구현)
  // mock에서는 무조건 거부하지 않고, 상위 role-view 엔드포인트에서만 별도 처리한다.
  return false;
}
