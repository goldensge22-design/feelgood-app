// §19 Empty States — 고정 문구 카탈로그. 컴포넌트가 각자 문구를 새로 짓지 않는다.
export const EMPTY_STATES = {
  noAssessment: "아직 연결된 검사결과가 없습니다.",
  noProgram: "아직 연결된 NUVIA 프로그램이 없습니다.",
  growthInsufficient: "아직 변화 추세를 보여주기에 데이터가 충분하지 않습니다.",
  connectionInsufficient: "아직 여러 활동을 연결해 해석할 만큼 데이터가 충분하지 않습니다.",
  reassessed: "새 검사 결과가 반영되었습니다. 이후 데이터는 새로운 성장 구간으로 표시됩니다.",
  programUnused: "아직 이용하지 않는 프로그램입니다.",
  noPrimaryMetric: "요약 가능한 대표 지표가 아직 없습니다.",
} as const;
