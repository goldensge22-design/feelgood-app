import { ViewerContext } from "@/types/viewer-context";

// 이 Admin 화면군은 teacher Viewer Context에서만 의미가 있다.
// 실제로는 기존 FeelGood Admin의 인증/권한 체계 안에서 진입하므로, 별도 로그인 화면을 만들지 않는다(§16).
export function AdminScopeNotice({ viewer }: { viewer: ViewerContext }) {
  if (viewer.viewer_role === "teacher") return null;
  return (
    <main className="mx-auto max-w-3xl px-6 py-10">
      <p className="text-slate-600">
        이 화면은 교사 Admin 전용 NUVIA Growth 메뉴입니다. 학생/보호자는 MY NUVIA(/my-nuvia)를 이용해 주세요.
      </p>
    </main>
  );
}

export function requireClassScope(viewer: ViewerContext): string | null {
  if (viewer.relationship_scope.type === "class" && viewer.relationship_scope.scope_id) {
    return viewer.relationship_scope.scope_id;
  }
  return null;
}
