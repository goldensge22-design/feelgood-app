import { cookies } from "next/headers";

// Prototype: 라우트 이동 시 learner 선택이 사라지지 않도록 쿠키로 유지한다.
// 실제 구현에서는 이 값을 ViewerContext/server session의 selected learner 필드로 대체한다
// (예: 세션 저장소에 subject_learner_id를 기록하고 매 요청마다 세션에서 읽음).
export const SELECTED_LEARNER_COOKIE = "nuvia_selected_learner";

export function getSelectedLearnerIdFromCookie(): string | null {
  return cookies().get(SELECTED_LEARNER_COOKIE)?.value ?? null;
}
