// STEP 0 Implementation Prerequisite: 실제 교사 Admin 학생 key ↔ canonical learner_id 매핑은
// 실제 FeelGood 서버 확인 후 연결한다. 지금은 고정 roster mock.
export interface RosterEntry {
  learner_id: string;
  display_name: string;
}

const ROSTER_BY_CLASS: Record<string, RosterEntry[]> = {
  "class-9-2": [
    { learner_id: "learner-0001", display_name: "학생 A" },
    { learner_id: "learner-0002", display_name: "학생 B" },
  ],
};

export function getClassRoster(classId: string): RosterEntry[] {
  return ROSTER_BY_CLASS[classId] ?? [];
}

export function isStudentInClass(classId: string, learnerId: string): boolean {
  return getClassRoster(classId).some((s) => s.learner_id === learnerId);
}
