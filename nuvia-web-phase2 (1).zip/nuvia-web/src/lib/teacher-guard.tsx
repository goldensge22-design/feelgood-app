import { ViewerContext } from "@/types/viewer-context";

// Increment 3는 학생/보호자 여정만 다룬다 — 교사 Admin은 다음 증분에서 별도 구현.
export function TeacherScopeNotice({ viewer }: { viewer: ViewerContext }) {
  if (viewer.viewer_role !== "teacher") return null;
  return (
    <main className="mx-auto max-w-4xl px-6 py-10">
      <p className="text-slate-600">
        이 화면은 학생·보호자용 MY NUVIA입니다. 교사용 화면은 기존 Admin 내부에 별도로 제공되며, 다음 증분에서 구현합니다.
      </p>
    </main>
  );
}
