import { getAdapterMode } from "@/adapters/registry";
import { adapterConfig } from "@/adapters/real/config";

const RETURN_TO_PLACEHOLDER = "{return_to}";

/**
 * 비로그인 상태에서 이동시킬 로그인 URL을 mode별로 결정한다.
 * - mock: `/dev/login` (개발 편의 전용, real 모드에서는 자연히 사용되지 않음)
 * - real: 기존 FeelGood 로그인 URL 템플릿(§18 — 새 로그인 시스템을 만들지 않는다)
 * 두 모드 모두 로그인 완료 후 원래 있던 곳(returnTo)으로 되돌아오는 계약을 유지한다.
 */
export function resolveLoginUrl(returnTo: string): string {
  if (getAdapterMode() === "real") {
    const template = adapterConfig.login.urlTemplate("LoginRedirect");
    return template.replace(RETURN_TO_PLACEHOLDER, encodeURIComponent(returnTo));
  }
  return `/dev/login?redirect=${encodeURIComponent(returnTo)}`;
}
