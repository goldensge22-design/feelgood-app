// §9 결과지 Deep Link / QR 설계 — 토큰 payload 스키마.
// 토큰 자체(서명/발급)는 기존 결과지 발급 시스템이 담당하고, 이 앱은 검증만 한다.

export interface DeepLinkTokenPayload {
  learner_id: string;
  assessment_id: string;
  purpose: "assessment_report_deep_link";
  iat: number; // 발급 시각(unix seconds)
  exp: number; // 만료 시각(unix seconds) — 짧게 설정 권장(예: 발급 후 10분)
}

// 검증 실패 사유 — 클라이언트에는 모두 동일한 "유효하지 않은 링크"로만 노출한다(§9,
// 어떤 사유인지 세분화해 보여주는 것 자체가 정보 노출이 될 수 있음).
export type DeepLinkVerifyFailureReason = "expired" | "invalid_signature" | "malformed" | "learner_not_authorized";
