// PHASE 1 §5 (PATCH 2 반영) — 서버에서만 생성. 클라이언트는 이 값을 직접 지정할 수 없다.

export type ViewerRole = "learner" | "parent" | "teacher" | "institution";

export interface RelationshipScope {
  type: "direct" | "class" | "institution";
  scope_id?: string;       // type이 class/institution일 때 학급/기관 식별자
  learner_ids?: string[];  // type이 direct일 때만 (부모/본인)
}

export interface ViewerContext {
  account_id: string;
  viewer_role: ViewerRole;
  subject_learner_id: string | null;
  relationship_scope: RelationshipScope;
}
