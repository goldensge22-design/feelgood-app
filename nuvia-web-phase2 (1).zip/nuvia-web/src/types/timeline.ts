// §11 Growth Timeline — 서로 다른 Branch 점수를 같은 Y축에 올리지 않는다.
// 병렬 이벤트/추세 트랙으로만 구성한다.
// §20 Epoch — 첫 검사 이전 활동은 별도 phase("pre_assessment")로 분리한다.
// 첫 검사 이전 데이터를 첫 검사 이후 성장 구간(epoch 0)과 절대 합치지 않는다.

export type TimelineEventType = "assessment" | "program_start" | "recent_activity" | "growth_signal" | "profile_update" | "milestone";

export type EpochPhase = "pre_assessment" | "assessment_epoch";

export interface EpochAssignment {
  /** pre_assessment이면 항상 null — 특정 epoch 번호를 임의로 붙이지 않는다. */
  epoch_index: number | null;
  phase: EpochPhase;
}

export interface TimelineEvent {
  type: TimelineEventType;
  label: string;
  occurred_at: string;
  source?: "KIDS" | "HISTORY" | "PLANNER" | "ASSESSMENT";
  /** 재검사(assessment_profile_version 변경) 기준으로 구분된 구간 — 이전/이후를 하나의
   *  연속 성장선으로 합치지 않기 위한 태그(§20). pre_assessment 구간은 null. */
  epoch_index: number | null;
  phase: EpochPhase;
}

export interface EpochInfo {
  epoch_index: number;
  assessment_profile_version: string | null;
  started_at: string; // 해당 epoch가 시작된 시점(검사일).
}

export interface TimelineResponse {
  assessment_events: TimelineEvent[];
  program_events: TimelineEvent[];
  growth_signals: TimelineEvent[];
  /** 검사 이력 기반 epoch만 담는다(pre_assessment는 여기 포함되지 않음 — 검사 이력이 전혀
   *  없으면 이 배열은 비어 있고 모든 이벤트가 pre_assessment로 표시된다). */
  epochs: EpochInfo[];
}
