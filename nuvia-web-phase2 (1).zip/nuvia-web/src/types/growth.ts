// PHASE 1 §7/§8 (PATCH 4 반영)

export type GrowthDataStatus = "no_data" | "insufficient" | "sufficient";
export type ProgramStatus = "active" | "inactive" | "expired";
export type ConnectionStatus = "INSUFFICIENT_DATA" | "OBSERVED_TOGETHER" | "CONSISTENT_PATTERN";

export interface MetricPoint {
  trend: "up" | "down" | "flat";                 // Branch 원본 방향값
  display_direction: "improving" | "stable" | "needs_observation" | "not_interpreted"; // Branch가 해석한 방향
  observation: string;
  /** 이 metric의 근거가 된 관찰 횟수. Growth Connection Engine의 MINIMUM DATA 판정에 사용.
   *  Branch가 제공하지 않으면 undefined — MINIMUM DATA 조건을 만족할 수 없는 것으로 취급. */
  observation_count?: number;
  /** 관찰 기간. SAME PERIOD 판정에 사용 — 없으면 기간 불명으로 취급. */
  window?: { from: string; to: string };
}

export interface GrowthSummary<K extends string = string> {
  growth_data_status: GrowthDataStatus;
  /** Branch가 명시적으로 지정하는 대표 metric. Unified Growth Module은 이 값을 그대로 쓸 뿐,
   *  metric 중요도를 자체 판단하지 않는다(PATCH 2). 없으면 §config의 summary_metric_priority로
   *  fallback하고, 그마저 없으면 대표 지표를 임의로 고르지 않는다. */
  primary_metric_key?: K;
  metrics: Partial<Record<K, MetricPoint>>;
  updated_at: string;
}

export interface ObservationNote {
  text: string;
  observed_at: string;
}

export type KidsMetricKey = "difficulty" | "accuracy" | "latency" | "error_pattern" | "strategy" | "adherence";
export type HistoryMetricKey = "chronology" | "cause_effect" | "evidence" | "perspective" | "comparison" | "decision";
export type PlannerMetricKey =
  | "time_prediction_accuracy" | "start_accuracy" | "planning_accuracy" | "focus_stability"
  | "completion_reliability" | "recovery_skill" | "plan_order_consistency" | "metacognitive_accuracy";

export interface PlannerGrowthSummary extends GrowthSummary<PlannerMetricKey> {
  task_breakdown_observation?: ObservationNote; // Growth Score로 승격하지 않음 (§9)
}

export interface MetacogSummary {
  patterns: {
    prediction_vs_actual: string | null;
    self_assessment_vs_actual: string | null;
    strategy_awareness: string | null;
    strategy_change: string | null;
    next_action_choice: string | null;
  };
}

export interface InsightCard {
  observation: string;
  interpretation: string;
  actions: string[]; // 1~3개
  /** 학생 본인만 보는 필드 — Visibility Policy(§16 SUPPORT)가 parent/teacher/institution에게는 제거한다. */
  student_reflection_text?: string;
  atomic_behavior_log?: string[];
}

export interface GrowthConnection {
  domain: string;
  sources: string[];
  period: { from: string; to: string };
  status: ConnectionStatus;
  display_text: string; // 비인과적 문구, 서버 확정
}

export interface DistributionSummary {
  labels: string[];
  counts: number[]; // labels와 동일 길이 — 개인 식별 없음
}

export interface ParticipationSummary {
  active_learner_count: number;
  stable_participation_ratio: number; // 0~1
}

export interface ClassSummary {
  cognitive_distribution: DistributionSummary;
  training_distribution: DistributionSummary;
  thinking_distribution: DistributionSummary;
  self_management_distribution: DistributionSummary;
  participation_summary: ParticipationSummary;
  suggested_class_strategy: string[]; // 학생 개별 식별/랭킹 없음
}
