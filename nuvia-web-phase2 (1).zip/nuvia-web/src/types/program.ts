import { ProgramStatus, GrowthDataStatus } from "./growth";

export type ProgramId = "KIDS" | "HISTORY" | "PLANNER";

export interface ProgramState {
  program_id: ProgramId;
  program_status: ProgramStatus;      // 이용권/사용 가능 상태
  growth_data_status: GrowthDataStatus; // 성장 추세 표시 가능 여부 — program_status와 분리 (§28)
  last_activity_at: string | null;
  launch_url: string; // program_status === "active"일 때 CTA가 사용 — 실행 URL
  info_url: string;   // inactive/expired일 때 CTA가 사용 — 소개/안내 URL (실행 URL과 혼동 금지)
}
