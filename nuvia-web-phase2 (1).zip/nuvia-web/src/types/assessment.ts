// PHASE 1 §7 (PATCH 1 반영) — canonical domain_key는 하드코딩하지 않는다.

export interface CognitiveDomainScore {
  domain_key: string;      // 실제 canonical key는 K-PASS/D-CAS API Technical Spec에서 확정
  display_name: string;
  score: number;
}

export interface AssessmentProfile {
  assessment_id: string;
  assessment_profile_version: string;
  assessed_at: string;
  cognitive_domains: CognitiveDomainScore[];
  strengths: string[];
  support_areas: string[];
  report_url: string;
}
