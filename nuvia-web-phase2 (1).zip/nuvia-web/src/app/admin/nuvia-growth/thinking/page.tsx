import { resolveViewerContext } from "@/lib/resolve-viewer-context";
import { AdminScopeNotice, requireClassScope } from "@/lib/admin-guard";
import { SignedOutNotice } from "@/components/SignedOutNotice";
import { unifiedGrowthModule } from "@/domain/unified-growth-module";
import { DistributionBar } from "@/components/admin/DistributionBar";

export default async function AdminThinkingPage() {
  const viewer = await resolveViewerContext();
  if (!viewer) return <SignedOutNotice />;
  if (viewer.viewer_role !== "teacher") return <AdminScopeNotice viewer={viewer} />;

  const classId = requireClassScope(viewer);
  if (!classId) {
    return (
      <main className="mx-auto max-w-4xl px-6 py-10">
        <p className="text-slate-600">담당 학급 정보가 없습니다.</p>
      </main>
    );
  }

  const summary = await unifiedGrowthModule.getClassSummary(classId);

  return (
    <main className="mx-auto max-w-4xl px-6 py-10">
      <DistributionBar title="THINKING · Class Think Map (NUVIA HISTORY)" distribution={summary.thinking_distribution} />
    </main>
  );
}
