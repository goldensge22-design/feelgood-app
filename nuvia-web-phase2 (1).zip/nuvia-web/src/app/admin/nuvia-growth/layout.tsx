import type { ReactNode } from "react";

// §17 교사용 Admin View — 신규 사이트가 아니라 "기존 Admin 내부"에 추가되는 메뉴라는 전제.
// 이 레이아웃은 그 메뉴 구획을 시연하기 위한 것으로, 실제로는 기존 Admin의 셸(상단 바/좌측
// 내비게이션 등) 안에 아래 7개 항목만 삽입된다.
const NAV_ITEMS = [
  { href: "/admin/nuvia-growth/students", label: "STUDENTS" },
  { href: "/admin/nuvia-growth/cognition", label: "COGNITION" },
  { href: "/admin/nuvia-growth/training", label: "TRAINING" },
  { href: "/admin/nuvia-growth/thinking", label: "THINKING" },
  { href: "/admin/nuvia-growth/self-management", label: "SELF-MANAGEMENT" },
  { href: "/admin/nuvia-growth/growth", label: "GROWTH" },
  { href: "/admin/nuvia-growth/class-insight", label: "CLASS INSIGHT" },
];

export default function AdminNuviaGrowthLayout({ children }: { children: ReactNode }) {
  return (
    <div>
      <div className="border-b border-slate-200 bg-ink px-6 py-2 text-xs text-slate-300">
        기존 Admin &gt; NUVIA Growth (데모용 독립 셸)
      </div>
      <nav className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-5xl items-center gap-1 overflow-x-auto px-6 py-3">
          {NAV_ITEMS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="whitespace-nowrap rounded-full px-3 py-1.5 text-sm text-slate-600 hover:bg-slate-100 hover:text-ink"
            >
              {item.label}
            </a>
          ))}
        </div>
      </nav>
      {children}
    </div>
  );
}
