import { resolveViewerContext } from "@/lib/resolve-viewer-context";
import { AdminScopeNotice, requireClassScope } from "@/lib/admin-guard";
import { SignedOutNotice } from "@/components/SignedOutNotice";
import { unifiedGrowthModule } from "@/domain/unified-growth-module";
import { SuggestedClassStrategy } from "@/components/admin/SuggestedClassStrategy";

export default async function AdminClassInsightPage() {
  const viewer = await resolveViewerContext();
  if (!viewer) return <SignedOutNotice />;
  if (viewer.viewer_role !== "teacher") return <AdminScopeNotice viewer={viewer} />;

  const classId = requireClassScope(viewer);
  if (!classId) {
    return (
      <main className="mx-auto max-w-4xl px-6 py-10">
        <p className="text-slate-600">담당 학급 정보가 없습니다.</p>
      </main>
    );
  }

  const summary = await unifiedGrowthModule.getClassSummary(classId);

  return (
    <main className="mx-auto max-w-4xl px-6 py-10">
      <div className="space-y-5">
        <section className="rounded-card border border-slate-200 bg-white p-5">
          <h2 className="font-semibold text-ink">참여 안정성</h2>
          <p className="mt-2 text-sm text-ink">
            활동 중인 학생 {summary.participation_summary.active_learner_count}명 ·
            안정적 참여 비율 {Math.round(summary.participation_summary.stable_participation_ratio * 100)}%
          </p>
        </section>
        <SuggestedClassStrategy strategies={summary.suggested_class_strategy} />
      </div>
    </main>
  );
}
