import { redirect } from "next/navigation";

export default function AdminNuviaGrowthIndex() {
  redirect("/admin/nuvia-growth/students");
}
