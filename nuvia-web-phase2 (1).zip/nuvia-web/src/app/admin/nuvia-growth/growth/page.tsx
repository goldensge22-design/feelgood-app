import { resolveViewerContext } from "@/lib/resolve-viewer-context";
import { AdminScopeNotice, requireClassScope } from "@/lib/admin-guard";
import { SignedOutNotice } from "@/components/SignedOutNotice";
import { isStudentInClass, getClassRoster } from "@/lib/mock-class-roster";
import { unifiedGrowthModule } from "@/domain/unified-growth-module";
import { ProfileView } from "@/components/growth/ProfileView";
import { TrainView } from "@/components/growth/TrainView";
import { ThinkView } from "@/components/growth/ThinkView";
import { ManageView } from "@/components/growth/ManageView";
import { MetacognitionView } from "@/components/growth/MetacognitionView";
import { GrowthTimeline } from "@/components/growth/GrowthTimeline";
import { GrowthConnectionPanel } from "@/components/growth/GrowthConnectionPanel";
import { TrainThinkManageTabs } from "@/components/growth/TrainThinkManageTabs";

// §17 Student View(개인) — 학급 집계(Class View)와 분리된 화면. 학급 로스터에 속한
// 학생만 조회 가능(role-view API와 동일한 접근 통제 규칙).
export default async function AdminStudentGrowthPage({ searchParams }: { searchParams: { learner_id?: string } }) {
  const viewer = await resolveViewerContext();
  if (!viewer) return <SignedOutNotice />;
  if (viewer.viewer_role !== "teacher") return <AdminScopeNotice viewer={viewer} />;

  const classId = requireClassScope(viewer);
  const learnerId = searchParams.learner_id;

  if (!classId || !learnerId || !isStudentInClass(classId, learnerId)) {
    return (
      <main className="mx-auto max-w-4xl px-6 py-10">
        <p className="text-slate-600">조회할 학생을 먼저 STUDENTS 목록에서 선택해 주세요.</p>
        <a href="/admin/nuvia-growth/students" className="mt-2 inline-block text-sm font-medium text-brand-blueDeep hover:underline">
          STUDENTS로 이동 →
        </a>
      </main>
    );
  }

  const studentName = getClassRoster(classId).find((s) => s.learner_id === learnerId)?.display_name ?? learnerId;
  const ctx = { ...viewer, subject_learner_id: learnerId };
  const [overview, timeline, connections] = await Promise.all([
    unifiedGrowthModule.getOverview(ctx, learnerId),
    unifiedGrowthModule.getTimeline(ctx, learnerId),
    unifiedGrowthModule.getConnections(ctx, learnerId),
  ]);

  return (
    <main className="mx-auto max-w-5xl px-6 py-10">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-xl font-semibold text-ink">GROWTH · {studentName}</h1>
        <a href="/admin/nuvia-growth/students" className="text-sm font-medium text-brand-blueDeep hover:underline">
          ← STUDENTS
        </a>
      </div>

      <div className="space-y-5">
        <ProfileView profile={overview.profile_summary} />

        <TrainThinkManageTabs
          train={<TrainView summary={overview.growth_preview.train} />}
          think={<ThinkView summary={overview.growth_preview.think} />}
          manage={<ManageView summary={overview.growth_preview.manage} />}
        />

        <MetacognitionView summary={overview.growth_preview.metacognition} />
        <GrowthTimeline timeline={timeline} />
        <GrowthConnectionPanel connections={connections} />
      </div>
    </main>
  );
}
