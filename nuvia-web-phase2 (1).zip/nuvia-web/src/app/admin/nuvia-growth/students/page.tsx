import { resolveViewerContext } from "@/lib/resolve-viewer-context";
import { AdminScopeNotice, requireClassScope } from "@/lib/admin-guard";
import { SignedOutNotice } from "@/components/SignedOutNotice";
import { getClassRoster } from "@/lib/mock-class-roster";
import { StudentGrowthList } from "@/components/admin/StudentGrowthList";

export default async function AdminStudentsPage() {
  const viewer = await resolveViewerContext();
  if (!viewer) return <SignedOutNotice />;
  if (viewer.viewer_role !== "teacher") return <AdminScopeNotice viewer={viewer} />;

  const classId = requireClassScope(viewer);
  const students = classId ? getClassRoster(classId) : [];

  return (
    <main className="mx-auto max-w-4xl px-6 py-10">
      <StudentGrowthList students={students} />
    </main>
  );
}
