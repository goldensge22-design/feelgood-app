import "./globals.css";
import type { ReactNode } from "react";

export const metadata = { title: "MY NUVIA" };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ko">
      <body className="min-h-screen">{children}</body>
    </html>
  );
}
