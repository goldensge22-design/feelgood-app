export default function DeepLinkForbiddenPage() {
  return (
    <main className="mx-auto max-w-md px-6 py-16 text-center">
      <h1 className="text-lg font-semibold text-ink">접근 권한이 없습니다</h1>
      <p className="mt-2 text-sm text-slate-600">
        현재 로그인된 계정으로는 이 결과지의 성장 정보를 볼 수 없습니다.
      </p>
      <a href="/my-nuvia" className="mt-4 inline-block text-sm font-medium text-brand-blueDeep hover:underline">
        MY NUVIA Home으로 이동 →
      </a>
    </main>
  );
}
