// §9 — 검증 실패 사유(위조/형식오류/만료)를 구분해 노출하지 않는다. 전부 동일한 안내.
export default function DeepLinkInvalidPage() {
  return (
    <main className="mx-auto max-w-md px-6 py-16 text-center">
      <h1 className="text-lg font-semibold text-ink">유효하지 않은 링크입니다</h1>
      <p className="mt-2 text-sm text-slate-600">
        결과지의 QR/버튼을 다시 스캔하시거나, 검사결과 페이지에서 다시 시도해 주세요.
      </p>
      <a href="/my-nuvia" className="mt-4 inline-block text-sm font-medium text-brand-blueDeep hover:underline">
        MY NUVIA Home으로 이동 →
      </a>
    </main>
  );
}
