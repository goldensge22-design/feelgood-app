import { NextRequest, NextResponse } from "next/server";
import { getSessionAdapterBundle } from "@/adapters/registry";
import { resolveViewerContextFromRequest } from "@/lib/resolve-viewer-context";
import { isLearnerAllowed } from "@/lib/viewer-context";
import { isStudentInClass } from "@/lib/mock-class-roster";
import { SELECTED_LEARNER_COOKIE } from "@/lib/selected-learner";
import { resolveLoginUrl } from "@/lib/login-redirect";

// §9 결과지 Deep Link 흐름 — token 검증 → 로그인 확인 → relationship_scope 확인 →
// learner 선택 → /my-nuvia/growth. URL에는 opaque token 하나만 실리고, 검사점수 등
// 민감 데이터는 전달하지 않는다(§9 "URL 파라미터로 노출하지 않는다").
export async function GET(req: NextRequest) {
  const token = new URL(req.url).searchParams.get("token");
  if (!token) {
    return NextResponse.redirect(new URL("/report/deep-link/invalid", req.url));
  }

  // 1) token 검증
  const { deepLinkToken } = getSessionAdapterBundle();
  const verified = await deepLinkToken.verify(token);
  if (!verified) {
    return NextResponse.redirect(new URL("/report/deep-link/invalid", req.url));
  }

  // 2) 로그인 확인 — 비로그인 상태면 로그인 후 같은 Deep Link로 되돌아온다
  //    mock: /dev/login. real: 기존 FeelGood 로그인 URL(§18 — 새 로그인 시스템을 만들지 않는다).
  const viewer = await resolveViewerContextFromRequest(req);
  if (!viewer) {
    return NextResponse.redirect(new URL(resolveLoginUrl(req.url), req.url));
  }

  // 3) relationship_scope 확인 — 이 learner를 볼 권한이 있는 계정인지
  const allowed =
    viewer.relationship_scope.type === "direct"
      ? isLearnerAllowed(viewer, verified.learner_id)
      : viewer.relationship_scope.type === "class" &&
        !!viewer.relationship_scope.scope_id &&
        isStudentInClass(viewer.relationship_scope.scope_id, verified.learner_id);

  if (!allowed) {
    return NextResponse.redirect(new URL("/report/deep-link/forbidden", req.url));
  }

  // 4) learner 선택 반영(select-learner와 동일한 쿠키 메커니즘) + 5) 성장 화면으로 이동
  //    교사는 학생/보호자용 My Page가 아니라 Admin의 개인 View로 이동한다(§17).
  const target =
    viewer.viewer_role === "teacher"
      ? `/admin/nuvia-growth/growth?learner_id=${verified.learner_id}`
      : "/my-nuvia/growth";

  const res = NextResponse.redirect(new URL(target, req.url));
  res.cookies.set(SELECTED_LEARNER_COOKIE, verified.learner_id, { path: "/my-nuvia", httpOnly: true, sameSite: "lax" });
  return res;
}
