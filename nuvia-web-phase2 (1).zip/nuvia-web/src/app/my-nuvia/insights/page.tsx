import { resolveViewerContext } from "@/lib/resolve-viewer-context";
import { resolveSubjectLearnerId } from "@/lib/resolve-subject-learner";
import { unifiedGrowthModule } from "@/domain/unified-growth-module";
import { RecentInsight } from "@/components/RecentInsight";
import { TeacherScopeNotice } from "@/lib/teacher-guard";
import { SignedOutNotice } from "@/components/SignedOutNotice";
import { EMPTY_STATES } from "@/lib/empty-states";

// /my-nuvia/insights → overview.recent_insights (PHASE 1 §3/§27) — 새 Insight를 만들지 않고
// getInsights()로 동일 소스를 캡 없이 표시한다.
export default async function InsightsPage({ searchParams }: { searchParams: { learner_id?: string } }) {
  const viewer = await resolveViewerContext();
  if (!viewer) return <SignedOutNotice />;
  if (viewer.viewer_role === "teacher") return <TeacherScopeNotice viewer={viewer} />;

  const subjectLearnerId = resolveSubjectLearnerId(viewer, searchParams.learner_id);

  if (!subjectLearnerId) {
    return (
      <main className="mx-auto max-w-4xl px-6 py-10">
        <p className="text-slate-600">조회할 대상자가 없습니다.</p>
      </main>
    );
  }

  const ctx = { ...viewer, subject_learner_id: subjectLearnerId };
  const insights = await unifiedGrowthModule.getInsights(ctx, subjectLearnerId);

  return (
    <main className="mx-auto max-w-3xl px-6 py-10">
      {insights.length === 0 ? (
        <>
          <h1 className="mb-4 text-xl font-semibold text-ink">INSIGHTS</h1>
          <p className="text-sm text-slate-600">{EMPTY_STATES.growthInsufficient}</p>
        </>
      ) : (
        <RecentInsight insights={insights} limit={insights.length} title="INSIGHTS" />
      )}
    </main>
  );
}
