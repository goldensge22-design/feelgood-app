import { resolveViewerContext } from "@/lib/resolve-viewer-context";
import { TeacherScopeNotice } from "@/lib/teacher-guard";
import { SignedOutNotice } from "@/components/SignedOutNotice";

// §13 "자녀 미연결" / §18 "개발하지 말아야 할 것" — 새로운 회원가입·로그인·자녀관리
// 시스템을 만들지 않는다. 이 페이지는 기존 자녀관리 흐름으로 연결하는 placeholder다.
export default async function AccountPage() {
  const viewer = await resolveViewerContext();
  if (!viewer) return <SignedOutNotice />;
  if (viewer.viewer_role === "teacher") return <TeacherScopeNotice viewer={viewer} />;

  return (
    <main className="mx-auto max-w-3xl px-6 py-10">
      <h1 className="mb-6 text-xl font-semibold text-ink">계정 · 자녀관리</h1>

      <div className="rounded-card border border-dashed border-slate-300 bg-white p-5">
        <p className="text-sm text-ink">
          계정 정보, 비밀번호, {viewer.viewer_role === "parent" ? "자녀 연결/해제" : "본인 정보"} 관리는 기존
          K-PASS/D-CAS 계정·자녀관리 화면을 그대로 사용합니다. MY NUVIA는 이 기능을 재구현하지 않고 연결만 합니다.
        </p>
        <a href="#" className="mt-3 inline-block text-sm font-medium text-brand-blueDeep hover:underline">
          기존 계정 · 자녀관리 화면으로 이동 → (placeholder — 실제 경로는 기존 시스템 라우트로 연결)
        </a>
      </div>
    </main>
  );
}
