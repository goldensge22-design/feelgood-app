import { resolveViewerContext } from "@/lib/resolve-viewer-context";
import { resolveSubjectLearnerId } from "@/lib/resolve-subject-learner";
import { unifiedGrowthModule } from "@/domain/unified-growth-module";
import { StudentOverviewPanel } from "@/components/nuvia-home/StudentOverviewPanel";
import { ParentNuviaShell } from "@/components/parent/ParentNuviaShell";
import { LearnerSelector } from "@/components/LearnerSelector";
import { SignedOutNotice } from "@/components/SignedOutNotice";
import { TeacherScopeNotice } from "@/lib/teacher-guard";

const MOCK_LEARNER_LABELS: Record<string, string> = {
  "learner-0001": "자녀 A",
  "learner-0002": "자녀 B",
};

// §14/§15 — learner는 자신의 Home을, parent는 OVERVIEW/PROFILE/GROWTH/SUPPORT/PROGRAMS 탭 구조를 본다.
// 같은 라우트(/my-nuvia)를 재사용하고 viewer_role로만 분기한다 — 별도 사이트를 만들지 않는다(§4).
export default async function MyNuviaHome({ searchParams }: { searchParams: { learner_id?: string } }) {
  const viewer = await resolveViewerContext();
  if (!viewer) return <SignedOutNotice />;
  if (viewer.viewer_role === "teacher") return <TeacherScopeNotice viewer={viewer} />;

  const allowedLearnerIds = viewer.relationship_scope.learner_ids ?? [];
  const subjectLearnerId = resolveSubjectLearnerId(viewer, searchParams.learner_id);

  if (!subjectLearnerId) {
    return (
      <main className="mx-auto max-w-4xl px-6 py-10">
        <p className="text-slate-600">조회할 대상자가 없습니다. 자녀관리에서 먼저 연결해 주세요.</p>
      </main>
    );
  }

  const ctx = { ...viewer, subject_learner_id: subjectLearnerId };
  const overview = await unifiedGrowthModule.getOverview(ctx, subjectLearnerId);

  return (
    <main className="mx-auto max-w-5xl px-6 py-10">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-xl font-semibold text-ink">MY NUVIA</h1>
        {viewer.viewer_role === "parent" && (
          <LearnerSelector
            currentLearnerId={subjectLearnerId}
            redirectTo="/my-nuvia"
            options={allowedLearnerIds.map((id) => ({ learner_id: id, label: MOCK_LEARNER_LABELS[id] ?? id }))}
          />
        )}
      </div>

      {viewer.viewer_role === "parent" ? (
        <ParentNuviaShell overview={overview} />
      ) : (
        <StudentOverviewPanel overview={overview} />
      )}
    </main>
  );
}
