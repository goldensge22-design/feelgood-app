import { NextRequest, NextResponse } from "next/server";
import { resolveViewerContextFromRequest } from "@/lib/resolve-viewer-context";
import { isLearnerAllowed } from "@/lib/viewer-context";
import { SELECTED_LEARNER_COOKIE } from "@/lib/selected-learner";

// learner 전환 전용 route handler. §5/§6 대상자 선택 구조 — 서버가 선택을 검증한 뒤에만 반영한다.
// 실제 구현에서는 이 지점에서 서버 세션의 selected learner를 갱신한다(쿠키는 prototype 대체 수단).
export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const learnerId = url.searchParams.get("learner_id");
  const redirectPath = url.searchParams.get("redirect") ?? "/my-nuvia";

  const viewer = await resolveViewerContextFromRequest(req);
  const target = new URL(redirectPath, req.url);

  if (!viewer || !learnerId || !isLearnerAllowed(viewer, learnerId)) {
    // 허용되지 않은 learner_id 요청 — §9 Deep Link 무권한 접근과 동일하게 기본 Home으로 폴백
    return NextResponse.redirect(new URL("/my-nuvia", req.url));
  }

  const res = NextResponse.redirect(target);
  res.cookies.set(SELECTED_LEARNER_COOKIE, learnerId, { path: "/my-nuvia", httpOnly: true, sameSite: "lax" });
  return res;
}
