import { resolveViewerContext } from "@/lib/resolve-viewer-context";
import { resolveSubjectLearnerId } from "@/lib/resolve-subject-learner";
import { unifiedGrowthModule } from "@/domain/unified-growth-module";
import { ProfileView } from "@/components/growth/ProfileView";
import { TrainView } from "@/components/growth/TrainView";
import { ThinkView } from "@/components/growth/ThinkView";
import { ManageView } from "@/components/growth/ManageView";
import { MetacognitionView } from "@/components/growth/MetacognitionView";
import { GrowthTimeline } from "@/components/growth/GrowthTimeline";
import { GrowthConnectionPanel } from "@/components/growth/GrowthConnectionPanel";
import { TrainThinkManageTabs } from "@/components/growth/TrainThinkManageTabs";
import { MyGrowthPreview } from "@/components/MyGrowthPreview";
import { SupportTipPanel } from "@/components/parent/SupportTipPanel";
import { TeacherScopeNotice } from "@/lib/teacher-guard";
import { SignedOutNotice } from "@/components/SignedOutNotice";

// /my-nuvia/growth → overview + timeline + connections (PHASE 1 §3/§27)
// Route Map: learner, parent(요약 범위만) — 부모에게는 학생용 상세 Metric Grid를 노출하지 않는다.
export default async function UnifiedGrowthDashboard({ searchParams }: { searchParams: { learner_id?: string } }) {
  const viewer = await resolveViewerContext();
  if (!viewer) return <SignedOutNotice />;
  if (viewer.viewer_role === "teacher") return <TeacherScopeNotice viewer={viewer} />;

  const subjectLearnerId = resolveSubjectLearnerId(viewer, searchParams.learner_id);

  if (!subjectLearnerId) {
    return (
      <main className="mx-auto max-w-4xl px-6 py-10">
        <p className="text-slate-600">조회할 대상자가 없습니다.</p>
      </main>
    );
  }

  const ctx = { ...viewer, subject_learner_id: subjectLearnerId };
  const [overview, timeline, connections] = await Promise.all([
    unifiedGrowthModule.getOverview(ctx, subjectLearnerId),
    unifiedGrowthModule.getTimeline(ctx, subjectLearnerId),
    unifiedGrowthModule.getConnections(ctx, subjectLearnerId),
  ]);

  const header = (
    <div className="mb-6 flex items-center justify-between">
      <h1 className="text-xl font-semibold text-ink">Unified Growth Dashboard</h1>
      <a href="/my-nuvia" className="text-sm font-medium text-brand-blueDeep hover:underline">
        ← MY NUVIA Home
      </a>
    </div>
  );

  // 부모: 요약 범위만 — Growth Summary / 최근 변화 / Support Point. 학생용 상세 Metric Grid는 노출하지 않는다.
  if (viewer.viewer_role === "parent") {
    return (
      <main className="mx-auto max-w-5xl px-6 py-10">
        {header}
        <div className="space-y-5">
          <ProfileView profile={overview.profile_summary} />
          <MyGrowthPreview
            train={overview.growth_preview.train}
            think={overview.growth_preview.think}
            manage={overview.growth_preview.manage}
            metacognition={overview.growth_preview.metacognition}
          />
          <GrowthTimeline timeline={timeline} />
          <GrowthConnectionPanel connections={connections} />
          <SupportTipPanel insights={overview.recent_insights} />
        </div>
      </main>
    );
  }

  // 학생 본인: 상세 Metric Grid + Metacognition 전체
  return (
    <main className="mx-auto max-w-5xl px-6 py-10">
      {header}
      <div className="space-y-5">
        <ProfileView profile={overview.profile_summary} />

        <TrainThinkManageTabs
          train={<TrainView summary={overview.growth_preview.train} />}
          think={<ThinkView summary={overview.growth_preview.think} />}
          manage={<ManageView summary={overview.growth_preview.manage} />}
        />

        <MetacognitionView summary={overview.growth_preview.metacognition} />
        <GrowthTimeline timeline={timeline} />
        <GrowthConnectionPanel connections={connections} />
      </div>
    </main>
  );
}
