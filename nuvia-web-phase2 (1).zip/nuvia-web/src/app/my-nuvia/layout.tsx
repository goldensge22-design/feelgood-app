import type { ReactNode } from "react";

// §5 MY NUVIA Home IA: HOME / 검사결과 / NUVIA / MY GROWTH / INSIGHTS / 계정·자녀관리
const NAV_ITEMS = [
  { href: "/my-nuvia", label: "HOME" },
  { href: "/my-nuvia/assessments", label: "검사결과" },
  { href: "/my-nuvia/programs", label: "NUVIA" },
  { href: "/my-nuvia/growth", label: "MY GROWTH" },
  { href: "/my-nuvia/insights", label: "INSIGHTS" },
  { href: "/my-nuvia/account", label: "계정 · 자녀관리" },
];

export default function MyNuviaLayout({ children }: { children: ReactNode }) {
  return (
    <div>
      <nav className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-5xl items-center gap-1 overflow-x-auto px-6 py-3">
          {NAV_ITEMS.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="whitespace-nowrap rounded-full px-3 py-1.5 text-sm text-slate-600 hover:bg-slate-100 hover:text-ink"
            >
              {item.label}
            </a>
          ))}
        </div>
      </nav>
      {children}
    </div>
  );
}
