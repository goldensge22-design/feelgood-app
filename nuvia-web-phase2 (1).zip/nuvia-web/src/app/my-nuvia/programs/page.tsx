import { resolveViewerContext } from "@/lib/resolve-viewer-context";
import { resolveSubjectLearnerId } from "@/lib/resolve-subject-learner";
import { unifiedGrowthModule } from "@/domain/unified-growth-module";
import { ProgramGrid } from "@/components/ProgramGrid";
import { TeacherScopeNotice } from "@/lib/teacher-guard";
import { SignedOutNotice } from "@/components/SignedOutNotice";

// /my-nuvia/programs → Branch status/launch API (PHASE 1 §3/§27) — Program Entry 설계(§12)
export default async function ProgramsPage({ searchParams }: { searchParams: { learner_id?: string } }) {
  const viewer = await resolveViewerContext();
  if (!viewer) return <SignedOutNotice />;
  if (viewer.viewer_role === "teacher") return <TeacherScopeNotice viewer={viewer} />;

  const subjectLearnerId = resolveSubjectLearnerId(viewer, searchParams.learner_id);

  if (!subjectLearnerId) {
    return (
      <main className="mx-auto max-w-4xl px-6 py-10">
        <p className="text-slate-600">조회할 대상자가 없습니다.</p>
      </main>
    );
  }

  const ctx = { ...viewer, subject_learner_id: subjectLearnerId };
  const overview = await unifiedGrowthModule.getOverview(ctx, subjectLearnerId);

  return (
    <main className="mx-auto max-w-4xl px-6 py-10">
      <h1 className="mb-6 text-xl font-semibold text-ink">NUVIA 프로그램</h1>
      <ProgramGrid activePrograms={overview.active_programs} />
    </main>
  );
}
