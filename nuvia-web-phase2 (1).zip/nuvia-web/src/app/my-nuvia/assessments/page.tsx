import { resolveViewerContext } from "@/lib/resolve-viewer-context";
import { resolveSubjectLearnerId } from "@/lib/resolve-subject-learner";
import { unifiedGrowthModule } from "@/domain/unified-growth-module";
import { ProfileView } from "@/components/growth/ProfileView";
import { TeacherScopeNotice } from "@/lib/teacher-guard";
import { SignedOutNotice } from "@/components/SignedOutNotice";

// §8 검사결과 화면과 MY NUVIA 연결 — "기존 검사결과 목록과 결과지 보기 기능은 유지한다."
// 이 페이지는 검사결과 시스템을 재구현하지 않는다. 최근 프로파일 요약만 Unified Growth API로
// 보여주고, 전체 이력/결과지 목록은 기존 K-PASS/D-CAS Assessment 화면으로 연결하는
// placeholder integration이다 (§20 "기존 자녀관리 흐름으로 연결" 원칙과 동일하게 적용).
export default async function AssessmentsPage({ searchParams }: { searchParams: { learner_id?: string } }) {
  const viewer = await resolveViewerContext();
  if (!viewer) return <SignedOutNotice />;
  if (viewer.viewer_role === "teacher") return <TeacherScopeNotice viewer={viewer} />;

  const subjectLearnerId = resolveSubjectLearnerId(viewer, searchParams.learner_id);

  if (!subjectLearnerId) {
    return (
      <main className="mx-auto max-w-3xl px-6 py-10">
        <p className="text-slate-600">조회할 대상자가 없습니다.</p>
      </main>
    );
  }

  const ctx = { ...viewer, subject_learner_id: subjectLearnerId };
  const overview = await unifiedGrowthModule.getOverview(ctx, subjectLearnerId);

  return (
    <main className="mx-auto max-w-3xl px-6 py-10">
      <h1 className="mb-6 text-xl font-semibold text-ink">검사결과</h1>

      <ProfileView profile={overview.profile_summary} />

      {/* Placeholder integration — 기존 Assessment 시스템의 전체 이력/결과지 목록으로 연결.
          AssessmentAdapter에 getHistory() 등이 추가되면 이 블록을 실제 목록으로 교체한다. */}
      <div className="mt-4 rounded-card border border-dashed border-slate-300 bg-white p-4">
        <p className="text-sm text-ink">지난 검사 이력 전체와 결과지 상세는 기존 검사결과 페이지에서 확인할 수 있습니다.</p>
        <a href="#" className="mt-2 inline-block text-sm font-medium text-brand-blueDeep hover:underline">
          기존 검사결과 목록으로 이동 → (placeholder — 실제 경로는 기존 K-PASS/D-CAS 라우트로 연결)
        </a>
      </div>
    </main>
  );
}
