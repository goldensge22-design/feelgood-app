import { NextRequest, NextResponse } from "next/server";
import { MOCK_SESSION_COOKIE } from "@/adapters/mock/auth-session-adapter.mock";
import { getAdapterMode } from "@/adapters/registry";

// 개발/데모 전용 "로그인 스위치". 실제 로그인 화면을 대체하지 않는다(§18 신규 인증 시스템
// 금지) — real 모드에서는 이 라우트가 심는 쿠키를 real AuthSessionAdapter가 이해하지
// 못하므로(실제 서버가 모르는 쿠키명) 자연히 무효화된다. mock 모드에서만 의미가 있다.
const ACCOUNT_BY_ROLE: Record<string, string> = {
  parent: "acc-parent-01",
  learner: "acc-learner-01",
  teacher: "acc-teacher-01",
};

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const as = url.searchParams.get("as") ?? "parent";
  const redirectTo = url.searchParams.get("redirect") ?? "/my-nuvia";
  const accountId = ACCOUNT_BY_ROLE[as] ?? ACCOUNT_BY_ROLE.parent;

  if (getAdapterMode() === "real") {
    return NextResponse.json(
      { error: "dev-login은 mock 모드에서만 동작합니다. NUVIA_ADAPTER_MODE=mock으로 설정하세요." },
      { status: 400 }
    );
  }

  const res = NextResponse.redirect(new URL(redirectTo, req.url));
  res.cookies.set(MOCK_SESSION_COOKIE, accountId, { path: "/", httpOnly: true, sameSite: "lax" });
  return res;
}
