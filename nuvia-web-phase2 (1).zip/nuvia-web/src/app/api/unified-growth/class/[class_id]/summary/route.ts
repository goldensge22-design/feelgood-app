import { NextRequest, NextResponse } from "next/server";
import { resolveViewerContextFromRequest } from "@/lib/resolve-viewer-context";
import { unifiedGrowthModule } from "@/domain/unified-growth-module";

// GET /unified-growth/class/{class_id}/summary — PHASE 1 §8 (PATCH 3)
// viewer_role=teacher && relationship_scope.type="class" && scope_id=class_id 세션만 호출 가능.
// 학생 개별 식별/랭킹 데이터는 포함하지 않는다.
export async function GET(req: NextRequest, { params }: { params: { class_id: string } }) {
  const viewer = await resolveViewerContextFromRequest(req);
  if (!viewer) return NextResponse.json({ error: "unauthenticated" }, { status: 401 });

  const allowed =
    viewer.viewer_role === "teacher" &&
    viewer.relationship_scope.type === "class" &&
    viewer.relationship_scope.scope_id === params.class_id;

  if (!allowed) {
    return NextResponse.json({ error: "forbidden" }, { status: 403 });
  }

  const summary = await unifiedGrowthModule.getClassSummary(params.class_id);
  return NextResponse.json(summary);
}
