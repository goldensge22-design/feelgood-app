import { NextRequest, NextResponse } from "next/server";
import { resolveViewerContextFromRequest } from "@/lib/resolve-viewer-context";
import { isLearnerAllowed } from "@/lib/viewer-context";
import { unifiedGrowthModule } from "@/domain/unified-growth-module";

// GET /unified-growth/{learner_id}/connections — PHASE 1 §8 / Growth Connection Engine (§12)
export async function GET(req: NextRequest, { params }: { params: { learner_id: string } }) {
  const viewer = await resolveViewerContextFromRequest(req);
  if (!viewer) return NextResponse.json({ error: "unauthenticated" }, { status: 401 });

  if (viewer.relationship_scope.type === "direct" && !isLearnerAllowed(viewer, params.learner_id)) {
    return NextResponse.json({ error: "forbidden", fallback: "/my-nuvia" }, { status: 403 });
  }

  const connections = await unifiedGrowthModule.getConnections(viewer, params.learner_id);
  return NextResponse.json(connections);
}
