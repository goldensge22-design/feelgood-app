import { NextRequest, NextResponse } from "next/server";
import { resolveViewerContextFromRequest } from "@/lib/resolve-viewer-context";
import { isLearnerAllowed } from "@/lib/viewer-context";
import { unifiedGrowthModule } from "@/domain/unified-growth-module";
import { isStudentInClass } from "@/lib/mock-class-roster";

// GET /unified-growth/{learner_id}/role-view — PHASE 1 §8
// viewer_role은 응답 구성 요소일 뿐 입력 파라미터가 아니다 — 세션에서만 파생.
export async function GET(req: NextRequest, { params }: { params: { learner_id: string } }) {
  const viewer = await resolveViewerContextFromRequest(req);
  if (!viewer) return NextResponse.json({ error: "unauthenticated" }, { status: 401 });

  if (viewer.viewer_role === "teacher") {
    // 학생 key → canonical learner_id 매핑은 STEP 0 항목이지만, 요청된 learner가 자신의
    // class 소속인지는 지금도 검증한다 — 다른 학급 학생 조회를 막는다(개인 View 접근 통제).
    const allowed =
      viewer.relationship_scope.type === "class" &&
      !!viewer.relationship_scope.scope_id &&
      isStudentInClass(viewer.relationship_scope.scope_id, params.learner_id);

    if (!allowed) {
      return NextResponse.json({ error: "forbidden" }, { status: 403 });
    }

    const payload = await unifiedGrowthModule.getOverview(viewer, params.learner_id);
    return NextResponse.json({ viewer_role: viewer.viewer_role, visibility_filtered_payload: payload });
  }

  if (viewer.relationship_scope.type === "direct" && !isLearnerAllowed(viewer, params.learner_id)) {
    return NextResponse.json({ error: "forbidden", fallback: "/my-nuvia" }, { status: 403 });
  }

  const payload = await unifiedGrowthModule.getOverview(viewer, params.learner_id);
  return NextResponse.json({ viewer_role: viewer.viewer_role, visibility_filtered_payload: payload });
}
