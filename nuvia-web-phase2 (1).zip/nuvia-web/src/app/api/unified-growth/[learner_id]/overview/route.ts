import { NextRequest, NextResponse } from "next/server";
import { resolveViewerContextFromRequest } from "@/lib/resolve-viewer-context";
import { isLearnerAllowed } from "@/lib/viewer-context";
import { unifiedGrowthModule } from "@/domain/unified-growth-module";

// GET /unified-growth/{learner_id}/overview — PHASE 1 §8
// viewer_role은 절대 query/body로 받지 않는다 — 요청의 쿠키/Authorization에서만 파생.
export async function GET(req: NextRequest, { params }: { params: { learner_id: string } }) {
  const viewer = await resolveViewerContextFromRequest(req);
  if (!viewer) {
    return NextResponse.json({ error: "unauthenticated" }, { status: 401 });
  }

  const { learner_id } = params;

  if (viewer.relationship_scope.type === "direct" && !isLearnerAllowed(viewer, learner_id)) {
    // §9 Deep Link 무권한 접근 처리와 동일 규칙: 403 + 기본 Home 폴백 지시
    return NextResponse.json({ error: "forbidden", fallback: "/my-nuvia" }, { status: 403 });
  }

  const overview = await unifiedGrowthModule.getOverview(viewer, learner_id);
  return NextResponse.json(overview);
}
