// PHASE 1 §1 Technical Architecture의 Domain Layer.
// - read-only: 어떤 Adapter도 write 호출을 하지 않는다.
// - Branch 원본 metric을 재계산하지 않고 Adapter가 제공하는 summary를 그대로 조립한다.
// - Visibility Policy는 이 계층 한 곳에서만 적용한다.

import { ViewerContext } from "../types/viewer-context";
import { GrowthConnection, InsightCard, MetacogSummary, ClassSummary } from "../types/growth";
import { TimelineResponse, TimelineEvent, EpochInfo, EpochAssignment } from "../types/timeline";
import { AssessmentProfile } from "../types/assessment";
import { ProgramState } from "../types/program";

import {
  AssessmentAdapter,
  ProgramStatusAdapter,
  KidsGrowthAdapter,
  HistoryGrowthAdapter,
  PlannerGrowthAdapter,
  VisibilityPolicyAdapter,
  ClassRosterAdapter,
} from "../adapters/types";
import { AdapterError, AdapterErrorKind } from "../adapters/errors";
import { evaluateGrowthConnections } from "./growth-connection-engine";
import { getDomainAdapterBundle } from "../adapters/registry";

const defaultAdapters = getDomainAdapterBundle(); // NUVIA_ADAPTER_MODE (기본값 mock)에 따라 결정

const EMPTY_GROWTH_SUMMARY = { growth_data_status: "no_data" as const, metrics: {}, updated_at: new Date(0).toISOString() };
const EMPTY_PLANNER_SUMMARY = { ...EMPTY_GROWTH_SUMMARY };

export type OverviewSource = "assessment" | "programs" | "kids" | "history" | "planner";
export interface PartialError {
  source: OverviewSource;
  kind: AdapterErrorKind;
}

export interface OverviewResponse {
  profile_summary: AssessmentProfile | null;
  active_programs: ProgramState[];
  growth_preview: {
    train: Awaited<ReturnType<KidsGrowthAdapter["getTrainSummary"]>>;
    think: Awaited<ReturnType<HistoryGrowthAdapter["getThinkSummary"]>>;
    manage: Awaited<ReturnType<PlannerGrowthAdapter["getManageSummary"]>>;
    metacognition: MetacogSummary;
  };
  recent_insights: InsightCard[];
  /** (9) API error/timeout/partial-data 처리 규칙 — 일부 소스가 실패해도 나머지는 정상 렌더하고,
   *  실패한 영역만 여기 기록한다(UI가 "일시적으로 불러올 수 없습니다"로 표시할 수 있게). */
  partial_errors?: PartialError[];
}

export class UnifiedGrowthModule {
  constructor(
    private assessment: AssessmentAdapter = defaultAdapters.assessment,
    private programStatus: ProgramStatusAdapter = defaultAdapters.programStatus,
    private kids: KidsGrowthAdapter = defaultAdapters.kids,
    private history: HistoryGrowthAdapter = defaultAdapters.history,
    private planner: PlannerGrowthAdapter = defaultAdapters.planner,
    private visibility: VisibilityPolicyAdapter = defaultAdapters.visibilityPolicy,
    private classRoster: ClassRosterAdapter = defaultAdapters.classRoster
  ) {}

  /**
   * (9) 공통 partial-data 처리 규칙.
   * - unauthorized / invalid_config → 그대로 던진다: 세션이 무효하거나 배포 설정이 잘못된
   *   상태로 "일부만 비어 보이는" 화면을 보여주면 안 된다(상위에서 401/500으로 처리).
   * - timeout / not_found / upstream_error / network_error → fallback 값으로 흡수하고
   *   partial_errors에 기록한다. 해당 영역만 Empty/일시 오류로 보이고 나머지는 정상 렌더된다.
   */
  private async loadWithFallback<T>(
    source: OverviewSource,
    promise: Promise<T>,
    fallback: T
  ): Promise<{ value: T; error?: PartialError }> {
    try {
      return { value: await promise };
    } catch (err) {
      const kind: AdapterErrorKind = err instanceof AdapterError ? err.kind : "network_error";
      if (kind === "unauthorized" || kind === "invalid_config") throw err;
      return { value: fallback, error: { source, kind } };
    }
  }

  async getOverview(viewer: ViewerContext, learnerId: string): Promise<OverviewResponse> {
    const [profileR, programsR, trainR, thinkR, manageR] = await Promise.all([
      this.loadWithFallback("assessment", this.assessment.getLatestProfile(learnerId), null),
      this.loadWithFallback("programs", this.programStatus.getActivePrograms(learnerId), [] as ProgramState[]),
      this.loadWithFallback("kids", this.kids.getTrainSummary(learnerId), EMPTY_GROWTH_SUMMARY),
      this.loadWithFallback("history", this.history.getThinkSummary(learnerId), EMPTY_GROWTH_SUMMARY),
      this.loadWithFallback("planner", this.planner.getManageSummary(learnerId), EMPTY_PLANNER_SUMMARY),
    ]);
    const profile = profileR.value;
    const activePrograms = programsR.value;
    const train = trainR.value;
    const think = thinkR.value;
    const manage = manageR.value;
    const partial_errors = [profileR.error, programsR.error, trainR.error, thinkR.error, manageR.error].filter(
      (e): e is PartialError => !!e
    );

    // Unified Total Score 생성 금지: train/think/manage를 합산하지 않고 그대로 병렬 반환
    const metacognition: MetacogSummary = {
      patterns: {
        prediction_vs_actual: manage.metrics.time_prediction_accuracy?.observation ?? null,
        self_assessment_vs_actual: null,
        strategy_awareness: train.metrics.strategy?.observation ?? null,
        strategy_change: null,
        next_action_choice: null,
      },
    };

    const recentInsights = this.buildRecentInsights({ train, manage }).slice(0, 2); // Home 노출은 1~2개로 제한 (§7)

    const raw: OverviewResponse = {
      profile_summary: await this.visibility.filter(viewer, learnerId, "assessment", profile),
      active_programs: await this.visibility.filter(viewer, learnerId, "program", activePrograms),
      growth_preview: await this.visibility.filter(viewer, learnerId, "growth", { train, think, manage, metacognition }),
      recent_insights: await this.visibility.filter(viewer, learnerId, "insight", recentInsights),
      ...(partial_errors.length > 0 ? { partial_errors } : {}),
    };
    return raw;
  }

  async getInsights(viewer: ViewerContext, learnerId: string): Promise<InsightCard[]> {
    // §8 라우팅: /my-nuvia/insights → overview.recent_insights. Home은 1~2개로 제한 노출하지만(§7)
    // 전용 Insights 화면에서는 캡 없이 동일 소스를 그대로 보여준다 — 새 Insight를 생성하지 않는다.
    const [trainR, manageR] = await Promise.all([
      this.loadWithFallback("kids", this.kids.getTrainSummary(learnerId), EMPTY_GROWTH_SUMMARY),
      this.loadWithFallback("planner", this.planner.getManageSummary(learnerId), EMPTY_PLANNER_SUMMARY),
    ]);
    const all = this.buildRecentInsights({ train: trainR.value, manage: manageR.value });
    return this.visibility.filter(viewer, learnerId, "insight", all);
  }

  async getConnections(viewer: ViewerContext, learnerId: string): Promise<GrowthConnection[]> {
    // Growth Connection Engine — SAME DOMAIN / SAME PERIOD / MINIMUM DATA / VALID METRIC (evaluateGrowthConnections)
    // VISIBILITY는 아래 visibility.filter가 최종 결과에 적용한다(§12).
    const [kidsR, historyR, plannerR] = await Promise.all([
      this.loadWithFallback("kids", this.kids.getTrainSummary(learnerId), EMPTY_GROWTH_SUMMARY),
      this.loadWithFallback("history", this.history.getThinkSummary(learnerId), EMPTY_GROWTH_SUMMARY),
      this.loadWithFallback("planner", this.planner.getManageSummary(learnerId), EMPTY_PLANNER_SUMMARY),
    ]);
    const connections = evaluateGrowthConnections({ kids: kidsR.value, history: historyR.value, planner: plannerR.value });
    return this.visibility.filter(viewer, learnerId, "growth", connections);
  }

  async getTimeline(viewer: ViewerContext, learnerId: string): Promise<TimelineResponse> {
    // §11: 서로 다른 Branch 이벤트를 하나의 Y축에 합치지 않고 병렬 트랙으로만 구성한다.
    // §20: 재검사 전/후를 하나의 연속 성장선으로 합치지 않는다 — 모든 이벤트에 epoch_index를 태그한다.
    const [historyR, programsR] = await Promise.all([
      this.loadWithFallback("assessment", this.assessment.getProfileHistory(learnerId), [] as AssessmentProfile[]),
      this.loadWithFallback("programs", this.programStatus.getActivePrograms(learnerId), [] as ProgramState[]),
    ]);
    const profileHistory = [...historyR.value].sort((a, b) => (a.assessed_at < b.assessed_at ? -1 : 1));
    const activePrograms = programsR.value;

    const epochs: EpochInfo[] = profileHistory.map((p, i) => ({
      epoch_index: i,
      assessment_profile_version: p.assessment_profile_version,
      started_at: p.assessed_at,
    })); // 검사 이력이 없으면 빈 배열 — pre_assessment로만 표시된다(§20).

    const assessment_events: TimelineEvent[] = profileHistory.map((p, i) => ({
      type: i === 0 ? "assessment" : "profile_update",
      label: `${p.assessment_profile_version} 검사`,
      occurred_at: p.assessed_at,
      source: "ASSESSMENT",
      epoch_index: i,
      phase: "assessment_epoch",
    }));

    const program_events: TimelineEvent[] = activePrograms
      .filter((p) => p.last_activity_at)
      .map((p) => {
        const assignment = computeEpochAssignment(p.last_activity_at as string, profileHistory);
        return {
          type: "recent_activity", // started_at이 없으므로 '시작'으로 단정하지 않고 최근 활동으로만 표시
          label: `${p.program_id} 최근 활동`,
          occurred_at: p.last_activity_at as string,
          source: p.program_id,
          epoch_index: assignment.epoch_index,
          phase: assignment.phase,
        };
      });

    const growth_signals: TimelineEvent[] = []; // 최소 데이터 조건 충족 시에만 채워짐(§11)

    const raw: TimelineResponse = { assessment_events, program_events, growth_signals, epochs };
    return this.visibility.filter(viewer, learnerId, "growth", raw);
  }

  async getClassSummary(classId: string): Promise<ClassSummary> {
    // §12/§17 Class View — 개인 식별/랭킹 없이 분포·집계만 반환. roster의 실제(mock) 학생
    // 데이터를 집계한다 — 고정 숫자를 반환하지 않는다. 학생 한 명의 API 실패가 전체 집계를
    // 막지 않도록 개별 조회는 safeFetch로 흡수한다(Partial Failure 유지).
    const learnerIds = await this.classRoster.getRosterLearnerIds(classId);

    const perStudent = await Promise.all(
      learnerIds.map(async (id) => ({
        profile: await this.safeFetch(this.assessment.getLatestProfile(id), null),
        programs: await this.safeFetch(this.programStatus.getActivePrograms(id), [] as ProgramState[]),
        train: await this.safeFetch(this.kids.getTrainSummary(id), EMPTY_GROWTH_SUMMARY),
        think: await this.safeFetch(this.history.getThinkSummary(id), EMPTY_GROWTH_SUMMARY),
        manage: await this.safeFetch(this.planner.getManageSummary(id), EMPTY_PLANNER_SUMMARY),
      }))
    );

    const cognitive_distribution = tallyLabels(perStudent.flatMap((s) => s.profile?.support_areas ?? []));
    const training_distribution = tallyDirections(perStudent.map((s) => s.train));
    const thinking_distribution = tallyDirections(perStudent.map((s) => s.think));
    const self_management_distribution = tallyDirections(perStudent.map((s) => s.manage));
    const self_management_needs_observation_by_metric = tallyNeedsObservationByMetricKey(perStudent.map((s) => s.manage));

    const activeLearnerCount = perStudent.filter((s) => s.programs.some((p) => p.program_status === "active")).length;
    const sufficientCount = perStudent.filter((s) =>
      [s.train, s.think, s.manage].some((g) => g.growth_data_status === "sufficient")
    ).length;
    const stableRatio = learnerIds.length > 0 ? sufficientCount / learnerIds.length : 0;

    return {
      cognitive_distribution,
      training_distribution,
      thinking_distribution,
      self_management_distribution,
      participation_summary: {
        active_learner_count: activeLearnerCount,
        stable_participation_ratio: Math.round(stableRatio * 100) / 100,
      },
      suggested_class_strategy: buildClassStrategy(self_management_distribution, self_management_needs_observation_by_metric),
    };
  }

  /** Class Aggregate 전용 — 학생 1인의 실패가 전체 집계를 막지 않도록 조용히 fallback으로 흡수한다. */
  private async safeFetch<T>(promise: Promise<T>, fallback: T): Promise<T> {
    try {
      return await promise;
    } catch (err) {
      const kind: AdapterErrorKind = err instanceof AdapterError ? err.kind : "network_error";
      if (kind === "unauthorized" || kind === "invalid_config") throw err;
      return fallback;
    }
  }

  private buildRecentInsights(input: {
    train: Awaited<ReturnType<KidsGrowthAdapter["getTrainSummary"]>>;
    manage: Awaited<ReturnType<PlannerGrowthAdapter["getManageSummary"]>>;
  }): InsightCard[] {
    const cards: InsightCard[] = [];
    if (input.train.metrics.strategy) {
      cards.push({
        observation: input.train.metrics.strategy.observation,
        interpretation: "과제 접근에서 단계적 전략을 시도하는 패턴이 나타나고 있습니다.",
        actions: ["다음 미션에서도 같은 전략을 이어가 보세요."],
      });
    }
    if (input.manage.task_breakdown_observation) {
      cards.push({
        observation: input.manage.task_breakdown_observation.text,
        interpretation: "큰 과제를 여러 단계로 나누어 접근하는 행동이 나타나고 있습니다.",
        actions: ["다음 큰 과제도 시작 전에 2~3단계로 나눠보세요."],
      });
    }
    return cards; // 캡은 getOverview 호출부에서만 적용 — 이 메서드 자체는 전체 목록을 반환
  }
}

export const unifiedGrowthModule = new UnifiedGrowthModule();

/** §20 Epoch 판정 — occurredAt 이전(또는 당일)에 시작된 가장 최근 assessment의 index를 반환한다. */
/** §20 Epoch 판정 — 첫 검사 이전은 pre_assessment(epoch_index null), 그 이후는
 *  occurredAt 이전(또는 당일)에 시작된 가장 최근 assessment의 index를 assessment_epoch로 반환한다. */
export function computeEpochAssignment(
  occurredAt: string,
  sortedAssessments: { assessed_at: string }[]
): EpochAssignment {
  if (sortedAssessments.length === 0 || occurredAt < sortedAssessments[0].assessed_at) {
    return { epoch_index: null, phase: "pre_assessment" };
  }
  let idx = 0;
  for (let i = 0; i < sortedAssessments.length; i++) {
    if (sortedAssessments[i].assessed_at <= occurredAt) idx = i;
  }
  return { epoch_index: idx, phase: "assessment_epoch" };
}

// --- Class Aggregate 집계 헬퍼 (순수 함수, 단위 테스트 대상) ---

export function tallyLabels(labels: string[]): { labels: string[]; counts: number[] } {
  const counts = new Map<string, number>();
  for (const label of labels) counts.set(label, (counts.get(label) ?? 0) + 1);
  return { labels: Array.from(counts.keys()), counts: Array.from(counts.values()) };
}

const DIRECTION_LABEL: Record<string, string> = {
  improving: "개선 경향",
  stable: "안정적 유지",
  needs_observation: "관찰 필요",
  not_interpreted: "해석 보류",
};

export function tallyDirections(summaries: { metrics: Record<string, { display_direction: string } | undefined> }[]) {
  const directions: string[] = [];
  for (const s of summaries) {
    for (const metric of Object.values(s.metrics)) {
      if (metric) directions.push(DIRECTION_LABEL[metric.display_direction] ?? metric.display_direction);
    }
  }
  return tallyLabels(directions);
}

/** metric_key별로 "관찰 필요/해석 보류" 빈도를 집계한다 — buildClassStrategy가 특정 metric에
 *  근거가 있을 때만 그 metric에 맞는 제안을 하도록 하기 위한 근거 데이터. */
export function tallyNeedsObservationByMetricKey(
  summaries: { metrics: Record<string, { display_direction: string } | undefined> }[]
): Record<string, number> {
  const counts: Record<string, number> = {};
  for (const s of summaries) {
    for (const [key, metric] of Object.entries(s.metrics)) {
      if (metric && (metric.display_direction === "needs_observation" || metric.display_direction === "not_interpreted")) {
        counts[key] = (counts[key] ?? 0) + 1;
      }
    }
  }
  return counts;
}

export function buildClassStrategy(
  selfManagementDistribution: { labels: string[]; counts: number[] },
  needsObservationByMetricKey: Record<string, number> = {}
): string[] {
  if (selfManagementDistribution.labels.length === 0) return [];

  let topIndex = 0;
  for (let i = 1; i < selfManagementDistribution.counts.length; i++) {
    if (selfManagementDistribution.counts[i] > selfManagementDistribution.counts[topIndex]) topIndex = i;
  }
  const topLabel = selfManagementDistribution.labels[topIndex];

  if (topLabel === "개선 경향") {
    return ["이 학급은 자기관리 영역에서 전반적으로 개선 경향이 관찰됩니다. 현재 진행 중인 활동을 유지해볼 수 있습니다."];
  }

  if (topLabel === "관찰 필요" || topLabel === "해석 보류") {
    // 집계(direction 라벨)만으로는 어떤 metric이 원인인지 특정할 수 없다 — metric_key별 근거가
    // 있을 때만, 그리고 그 근거가 실제로 time_prediction_accuracy를 가리킬 때만 구체적 제안을 한다.
    const entries = Object.entries(needsObservationByMetricKey);
    if (entries.length > 0) {
      const [topMetricKey] = entries.reduce((a, b) => (b[1] > a[1] ? b : a));
      if (topMetricKey === "time_prediction_accuracy") {
        return [
          "이 학급에서는 예상 소요시간과 실제시간의 차이가 더 자주 관찰됩니다. 다음 수행평가에서 예상시간 기록 활동을 활용해볼 수 있습니다.",
        ];
      }
    }
    return ["이 학급은 자기관리 영역에서 관찰이 필요한 패턴이 나타납니다. 학생별 최근 활동을 개별적으로 확인해보는 것을 권장합니다."];
  }

  return [];
}
