import { test } from "node:test";
import assert from "node:assert/strict";
import { tallyLabels, tallyDirections, tallyNeedsObservationByMetricKey, buildClassStrategy } from "../unified-growth-module";

test("TC-CA-1: tallyLabels — 개인 식별자 없이 라벨별 빈도만 집계", () => {
  const result = tallyLabels(["Attention", "Planning", "Attention"]);
  assert.equal(result.labels.length, 2);
  const idx = result.labels.indexOf("Attention");
  assert.equal(result.counts[idx], 2);
});

test("TC-CA-2: tallyLabels — 데이터 없음(빈 배열)이면 빈 분포", () => {
  const result = tallyLabels([]);
  assert.deepEqual(result, { labels: [], counts: [] });
});

test("TC-CA-3: tallyDirections — display_direction을 한글 라벨로 변환해 집계, 학생 식별자는 결과에 없음", () => {
  const summaries = [
    { metrics: { a: { display_direction: "improving" }, b: { display_direction: "needs_observation" } } },
    { metrics: { a: { display_direction: "improving" } } },
  ];
  const result = tallyDirections(summaries);
  const improvingIdx = result.labels.indexOf("개선 경향");
  assert.equal(result.counts[improvingIdx], 2);
  assert.deepEqual(Object.keys(result).sort(), ["counts", "labels"]);
});

test("TC-CA-4 (semantic patch): metric 근거 없이 '관찰 필요'가 최빈값이면 일반 문구만 — 시간예측을 임의로 특정하지 않음", () => {
  const strategy = buildClassStrategy({ labels: ["개선 경향", "관찰 필요"], counts: [3, 7] }); // 두 번째 인자 생략
  assert.equal(strategy.length, 1);
  assert.doesNotMatch(strategy[0], /예상 소요시간과 실제시간/);
  assert.match(strategy[0], /개별적으로 확인/);
});

test("TC-CA-5 (semantic patch): time_prediction_accuracy가 실제 최다 근거일 때만 시간예측 문구", () => {
  const strategy = buildClassStrategy(
    { labels: ["관찰 필요"], counts: [7] },
    { time_prediction_accuracy: 6, start_accuracy: 2 }
  );
  assert.equal(strategy.length, 1);
  assert.match(strategy[0], /예상 소요시간과 실제시간/);
});

test("TC-CA-6 (semantic patch): 다른 metric(time_prediction_accuracy 아님)이 최다 근거면 일반 문구", () => {
  const strategy = buildClassStrategy(
    { labels: ["관찰 필요"], counts: [7] },
    { start_accuracy: 5, focus_stability: 3 } // time_prediction_accuracy가 최다가 아님
  );
  assert.equal(strategy.length, 1);
  assert.doesNotMatch(strategy[0], /예상 소요시간과 실제시간/);
});

test("TC-CA-7: buildClassStrategy — 분포가 비어 있으면 제안 없음(빈 배열)", () => {
  assert.deepEqual(buildClassStrategy({ labels: [], counts: [] }), []);
});

test("TC-CA-8: buildClassStrategy — 출력 문구에 학생 개인 식별/순위 표현이 없음", () => {
  const strategy = buildClassStrategy({ labels: ["관찰 필요"], counts: [5] });
  for (const line of strategy) {
    assert.doesNotMatch(line, /\d+등|1위|랭킹|순위/);
  }
});

test("TC-CA-9: tallyNeedsObservationByMetricKey — needs_observation/not_interpreted만 집계, improving/stable은 제외", () => {
  const summaries = [
    { metrics: { time_prediction_accuracy: { display_direction: "needs_observation" }, start_accuracy: { display_direction: "improving" } } },
    { metrics: { time_prediction_accuracy: { display_direction: "not_interpreted" } } },
  ];
  const result = tallyNeedsObservationByMetricKey(summaries);
  assert.equal(result.time_prediction_accuracy, 2);
  assert.equal(result.start_accuracy, undefined);
});
