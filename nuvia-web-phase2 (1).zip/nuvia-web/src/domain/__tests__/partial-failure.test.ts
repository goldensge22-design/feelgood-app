import { test } from "node:test";
import assert from "node:assert/strict";
import { UnifiedGrowthModule } from "../unified-growth-module";
import { AdapterError } from "../../adapters/errors";
import { ViewerContext } from "../../types/viewer-context";

const viewer: ViewerContext = {
  account_id: "acc-test",
  viewer_role: "learner",
  subject_learner_id: "learner-test",
  relationship_scope: { type: "direct", learner_ids: ["learner-test"] },
};

const passthroughVisibility = { filter: async (_v: unknown, _s: unknown, _d: unknown, payload: unknown) => payload };

test("TC-PF-1: PLANNER가 timeout이어도 나머지 소스는 정상 반환되고 partial_errors에 기록됨", async () => {
  const module = new UnifiedGrowthModule(
    { getLatestProfile: async () => null, getProfileHistory: async () => [] },
    { getProgramStatus: async () => { throw new Error("unused"); }, getActivePrograms: async () => [] },
    { getTrainSummary: async () => ({ growth_data_status: "sufficient", metrics: {}, updated_at: "" }) },
    { getThinkSummary: async () => ({ growth_data_status: "no_data", metrics: {}, updated_at: "" }) },
    { getManageSummary: async () => { throw new AdapterError("timeout", "PlannerGrowthAdapter", "boom"); } },
    passthroughVisibility as never
  );

  const overview = await module.getOverview(viewer, "learner-test");
  assert.equal(overview.growth_preview.manage.growth_data_status, "no_data"); // fallback 값
  assert.ok(overview.partial_errors && overview.partial_errors.some((e) => e.source === "planner" && e.kind === "timeout"));
  // 다른 소스는 정상 반영됨을 확인
  assert.equal(overview.growth_preview.train.growth_data_status, "sufficient");
});

test("TC-PF-2: unauthorized는 흡수하지 않고 그대로 던진다(전체 요청 실패)", async () => {
  const module = new UnifiedGrowthModule(
    { getLatestProfile: async () => { throw new AdapterError("unauthorized", "AssessmentAdapter", "no session"); }, getProfileHistory: async () => [] },
    { getProgramStatus: async () => { throw new Error("unused"); }, getActivePrograms: async () => [] },
    { getTrainSummary: async () => ({ growth_data_status: "no_data", metrics: {}, updated_at: "" }) },
    { getThinkSummary: async () => ({ growth_data_status: "no_data", metrics: {}, updated_at: "" }) },
    { getManageSummary: async () => ({ growth_data_status: "no_data", metrics: {}, updated_at: "" }) },
    passthroughVisibility as never
  );

  await assert.rejects(() => module.getOverview(viewer, "learner-test"), (err: unknown) => err instanceof AdapterError && err.kind === "unauthorized");
});

test("TC-PF-3: invalid_config도 흡수하지 않고 그대로 던진다", async () => {
  const module = new UnifiedGrowthModule(
    { getLatestProfile: async () => null, getProfileHistory: async () => [] },
    { getProgramStatus: async () => { throw new Error("unused"); }, getActivePrograms: async () => { throw new AdapterError("invalid_config", "ProgramStatusAdapter", ".env missing"); } },
    { getTrainSummary: async () => ({ growth_data_status: "no_data", metrics: {}, updated_at: "" }) },
    { getThinkSummary: async () => ({ growth_data_status: "no_data", metrics: {}, updated_at: "" }) },
    { getManageSummary: async () => ({ growth_data_status: "no_data", metrics: {}, updated_at: "" }) },
    passthroughVisibility as never
  );

  await assert.rejects(() => module.getOverview(viewer, "learner-test"), (err: unknown) => err instanceof AdapterError && err.kind === "invalid_config");
});

test("TC-PF-4: 여러 소스가 동시에 실패해도 각각 partial_errors에 개별 기록됨", async () => {
  const module = new UnifiedGrowthModule(
    { getLatestProfile: async () => { throw new AdapterError("not_found", "AssessmentAdapter", "no profile"); }, getProfileHistory: async () => [] },
    { getProgramStatus: async () => { throw new Error("unused"); }, getActivePrograms: async () => { throw new AdapterError("network_error", "ProgramStatusAdapter", "conn refused"); } },
    { getTrainSummary: async () => ({ growth_data_status: "no_data", metrics: {}, updated_at: "" }) },
    { getThinkSummary: async () => ({ growth_data_status: "no_data", metrics: {}, updated_at: "" }) },
    { getManageSummary: async () => ({ growth_data_status: "no_data", metrics: {}, updated_at: "" }) },
    passthroughVisibility as never
  );

  const overview = await module.getOverview(viewer, "learner-test");
  assert.equal(overview.profile_summary, null);
  assert.deepEqual(overview.active_programs, []);
  const sources = (overview.partial_errors ?? []).map((e) => e.source).sort();
  assert.deepEqual(sources, ["assessment", "programs"]);
});
