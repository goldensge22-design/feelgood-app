import { test } from "node:test";
import assert from "node:assert/strict";
import { pickPrimaryMetric } from "../visibility-policy";
import { GrowthSummary } from "../../types/growth";

type K = "a" | "b" | "c";
const PRIORITY: readonly K[] = ["b", "a", "c"]; // 우선순위상 b가 a보다 먼저

function summary(overrides: Partial<GrowthSummary<K>>): GrowthSummary<K> {
  return { growth_data_status: "sufficient", metrics: {}, updated_at: "", ...overrides };
}

test("TC-PM-1 (PATCH 2): primary_metric_key가 있으면 우선순위 목록과 무관하게 그 metric을 사용", () => {
  const s = summary({
    primary_metric_key: "a",
    metrics: {
      a: { trend: "up", display_direction: "improving", observation: "A" },
      b: { trend: "up", display_direction: "improving", observation: "B" },
    },
  });
  const result = pickPrimaryMetric(s, PRIORITY); // priority상 b가 먼저지만 primary_metric_key=a를 따라야 함
  assert.deepEqual(Object.keys(result.metrics), ["a"]);
});

test("TC-PM-2 (PATCH 2): primary_metric_key 없음 + priority 있음 → priority 순서상 첫 번째로 존재하는 metric 사용", () => {
  const s = summary({
    metrics: {
      a: { trend: "up", display_direction: "improving", observation: "A" },
      c: { trend: "up", display_direction: "improving", observation: "C" },
      // b는 없음 — priority 1순위(b)가 없으므로 다음 순위(a)를 써야 함
    },
  });
  const result = pickPrimaryMetric(s, PRIORITY);
  assert.deepEqual(Object.keys(result.metrics), ["a"]);
});

test("TC-PM-3 (PATCH 2): primary_metric_key 없음 + priority에 해당하는 metric도 전혀 없음 → 임의 선택하지 않고 metrics 비움", () => {
  const s = summary({
    metrics: {
      // priority(a/b/c) 중 어느 것도 존재하지 않는, 우선순위 밖의 metric만 있는 상황을 시뮬레이션
    },
  });
  const result = pickPrimaryMetric(s, PRIORITY);
  assert.deepEqual(result.metrics, {});
});

test("TC-PM-4 (PATCH 2): primary_metric_key가 지정됐지만 실제 metrics에 값이 없으면(유효하지 않으면) priority로 fallback", () => {
  const s = summary({
    primary_metric_key: "b", // b는 우선순위 1순위지만 실제 데이터가 없음
    metrics: {
      a: { trend: "up", display_direction: "improving", observation: "A" },
    },
  });
  const result = pickPrimaryMetric(s, PRIORITY);
  assert.deepEqual(Object.keys(result.metrics), ["a"]); // b 데이터가 없으므로 priority상 존재하는 a로 fallback
});

test("TC-PM-5 (PATCH 2): 대표 지표가 없을 때 나머지 필드(growth_data_status/updated_at)는 그대로 유지", () => {
  const s = summary({ growth_data_status: "sufficient", updated_at: "2026-09-09", metrics: {} });
  const result = pickPrimaryMetric(s, PRIORITY);
  assert.equal(result.growth_data_status, "sufficient");
  assert.equal(result.updated_at, "2026-09-09");
  assert.deepEqual(result.metrics, {});
});
