import { test } from "node:test";
import assert from "node:assert/strict";
import { evaluateGrowthConnections, mergePeriod, Candidate } from "../growth-connection-engine";
import { getMinimumObservations } from "../../config/observation-thresholds";
import { GrowthSummary, PlannerGrowthSummary, KidsMetricKey, HistoryMetricKey } from "../../types/growth";

const EMPTY_HISTORY: GrowthSummary<HistoryMetricKey> = { growth_data_status: "no_data", metrics: {}, updated_at: "" };
const EMPTY_PLANNER: PlannerGrowthSummary = { growth_data_status: "no_data", metrics: {}, updated_at: "" };

test("TC-GCE-1: 기준(threshold)이 미확정(null)이면 조건을 다 만족해도 INSUFFICIENT_DATA (실제 프로덕션 기본 동작)", () => {
  assert.equal(getMinimumObservations("planning_stepwise"), null); // observation-thresholds.ts 기본값 확인

  const result = evaluateGrowthConnections({
    kids: {
      growth_data_status: "sufficient",
      metrics: {
        strategy: {
          trend: "up", display_direction: "improving", observation: "x",
          observation_count: 100, window: { from: "2026-08-01", to: "2026-09-01" },
        },
      },
      updated_at: "",
    },
    history: EMPTY_HISTORY,
    planner: {
      ...EMPTY_PLANNER,
      metrics: {
        plan_order_consistency: {
          trend: "up", display_direction: "improving", observation: "y",
          observation_count: 100, window: { from: "2026-08-01", to: "2026-09-01" },
        },
      },
    },
  }); // getMinimum 인자 생략 → 실제 config(null) 사용

  assert.equal(result.length, 1);
  assert.equal(result[0].status, "INSUFFICIENT_DATA");
  assert.equal(result[0].sources.sort().join(","), "KIDS,PLANNER");
});

test("TC-GCE-2: SAME DOMAIN 미충족 — 단일 Branch만 기여하면 후보에서 제외", () => {
  const result = evaluateGrowthConnections({
    kids: {
      growth_data_status: "sufficient",
      metrics: { strategy: { trend: "up", display_direction: "improving", observation: "x" } },
      updated_at: "",
    },
    history: EMPTY_HISTORY,
    planner: EMPTY_PLANNER,
  });
  assert.equal(result.length, 0);
});

test("TC-GCE-3: VALID METRIC 미충족 — 태그 등록 안 된 metric은 후보에서 제외", () => {
  const result = evaluateGrowthConnections({
    kids: {
      growth_data_status: "sufficient",
      metrics: { accuracy: { trend: "up", display_direction: "improving", observation: "x" } }, // 태그 없음
      updated_at: "",
    },
    history: EMPTY_HISTORY,
    planner: EMPTY_PLANNER,
  });
  assert.equal(result.length, 0);
});

test("TC-GCE-4: threshold 주입 시 5조건 모두 충족 + 방향 일치 → CONSISTENT_PATTERN", () => {
  const result = evaluateGrowthConnections(
    {
      kids: {
        growth_data_status: "sufficient",
        metrics: {
          strategy: {
            trend: "up", display_direction: "improving", observation: "x",
            observation_count: 6, window: { from: "2026-08-15", to: "2026-09-09" },
          },
        },
        updated_at: "",
      },
      history: EMPTY_HISTORY,
      planner: {
        ...EMPTY_PLANNER,
        metrics: {
          plan_order_consistency: {
            trend: "up", display_direction: "improving", observation: "y",
            observation_count: 5, window: { from: "2026-08-20", to: "2026-09-09" },
          },
        },
      },
    },
    () => 5 // threshold를 5로 주입 (실제 config를 건드리지 않고 테스트)
  );
  assert.equal(result.length, 1);
  assert.equal(result[0].status, "CONSISTENT_PATTERN");
});

test("TC-GCE-5: threshold 충족 + 방향 불일치 → OBSERVED_TOGETHER", () => {
  const result = evaluateGrowthConnections(
    {
      kids: {
        growth_data_status: "sufficient",
        metrics: {
          strategy: {
            trend: "up", display_direction: "improving", observation: "x",
            observation_count: 6, window: { from: "2026-08-01", to: "2026-09-05" },
          },
        },
        updated_at: "",
      },
      history: {
        growth_data_status: "sufficient",
        metrics: {
          comparison: {
            trend: "flat", display_direction: "needs_observation", observation: "z",
            observation_count: 3, window: { from: "2026-08-01", to: "2026-09-05" },
          },
        },
        updated_at: "",
      },
      planner: EMPTY_PLANNER,
    },
    () => 3
  );
  assert.equal(result.length, 1);
  assert.equal(result[0].status, "OBSERVED_TOGETHER");
});

test("TC-GCE-6: MINIMUM DATA 미충족 — 한 소스라도 count가 기준 미만이면 INSUFFICIENT_DATA", () => {
  const result = evaluateGrowthConnections(
    {
      kids: {
        growth_data_status: "sufficient",
        metrics: {
          strategy: {
            trend: "up", display_direction: "improving", observation: "x",
            observation_count: 2, window: { from: "2026-08-01", to: "2026-09-05" }, // 기준(5) 미만
          },
        },
        updated_at: "",
      },
      history: EMPTY_HISTORY,
      planner: {
        ...EMPTY_PLANNER,
        metrics: {
          plan_order_consistency: {
            trend: "up", display_direction: "improving", observation: "y",
            observation_count: 10, window: { from: "2026-08-01", to: "2026-09-05" },
          },
        },
      },
    },
    () => 5
  );
  assert.equal(result.length, 1);
  assert.equal(result[0].status, "INSUFFICIENT_DATA");
});

test("TC-GCE-7: SAME PERIOD 불명(window 없음) → INSUFFICIENT_DATA", () => {
  const result = evaluateGrowthConnections(
    {
      kids: {
        growth_data_status: "sufficient",
        metrics: {
          strategy: { trend: "up", display_direction: "improving", observation: "x", observation_count: 10 }, // window 없음
        },
        updated_at: "",
      },
      history: EMPTY_HISTORY,
      planner: {
        ...EMPTY_PLANNER,
        metrics: {
          plan_order_consistency: {
            trend: "up", display_direction: "improving", observation: "y",
            observation_count: 10, window: { from: "2026-08-01", to: "2026-09-01" },
          },
        },
      },
    },
    () => 5
  );
  assert.equal(result.length, 1);
  assert.equal(result[0].status, "INSUFFICIENT_DATA");
});

test("TC-GCE-8 (화이트박스): mergePeriod — 겹치지 않는 구간은 null", () => {
  const group: Candidate[] = [
    { source: "KIDS", domain_key: "d", display_label: "d", metric: { trend: "up", display_direction: "improving", observation: "", window: { from: "2026-01-01", to: "2026-01-31" } } },
    { source: "PLANNER", domain_key: "d", display_label: "d", metric: { trend: "up", display_direction: "improving", observation: "", window: { from: "2026-03-01", to: "2026-03-31" } } },
  ];
  assert.equal(mergePeriod(group), null);
});
