import { test } from "node:test";
import assert from "node:assert/strict";
import { computeEpochAssignment } from "../unified-growth-module";

const assessments = [
  { assessed_at: "2025-09-01" }, // epoch 0 (v2)
  { assessed_at: "2026-03-10" }, // epoch 1 (v3)
];

test("TC-EPOCH-1 (PATCH 1): 첫 검사 이전 activity → phase=pre_assessment, epoch_index=null (첫 epoch과 섞이지 않음)", () => {
  const result = computeEpochAssignment("2025-08-01", assessments); // 첫 검사(2025-09-01) 이전
  assert.equal(result.phase, "pre_assessment");
  assert.equal(result.epoch_index, null);
});

test("TC-EPOCH-2: 첫 검사 이후 ~ 재검사 전 activity → phase=assessment_epoch, epoch_index=0", () => {
  const result = computeEpochAssignment("2025-12-01", assessments);
  assert.equal(result.phase, "assessment_epoch");
  assert.equal(result.epoch_index, 0);
});

test("TC-EPOCH-3: 재검사 당일 activity → 새 epoch(1)에 포함", () => {
  const result = computeEpochAssignment("2026-03-10", assessments);
  assert.equal(result.phase, "assessment_epoch");
  assert.equal(result.epoch_index, 1);
});

test("TC-EPOCH-4 (PATCH 1): 재검사 이후 activity → epoch 1 — pre_assessment/epoch 0과 섞이지 않음", () => {
  const result = computeEpochAssignment("2026-09-01", assessments);
  assert.equal(result.phase, "assessment_epoch");
  assert.equal(result.epoch_index, 1);
});

test("TC-EPOCH-5 (PATCH 1): 검사 이력이 전혀 없으면 모든 이벤트가 pre_assessment(더 이상 epoch 0으로 넣지 않음)", () => {
  const result = computeEpochAssignment("2026-09-01", []);
  assert.equal(result.phase, "pre_assessment");
  assert.equal(result.epoch_index, null);
});

test("TC-EPOCH-6 (PATCH 1): 첫 검사 이전/이후/재검사 이후 3개 이벤트가 서로 다른 phase·epoch로 배정된다", () => {
  const preAssessmentEvent = computeEpochAssignment("2025-06-01", assessments); // 첫 검사 이전
  const firstEpochEvent = computeEpochAssignment("2025-10-15", assessments); // 첫 검사 이후 ~ 재검사 전
  const secondEpochEvent = computeEpochAssignment("2026-05-01", assessments); // 재검사 이후

  assert.deepEqual(preAssessmentEvent, { phase: "pre_assessment", epoch_index: null });
  assert.deepEqual(firstEpochEvent, { phase: "assessment_epoch", epoch_index: 0 });
  assert.deepEqual(secondEpochEvent, { phase: "assessment_epoch", epoch_index: 1 });

  // 세 값이 서로 완전히 구분되는지(연속 성장선으로 합쳐지지 않는지) 명시적으로 확인
  const keys = [preAssessmentEvent, firstEpochEvent, secondEpochEvent].map((a) => `${a.phase}:${a.epoch_index}`);
  assert.equal(new Set(keys).size, 3);
});
