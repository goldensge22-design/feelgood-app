import { test } from "node:test";
import assert from "node:assert/strict";
import { applyVisibilityPolicy } from "../visibility-policy";
import { GrowthSummary, MetacogSummary, PlannerGrowthSummary } from "../../types/growth";

const preview = {
  train: {
    growth_data_status: "sufficient",
    metrics: {
      accuracy: { trend: "up", display_direction: "improving", observation: "정확도 상승" },
      strategy: { trend: "up", display_direction: "improving", observation: "전략 사용 증가" },
    },
    updated_at: "2026-09-09",
  } as GrowthSummary<string>,
  think: { growth_data_status: "no_data", metrics: {}, updated_at: "" } as GrowthSummary<string>,
  manage: {
    growth_data_status: "sufficient",
    metrics: { time_prediction_accuracy: { trend: "up", display_direction: "improving", observation: "시간예측 개선" } },
    updated_at: "2026-09-08",
    task_breakdown_observation: { text: "단계화 시도", observed_at: "2026-09-07" },
  } as PlannerGrowthSummary,
  metacognition: {
    patterns: {
      prediction_vs_actual: "예측-실제 차이 감소",
      self_assessment_vs_actual: "자기평가 일치도 상승",
      strategy_awareness: "전략 설명 가능",
      strategy_change: "전략 전환 관찰됨",
      next_action_choice: "다음 행동 스스로 선택",
    },
  } as MetacogSummary,
};

test("TC-VIS-1: learner — 전체 상세 그대로 노출", () => {
  const result = applyVisibilityPolicy("learner", "growth", preview);
  assert.equal(Object.keys(result.train.metrics).length, 2); // accuracy + strategy 둘 다
  assert.equal(result.metacognition.patterns.strategy_change, "전략 전환 관찰됨");
});

test("TC-VIS-2: teacher — 개인 View에서는 전체 상세 그대로 노출 (§17)", () => {
  const result = applyVisibilityPolicy("teacher", "growth", preview);
  assert.equal(Object.keys(result.train.metrics).length, 2);
});

test("TC-VIS-3: parent — domain당 대표 metric 1개로 축소, metacognition은 예측-실제만 유지", () => {
  const result = applyVisibilityPolicy("parent", "growth", preview);
  assert.equal(Object.keys(result.train.metrics).length, 1);
  assert.ok("accuracy" in result.train.metrics); // Object.keys 첫 번째 항목(accuracy)만 남음
  assert.equal(result.metacognition.patterns.prediction_vs_actual, "예측-실제 차이 감소");
  assert.equal(result.metacognition.patterns.strategy_change, null); // 나머지 패턴은 제거
  // growth_data_status/task_breakdown_observation 등 축소 대상이 아닌 필드는 유지
  assert.equal(result.manage.growth_data_status, "sufficient");
  assert.equal(result.manage.task_breakdown_observation?.text, "단계화 시도");
});

test("TC-VIS-4: institution — metric 자체를 노출하지 않고 상태값만", () => {
  const result = applyVisibilityPolicy("institution", "growth", preview);
  assert.equal(Object.keys(result.train.metrics).length, 0);
  assert.equal(Object.keys(result.manage.metrics).length, 0);
  assert.equal(result.train.growth_data_status, "sufficient"); // 상태값 자체는 유지(집계용)
  assert.equal(result.metacognition.patterns.prediction_vs_actual, null);
});

test("TC-VIS-5: growth 도메인이 아니면 role과 무관하게 그대로 통과", () => {
  const payload = { assessment_id: "a-001" };
  const result = applyVisibilityPolicy("parent", "assessment", payload);
  assert.deepEqual(result, payload);
});

test("TC-VIS-6: growth 도메인이지만 GrowthPreview 모양이 아니면(GrowthConnection[] 등) 그대로 통과", () => {
  const connections = [{ domain: "d", sources: ["KIDS"], period: { from: "", to: "" }, status: "INSUFFICIENT_DATA", display_text: "x" }];
  const result = applyVisibilityPolicy("parent", "growth", connections);
  assert.deepEqual(result, connections);
});

const insightWithPrivateFields = [
  {
    observation: "최근 시간예측 오차 감소",
    interpretation: "시간을 현실적으로 예상하는 패턴",
    actions: ["다음 과제도 단계별로 나눠보세요"],
    student_reflection_text: "오늘은 계획대로 못 해서 속상했다", // 학생 개인 일지 — 비공개 대상
    atomic_behavior_log: ["09:12 앱 실행", "09:15 미션1 시작", "09:40 미션1 중단"], // 원자 행동로그 — 비공개 대상
  },
];

test("TC-VIS-7 (semantic patch): learner — insight의 사적 필드까지 전부 그대로 노출(본인 데이터)", () => {
  const result = applyVisibilityPolicy("learner", "insight", insightWithPrivateFields);
  assert.equal(result[0].student_reflection_text, "오늘은 계획대로 못 해서 속상했다");
  assert.equal(result[0].atomic_behavior_log?.length, 3);
});

test("TC-VIS-8 (semantic patch): parent — insight에서 student_reflection_text/atomic_behavior_log 제거, observation/interpretation/actions는 유지", () => {
  const result = applyVisibilityPolicy("parent", "insight", insightWithPrivateFields);
  assert.equal(result[0].student_reflection_text, undefined);
  assert.equal(result[0].atomic_behavior_log, undefined);
  assert.equal(result[0].observation, "최근 시간예측 오차 감소");
  assert.equal(result[0].actions.length, 1);
});

test("TC-VIS-9 (semantic patch): teacher — insight에서도 동일하게 사적 필드 제거(§16)", () => {
  const result = applyVisibilityPolicy("teacher", "insight", insightWithPrivateFields);
  assert.equal(result[0].student_reflection_text, undefined);
  assert.equal(result[0].atomic_behavior_log, undefined);
});

test("TC-VIS-10 (semantic patch): institution — insight에서도 사적 필드 제거", () => {
  const result = applyVisibilityPolicy("institution", "insight", insightWithPrivateFields);
  assert.equal(result[0].student_reflection_text, undefined);
  assert.equal(result[0].atomic_behavior_log, undefined);
});
