// §12/§13 Growth Connection Engine — 실제 5조건 판정.
// SAME DOMAIN / SAME PERIOD / MINIMUM DATA / VALID METRIC / VISIBILITY.
// VISIBILITY는 이 모듈이 아니라 호출부(UnifiedGrowthModule)가 VisibilityPolicyAdapter로
// 최종 결과에 적용한다 — 이 모듈은 나머지 4조건만 판정하는 순수 함수다(테스트 용이성).

import { GrowthSummary, PlannerGrowthSummary, GrowthConnection, ConnectionStatus, KidsMetricKey, HistoryMetricKey, PlannerMetricKey, MetricPoint } from "../types/growth";
import { ProgramId } from "../types/program";
import { KIDS_DOMAIN_TAGS, HISTORY_DOMAIN_TAGS, PLANNER_DOMAIN_TAGS, DomainTag } from "../config/growth-domain-tags";
import { getMinimumObservations } from "../config/observation-thresholds";

export interface Candidate {
  source: ProgramId;
  domain_key: string;
  display_label: string;
  metric: MetricPoint;
}

export interface GrowthConnectionInput {
  kids: GrowthSummary<KidsMetricKey>;
  history: GrowthSummary<HistoryMetricKey>;
  planner: PlannerGrowthSummary;
}

export function evaluateGrowthConnections(
  input: GrowthConnectionInput,
  getMinimum: (domainKey: string) => number | null = getMinimumObservations
): GrowthConnection[] {
  const candidates: Candidate[] = [
    ...collect("KIDS", input.kids.metrics, KIDS_DOMAIN_TAGS),
    ...collect("HISTORY", input.history.metrics, HISTORY_DOMAIN_TAGS),
    ...collect("PLANNER", input.planner.metrics, PLANNER_DOMAIN_TAGS),
  ];

  const byDomain = new Map<string, Candidate[]>();
  for (const c of candidates) {
    const list = byDomain.get(c.domain_key) ?? [];
    list.push(c);
    byDomain.set(c.domain_key, list);
  }

  const connections: GrowthConnection[] = [];
  for (const [domainKey, group] of byDomain) {
    const sources = Array.from(new Set(group.map((c) => c.source)));
    if (sources.length < 2) continue; // SAME DOMAIN: 최소 2개 Branch가 같은 domain에 기여해야 후보가 된다

    connections.push(evaluateDomain(domainKey, group[0].display_label, sources, group, getMinimum));
  }

  return connections;
}

function collect<K extends string>(
  source: ProgramId,
  metrics: Partial<Record<K, MetricPoint>>,
  tags: Partial<Record<K, DomainTag>>
): Candidate[] {
  const out: Candidate[] = [];
  for (const key of Object.keys(metrics) as K[]) {
    const metric = metrics[key];
    const tag = tags[key];
    if (!metric || !tag) continue; // VALID METRIC: 태그 등록된 metric만 후보
    out.push({ source, domain_key: tag.domain_key, display_label: tag.display_label, metric });
  }
  return out;
}

function evaluateDomain(
  domainKey: string,
  label: string,
  sources: ProgramId[],
  group: Candidate[],
  getMinimum: (domainKey: string) => number | null
): GrowthConnection {
  const period = mergePeriod(group);
  const minimum = getMinimum(domainKey);

  const status = decideStatus(minimum, group, period);

  return {
    domain: label,
    sources,
    period: period ?? { from: "", to: "" },
    status,
    display_text: displayText(status, label),
  };
}

function decideStatus(
  minimum: number | null,
  group: Candidate[],
  period: { from: string; to: string } | null
): ConnectionStatus {
  // MINIMUM DATA: 기준이 미확정(null)이면 무조건 INSUFFICIENT_DATA — 임의 숫자로 통과시키지 않는다.
  if (minimum === null) return "INSUFFICIENT_DATA";
  const meetsMinimum = group.every((c) => (c.metric.observation_count ?? 0) >= minimum);
  if (!meetsMinimum) return "INSUFFICIENT_DATA";

  // SAME PERIOD: 관찰 기간이 겹치지 않거나 불명확하면 연결 해석 불가로 취급.
  if (!period) return "INSUFFICIENT_DATA";

  // 4조건(SAME DOMAIN/SAME PERIOD/MINIMUM DATA/VALID METRIC) 충족 — 방향 일치 여부로 세분화.
  const directions = new Set(group.map((c) => c.metric.display_direction));
  const allAgreeAndInterpreted = directions.size === 1 && !directions.has("not_interpreted");
  return allAgreeAndInterpreted ? "CONSISTENT_PATTERN" : "OBSERVED_TOGETHER";
}

/** 모든 candidate가 window를 갖고 있고 구간이 겹칠 때만 병합된 기간을 반환한다. */
export function mergePeriod(group: Candidate[]): { from: string; to: string } | null {
  const windows = group.map((c) => c.metric.window).filter((w): w is { from: string; to: string } => !!w);
  if (windows.length !== group.length) return null; // 하나라도 기간 정보가 없으면 SAME PERIOD 판정 불가

  const latestFrom = windows.reduce((a, w) => (w.from > a ? w.from : a), windows[0].from);
  const earliestTo = windows.reduce((a, w) => (w.to < a ? w.to : a), windows[0].to);
  if (latestFrom > earliestTo) return null; // 겹치는 구간이 없음

  return { from: latestFrom, to: earliestTo };
}

function displayText(status: ConnectionStatus, label: string): string {
  if (status === "INSUFFICIENT_DATA") {
    return "아직 여러 활동을 연결해 해석할 만큼 데이터가 충분하지 않습니다.";
  }
  if (status === "CONSISTENT_PATTERN") {
    return `최근 여러 관찰창에서 ${label}와 관련된 행동 변화가 일관된 방향으로 반복 관찰되고 있습니다.`;
  }
  return `최근 여러 NUVIA 활동에서 ${label}와 관련된 행동 변화가 함께 관찰되고 있습니다.`;
}
