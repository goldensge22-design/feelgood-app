// §26/§35 Visibility Policy — 실제 role별 축소 로직 (순수 함수, 테스트 용이).
// 검사/프로그램/성장/Insight가 각자 권한 로직을 재구현하지 않도록 이 한 곳에서만 판단한다.
// 실제 서버 연결 후에는 VisibilityPolicyAdapter(real)이 외부 Policy 서비스를 호출해 동일한
// 역할을 대신하게 되지만, 그 전까지 mock 모드는 이 로직을 "실제 적용"으로 사용한다.

import { ViewerRole } from "../types/viewer-context";
import { GrowthSummary, MetacogSummary, PlannerGrowthSummary, InsightCard } from "../types/growth";
import { KIDS_METRIC_PRIORITY, HISTORY_METRIC_PRIORITY, PLANNER_METRIC_PRIORITY } from "../config/growth-metric-priority";

export type VisibilityDomain = "assessment" | "program" | "growth" | "insight";

interface GrowthPreviewShape {
  train: GrowthSummary<string>;
  think: GrowthSummary<string>;
  manage: PlannerGrowthSummary;
  metacognition: MetacogSummary;
}

export function applyVisibilityPolicy<T>(viewerRole: ViewerRole, domain: VisibilityDomain, payload: T): T {
  if (domain === "insight") return applyInsightPolicy(viewerRole, payload);
  if (domain !== "growth") return payload; // assessment/program은 이번 단계에서 축소 규칙 없음(문서상 제약 없음)
  if (viewerRole === "learner" || viewerRole === "teacher") return payload; // §17 Student View는 전체 상세

  if (!isGrowthPreviewShape(payload)) return payload; // GrowthConnection[]/TimelineResponse 등은 그대로 통과

  const reduced =
    viewerRole === "institution"
      ? reduceToAggregateOnly(payload)
      : reduceToSummary(payload); // parent

  return reduced as unknown as T;
}

/**
 * insight — §16 SUPPORT: "중·고등학생의 사적 Reflection 원문·세부 로그는 기본 비공개".
 * 학생 본인만 전체를 보고, 그 외 role(parent/teacher/institution)은 허용 필드
 * (observation/interpretation/actions)만 남기고 student_reflection_text/atomic_behavior_log를 제거한다.
 */
function applyInsightPolicy<T>(viewerRole: ViewerRole, payload: T): T {
  if (viewerRole === "learner") return payload;
  if (!isInsightCardArray(payload)) return payload; // 모양이 다르면(예: 단일 객체) 그대로 통과
  return payload.map(reduceInsightCard) as unknown as T;
}

function isInsightCardArray(payload: unknown): payload is InsightCard[] {
  return (
    Array.isArray(payload) &&
    payload.every(
      (item) =>
        !!item && typeof item === "object" && "observation" in item && "interpretation" in item && "actions" in item
    )
  );
}

/** 허용 필드만 남기는 allow-list — 새 민감 필드가 추가돼도 기본은 비공개(deny-by-default). */
function reduceInsightCard(card: InsightCard): InsightCard {
  return { observation: card.observation, interpretation: card.interpretation, actions: card.actions };
}

function isGrowthPreviewShape(payload: unknown): payload is GrowthPreviewShape {
  return (
    !!payload &&
    typeof payload === "object" &&
    "train" in payload &&
    "think" in payload &&
    "manage" in payload &&
    "metacognition" in payload
  );
}

/**
 * PATCH 2 — 대표 metric 선택 순서:
 * 1) Branch가 명시한 primary_metric_key
 * 2) Branch가 정의한 summary_metric_priority(§config/growth-metric-priority.ts)에서
 *    실제로 값이 있는 첫 metric
 * 3) 둘 다 없으면 metric을 임의로 고르지 않는다 — metrics를 빈 객체로 반환한다
 *    ("요약 가능한 대표 지표가 아직 없습니다" 상태는 UI가 growth_data_status와 함께 표시).
 * Unified Growth Module은 여기서 metric 중요도를 스스로 판단하지 않는다.
 */
export function pickPrimaryMetric<K extends string>(summary: GrowthSummary<K>, priority: readonly K[]): GrowthSummary<K> {
  const key: K | undefined =
    (summary.primary_metric_key && summary.metrics[summary.primary_metric_key] ? summary.primary_metric_key : undefined) ??
    priority.find((k) => summary.metrics[k]);

  return {
    ...summary,
    metrics: key ? ({ [key]: summary.metrics[key] } as GrowthSummary<K>["metrics"]) : {},
  };
}

/** parent — "요약 범위만"(§11): domain별 대표 metric 1개만 남기고 나머지는 제거. */
function reduceToSummary(preview: GrowthPreviewShape): GrowthPreviewShape {
  return {
    train: pickPrimaryMetric(preview.train, KIDS_METRIC_PRIORITY),
    think: pickPrimaryMetric(preview.think, HISTORY_METRIC_PRIORITY),
    manage: {
      ...pickPrimaryMetric(preview.manage, PLANNER_METRIC_PRIORITY),
      task_breakdown_observation: preview.manage.task_breakdown_observation,
    },
    metacognition: {
      patterns: {
        prediction_vs_actual: preview.metacognition.patterns.prediction_vs_actual,
        self_assessment_vs_actual: null,
        strategy_awareness: null,
        strategy_change: null,
        next_action_choice: null,
      },
    },
  };
}

/** institution — "집계/승인된 가명화 데이터만"(§6): 개별 metric 자체를 노출하지 않는다. */
function reduceToAggregateOnly(preview: GrowthPreviewShape): GrowthPreviewShape {
  const statusOnly = <K extends string>(summary: GrowthSummary<K>): GrowthSummary<K> => ({
    growth_data_status: summary.growth_data_status,
    metrics: {},
    updated_at: summary.updated_at,
  });

  return {
    train: statusOnly(preview.train),
    think: statusOnly(preview.think),
    manage: statusOnly(preview.manage),
    metacognition: {
      patterns: {
        prediction_vs_actual: null,
        self_assessment_vs_actual: null,
        strategy_awareness: null,
        strategy_change: null,
        next_action_choice: null,
      },
    },
  };
}
