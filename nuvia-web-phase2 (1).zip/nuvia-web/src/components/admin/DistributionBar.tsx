import { DistributionSummary } from "@/types/growth";

// 학급 집계 전용 — 개인 식별자를 받지 않는다(labels/counts는 항목별 분포일 뿐 학생명이 아님).
export function DistributionBar({ title, distribution }: { title: string; distribution: DistributionSummary }) {
  const max = Math.max(1, ...distribution.counts);
  return (
    <section className="rounded-card border border-slate-200 bg-white p-5">
      <h2 className="font-semibold text-ink">{title}</h2>
      <ul className="mt-4 space-y-2">
        {distribution.labels.map((label, i) => (
          <li key={label}>
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span>{label}</span>
              <span>{distribution.counts[i]}명</span>
            </div>
            <div className="mt-1 h-2 rounded-full bg-slate-100">
              <div
                className="h-2 rounded-full bg-brand-blue"
                style={{ width: `${(distribution.counts[i] / max) * 100}%` }}
              />
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}
