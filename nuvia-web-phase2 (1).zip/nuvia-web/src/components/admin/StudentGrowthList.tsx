import { RosterEntry } from "@/lib/mock-class-roster";

// §17 Student View 진입점 — 정렬은 로스터 순서 그대로(성적/점수 기준 정렬 금지, 랭킹 아님).
export function StudentGrowthList({ students }: { students: RosterEntry[] }) {
  if (students.length === 0) {
    return (
      <section className="rounded-card border border-slate-200 bg-white p-5">
        <p className="text-sm text-slate-600">이 학급에 등록된 학생이 없습니다.</p>
      </section>
    );
  }

  return (
    <section className="rounded-card border border-slate-200 bg-white p-5">
      <h2 className="font-semibold text-ink">STUDENTS</h2>
      <ul className="mt-4 divide-y divide-slate-100">
        {students.map((s) => (
          <li key={s.learner_id} className="flex items-center justify-between py-3">
            <span className="text-sm text-ink">{s.display_name}</span>
            <a
              href={`/admin/nuvia-growth/growth?learner_id=${s.learner_id}`}
              className="text-sm font-medium text-brand-blueDeep hover:underline"
            >
              개인 Growth 보기 →
            </a>
          </li>
        ))}
      </ul>
    </section>
  );
}
