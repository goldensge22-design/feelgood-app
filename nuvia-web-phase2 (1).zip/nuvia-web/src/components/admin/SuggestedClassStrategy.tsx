export function SuggestedClassStrategy({ strategies }: { strategies: string[] }) {
  return (
    <section className="rounded-card border border-slate-200 bg-white p-5">
      <h2 className="font-semibold text-ink">CLASS INSIGHT · Suggested Class Strategy</h2>
      {strategies.length === 0 ? (
        <p className="mt-3 text-sm text-slate-600">아직 제안할 만큼 학급 데이터가 충분하지 않습니다.</p>
      ) : (
        <ul className="mt-3 space-y-3">
          {strategies.map((s, i) => (
            <li key={i} className="rounded-lg bg-brand-orange/5 border border-brand-orange/30 p-3 text-sm text-ink">
              {s}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
