import { OverviewResponse } from "@/domain/unified-growth-module";
import { CognitiveProfileCard } from "@/components/CognitiveProfileCard";
import { ProgramGrid } from "@/components/ProgramGrid";
import { MyGrowthPreview } from "@/components/MyGrowthPreview";
import { RecentInsight } from "@/components/RecentInsight";
import { PartialErrorBanner } from "@/components/PartialErrorBanner";

// Home(learner 기본 화면)과 Parent OVERVIEW 탭이 공유하는 핵심 패널.
// §7 AREA A~D 구성을 그대로 따른다 — 화면마다 다시 구현하지 않는다.
export function StudentOverviewPanel({ overview }: { overview: OverviewResponse }) {
  return (
    <div className="space-y-5">
      <PartialErrorBanner errors={overview.partial_errors} />

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
        <CognitiveProfileCard profile={overview.profile_summary} />
        <MyGrowthPreview
          train={overview.growth_preview.train}
          think={overview.growth_preview.think}
          manage={overview.growth_preview.manage}
          metacognition={overview.growth_preview.metacognition}
        />
      </div>

      <ProgramGrid activePrograms={overview.active_programs} />

      <RecentInsight insights={overview.recent_insights} />
    </div>
  );
}
