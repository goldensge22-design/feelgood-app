export function SignedOutNotice() {
  return (
    <main className="mx-auto max-w-3xl px-6 py-10">
      <p className="text-slate-600">로그인이 필요합니다.</p>
      <div className="mt-3 flex gap-2 text-sm">
        <a href="/dev/login?as=parent" className="text-brand-blueDeep hover:underline">부모로 로그인(mock)</a>
        <a href="/dev/login?as=learner" className="text-brand-blueDeep hover:underline">학생으로 로그인(mock)</a>
        <a href="/dev/login?as=teacher" className="text-brand-blueDeep hover:underline">교사로 로그인(mock)</a>
      </div>
    </main>
  );
}
