import { ProgramCard } from "@/components/ProgramCard";
import { ProgramId, ProgramState } from "@/types/program";

// §12 Program Entry 설계 — /my-nuvia/programs 페이지와 부모 PROGRAMS 탭이 공유한다.
export function ProgramGrid({ activePrograms }: { activePrograms: ProgramState[] }) {
  const programIds: ProgramId[] = ["KIDS", "HISTORY", "PLANNER"];
  const activeByProgram = new Map(activePrograms.map((p) => [p.program_id, p]));

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
      {programIds.map((id) => (
        <ProgramCard key={id} programId={id} state={activeByProgram.get(id) ?? null} />
      ))}
    </div>
  );
}
