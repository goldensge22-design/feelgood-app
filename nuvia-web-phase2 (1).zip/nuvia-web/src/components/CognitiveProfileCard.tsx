import { AssessmentProfile } from "@/types/assessment";
import { EMPTY_STATES } from "@/lib/empty-states";

export function CognitiveProfileCard({ profile }: { profile: AssessmentProfile | null }) {
  if (!profile) {
    return (
      <section className="rounded-card border border-slate-200 bg-white p-5">
        <h2 className="text-sm font-medium text-slate-500">인지 프로파일</h2>
        <p className="mt-3 text-slate-600">{EMPTY_STATES.noAssessment}</p>
      </section>
    );
  }

  return (
    <section className="rounded-card border border-slate-200 bg-white p-5">
      <div className="flex items-baseline justify-between">
        <h2 className="text-sm font-medium text-slate-500">인지 프로파일</h2>
        <span className="text-xs text-slate-400">{profile.assessed_at} 검사</span>
      </div>

      <dl className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {profile.cognitive_domains.map((d) => (
          <div key={d.domain_key} className="rounded-lg bg-brand-blue/5 px-3 py-2">
            <dt className="text-xs text-slate-500">{d.display_name}</dt>
            <dd className="text-lg font-semibold text-brand-blueDeep">{d.score}</dd>
          </div>
        ))}
      </dl>

      <div className="mt-4 flex flex-wrap gap-2 text-xs">
        {profile.strengths.map((s) => (
          <span key={s} className="rounded-full bg-brand-orange/15 px-2.5 py-1 text-brand-orangeDeep">
            강점 · {s}
          </span>
        ))}
        {profile.support_areas.map((s) => (
          <span key={s} className="rounded-full bg-slate-100 px-2.5 py-1 text-slate-600">
            성장 포인트 · {s}
          </span>
        ))}
      </div>

      <a href={profile.report_url} className="mt-4 inline-block text-sm font-medium text-brand-blueDeep hover:underline">
        결과지 보기 →
      </a>
    </section>
  );
}
