import { GrowthSummary, MetacogSummary } from "@/types/growth";
import { EMPTY_STATES } from "@/lib/empty-states";

type PreviewRow = { label: string; summary: GrowthSummary<string> };

function StatusPill({ status }: { status: GrowthSummary<string>["growth_data_status"] }) {
  if (status === "sufficient") {
    return <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-xs text-emerald-700">추세 확인 가능</span>;
  }
  return <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs text-slate-500">데이터 부족</span>;
}

export function MyGrowthPreview({
  train,
  think,
  manage,
  metacognition,
}: {
  train: GrowthSummary<string>;
  think: GrowthSummary<string>;
  manage: GrowthSummary<string>;
  metacognition: MetacogSummary;
}) {
  const rows: PreviewRow[] = [
    { label: "TRAIN · Cognitive Training", summary: train },
    { label: "THINK · Thinking Application", summary: think },
    { label: "MANAGE · Self-Management", summary: manage },
  ];

  return (
    <section className="rounded-card border border-slate-200 bg-white p-5">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-medium text-slate-500">MY GROWTH</h2>
        <a href="/my-nuvia/growth" className="text-sm font-medium text-brand-blueDeep hover:underline">
          성장 전체 보기 →
        </a>
      </div>

      <ul className="mt-4 space-y-3">
        {rows.map((row) => {
          const firstMetric = Object.values(row.summary.metrics)[0];
          const text =
            row.summary.growth_data_status !== "sufficient"
              ? EMPTY_STATES.growthInsufficient
              : firstMetric
              ? firstMetric.observation
              : EMPTY_STATES.noPrimaryMetric; // PATCH 2 — 데이터는 있지만 대표 지표를 고를 근거가 없는 경우
          return (
            <li key={row.label} className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2.5">
              <div>
                <p className="text-sm font-medium text-ink">{row.label}</p>
                <p className="text-xs text-slate-500">{text}</p>
              </div>
              <StatusPill status={row.summary.growth_data_status} />
            </li>
          );
        })}
      </ul>

      <div className="mt-3 rounded-lg bg-brand-blue/5 px-3 py-2.5">
        <p className="text-sm font-medium text-ink">METACOGNITION</p>
        <p className="text-xs text-slate-500">
          {metacognition.patterns.prediction_vs_actual ?? EMPTY_STATES.growthInsufficient}
        </p>
      </div>
    </section>
  );
}
