import { InsightCard } from "@/types/growth";
import { EMPTY_STATES } from "@/lib/empty-states";

// §16 SUPPORT — 가정에서 사용할 수 있는 질문/지원 Tip.
// 새 문구를 지어내지 않고 이미 승인된 Insight의 action을 그대로 재사용한다.
// 프로그램 활동을 대신 수행하게 만드는 지시는 만들지 않는다.
export function SupportTipPanel({ insights }: { insights: InsightCard[] }) {
  return (
    <section className="rounded-card border border-slate-200 bg-white p-5">
      <h2 className="font-semibold text-ink">SUPPORT</h2>
      <p className="mt-1 text-xs text-slate-400">
        아이를 대신해 과제를 수행하게 하는 지시가 아니라, 가정에서 건넬 수 있는 질문·지원 방향입니다.
      </p>

      {insights.length === 0 ? (
        <p className="mt-3 text-sm text-slate-600">{EMPTY_STATES.growthInsufficient}</p>
      ) : (
        <ul className="mt-4 space-y-3">
          {insights.map((insight, i) => (
            <li key={i} className="rounded-lg bg-brand-blue/5 p-3">
              <p className="text-xs text-slate-500">관찰됨 · {insight.observation}</p>
              {insight.actions.slice(0, 1).map((a, j) => (
                <p key={j} className="mt-1 text-sm font-medium text-ink">
                  지원 Tip · {a}
                </p>
              ))}
            </li>
          ))}
        </ul>
      )}

      <p className="mt-4 text-xs text-slate-400">
        중·고등학생의 사적 Reflection 원문·세부 행동 로그는 이 화면에 기본 비공개됩니다.
      </p>
    </section>
  );
}
