"use client";

import { useState } from "react";
import { OverviewResponse } from "@/domain/unified-growth-module";
import { StudentOverviewPanel } from "@/components/nuvia-home/StudentOverviewPanel";
import { CognitiveProfileCard } from "@/components/CognitiveProfileCard";
import { MyGrowthPreview } from "@/components/MyGrowthPreview";
import { ProgramGrid } from "@/components/ProgramGrid";
import { SupportTipPanel } from "@/components/parent/SupportTipPanel";

// §16 학부모용 Dashboard IA — OVERVIEW / PROFILE / GROWTH / SUPPORT / PROGRAMS
type Tab = "overview" | "profile" | "growth" | "support" | "programs";

export function ParentNuviaShell({ overview }: { overview: OverviewResponse }) {
  const [active, setActive] = useState<Tab>("overview");

  const tabs: { key: Tab; label: string }[] = [
    { key: "overview", label: "OVERVIEW" },
    { key: "profile", label: "PROFILE" },
    { key: "growth", label: "GROWTH" },
    { key: "support", label: "SUPPORT" },
    { key: "programs", label: "PROGRAMS" },
  ];

  return (
    <div>
      <div className="flex flex-wrap gap-2">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setActive(t.key)}
            className={
              active === t.key
                ? "rounded-full bg-brand-blueDeep px-4 py-1.5 text-sm font-medium text-white"
                : "rounded-full border border-slate-300 px-4 py-1.5 text-sm font-medium text-slate-600 hover:bg-slate-50"
            }
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="mt-5">
        {active === "overview" && <StudentOverviewPanel overview={overview} />}
        {active === "profile" && <CognitiveProfileCard profile={overview.profile_summary} />}
        {active === "growth" && (
          <div className="space-y-3">
            <MyGrowthPreview
              train={overview.growth_preview.train}
              think={overview.growth_preview.think}
              manage={overview.growth_preview.manage}
              metacognition={overview.growth_preview.metacognition}
            />
            <a href="/my-nuvia/growth" className="inline-block text-sm font-medium text-brand-blueDeep hover:underline">
              Unified Growth Dashboard 전체 보기 →
            </a>
          </div>
        )}
        {active === "support" && <SupportTipPanel insights={overview.recent_insights} />}
        {active === "programs" && <ProgramGrid activePrograms={overview.active_programs} />}
      </div>
    </div>
  );
}
