"use client";

import { useState, ReactNode } from "react";

export function TrainThinkManageTabs({
  train,
  think,
  manage,
}: {
  train: ReactNode;
  think: ReactNode;
  manage: ReactNode;
}) {
  const [active, setActive] = useState<"train" | "think" | "manage">("train");
  const tabs: { key: typeof active; label: string; content: ReactNode }[] = [
    { key: "train", label: "TRAIN", content: train },
    { key: "think", label: "THINK", content: think },
    { key: "manage", label: "MANAGE", content: manage },
  ];

  return (
    <div>
      <div className="flex gap-2">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setActive(t.key)}
            className={
              active === t.key
                ? "rounded-full bg-brand-blueDeep px-4 py-1.5 text-sm font-medium text-white"
                : "rounded-full border border-slate-300 px-4 py-1.5 text-sm font-medium text-slate-600 hover:bg-slate-50"
            }
          >
            {t.label}
          </button>
        ))}
      </div>
      <div className="mt-4">{tabs.find((t) => t.key === active)?.content}</div>
    </div>
  );
}
