import { TimelineResponse, TimelineEvent } from "@/types/timeline";

const TYPE_LABEL: Record<TimelineEvent["type"], string> = {
  assessment: "검사",
  program_start: "프로그램 시작",
  recent_activity: "최근 활동",
  growth_signal: "Growth Signal",
  profile_update: "재검사",
  milestone: "Milestone",
};

// §11 — 서로 다른 Branch 점수를 같은 Y축에 겹치지 않는다. 병렬 트랙으로만 표시.
// §20 — epoch 경계를 시각적으로 분리해 재검사 전/후를 하나의 연속 성장선처럼 보이지 않게 한다.
// PATCH 1 — 첫 검사 이전(pre_assessment) 활동은 별도 섹션으로 완전히 분리하고, 어떤 Epoch에도
// 포함하지 않는다(첫 검사 이후 성장 구간과 절대 합치지 않는다).
export function GrowthTimeline({ timeline }: { timeline: TimelineResponse }) {
  const allEvents = [...timeline.assessment_events, ...timeline.program_events, ...timeline.growth_signals];
  const preAssessmentEvents = allEvents
    .filter((ev) => ev.phase === "pre_assessment")
    .sort((a, b) => (a.occurred_at < b.occurred_at ? -1 : 1));

  const isEmpty = preAssessmentEvents.length === 0 && timeline.epochs.length === 0;

  return (
    <section className="rounded-card border border-slate-200 bg-white p-5">
      <h2 className="font-semibold text-ink">GROWTH TIMELINE — MY GROWTH JOURNEY</h2>
      <div className="mt-4 space-y-5">
        {preAssessmentEvents.length > 0 && (
          <div>
            <div className="flex items-center gap-2">
              <span className="rounded-full bg-slate-400 px-2.5 py-0.5 text-xs font-medium text-white">검사 이전</span>
              <span className="text-xs text-slate-400">첫 검사 이전 활동 — 이후 성장 구간과 별도로 표시됩니다</span>
            </div>
            <ol className="mt-2 flex flex-wrap gap-2">
              {preAssessmentEvents.map((ev, i) => (
                <li key={i} className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs text-ink">
                  <span className="text-slate-400">{ev.occurred_at}</span> · {TYPE_LABEL[ev.type]} · {ev.label}
                </li>
              ))}
            </ol>
          </div>
        )}

        {timeline.epochs.map((epoch) => {
          const events = allEvents
            .filter((ev) => ev.phase === "assessment_epoch" && ev.epoch_index === epoch.epoch_index)
            .sort((a, b) => (a.occurred_at < b.occurred_at ? -1 : 1));

          return (
            <div key={epoch.epoch_index}>
              <div className="flex items-center gap-2">
                <span className="rounded-full bg-ink px-2.5 py-0.5 text-xs font-medium text-white">
                  Epoch {epoch.epoch_index + 1}
                </span>
                <span className="text-xs text-slate-400">
                  {epoch.assessment_profile_version} 검사 이후{epoch.started_at ? ` (${epoch.started_at}~)` : ""}
                </span>
              </div>
              {events.length === 0 ? (
                <p className="mt-1 text-xs text-slate-400">이 구간에 기록된 이벤트가 없습니다.</p>
              ) : (
                <ol className="mt-2 flex flex-wrap gap-2">
                  {events.map((ev, i) => (
                    <li key={i} className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs text-ink">
                      <span className="text-slate-400">{ev.occurred_at}</span> · {TYPE_LABEL[ev.type]} · {ev.label}
                    </li>
                  ))}
                </ol>
              )}
            </div>
          );
        })}

        {isEmpty && <p className="text-xs text-slate-400">기록된 이벤트가 없습니다.</p>}
      </div>
      {timeline.epochs.length > 0 && (
        <p className="mt-4 text-[11px] text-slate-400">
          검사 이전 활동과 재검사 이후 데이터는 이전 구간과 이어 붙이지 않고 각각 분리해서 표시합니다.
        </p>
      )}
    </section>
  );
}
