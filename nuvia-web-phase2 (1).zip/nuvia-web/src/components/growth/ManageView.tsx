import { PlannerGrowthSummary, PlannerMetricKey } from "@/types/growth";
import { GrowthMetricGrid } from "./GrowthMetricGrid";

const LABELS: Record<PlannerMetricKey, string> = {
  time_prediction_accuracy: "Time Prediction Accuracy",
  start_accuracy: "Start Accuracy",
  planning_accuracy: "Planning Accuracy",
  focus_stability: "Focus Stability",
  completion_reliability: "Completion Reliability",
  recovery_skill: "Recovery Skill",
  plan_order_consistency: "Plan-Order Consistency",
  metacognitive_accuracy: "Metacognitive Accuracy",
};

export function ManageView({ summary }: { summary: PlannerGrowthSummary }) {
  return (
    <div className="space-y-3">
      <GrowthMetricGrid title="MANAGE · NUVIA PLANNER" labels={LABELS} summary={summary} />
      {summary.task_breakdown_observation && (
        <div className="rounded-card border border-dashed border-slate-300 bg-white p-4">
          <p className="text-xs font-medium text-slate-500">Task Breakdown Observation (관찰정보 — Growth Score 아님)</p>
          <p className="mt-1 text-sm text-ink">{summary.task_breakdown_observation.text}</p>
        </div>
      )}
    </div>
  );
}
