import { GrowthSummary, KidsMetricKey } from "@/types/growth";
import { GrowthMetricGrid } from "./GrowthMetricGrid";

const LABELS: Record<KidsMetricKey, string> = {
  difficulty: "도전 난이도 변화",
  accuracy: "정확도 변화",
  latency: "반응시간 변화",
  error_pattern: "오류 패턴",
  strategy: "전략 사용/전환",
  adherence: "일관성/참여 안정성",
};

export function TrainView({ summary }: { summary: GrowthSummary<KidsMetricKey> }) {
  return <GrowthMetricGrid title="TRAIN · NUVIA KIDS" labels={LABELS} summary={summary} />;
}
