import { GrowthSummary } from "@/types/growth";
import { EMPTY_STATES } from "@/lib/empty-states";

const DIRECTION_LABEL: Record<string, string> = {
  improving: "개선 경향",
  stable: "안정적 유지",
  needs_observation: "관찰 필요",
  not_interpreted: "해석 보류",
};

const DIRECTION_STYLE: Record<string, string> = {
  improving: "bg-emerald-100 text-emerald-700",
  stable: "bg-slate-100 text-slate-600",
  needs_observation: "bg-amber-100 text-amber-700",
  not_interpreted: "bg-slate-100 text-slate-500",
};

// 공통 렌더러: TRAIN/THINK/MANAGE가 동일한 GrowthSummary 구조를 쓰므로 표시 로직을 공유한다.
// trend(원본)만으로 Unified Growth Module이 자체 판정하지 않고, display_direction(Branch 해석)만 배지로 노출한다.
export function GrowthMetricGrid<K extends string>({
  title,
  labels,
  summary,
}: {
  title: string;
  labels: Record<K, string>;
  summary: GrowthSummary<K>;
}) {
  const entries = Object.entries(summary.metrics) as [K, GrowthSummary<K>["metrics"][K]][];

  return (
    <section className="rounded-card border border-slate-200 bg-white p-5">
      <h2 className="font-semibold text-ink">{title}</h2>

      {summary.growth_data_status !== "sufficient" || entries.length === 0 ? (
        <p className="mt-3 text-sm text-slate-600">{EMPTY_STATES.growthInsufficient}</p>
      ) : (
        <ul className="mt-4 space-y-2">
          {entries.map(([key, metric]) => {
            if (!metric) return null;
            return (
              <li key={key} className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2.5">
                <div>
                  <p className="text-sm font-medium text-ink">{labels[key]}</p>
                  <p className="text-xs text-slate-500">{metric.observation}</p>
                </div>
                <span className={`rounded-full px-2 py-0.5 text-xs ${DIRECTION_STYLE[metric.display_direction]}`}>
                  {DIRECTION_LABEL[metric.display_direction]}
                </span>
              </li>
            );
          })}
        </ul>
      )}
      <p className="mt-3 text-[11px] text-slate-400">최근 업데이트 · {summary.updated_at}</p>
    </section>
  );
}
