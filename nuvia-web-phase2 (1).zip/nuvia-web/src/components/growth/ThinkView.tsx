import { GrowthSummary, HistoryMetricKey } from "@/types/growth";
import { GrowthMetricGrid } from "./GrowthMetricGrid";

const LABELS: Record<HistoryMetricKey, string> = {
  chronology: "Chronology",
  cause_effect: "Cause & Effect",
  evidence: "Evidence",
  perspective: "Perspective",
  comparison: "Comparison",
  decision: "Decision",
};

export function ThinkView({ summary }: { summary: GrowthSummary<HistoryMetricKey> }) {
  return <GrowthMetricGrid title="THINK · NUVIA HISTORY" labels={LABELS} summary={summary} />;
}
