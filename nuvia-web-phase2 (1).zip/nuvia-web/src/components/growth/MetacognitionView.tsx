import { MetacogSummary } from "@/types/growth";
import { EMPTY_STATES } from "@/lib/empty-states";

const ROW_LABELS: { key: keyof MetacogSummary["patterns"]; label: string }[] = [
  { key: "prediction_vs_actual", label: "예측과 실제 수행의 차이" },
  { key: "self_assessment_vs_actual", label: "자기평가와 실제 수행의 차이" },
  { key: "strategy_awareness", label: "전략을 설명할 수 있는가" },
  { key: "strategy_change", label: "전략을 바꾸는가" },
  { key: "next_action_choice", label: "다음 행동을 스스로 선택하는가" },
];

// §10 METACOGNITION View — 여러 Branch의 metric을 임의 합산하지 않고 패턴 요약만 연결한다.
export function MetacognitionView({ summary }: { summary: MetacogSummary }) {
  return (
    <section className="rounded-card border border-slate-200 bg-white p-5">
      <h2 className="font-semibold text-ink">METACOGNITION</h2>
      <ul className="mt-4 space-y-2">
        {ROW_LABELS.map((row) => (
          <li key={row.key} className="rounded-lg bg-slate-50 px-3 py-2.5">
            <p className="text-xs text-slate-500">{row.label}</p>
            <p className="mt-0.5 text-sm text-ink">{summary.patterns[row.key] ?? EMPTY_STATES.growthInsufficient}</p>
          </li>
        ))}
      </ul>
    </section>
  );
}
