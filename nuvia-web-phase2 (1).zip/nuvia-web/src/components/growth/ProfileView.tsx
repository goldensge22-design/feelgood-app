import { AssessmentProfile } from "@/types/assessment";
import { EMPTY_STATES } from "@/lib/empty-states";

// §6 Profile View — Growth Score가 아니라 최근 공식 검사 프로파일을 보여주는 기준 영역.
export function ProfileView({ profile }: { profile: AssessmentProfile | null }) {
  if (!profile) {
    return (
      <section className="rounded-card border border-slate-200 bg-white p-5">
        <h2 className="font-semibold text-ink">PROFILE</h2>
        <p className="mt-2 text-sm text-slate-600">{EMPTY_STATES.noAssessment}</p>
      </section>
    );
  }

  return (
    <section className="rounded-card border border-slate-200 bg-white p-5">
      <div className="flex items-baseline justify-between">
        <h2 className="font-semibold text-ink">PROFILE</h2>
        <span className="text-xs text-slate-400">
          {profile.assessment_profile_version} · {profile.assessed_at}
        </span>
      </div>
      <p className="mt-1 text-xs text-slate-400">Growth Score가 아니라 기준 영역입니다.</p>

      <dl className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {profile.cognitive_domains.map((d) => (
          <div key={d.domain_key} className="rounded-lg bg-brand-blue/5 px-3 py-2">
            <dt className="text-xs text-slate-500">{d.display_name}</dt>
            <dd className="text-lg font-semibold text-brand-blueDeep">{d.score}</dd>
          </div>
        ))}
      </dl>

      <a href={profile.report_url} className="mt-4 inline-block text-sm font-medium text-brand-blueDeep hover:underline">
        결과지 보기 →
      </a>
    </section>
  );
}
