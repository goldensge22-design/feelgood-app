import { GrowthConnection } from "@/types/growth";
import { EMPTY_STATES } from "@/lib/empty-states";

const STATUS_LABEL: Record<GrowthConnection["status"], string> = {
  INSUFFICIENT_DATA: "데이터 부족",
  OBSERVED_TOGETHER: "함께 관찰됨",
  CONSISTENT_PATTERN: "반복 패턴",
};
const STATUS_STYLE: Record<GrowthConnection["status"], string> = {
  INSUFFICIENT_DATA: "bg-slate-100 text-slate-500",
  OBSERVED_TOGETHER: "bg-brand-blue/10 text-brand-blueDeep",
  CONSISTENT_PATTERN: "bg-brand-orange/15 text-brand-orangeDeep",
};

// §12/§13 — SAME DOMAIN/SAME PERIOD/MINIMUM DATA/VALID METRIC/VISIBILITY 5조건 충족 시에만 생성.
// 상태는 3가지뿐이며 과학적 확률로 표현하지 않는다.
export function GrowthConnectionPanel({ connections }: { connections: GrowthConnection[] }) {
  return (
    <section className="rounded-card border border-slate-200 bg-white p-5">
      <h2 className="font-semibold text-ink">GROWTH CONNECTION</h2>
      {connections.length === 0 ? (
        <p className="mt-2 text-sm text-slate-600">{EMPTY_STATES.connectionInsufficient}</p>
      ) : (
        <ul className="mt-3 space-y-2">
          {connections.map((c, i) => (
            <li key={i} className="rounded-lg bg-slate-50 px-3 py-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-500">{c.sources.join(" · ")}</span>
                <span className={`rounded-full px-2 py-0.5 text-xs ${STATUS_STYLE[c.status]}`}>
                  {STATUS_LABEL[c.status]}
                </span>
              </div>
              <p className="mt-1 text-sm text-ink">{c.display_text}</p>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
