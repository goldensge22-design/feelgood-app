import { InsightCard } from "@/types/growth";

export function RecentInsight({
  insights,
  limit = 2, // Home 노출 기본값 1~2개(§7). 전용 Insights 화면은 limit={insights.length}로 호출.
  title = "Recent Insight",
}: {
  insights: InsightCard[];
  limit?: number;
  title?: string;
}) {
  if (insights.length === 0) return null; // 최근 변화 없으면 섹션 자체를 노출하지 않음

  return (
    <section className="rounded-card border border-slate-200 bg-white p-5">
      <h2 className="text-sm font-medium text-slate-500">{title}</h2>
      <ul className="mt-3 space-y-3">
        {insights.slice(0, limit).map((insight, i) => (
          <li key={i} className="rounded-lg border border-brand-orange/30 bg-brand-orange/5 p-3">
            <p className="text-sm text-ink">{insight.observation}</p>
            <p className="mt-1 text-xs text-slate-600">{insight.interpretation}</p>
            {insight.actions.slice(0, 1).map((a, j) => (
              <p key={j} className="mt-2 text-xs font-medium text-brand-orangeDeep">
                다음 행동 제안 · {a}
              </p>
            ))}
          </li>
        ))}
      </ul>
    </section>
  );
}
