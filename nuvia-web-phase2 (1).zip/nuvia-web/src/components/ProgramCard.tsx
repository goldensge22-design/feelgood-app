import { ProgramState, ProgramId } from "@/types/program";
import { EMPTY_STATES } from "@/lib/empty-states";

const COPY: Record<ProgramId, { title: string; tagline: string; cta: string; introUrl: string }> = {
  KIDS: { title: "NUVIA KIDS", tagline: "Train My Brain", cta: "훈련하기", introUrl: "/programs/kids/intro" },
  HISTORY: { title: "NUVIA HISTORY", tagline: "Use My Thinking", cta: "계속하기", introUrl: "/programs/history/intro" },
  PLANNER: { title: "NUVIA PLANNER", tagline: "Manage Myself", cta: "오늘 계획하기", introUrl: "/programs/planner/intro" },
};

export function ProgramCard({ programId, state }: { programId: ProgramId; state: ProgramState | null }) {
  const copy = COPY[programId];
  const isActive = state?.program_status === "active";
  // 실행 URL(launch_url)과 안내 URL(info_url)을 상태별로 명확히 분리 — active가 아니면 launch_url을 절대 사용하지 않는다.
  const href = isActive ? state!.launch_url : state?.info_url ?? copy.introUrl;

  return (
    <div className="flex flex-col justify-between rounded-card border border-slate-200 bg-white p-5">
      <div>
        <h3 className="font-semibold text-ink">{copy.title}</h3>
        <p className="text-sm text-slate-500">{copy.tagline}</p>
        {!isActive && <p className="mt-3 text-sm text-slate-500">{EMPTY_STATES.programUnused}</p>}
      </div>
      <a
        href={href}
        className={
          isActive
            ? "mt-4 inline-block rounded-lg bg-brand-blue px-4 py-2 text-center text-sm font-medium text-white hover:bg-brand-blueDeep"
            : "mt-4 inline-block rounded-lg border border-slate-300 px-4 py-2 text-center text-sm font-medium text-slate-600 hover:bg-slate-50"
        }
      >
        {isActive ? copy.cta : "프로그램 알아보기"}
      </a>
    </div>
  );
}
