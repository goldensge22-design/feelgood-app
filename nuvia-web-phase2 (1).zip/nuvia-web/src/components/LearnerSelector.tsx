"use client";

export function LearnerSelector({
  options,
  currentLearnerId,
  redirectTo,
}: {
  options: { learner_id: string; label: string }[];
  currentLearnerId: string | null;
  redirectTo: string;
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {options.map((opt) => {
        const params = new URLSearchParams({ learner_id: opt.learner_id, redirect: redirectTo });
        return (
          <a
            key={opt.learner_id}
            href={`/my-nuvia/select-learner?${params.toString()}`}
            className={
              opt.learner_id === currentLearnerId
                ? "rounded-full bg-brand-blueDeep px-4 py-1.5 text-sm font-medium text-white"
                : "rounded-full border border-slate-300 px-4 py-1.5 text-sm font-medium text-slate-600 hover:bg-slate-50"
            }
          >
            {opt.label}
          </a>
        );
      })}
    </div>
  );
}
