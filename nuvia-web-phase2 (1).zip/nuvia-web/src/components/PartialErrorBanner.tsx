import { PartialError } from "@/domain/unified-growth-module";

const SOURCE_LABEL: Record<PartialError["source"], string> = {
  assessment: "검사 프로파일",
  programs: "프로그램 상태",
  kids: "NUVIA KIDS 성장 데이터",
  history: "NUVIA HISTORY 성장 데이터",
  planner: "NUVIA PLANNER 성장 데이터",
};

// (9) partial-data 처리 규칙의 UI 표현 — 실패한 영역만 안내하고 나머지 화면은 그대로 보여준다.
export function PartialErrorBanner({ errors }: { errors?: PartialError[] }) {
  if (!errors || errors.length === 0) return null;
  return (
    <div className="rounded-card border border-amber-300 bg-amber-50 p-3 text-sm text-amber-800">
      {errors.map((e) => SOURCE_LABEL[e.source]).join(", ")}를 일시적으로 불러오지 못했습니다. 나머지 정보는 정상적으로 표시됩니다.
    </div>
  );
}
