#!/usr/bin/env python3
"""
K-PASS Home 데모 자동 UI 테스트
------------------------------
데모 HTML 파일을 헤드리스 브라우저로 열어서, 모든 주요 버튼/시트/플로우를
순서대로 클릭해보고 다음을 확인합니다:
  1. JS 런타임 에러(pageerror)가 발생하지 않는지
  2. 각 시트(모달)가 실제로 열리고/닫히는지
  3. "오늘의 훈련 완료" 플로우가 XP·레벨 표시까지 정상 진행되는지
  4. "더 하고 싶어요" 보너스 활동이 선택→시작→완료→재오픈 초기화까지 정상인지
  5. 화면에 같은 문구의 <button>이 의도치 않게 중복되지 않는지 (회귀 테스트)

사용법:
    python3 test_kpass_demo.py [파일경로]
    (파일경로 생략 시 기본값: ./kpass-home-demo-v2.html)

수정할 때마다 이 스크립트를 다시 돌려서, 새로 깨진 부분이 있는지 먼저 확인합니다.
"""

import sys
import pathlib
from playwright.sync_api import sync_playwright

DEFAULT_FILE = "kpass-home-demo-v2.html"

results = []          # (label, ok: bool, detail: str)
page_errors = []       # uncaught JS exceptions
console_errors = []    # console.error(...) calls (network/font 404 등은 별도 필터링)


def check(label, condition, detail=""):
    ok = bool(condition)
    results.append((label, ok, detail))
    mark = "✅" if ok else "❌"
    print(f"{mark} {label}" + (f"  — {detail}" if detail and not ok else ""))
    return ok


def main(path: str):
    file_url = pathlib.Path(path).resolve().as_uri()

    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.on("pageerror", lambda exc: page_errors.append(str(exc)))
        page.on("console", lambda msg: console_errors.append(msg.text) if msg.type == "error" else None)

        page.goto(file_url)
        page.wait_for_timeout(300)

        # ---- 0. 초기 렌더 확인 ----
        check("페이지 로드 후 JS 에러 없음", len(page_errors) == 0, "; ".join(page_errors))
        check("영역별 성장 나무 렌더됨", page.locator(".sapling").count() == 4)
        check("주간 흐름 스트립 7일 렌더됨", page.locator(".day-chip").count() == 7)
        check("오늘의 훈련 카드 초기 상태(시작 버튼) 노출", page.locator("text=훈련 시작하기").count() == 1)

        # ---- 1. 설정 시트 ----
        page.click(".icon-btn >> nth=0")
        page.wait_for_timeout(150)
        check("설정 시트 열림", page.locator("#ov-sheet-settings").get_attribute("class").find("show") != -1)
        page.click("#toggle-pace")
        page.wait_for_timeout(100)
        check("자율모드 토글 시 설명 문구 변경됨",
              "자유롭게" in page.text_content("#pace-desc"))
        page.click("#toggle-pace")  # 원복
        page.click("#ov-sheet-settings .close")
        page.wait_for_timeout(150)
        check("설정 시트 닫힘", page.locator("#ov-sheet-settings").get_attribute("class").find("show") == -1)

        # ---- 2. "왜 하루에 하나씩" 안내 ----
        page.click("text=왜 오늘 훈련은 하나만 볼 수 있을까요?")
        page.wait_for_timeout(150)
        check("안내 시트 열림", "show" in page.locator("#ov-sheet-why").get_attribute("class"))
        page.click("#ov-sheet-why >> text=이해했어요")
        page.wait_for_timeout(150)
        check("안내 시트 닫힘", "show" not in page.locator("#ov-sheet-why").get_attribute("class"))

        # ---- 3. 주간 스트립 - 잠긴 날 탭 ----
        page.click(".day-chip.locked >> nth=0")
        page.wait_for_timeout(150)
        check("잠긴 날 탭 시 미리보기 시트 열림", "show" in page.locator("#ov-sheet-day").get_attribute("class"))
        page.click("#ov-sheet-day >> text=알겠어요")
        page.wait_for_timeout(150)

        # ---- 4. 도움 시트 (Home AI 상담으로 바로 진입) ----
        page.click("text=잘 모르겠어요")
        page.wait_for_timeout(900)
        check("도움 시트 열림", "show" in page.locator("#ov-sheet-help").get_attribute("class"))
        check("음성 다시 듣기/선생님 메시지 항목은 더 이상 없음",
              page.locator("#ov-sheet-help .mission-mini").count() == 0)
        check("Home AI 상담이 바로 열리며 실제 답변이 생성됨",
              "카드 4장" in (page.text_content("#help-ai-answer") or ""))
        check("남은 대화 횟수가 실제로 차감됨",
              "6/10" in (page.text_content("#help-ai-remain") or ""))
        page.click("#ov-sheet-help .close")
        page.wait_for_timeout(150)

        # ---- 5. 더 하고 싶어요: 선택 전 시작 버튼 비활성화 ----
        page.click("text=더 하고 싶어요")
        page.wait_for_timeout(150)
        check("보너스 시트 열림", "show" in page.locator("#ov-sheet-more").get_attribute("class"))
        check("항목 선택 전 시작 버튼 비활성화",
              page.eval_on_selector("#bonus-start-btn", "el => el.disabled") is True)

        # 항목 선택 -> 시작 -> 완료 -> 재오픈 시 초기화 확인
        page.click("#ov-sheet-more >> text=동시처리 마인드맵")
        page.wait_for_timeout(100)
        check("항목 선택 시 시작 버튼 활성화",
              page.eval_on_selector("#bonus-start-btn", "el => el.disabled") is False)
        page.click("#bonus-start-btn")
        page.wait_for_timeout(150)
        check("활동 상세 화면 생성됨(제목에 활동명 포함)",
              "동시처리 마인드맵" in page.text_content("#ov-sheet-more .sheet-title"))
        page.click("#ov-sheet-more >> text=다 했어요")
        page.wait_for_timeout(150)
        check("활동 완료 화면 노출", "잘했어요" in page.text_content("#ov-sheet-more .bonus-done"))
        page.click("#ov-sheet-more .close")
        page.wait_for_timeout(150)

        page.click("text=더 하고 싶어요")
        page.wait_for_timeout(150)
        check("재오픈 시 선택 목록으로 초기화됨(완료화면 안 남음)",
              page.locator("#ov-sheet-more >> text=더 해볼까요?").count() == 1)
        page.click("#ov-sheet-more .close")
        page.wait_for_timeout(150)

        # ---- 6. 오늘의 훈련 완료 플로우 ----
        page.click("text=훈련 시작하기")
        page.wait_for_timeout(900)
        check("훈련 완료 후 '오늘도 잘했어요' 노출",
              page.locator("text=오늘도 잘했어요!").count() == 1)
        check("XP 내역 카드 노출", page.locator(".xp-list").count() == 1)
        check("내일 예고 카드 노출", page.locator(".tomorrow-tease").count() == 1)
        check("완료 화면에 '더 하고 싶어요' 버튼이 중복 노출되지 않음 (회귀 테스트)",
              page.locator("#today-card >> text=더 하고 싶어요").count() == 0)
        check("'더 하고 싶어요' 버튼은 하단 플로팅에 정확히 1개만 존재",
              page.locator("button:has-text('더 하고 싶어요')").count() == 1)
        check("완료 후에도 주간 스트립의 오늘 칸이 done으로 반영됨",
              "done" in (page.locator(".day-chip").nth(3).get_attribute("class") or ""))

        # ---- 7. 부모 코칭 카드는 완료 이후에도 항상 노출 ----
        check("부모 코칭 카드가 완료 이후에도 화면에 남아있음",
              page.locator("text=인지훈련 부모 코칭").count() == 1)

        # ---- 종합 ----
        check("전체 시나리오 진행 중 콘솔 JS 에러(uncaught) 없음", len(page_errors) == 0, "; ".join(page_errors))

        browser.close()

    # ---- 리포트 ----
    total = len(results)
    passed = sum(1 for _, ok, _ in results if ok)
    failed = [label for label, ok, _ in results if not ok]

    print("\n" + "=" * 50)
    print(f"결과: {passed}/{total} 통과")
    if console_errors:
        noisy = [c for c in console_errors if "403" in c or "Failed to load resource" in c]
        real = [c for c in console_errors if c not in noisy]
        if noisy:
            print(f"(참고) 외부 리소스 로드 관련 콘솔 경고 {len(noisy)}건 — 폰트 CDN 등 샌드박스 네트워크 제약일 뿐, 기능과 무관")
        if real:
            print(f"⚠️ 그 외 콘솔 에러 {len(real)}건: {real}")
    if failed:
        print("실패 항목:")
        for f in failed:
            print(f"  - {f}")
        sys.exit(1)
    else:
        print("모든 항목 통과 ✅")
        sys.exit(0)


if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_FILE
    main(target)
