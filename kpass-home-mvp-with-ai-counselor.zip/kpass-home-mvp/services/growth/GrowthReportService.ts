import { ActivityLog, GrowthReport } from '@/domain/entities';
import {
  IActivityLogRepository,
  IGrowthReportRepository,
} from '@/repositories/interfaces';

export interface GrowthDashboardData {
  completionRate: number; // GM-0001 활동 수행률: 완료 수 / 전체 로그 수
  recentLogs: ActivityLog[];
  latestReport: GrowthReport | null;
  reassessmentNote: string;
}

export class GrowthReportService {
  constructor(
    private readonly activityLogRepo: IActivityLogRepository,
    private readonly growthReportRepo: IGrowthReportRepository,
  ) {}

  async getDashboard(studentId: number): Promise<GrowthDashboardData> {
    const logs = await this.activityLogRepo.listByStudent(studentId);
    const latestReport = await this.growthReportRepo.latestByStudent(studentId);

    // GM-0001 계산식(완료 활동 수 / 추천 활동 수)을 Round4 문서 그대로 적용.
    // "추천 활동 수"에 대한 정확한 분모 정의가 문서에 없어(활동 로그 전체 건수로
    // 근사), 실제 서비스 적용 전 재확인이 필요하다(TODO(GROWTH-001)).
    const completedCount = logs.filter((l) => l.score !== null && Number(l.score) >= 60).length;
    const completionRate = logs.length === 0 ? 0 : Math.round((completedCount / logs.length) * 100);

    return {
      completionRate,
      recentLogs: logs.slice(0, 10),
      latestReport,
      // GR-005 Reassessment Reminder / GM-0004: "4주 후 재검사 권장" 문구를 그대로
      // 사용하되, reassessment 저장 테이블이 없어(TODO(DB-003)) 알림 스케줄링은
      // 구현하지 않고 안내 문구만 반환한다.
      reassessmentNote: '누적 수행 기록을 기준으로 4주 후 재검사 또는 활동 조정을 권장합니다.',
    };
  }

  async createPeriodReport(input: {
    studentId: number;
    periodStart: Date;
    periodEnd: Date;
    summary: string;
    nextRecommendation: string;
  }): Promise<GrowthReport> {
    return this.growthReportRepo.create(input);
  }
}
