import { ActivityLog } from '@/domain/entities';
import { IActivityLogRepository } from '@/repositories/interfaces';
import { ValidationError } from '@/shared/errors/AppError';

export interface RecordActivityInput {
  studentId: number;
  activityId: string;
  score: number | null;
  memo: string | null;
}

export class ActivityLogService {
  constructor(private readonly activityLogRepo: IActivityLogRepository) {}

  async recordCompletion(input: RecordActivityInput): Promise<ActivityLog> {
    if (input.score !== null && (input.score < 0 || input.score > 100)) {
      throw new ValidationError('수행률(score)은 0~100 사이여야 합니다.');
    }
    return this.activityLogRepo.create(input);
  }

  listHistory(studentId: number): Promise<ActivityLog[]> {
    return this.activityLogRepo.listByStudent(studentId);
  }
}
