import { Student } from '@/domain/entities';
import { IStudentRepository } from '@/repositories/interfaces';
import { ForbiddenError, NotFoundError } from '@/shared/errors/AppError';

export class StudentService {
  constructor(private readonly studentRepo: IStudentRepository) {}

  /**
   * 부모 계정이 접근 가능한 자녀 목록.
   * TODO(DB-002) 정책에 따라 organization_id를 가족 단위 키로 사용한다.
   */
  listMyStudents(organizationId: number): Promise<Student[]> {
    return this.studentRepo.findByOrganization(organizationId);
  }

  async getStudentOrThrow(studentId: number, organizationId: number): Promise<Student> {
    const belongs = await this.studentRepo.belongsToOrganization(studentId, organizationId);
    if (!belongs) {
      throw new ForbiddenError('해당 학생 정보에 접근할 권한이 없습니다.');
    }
    const student = await this.studentRepo.findById(studentId);
    if (!student) {
      throw new NotFoundError('학생');
    }
    return student;
  }
}
