import { IPassResultRepository, PassResultWithProfile } from '@/repositories/interfaces';
import { NotFoundError } from '@/shared/errors/AppError';
import { classifyPassScore, PassBandLevel } from '@/shared/constants/passStandards';

export interface PassProfileAnalysis {
  planning: { score: number; band: PassBandLevel };
  attention: { score: number; band: PassBandLevel };
  simultaneous: { score: number; band: PassBandLevel };
  successive: { score: number; band: PassBandLevel };
  totalIndex: number;
  /**
   * 우선훈련영역(priority_domain) 및 강점 영역은 pass_profile 테이블에 저장된
   * 값을 그대로 노출한다. 이 서비스는 그 값을 "계산"하지 않는다 — 계산 로직은
   * PASS 알고리즘이며 정책 #4에 따라 구현 대상이 아니다.
   */
  priorityDomain: string | null;
  strengthDomain: string | null;
  dominanceType: string | null;
  aiSummary: string | null;
}

export class PassResultService {
  constructor(private readonly passResultRepo: IPassResultRepository) {}

  async getLatestResult(studentId: number): Promise<PassResultWithProfile> {
    const result = await this.passResultRepo.findLatestByStudent(studentId);
    if (!result) {
      throw new NotFoundError('PASS 검사 결과');
    }
    return result;
  }

  async getResultById(resultId: number): Promise<PassResultWithProfile> {
    const result = await this.passResultRepo.findById(resultId);
    if (!result) {
      throw new NotFoundError('PASS 검사 결과');
    }
    return result;
  }

  /**
   * AI-002 PASS Profile Analysis / AI-006 Age Band Mapping에 대응.
   * "낮음/중간/높음" 분류(§classifyPassScore)는 문서에 고정된 표준점수 임계값
   * (85 / 86~119 / 120)을 적용한 순수 규칙이며, PASS 알고리즘(추천 로직)이 아니다.
   */
  buildAnalysis(result: PassResultWithProfile): PassProfileAnalysis {
    return {
      planning: { score: result.planning, band: classifyPassScore(result.planning) },
      attention: { score: result.attention, band: classifyPassScore(result.attention) },
      simultaneous: { score: result.simultaneous, band: classifyPassScore(result.simultaneous) },
      successive: { score: result.successive, band: classifyPassScore(result.successive) },
      totalIndex: result.totalIndex,
      priorityDomain: result.profile?.priorityDomain ?? null,
      strengthDomain: result.profile?.strengthDomain ?? null,
      dominanceType: result.profile?.dominanceType ?? null,
      aiSummary: result.profile?.aiSummary ?? null,
    };
  }
}
