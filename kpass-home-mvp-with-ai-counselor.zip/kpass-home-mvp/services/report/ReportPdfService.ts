import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
// eslint-disable-next-line @typescript-eslint/no-var-requires
const fontkit = require('@pdf-lib/fontkit');
import fs from 'fs';
import path from 'path';
import { PassProfileAnalysis } from '@/services/pass/PassResultService';
import { DailyPrescriptionOutput } from '@/domain/services/RecommendationService';

/**
 * Home 결과지(처방전) PDF 생성.
 * UI Flow Slide 4 "결과지 출력" 대응. 실제 레이아웃 디자인 문서가 없어(문서 누락,
 * 분석 리포트 §4 참고) 디자인 시스템 컬러 토큰(§KPASS_Design_System_v1_1)만
 * 반영한 기본 1페이지 레이아웃으로 구현했다. 정식 템플릿 디자인이 확정되면
 * 이 서비스의 레이아웃 좌표만 교체하면 되도록 draw 함수를 섹션 단위로 분리했다.
 */

const COLORS = {
  primary: rgb(0x1f / 255, 0x4e / 255, 0x78 / 255), // #1F4E78
  secondary: rgb(0x0f / 255, 0x76 / 255, 0x6e / 255), // #0F766E
  evidenceBlue: rgb(0xd9 / 255, 0xea / 255, 0xf7 / 255), // #D9EAF7
  text: rgb(0.15, 0.15, 0.15),
  muted: rgb(0.4, 0.4, 0.4),
};

function loadKoreanFontBytes(): Buffer | null {
  const fontPath = path.join(process.cwd(), 'assets', 'fonts', 'NotoSansKR-Regular.ttf');
  try {
    return fs.readFileSync(fontPath);
  } catch {
    // TODO(PDF-001): 폰트 자산이 배포 환경에 없을 경우 StandardFonts로 폴백한다.
    // 폴백 시 한글은 렌더링되지 않으므로(WinAnsi 인코딩 한계), 운영 배포 전
    // assets/fonts/NotoSansKR-Regular.ttf 존재 여부를 반드시 확인해야 한다.
    return null;
  }
}

export interface HomeReportPdfInput {
  studentName: string;
  ageBand: string;
  analysis: PassProfileAnalysis;
  prescription: DailyPrescriptionOutput;
  generatedAt: Date;
}

export class ReportPdfService {
  async generateHomeReportPdf(input: HomeReportPdfInput): Promise<Uint8Array> {
    const pdfDoc = await PDFDocument.create();
    pdfDoc.registerFontkit(fontkit);

    const koreanFontBytes = loadKoreanFontBytes();
    const font = koreanFontBytes
      ? await pdfDoc.embedFont(koreanFontBytes, { subset: true })
      : await pdfDoc.embedFont(StandardFonts.Helvetica);

    const page = pdfDoc.addPage([595.28, 841.89]); // A4
    const { width } = page.getSize();
    let cursorY = 800;

    const drawText = (
      text: string,
      x: number,
      y: number,
      size: number,
      color = COLORS.text,
    ): void => {
      page.drawText(text, { x, y, size, font, color });
    };

    // Header
    page.drawRectangle({ x: 0, y: 780, width, height: 62, color: COLORS.primary });
    drawText('K-PASS 가정 인지훈련 처방전', 40, 812, 20, rgb(1, 1, 1));
    drawText(`isMock: ${input.prescription.isMock} (Mock Data 기반 예시)`, 40, 792, 9, rgb(1, 1, 1));
    cursorY = 750;

    drawText(`학생: ${input.studentName}  (${input.ageBand})`, 40, cursorY, 12);
    cursorY -= 18;
    drawText(
      `발급일: ${input.generatedAt.toISOString().slice(0, 10)}`,
      40,
      cursorY,
      10,
      COLORS.muted,
    );
    cursorY -= 30;

    // PASS Profile section
    drawText('PASS 프로파일 분석', 40, cursorY, 14, COLORS.secondary);
    cursorY -= 20;
    const domains: Array<[string, { score: number; band: string }]> = [
      ['Planning', input.analysis.planning],
      ['Attention', input.analysis.attention],
      ['Simultaneous', input.analysis.simultaneous],
      ['Successive', input.analysis.successive],
    ];
    for (const [label, d] of domains) {
      drawText(`${label}: ${d.score}점 (${d.band})`, 50, cursorY, 11);
      cursorY -= 16;
    }
    cursorY -= 10;

    // Daily prescription section
    drawText('오늘의 처방', 40, cursorY, 14, COLORS.secondary);
    cursorY -= 20;
    for (const item of input.prescription.items) {
      page.drawRectangle({
        x: 40,
        y: cursorY - 34,
        width: width - 80,
        height: 34,
        color: COLORS.evidenceBlue,
      });
      drawText(item.recommendation, 48, cursorY - 14, 11, COLORS.text);
      drawText(item.reason, 48, cursorY - 28, 8, COLORS.muted);
      cursorY -= 42;
    }
    cursorY -= 6;

    drawText(`부모 질문: ${input.prescription.parentQuestion}`, 40, cursorY, 10);
    cursorY -= 16;
    drawText(`부모 칭찬: ${input.prescription.parentPraise}`, 40, cursorY, 10);
    cursorY -= 16;
    drawText(`생활 속 PASS: ${input.prescription.lifePassMission}`, 40, cursorY, 10);
    cursorY -= 24;

    drawText(
      '본 결과지의 추천 활동은 Mock Data 기반 예시이며, 검증된 최종 추천이 아닙니다.',
      40,
      30,
      8,
      COLORS.muted,
    );

    return pdfDoc.save();
  }
}
