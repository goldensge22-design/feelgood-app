import { IUserAccountRepository } from '@/repositories/interfaces';
import { ICredentialVerifier } from '@/services/auth/CredentialVerifier';
import { UnauthorizedError } from '@/shared/errors/AppError';
import {
  signAccessToken,
  signRefreshToken,
  verifyRefreshToken,
} from '@/shared/utils/jwt';

export interface LoginResult {
  accessToken: string;
  refreshToken: string;
  user: {
    userId: number;
    organizationId: number;
    email: string;
    role: string;
  };
}

export class AuthService {
  constructor(
    private readonly userRepo: IUserAccountRepository,
    private readonly credentialVerifier: ICredentialVerifier,
  ) {}

  async login(email: string, password: string): Promise<LoginResult> {
    const user = await this.userRepo.findByEmail(email);
    if (!user) {
      throw new UnauthorizedError('이메일 또는 비밀번호가 올바르지 않습니다.');
    }

    // 정책 #1: 이 MVP는 PARENT/STUDENT 로그인만 지원한다.
    if (user.role !== 'PARENT' && user.role !== 'STUDENT') {
      throw new UnauthorizedError('가정용 서비스에서 사용할 수 없는 계정입니다.');
    }

    const verified = await this.credentialVerifier.verify(user.status, password);
    if (!verified) {
      throw new UnauthorizedError('이메일 또는 비밀번호가 올바르지 않습니다.');
    }

    const accessToken = signAccessToken({
      userId: user.userId,
      organizationId: user.organizationId,
      role: user.role,
      email: user.email,
    });
    const refreshToken = signRefreshToken({ userId: user.userId, tokenVersion: 0 });

    return {
      accessToken,
      refreshToken,
      user: {
        userId: user.userId,
        organizationId: user.organizationId,
        email: user.email,
        role: user.role,
      },
    };
  }

  async refresh(refreshToken: string): Promise<{ accessToken: string }> {
    const payload = verifyRefreshToken(refreshToken);
    const user = await this.userRepo.findById(payload.userId);
    if (!user || user.status !== 'ACTIVE') {
      throw new UnauthorizedError('사용자를 확인할 수 없습니다.');
    }
    const accessToken = signAccessToken({
      userId: user.userId,
      organizationId: user.organizationId,
      role: user.role,
      email: user.email,
    });
    return { accessToken };
  }
}
