/**
 * TODO(DB-001): ERD의 user_account 테이블에는 password_hash 등 인증 credential
 * 컬럼이 존재하지 않는다(원본 문서 누락). 지시서 §3 "DB 변경 금지" 정책에 따라
 * 컬럼을 임의로 추가하지 않았으며, credential 검증 로직은 아래처럼 Placeholder로
 * 분리했다.
 *
 * 이 클래스는 인터페이스만 실제 프로덕션과 동일하게 유지하고(email/password 입력,
 * boolean 반환), 내부 검증은 항상 실패로 처리하지 않고 개발/테스트가 가능하도록
 * "이메일이 존재하고 status가 ACTIVE이면 통과"라는 명시적 Placeholder 정책을 사용한다.
 * 실제 서비스 배포 전 반드시 DB 스펙 업데이트(password_hash 컬럼 추가)와 함께
 * bcrypt 비교 로직으로 교체해야 한다.
 */
export interface ICredentialVerifier {
  verify(userStatus: string, plainPassword: string): Promise<boolean>;
}

export class PlaceholderCredentialVerifier implements ICredentialVerifier {
  async verify(userStatus: string, plainPassword: string): Promise<boolean> {
    // 실제 비밀번호 해시 비교가 불가능하므로(컬럼 없음), 최소한의 형식 검증만 수행한다.
    if (userStatus !== 'ACTIVE') return false;
    if (!plainPassword || plainPassword.length < 4) return false;
    return true;
  }
}
