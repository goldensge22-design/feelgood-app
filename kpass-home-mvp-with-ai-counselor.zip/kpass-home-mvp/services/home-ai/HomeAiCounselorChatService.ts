import { HomeAiAudience, HomeAiChatResult, PassDomain } from '@/domain/entities';
import { RecommendationService } from '@/domain/services/RecommendationService';
import { PassResultService } from '@/services/pass/PassResultService';
import {
  IAvoidPhraseRepository,
  IHomeAiChatLogRepository,
  IParentFaqRepository,
  IParentLifeCaseRepository,
  ITeacherStrategyRepository,
} from '@/repositories/interfaces';
import { AppError, RateLimitError, ValidationError } from '@/shared/errors/AppError';
import { HOME_AI_CHAT_DAILY_LIMIT } from '@/shared/constants/homeAiCounselor';

const DOMAIN_LABEL: Record<PassDomain, string> = {
  PLANNING: '계획(Planning)',
  ATTENTION: '주의집중(Attention)',
  SIMULTANEOUS: '동시처리(Simultaneous)',
  SUCCESSIVE: '순차처리(Successive)',
};

export interface HomeAiChatInput {
  studentId: number;
  requestedByUserId: number;
  audience: HomeAiAudience;
  message: string;
}

/**
 * "② 부모 AI 상담" / "② 교사 AI 상담" — Home AI 상담사 안에서 유일하게
 * 생성형 AI를 사용하는 부분.
 *
 * 불변 원칙(지시서):
 *  - 새로운 훈련은 생성하지 않는다. 시스템 프롬프트에 이미 존재하는
 *    "PASS Cognitive Training Library 추천 후보" 컨텍스트만 제공하고, 그
 *    범위를 벗어난 훈련을 지어내지 못하도록 지시한다.
 *  - 답변은 반드시 인지훈련 플래너 또는 인지+정서훈련 프로그램으로 연결한다.
 *  - 하루 10회 생성 제한(HOME_AI_CHAT_DAILY_LIMIT).
 */
export class HomeAiCounselorChatService {
  constructor(
    private readonly passResultService: PassResultService,
    private readonly recommendationService: RecommendationService,
    private readonly chatLogRepo: IHomeAiChatLogRepository,
    private readonly parentFaqRepo: IParentFaqRepository,
    private readonly parentLifeCaseRepo: IParentLifeCaseRepository,
    private readonly avoidPhraseRepo: IAvoidPhraseRepository,
    private readonly teacherStrategyRepo: ITeacherStrategyRepository,
  ) {}

  async chat(input: HomeAiChatInput): Promise<HomeAiChatResult> {
    const message = input.message.trim();
    if (!message) {
      throw new ValidationError('상담 내용을 입력해주세요.');
    }
    if (message.length > 500) {
      throw new ValidationError('상담 내용은 500자 이내로 입력해주세요.');
    }

    const usedToday = await this.chatLogRepo.countTodayByUser(input.requestedByUserId, input.audience);
    if (usedToday >= HOME_AI_CHAT_DAILY_LIMIT) {
      throw new RateLimitError();
    }

    const result = await this.passResultService.getLatestResult(input.studentId);
    const analysis = this.passResultService.buildAnalysis(result);
    const priorityDomain = analysis.priorityDomain as PassDomain | null;
    const strengthDomain = analysis.strengthDomain as PassDomain | null;

    const { contextText, linkedProgramId } = await this.buildContext(
      input.studentId,
      result.resultId,
      priorityDomain,
      input.audience,
    );

    const weeklyPlannerLink = { href: `/students/${input.studentId}`, label: '인지훈련 플래너 바로가기' };
    const cognitiveEmotionalProgramLink = {
      href: `/students/${input.studentId}/cognitive-emotional-training`,
      label: '인지+정서훈련 바로가기',
    };

    const systemPrompt = this.buildSystemPrompt(
      input.audience,
      priorityDomain,
      strengthDomain,
      contextText,
      weeklyPlannerLink.href,
      cognitiveEmotionalProgramLink.href,
    );

    const reply = await this.callAnthropic(systemPrompt, message);

    await this.chatLogRepo.create({
      studentId: input.studentId,
      requestedByUserId: input.requestedByUserId,
      audience: input.audience,
      userMessage: message,
      aiResponse: reply,
      linkedProgramId,
    });

    return {
      reply,
      linkedProgramId,
      weeklyPlannerLink,
      cognitiveEmotionalProgramLink,
      remainingToday: Math.max(0, HOME_AI_CHAT_DAILY_LIMIT - (usedToday + 1)),
      dailyLimit: HOME_AI_CHAT_DAILY_LIMIT,
    };
  }

  /** 상담을 "기존 라이브러리 안"으로 붙잡아두기 위한 근거 컨텍스트를 조합한다(생성 없음). */
  private async buildContext(
    studentId: number,
    resultId: number,
    priorityDomain: PassDomain | null,
    audience: HomeAiAudience,
  ): Promise<{ contextText: string; linkedProgramId: string | null }> {
    const parts: string[] = [];
    let linkedProgramId: string | null = null;

    // PASS Cognitive Training Library에서 오늘 실제로 배정 가능한 추천 프로그램(있다면)을
    // 컨텍스트로 제공 — LLM이 이 범위를 벗어난 훈련을 지어내지 못하게 한다.
    try {
      const prescription = await this.recommendationService.generateDailyPrescription(studentId, resultId);
      if (prescription.items.length > 0) {
        linkedProgramId = prescription.items[0]!.programId;
        parts.push(
          '[PASS Cognitive Training Library 추천 후보(이 범위 밖의 훈련을 새로 만들지 말 것)]',
          ...prescription.items.map(
            (it) => `- ${it.recommendation} (programId=${it.programId ?? '없음'}): ${it.reason}`,
          ),
        );
      }
    } catch (err) {
      // 나이 매핑 등 정보 부족으로 추천을 만들지 못하면, 프로그램 링크 없이 상담을 계속한다
      // (조용히 추측 대체하지 않음 — 컨텍스트에 프로그램 후보가 없다는 것을 그대로 전달).
      parts.push(`[참고] 이번 학생에 대한 프로그램 추천 후보를 불러오지 못했습니다: ${(err as Error).message}`);
    }

    if (priorityDomain) {
      if (audience === 'PARENT') {
        const [lifeCase, avoidPhrase, faqs] = await Promise.all([
          this.parentLifeCaseRepo.findByDomain(priorityDomain),
          this.avoidPhraseRepo.findByDomain(priorityDomain),
          this.parentFaqRepo.listByDomain(priorityDomain),
        ]);
        if (lifeCase) {
          parts.push(
            '[생활 사례 라이브러리]',
            `학교: ${lifeCase.schoolBehavior}`,
            `집: ${lifeCase.homeBehavior}`,
            `도움말: ${lifeCase.parentGuidance}`,
          );
        }
        if (avoidPhrase) {
          parts.push('[하면 안 되는 말]', `피할 표현: ${avoidPhrase.phrase}`, `대신: ${avoidPhrase.insteadSay}`);
        }
        if (faqs.length > 0) {
          parts.push('[자주 묻는 질문]', ...faqs.slice(0, 5).map((f) => `Q: ${f.question} / A: ${f.answer}`));
        }
      } else {
        const strategy = await this.teacherStrategyRepo.findByDomain(priorityDomain);
        if (strategy) {
          parts.push(
            '[교사 전략 라이브러리]',
            `특성: ${strategy.characteristic}`,
            `교실 행동: ${strategy.classroomBehavior}`,
            `지도 전략: ${strategy.supportStrategy}`,
          );
        }
      }
    }

    return { contextText: parts.join('\n'), linkedProgramId };
  }

  private buildSystemPrompt(
    audience: HomeAiAudience,
    priorityDomain: PassDomain | null,
    strengthDomain: PassDomain | null,
    contextText: string,
    weeklyPlannerHref: string,
    cognitiveEmotionalHref: string,
  ): string {
    const who = audience === 'PARENT' ? '학부모' : '선생님';
    const domainLine =
      priorityDomain || strengthDomain
        ? `이 학생의 우선훈련영역은 ${priorityDomain ? DOMAIN_LABEL[priorityDomain] : '알 수 없음'}이고, ` +
          `강점 영역은 ${strengthDomain ? DOMAIN_LABEL[strengthDomain] : '알 수 없음'}입니다.`
        : '이 학생의 우선훈련영역/강점 영역 정보가 없습니다.';

    return [
      `당신은 K-PASS Home AI 상담사입니다. ${who}의 질문에 답하는 AI Coach 역할만 수행합니다.`,
      domainLine,
      contextText ? `다음은 참고할 수 있는 기존 자료입니다:\n${contextText}` : '',
      '',
      '반드시 지켜야 할 규칙:',
      '1) 새로운 인지훈련 프로그램이나 활동을 직접 만들어내지 마세요. 위 컨텍스트에 있는 프로그램/전략만 언급하세요.',
      '2) 검사 점수를 재계산하거나 새로운 진단명을 붙이지 마세요.',
      '3) 답변은 한국어로, 3~5문장, 실용적이고 따뜻한 톤으로 작성하세요.',
      `4) 답변 마지막에는 반드시 "인지훈련 플래너(${weeklyPlannerHref})" 또는 "인지+정서훈련 프로그램(${cognitiveEmotionalHref})" 중 상황에 맞는 것으로 연결하는 한 문장을 포함하세요.`,
      '5) 의학적 진단이 필요해 보이면 전문 기관 상담을 권유하고, 직접 진단하지 마세요.',
    ]
      .filter(Boolean)
      .join('\n');
  }

  private async callAnthropic(systemPrompt: string, userMessage: string): Promise<string> {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      throw new AppError(
        'CONFIG_MISSING',
        'ANTHROPIC_API_KEY가 설정되지 않아 Home AI 상담사를 사용할 수 없습니다.',
        500,
      );
    }
    const model = process.env.ANTHROPIC_MODEL ?? 'claude-sonnet-4-5';

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model,
        max_tokens: 500,
        system: systemPrompt,
        messages: [{ role: 'user', content: userMessage }],
      }),
    });

    if (!response.ok) {
      const bodyText = await response.text().catch(() => '');
      throw new AppError(
        'AI_PROVIDER_ERROR',
        'AI 상담 응답을 받아오지 못했습니다. 잠시 후 다시 시도해주세요.',
        502,
        bodyText.slice(0, 500),
      );
    }

    const data = (await response.json()) as { content?: Array<{ type: string; text?: string }> };
    const text = (data.content ?? [])
      .filter((block) => block.type === 'text' && block.text)
      .map((block) => block.text)
      .join('\n')
      .trim();

    if (!text) {
      throw new AppError('AI_PROVIDER_ERROR', 'AI 상담 응답이 비어 있습니다.', 502);
    }
    return text;
  }
}
