import { RecommendationService } from '@/domain/services/RecommendationService';
import {
  IAgeBandMappingRepository,
  ICognitiveProfileRepository,
  IDifficultyMappingRepository,
  IHomeMonthlyReportRepository,
  IHomeTrainingLogRepository,
  IHomeTrainingPlanRepository,
  IStudentRepository,
  ITrainingHistoryRepository,
  ITrainingProgramRepository,
} from '@/repositories/interfaces';
import { PassResultService } from '@/services/pass/PassResultService';
import { MonthlyReport, WeeklyTrainingPlan, WeeklyTrainingPlanItem } from '@/domain/entities';
import { PassDomain } from '@/shared/constants/passStandards';
import { calculateAgeInYears } from '@/shared/utils/ageBand';
import { NotFoundError, ValidationError } from '@/shared/errors/AppError';

const DOMAIN_ORDER: PassDomain[] = ['PLANNING', 'ATTENTION', 'SIMULTANEOUS', 'SUCCESSIVE'];
const WEEK_DAYS = 5; // 월~금

/**
 * Home AI = Weekly Planner AI.
 *
 * 대화형 챗봇이 아니다. 검사 결과(81 Cognitive Profile) -> 주간 훈련 계획 자동 설계
 * -> 이행 기록 -> 다음 주 자동 재설계 -> 4주 월간 리포트, 이 파이프라인만 수행한다.
 *
 * Teacher AI(TeacherDashboardService)와 동일한 RecommendationService
 * (LibraryRecommendationService)에만 의존하며, 이 서비스 자신은 프로그램을
 * 생성하지 않는다. 모든 추천은 findCandidates()가 pass_training_program에서
 * 반환한 것만 사용한다.
 */
export class WeeklyPlannerService {
  constructor(
    private readonly passResultService: PassResultService,
    private readonly recommendationService: RecommendationService,
    private readonly planRepo: IHomeTrainingPlanRepository,
    private readonly logRepo: IHomeTrainingLogRepository,
    private readonly monthlyReportRepo: IHomeMonthlyReportRepository,
    private readonly historyRepo: ITrainingHistoryRepository,
    private readonly profileRepo: ICognitiveProfileRepository,
    private readonly studentRepo: IStudentRepository,
    private readonly ageBandMappingRepo: IAgeBandMappingRepository,
    private readonly difficultyMappingRepo: IDifficultyMappingRepository,
    private readonly trainingProgramRepo: ITrainingProgramRepository,
  ) {}

  // -----------------------------------------------------------------
  // 1) 주간 계획 생성
  // -----------------------------------------------------------------
  async generateWeeklyPlan(studentId: number, weekStartDate: Date): Promise<WeeklyTrainingPlan> {
    const result = await this.passResultService.getLatestResult(studentId);

    const profile = await this.profileRepo.resolveFromScores({
      planning: result.planning,
      attention: result.attention,
      simultaneous: result.simultaneous,
      successive: result.successive,
    });

    const student = await this.studentRepo.findById(studentId);
    if (!student) throw new NotFoundError('학생');
    if (!student.birthDate) {
      throw new ValidationError('학생의 생년월일이 없어 연령대를 계산할 수 없습니다.');
    }
    const ageInYears = calculateAgeInYears(new Date(student.birthDate), weekStartDate);
    const ageBand = await this.ageBandMappingRepo.resolveAgeCode(ageInYears);
    if (!ageBand) {
      throw new ValidationError(`age_band_mapping에 만 ${ageInYears}세 구간이 없습니다.`);
    }

    // ---- 81 Profile 기반 강점/약점 -> 영역별 이번 주 세션 수(가중치) ----
    const domainWeights = await this.computeDomainWeights(
      studentId,
      profile.priorityDomain as PassDomain | null,
      profile.strengthDomain as PassDomain | null,
    );

    const weekEndDate = new Date(weekStartDate);
    weekEndDate.setDate(weekEndDate.getDate() + 4); // 월~금

    // ---- 영역 슬롯 나열 (가중 라운드로빈으로 같은 영역이 뭉치지 않게 분산) ----
    const domainSlots = this.buildWeightedDomainSequence(domainWeights.weights);
    const dayCounts = this.buildDayCounts(domainSlots.length);

    const usedProgramIdsByDomain = new Map<PassDomain, string[]>();
    const items: Array<{
      programId: string;
      programName: string;
      passDomain: PassDomain;
      dayIndex: number;
      dayDate: Date;
      orderInDay: number;
      trainingGoal: string;
      duration: string | null;
      parentGuidance: string;
      isSupplementary: boolean;
    }> = [];

    let slotCursor = 0;
    for (let day = 1; day <= WEEK_DAYS; day += 1) {
      const countToday = dayCounts[day - 1]!;
      const dayDate = new Date(weekStartDate);
      dayDate.setDate(dayDate.getDate() + (day - 1));

      for (let order = 1; order <= countToday; order += 1) {
        const domain = domainSlots[slotCursor]!;
        slotCursor += 1;

        const exclude = usedProgramIdsByDomain.get(domain) ?? [];
        const output = await this.recommendationService.recommendForDomain({
          studentId,
          resultId: result.resultId,
          passDomain: domain,
          ageBand: ageBand.ageCode,
          environment: 'HOME',
          excludeProgramIds: exclude,
        });
        if (!output.programId) {
          throw new Error(`추천 결과에 programId가 없습니다 (domain=${domain}).`);
        }
        usedProgramIdsByDomain.set(domain, [...exclude, output.programId]);

        const isSupplementary =
          domainWeights.supplementaryDomains.has(domain) &&
          this.isLastOccurrence(domainSlots, slotCursor - 1, domain);

        items.push({
          programId: output.programId,
          programName: output.recommendation,
          passDomain: domain,
          dayIndex: day,
          dayDate,
          orderInDay: order,
          trainingGoal: output.recommendation, // enrichItemsWithProgramSnapshot에서 실제 training_goal로 교체
          duration: null,
          parentGuidance: output.reason, // 위와 동일하게 교체됨
          isSupplementary,
        });
      }
    }

    // program_id 목록으로 duration/parent_guidance/training_goal을 Library 원본 스냅샷으로 보강
    await this.enrichItemsWithProgramSnapshot(items);

    return this.planRepo.create({
      studentId,
      resultId: result.resultId,
      profileCode: `${profile.planningLevel}${profile.attentionLevel}${profile.simultaneousLevel}${profile.successiveLevel}`,
      ageCode: ageBand.ageCode,
      weekStartDate,
      weekEndDate,
      domainWeights: domainWeights.weights,
      items,
    });
  }

  // -----------------------------------------------------------------
  // 2) 현재 활성 계획 조회
  // -----------------------------------------------------------------
  async getCurrentPlan(studentId: number): Promise<WeeklyTrainingPlan | null> {
    return this.planRepo.findActiveByStudent(studentId);
  }

  // -----------------------------------------------------------------
  // 4) 이행도 기록 (완료 여부 / 성공률 / 부모 메모 / 아이 반응)
  // -----------------------------------------------------------------
  async completeItem(
    itemId: number,
    input: {
      successRate: number;
      outcome: 'SUCCESS' | 'PARTIAL' | 'FAIL';
      parentMemo: string | null;
      childReaction: string | null;
    },
  ): Promise<{ item: WeeklyTrainingPlanItem; log: Awaited<ReturnType<IHomeTrainingLogRepository['create']>> }> {
    const existing = await this.planRepo.findItemById(itemId);
    if (!existing) throw new NotFoundError('훈련 항목');
    if (input.successRate < 0 || input.successRate > 100) {
      throw new ValidationError('successRate는 0~100 사이여야 합니다.');
    }

    const plan = await this.planRepo.findById(existing.planId);
    if (!plan) throw new NotFoundError('주간 훈련 계획');

    const item = await this.planRepo.markItemCompleted(itemId);

    const log = await this.logRepo.create({
      itemId,
      studentId: plan.studentId,
      successRate: input.successRate,
      outcome: input.outcome,
      parentMemo: input.parentMemo,
      childReaction: input.childReaction,
    });

    // Teacher AI와 공유하는 엔진의 난이도 승급/강등 판단이 이 기록을 그대로 사용한다.
    const program = await this.trainingProgramRepo.findById(item.programId);
    if (!program) throw new NotFoundError('훈련 프로그램');
    await this.historyRepo.record({
      studentId: plan.studentId,
      programId: item.programId,
      passDomain: item.passDomain,
      difficultyLevel: program.difficultyLevel,
      successRate: input.successRate,
      outcome: input.outcome,
    });

    return { item, log };
  }

  // -----------------------------------------------------------------
  // 6) 4주 월간 리포트
  // -----------------------------------------------------------------
  async generateMonthlyReport(studentId: number, month: string): Promise<MonthlyReport> {
    const { from, to } = this.monthRange(month);
    const plans = await this.planRepo.listByStudentInRange(studentId, from, to);
    if (plans.length === 0) {
      throw new ValidationError(`${month}에 해당하는 주간 훈련 계획이 없습니다.`);
    }

    const logs = await this.logRepo.listByStudentInRange(studentId, from, to);
    const logsByItemId = new Map(logs.map((l) => [l.itemId, l]));

    const totalItems = plans.reduce((sum, p) => sum + p.items.length, 0);
    const completedItems = plans.reduce((sum, p) => sum + p.items.filter((i) => i.isCompleted).length, 0);
    const completionRate = totalItems > 0 ? Math.round((completedItems / totalItems) * 10000) / 100 : 0;

    const sortedPlans = [...plans].sort((a, b) => a.weekStartDate.getTime() - b.weekStartDate.getTime());
    const firstWeekPlan = sortedPlans[0]!;
    const lastWeekPlan = sortedPlans[sortedPlans.length - 1]!;

    const domainChange: MonthlyReport['domainChange'] = {};
    for (const domain of DOMAIN_ORDER) {
      const week1Avg = this.averageSuccessForDomain(firstWeekPlan, domain, logsByItemId);
      const week4Avg = this.averageSuccessForDomain(lastWeekPlan, domain, logsByItemId);
      domainChange[domain] = {
        week1Avg,
        week4Avg,
        delta: week1Avg !== null && week4Avg !== null ? Math.round((week4Avg - week1Avg) * 100) / 100 : null,
      };
    }

    const latestProfile = await this.profileRepo.findByCode(lastWeekPlan.profileCode);
    const priorityDomain = latestProfile?.priorityDomain ?? null;
    const strengthDomain = latestProfile?.strengthDomain ?? null;

    const strengthMaintained: string[] = [];
    if (strengthDomain) {
      const change = domainChange[strengthDomain];
      if (change && change.week4Avg !== null && change.week4Avg >= 70) {
        strengthMaintained.push(strengthDomain);
      }
    }

    const weaknessProgress: MonthlyReport['weaknessProgress'] = {
      domain: priorityDomain,
      improvementRate: priorityDomain ? domainChange[priorityDomain]?.delta ?? null : null,
    };

    const nextMonthRecommendation = this.buildNextMonthRecommendation(
      priorityDomain,
      strengthDomain,
      weaknessProgress.improvementRate,
    );

    return this.monthlyReportRepo.upsert({
      studentId,
      reportMonth: month,
      domainChange,
      completionRate,
      strengthMaintained,
      weaknessProgress,
      nextMonthRecommendation,
    });
  }

  async getMonthlyReport(studentId: number, month: string): Promise<MonthlyReport | null> {
    return this.monthlyReportRepo.findByStudentAndMonth(studentId, month);
  }

  // -----------------------------------------------------------------
  // 내부 로직
  // -----------------------------------------------------------------

  /**
   * 81 Profile의 약점(priorityDomain)에 가장 많은 세션을, 강점(strengthDomain)에
   * 가장 적은(유지 목적) 세션을 배정한다. 또한 최근 2주 연속 특정 영역의 평균
   * 성공률이 REPEATED_FAILURE_THRESHOLD 미만이면 보조 훈련 1세션을 추가한다.
   */
  private async computeDomainWeights(
    studentId: number,
    priorityDomain: PassDomain | null,
    strengthDomain: PassDomain | null,
  ): Promise<{ weights: Record<PassDomain, number>; supplementaryDomains: Set<PassDomain> }> {
    const weights: Record<PassDomain, number> = {
      PLANNING: 3,
      ATTENTION: 3,
      SIMULTANEOUS: 3,
      SUCCESSIVE: 3,
    };
    if (priorityDomain) weights[priorityDomain] = 5;
    if (strengthDomain && strengthDomain !== priorityDomain) weights[strengthDomain] = 2;

    const supplementaryDomains = new Set<PassDomain>();
    for (const domain of DOMAIN_ORDER) {
      const failed = await this.hasRepeatedFailure(studentId, domain);
      if (failed) {
        supplementaryDomains.add(domain);
        weights[domain] += 1;
      }
    }

    // 총 세션 수를 10~15 범위로 클램프 (2~3개/일 x 5일)
    let total = DOMAIN_ORDER.reduce((sum, d) => sum + weights[d], 0);
    const supplementaryList = Array.from(supplementaryDomains);
    let i = 0;
    while (total > 15 && i < supplementaryList.length) {
      const d = supplementaryList[i]!;
      weights[d] -= 1;
      supplementaryDomains.delete(d);
      total -= 1;
      i += 1;
    }

    return { weights, supplementaryDomains };
  }

  /**
   * 최근 2주(각 7일 버킷)의 해당 영역 평균 성공률이, 최근 사용 난이도의
   * difficulty_mapping.demote_threshold 미만으로 2주 연속 나오면 "반복 실패"로 판정한다.
   */
  private async hasRepeatedFailure(studentId: number, domain: PassDomain): Promise<boolean> {
    const recent = await this.historyRepo.listRecentByStudentAndDomain(studentId, domain, 20);
    if (recent.length === 0) return false;

    const currentLevel = recent[0]!.difficultyLevel ?? 3;
    const thresholds = await this.difficultyMappingRepo.getByLevel(currentLevel);
    if (!thresholds) {
      throw new Error(`difficulty_mapping에 Level ${currentLevel}에 대한 임계값이 없습니다.`);
    }

    const now = Date.now();
    const week1 = recent.filter((h) => now - h.performedAt.getTime() <= 7 * 24 * 60 * 60 * 1000);
    const week2 = recent.filter(
      (h) =>
        now - h.performedAt.getTime() > 7 * 24 * 60 * 60 * 1000 &&
        now - h.performedAt.getTime() <= 14 * 24 * 60 * 60 * 1000,
    );
    if (week1.length === 0 || week2.length === 0) return false;

    const avg = (arr: typeof recent) => arr.reduce((sum, h) => sum + (h.successRate ?? 0), 0) / arr.length;
    return avg(week1) < thresholds.demoteThreshold && avg(week2) < thresholds.demoteThreshold;
  }

  /** 가중 라운드로빈: 가중치가 큰 영역이 골고루 퍼지도록 슬롯을 나열한다 */
  private buildWeightedDomainSequence(weights: Record<PassDomain, number>): PassDomain[] {
    const remaining = { ...weights };
    const sequence: PassDomain[] = [];
    const total = DOMAIN_ORDER.reduce((sum, d) => sum + remaining[d], 0);

    while (sequence.length < total) {
      for (const domain of DOMAIN_ORDER) {
        if (remaining[domain] > 0) {
          sequence.push(domain);
          remaining[domain] -= 1;
        }
        if (sequence.length >= total) break;
      }
    }
    return sequence;
  }

  /** 총 세션 수(10~15)를 5일에 2~3개씩 배분한다 */
  private buildDayCounts(total: number): number[] {
    const base = 2;
    const counts = Array(WEEK_DAYS).fill(base) as number[];
    let extra = total - base * WEEK_DAYS;
    let idx = 0;
    while (extra > 0 && idx < WEEK_DAYS) {
      counts[idx] = counts[idx]! + 1;
      extra -= 1;
      idx += 1;
    }
    return counts;
  }

  private isLastOccurrence(sequence: PassDomain[], indexJustAssigned: number, domain: PassDomain): boolean {
    for (let i = indexJustAssigned + 1; i < sequence.length; i += 1) {
      if (sequence[i] === domain) return false;
    }
    return true;
  }

  /** items를 program_id로 일괄 조회해 duration/training_goal/parent_guidance를 정확한 스냅샷으로 교체한다 */
  private async enrichItemsWithProgramSnapshot(
    items: Array<{
      programId: string;
      trainingGoal: string;
      duration: string | null;
      parentGuidance: string;
    }>,
  ): Promise<void> {
    const cache = new Map<string, Awaited<ReturnType<ITrainingProgramRepository['findById']>>>();
    for (const item of items) {
      if (!cache.has(item.programId)) {
        cache.set(item.programId, await this.trainingProgramRepo.findById(item.programId));
      }
      const program = cache.get(item.programId);
      if (!program) continue;
      item.trainingGoal = program.trainingGoal ?? item.trainingGoal;
      item.duration = program.duration;
      item.parentGuidance = [program.homeActivity10min, program.parentQuestion, program.parentFeedback]
        .filter(Boolean)
        .join(' / ');
    }
  }

  private averageSuccessForDomain(
    plan: WeeklyTrainingPlan,
    domain: PassDomain,
    logsByItemId: Map<number, { successRate: number }>,
  ): number | null {
    const rates = plan.items
      .filter((i) => i.passDomain === domain)
      .map((i) => logsByItemId.get(i.itemId)?.successRate)
      .filter((v): v is number => v !== undefined);
    if (rates.length === 0) return null;
    return Math.round((rates.reduce((sum, v) => sum + v, 0) / rates.length) * 100) / 100;
  }

  private buildNextMonthRecommendation(
    priorityDomain: string | null,
    strengthDomain: string | null,
    improvementRate: number | null,
  ): string {
    const parts: string[] = [];
    if (priorityDomain) {
      if (improvementRate !== null && improvementRate >= 10) {
        parts.push(
          `약점 영역(${priorityDomain})의 성취도가 뚜렷하게 개선되었습니다(+${improvementRate}점). ` +
            `다음 달에는 난이도를 한 단계 높여 심화 학습을 진행하는 것을 권장합니다.`,
        );
      } else if (improvementRate !== null && improvementRate < 0) {
        parts.push(
          `약점 영역(${priorityDomain})의 성취도가 오히려 낮아졌습니다(${improvementRate}점). ` +
            `난이도를 유지하거나 한 단계 낮추고, 보조 훈련을 추가해 반복 연습하는 것을 권장합니다.`,
        );
      } else {
        parts.push(
          `약점 영역(${priorityDomain})은 완만한 변화를 보였습니다. ` +
            `동일한 난이도로 꾸준히 진행하며 다음 달에 재평가하는 것을 권장합니다.`,
        );
      }
    } else {
      parts.push('4개 PASS 영역이 고르게 발달하고 있습니다. 균형 유지 훈련을 계속 진행하는 것을 권장합니다.');
    }
    if (strengthDomain) {
      parts.push(`강점 영역(${strengthDomain})은 주 2회 유지 훈련으로 계속 지원합니다.`);
    }
    return parts.join(' ');
  }

  private monthRange(month: string): { from: Date; to: Date } {
    const [yearStr, monthStr] = month.split('-');
    if (!yearStr || !monthStr) {
      throw new ValidationError('month는 YYYY-MM 형식이어야 합니다.');
    }
    const year = Number(yearStr);
    const monthNum = Number(monthStr);
    const from = new Date(Date.UTC(year, monthNum - 1, 1));
    const to = new Date(Date.UTC(year, monthNum, 0, 23, 59, 59));
    return { from, to };
  }
}
