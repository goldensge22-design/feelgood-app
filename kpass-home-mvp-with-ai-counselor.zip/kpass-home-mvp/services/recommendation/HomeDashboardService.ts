import { PassBandLevel } from '@/shared/constants/passStandards';
import { DailyPrescriptionOutput, RecommendationService } from '@/domain/services/RecommendationService';
import {
  IDailyLearningPlanRepository,
  IRecommendationRepository,
} from '@/repositories/interfaces';
import { PassResultService, PassProfileAnalysis } from '@/services/pass/PassResultService';
import { PassDomain } from '@/shared/constants/passStandards';

export interface HomeDashboardData {
  analysis: PassProfileAnalysis;
  prescription: DailyPrescriptionOutput;
  weeklyMissionNote: string;
  fourWeekPlanNote: string;
}

const DOMAIN_ORDER: PassDomain[] = ['PLANNING', 'ATTENTION', 'SIMULTANEOUS', 'SUCCESSIVE'];

function pickPriorityDomain(analysis: PassProfileAnalysis): PassDomain {
  // 우선훈련영역이 pass_profile에 저장되어 있으면 그대로 사용(§PassResultService 주석 참고).
  const stored = analysis.priorityDomain?.toUpperCase();
  if (stored && (DOMAIN_ORDER as string[]).includes(stored)) {
    return stored as PassDomain;
  }
  // 저장된 값이 없을 때만, "가장 낮은 표준점수 영역"이라는 단순 규칙(알고리즘이 아닌
  // 결측값 대응 fallback)으로 대체한다. 실제 우선순위 산정 로직은 구현하지 않는다.
  const scores: Array<{ domain: PassDomain; score: number; band: PassBandLevel }> = [
    { domain: 'PLANNING', score: analysis.planning.score, band: analysis.planning.band },
    { domain: 'ATTENTION', score: analysis.attention.score, band: analysis.attention.band },
    { domain: 'SIMULTANEOUS', score: analysis.simultaneous.score, band: analysis.simultaneous.band },
    { domain: 'SUCCESSIVE', score: analysis.successive.score, band: analysis.successive.band },
  ];
  scores.sort((a, b) => a.score - b.score);
  return scores[0]!.domain;
}

export class HomeDashboardService {
  constructor(
    private readonly passResultService: PassResultService,
    private readonly recommendationService: RecommendationService,
    private readonly recommendationRepo: IRecommendationRepository,
    private readonly dailyPlanRepo: IDailyLearningPlanRepository,
  ) {}

  /**
   * HOME-001 Home Dashboard / HOME-002 Daily Prescription 대응.
   * PASS 결과를 분석(규칙 기반 밴드 분류만)하고, 실제 추천은 전부
   * PlaceholderRecommendationService(정책 #4)에 위임한다.
   */
  async getDashboard(studentId: number): Promise<HomeDashboardData> {
    const result = await this.passResultService.getLatestResult(studentId);
    const analysis = this.passResultService.buildAnalysis(result);
    const priorityDomain = pickPriorityDomain(analysis);

    const prescription = await this.recommendationService.generateDailyPrescription(
      studentId,
      result.resultId,
    );

    // 오늘의 처방을 daily_learning_plan(생성 상태)으로 기록한다.
    await this.dailyPlanRepo.upsertToday(studentId, 'HOME');

    // 추천 결과를 recommendation 테이블에 감사 로그 목적으로 기록한다.
    const primary = prescription.items[0];
    if (primary) {
      await this.recommendationRepo.create({
        studentId,
        resultId: result.resultId,
        activityId: primary.activityId,
        reason: primary.reason,
        confidenceScore: primary.confidence,
      });
    }

    return {
      analysis,
      prescription,
      // HOME-006 Weekly Mission / UI Flow "주간 미션·4주 계획"은 Round4 문서에
      // 문구 템플릿만 있고 반복 스케줄링 로직이 없어 Placeholder 안내문으로 대체.
      weeklyMissionNote: `${priorityDomain} 영역을 중심으로 이번 주 미션이 곧 제공될 예정입니다. (TODO(HOME-006): 주간 미션 반복 로직 미정)`,
      fourWeekPlanNote:
        '4주 계획 기능은 준비 중입니다. (TODO(HOME-PLAN-004w): daily_learning_plan은 일 단위 테이블만 존재하여 주/월 단위 저장 구조가 ERD에 없음)',
    };
  }
}
