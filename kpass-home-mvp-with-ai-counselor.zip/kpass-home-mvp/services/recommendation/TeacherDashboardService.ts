import { RecommendationService } from '@/domain/services/RecommendationService';
import { IRecommendationRepository, IStudentRepository } from '@/repositories/interfaces';
import { PassResultService } from '@/services/pass/PassResultService';
import { PassDomain } from '@/shared/constants/passStandards';

export interface StudentRecommendationCard {
  studentId: number;
  studentName: string;
  passDomain: PassDomain;
  programId: string | null;
  programName: string;
  reason: string;
  evidenceLevel: number | null;
  confidence: number;
}

export interface GroupRecommendationCard {
  groupLabel: string; // 예: '약점: Attention 하 그룹'
  studentIds: number[];
  passDomain: PassDomain;
  programId: string | null;
  programName: string;
  reason: string;
}

export interface ClassRecommendationSummary {
  classId: number;
  domainCoverage: Record<PassDomain, number>; // 학급 내 약점으로 분류된 학생 수
  suggestedFocusDomain: PassDomain;
  representativeProgramName: string;
}

/**
 * Teacher AI 대시보드 서비스.
 *
 * Home AI(HomeDashboardService)와 동일하게 RecommendationService 인터페이스에만
 * 의존한다 — Teacher AI는 프로그램을 직접 생성하지 않으며, Program Recommendation
 * Engine(LibraryRecommendationService)이 PASS Cognitive Training Library에서
 * 선택한 결과만 학생별/그룹별/학급별로 재구성하여 보여준다.
 */
export class TeacherDashboardService {
  constructor(
    private readonly passResultService: PassResultService,
    private readonly recommendationService: RecommendationService,
    private readonly recommendationRepo: IRecommendationRepository,
    private readonly studentRepo: IStudentRepository,
  ) {}

  /** 학생 1명에 대한 추천 카드 (교사 화면 - 학생별 탭) */
  async getStudentRecommendation(studentId: number, ageBand: string): Promise<StudentRecommendationCard> {
    const student = await this.studentRepo.findById(studentId);
    if (!student) throw new Error(`student를 찾을 수 없습니다: ${studentId}`);

    const result = await this.passResultService.getLatestResult(studentId);
    const analysis = this.passResultService.buildAnalysis(result);
    const priorityDomain = (analysis.priorityDomain?.toUpperCase() ?? 'PLANNING') as PassDomain;

    const output = await this.recommendationService.recommendForDomain({
      studentId,
      resultId: result.resultId,
      passDomain: priorityDomain,
      ageBand,
      environment: 'TEACHER_INDIVIDUAL',
    });

    await this.recommendationRepo.create({
      studentId,
      resultId: result.resultId,
      activityId: output.programId,
      reason: output.reason,
      confidenceScore: output.confidence,
    });

    return {
      studentId,
      studentName: student.name,
      passDomain: priorityDomain,
      programId: output.programId,
      programName: output.recommendation,
      reason: output.reason,
      evidenceLevel: output.evidenceLevel,
      confidence: output.confidence,
    };
  }

  /**
   * 동일 약점 영역을 가진 학생들을 묶어 그룹 추천을 생성한다.
   * (그룹 판별 로직 자체는 서비스 계층 규칙이며, 프로그램 콘텐츠는 여전히
   *  Library에서만 선택된다.)
   */
  async getGroupRecommendation(
    studentIds: number[],
    passDomain: PassDomain,
    ageBand: string,
  ): Promise<GroupRecommendationCard> {
    if (studentIds.length === 0) {
      throw new Error('studentIds가 비어 있습니다.');
    }
    // 그룹 대표 학생 1명의 최신 결과로 추천을 생성(동일 도메인/연령대 그룹 가정).
    const representativeId = studentIds[0]!;
    const result = await this.passResultService.getLatestResult(representativeId);

    const output = await this.recommendationService.recommendForDomain({
      studentId: representativeId,
      resultId: result.resultId,
      passDomain,
      ageBand,
      environment: 'TEACHER_GROUP',
    });

    return {
      groupLabel: `약점: ${passDomain} 그룹 (${studentIds.length}명)`,
      studentIds,
      passDomain,
      programId: output.programId,
      programName: output.recommendation,
      reason: output.reason,
    };
  }

  /**
   * 학급 전체의 PASS 영역별 약점 분포를 집계하고, 가장 시급한 영역 1개에
   * 대한 대표 프로그램을 추천한다(학급 전체 활동용).
   */
  async getClassSummary(
    classId: number,
    studentScores: Array<{ studentId: number; priorityDomain: PassDomain }>,
    ageBand: string,
  ): Promise<ClassRecommendationSummary> {
    const coverage: Record<PassDomain, number> = {
      PLANNING: 0,
      ATTENTION: 0,
      SIMULTANEOUS: 0,
      SUCCESSIVE: 0,
    };
    for (const s of studentScores) {
      coverage[s.priorityDomain] += 1;
    }
    const focusDomain = (Object.entries(coverage).sort((a, b) => b[1] - a[1])[0]?.[0] ??
      'PLANNING') as PassDomain;

    const representative = studentScores.find((s) => s.priorityDomain === focusDomain) ?? studentScores[0];
    const result = await this.passResultService.getLatestResult(representative!.studentId);

    const output = await this.recommendationService.recommendForDomain({
      studentId: representative!.studentId,
      resultId: result.resultId,
      passDomain: focusDomain,
      ageBand,
      environment: 'TEACHER_CLASS',
    });

    return {
      classId,
      domainCoverage: coverage,
      suggestedFocusDomain: focusDomain,
      representativeProgramName: output.recommendation,
    };
  }
}
