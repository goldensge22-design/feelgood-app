import {
  DailyPrescriptionOutput,
  RecommendationInput,
  RecommendationOutput,
  RecommendationService,
} from '@/domain/services/RecommendationService';
import {
  HOME_EDITION_MOCK,
  toRecommendationOutput,
} from '@/domain/services/mock/round4HomeEditionMock';

/**
 * RecommendationService의 유일한 구현체 (Home MVP).
 * PASS 영역별 인지훈련 활동을 추천하는 인지훈련 추천 엔진의 Placeholder 구현체이다.
 *
 * 정책 #4: "Recommendation Engine은 반드시 Interface 기반 Placeholder로
 * 구현한다. 실제 PASS 알고리즘은 구현하지 않는다. 실제 AI 인지훈련 추천도
 * 구현하지 않는다. 실제 Evidence 생성도 구현하지 않는다."
 *
 * 이 클래스는:
 *   - PASS 점수를 분석하는 어떤 알고리즘도 포함하지 않는다.
 *   - Round4 Mock Data(정책 #5)를 PASS 영역별 인지훈련 활동으로 그대로 반환한다.
 *   - 모든 출력에 isMock: true 를 강제하여 프론트엔드가 "AI 인지훈련 예시" 배지를
 *     표시할 수 있게 한다.
 *
 * TODO(AI-ENGINE-001): 실제 Round3C AI Rule Engine이 "Draft" 상태를 벗어나
 * Evidence 검증(Round3.5)이 완료되면, 이 클래스를 교체할 새 구현체
 * (예: RuleEngineRecommendationService)를 domain/services/RecommendationService
 * 인터페이스를 그대로 구현하는 형태로 추가한다. 인터페이스 시그니처는 변경하지 않는다.
 */
export class PlaceholderRecommendationService implements RecommendationService {
  async recommendForDomain(input: RecommendationInput): Promise<RecommendationOutput> {
    // 실제 age/environment 조건 분기 로직(Round3C RULE-*)은 Draft 상태라 구현하지 않음.
    // input은 인터페이스 계약을 유지하기 위해 받되, Mock 조회는 PASS 영역으로만 수행한다.
    void input.ageBand;
    void input.environment;
    void input.studentId;
    void input.resultId;
    return toRecommendationOutput(input.passDomain);
  }

  async generateDailyPrescription(
    studentId: number,
    resultId: number,
  ): Promise<DailyPrescriptionOutput> {
    void studentId;
    void resultId;

    // 오늘의 인지훈련 활동 3개: Round4 Home Edition Mock 4건 중 앞 3건을 고정 반환한다.
    // 실제 "우선훈련영역 기반 선정" 로직(REC-004 Daily Plan)은 PASS 알고리즘이므로
    // 정책 #4에 따라 구현하지 않는다.
    const items = HOME_EDITION_MOCK.slice(0, 3).map((row) => toRecommendationOutput(row.passDomain));
    const first = HOME_EDITION_MOCK[0]!;

    return {
      date: new Date().toISOString().slice(0, 10),
      items,
      parentQuestion: first.parentQuestion,
      parentPraise: first.parentFeedback,
      lifePassMission: first.lifePassMission,
      isMock: true,
    };
  }
}
