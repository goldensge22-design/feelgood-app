/**
 * 이 파일의 모든 데이터는 KPASS_Round4_Evidence_Based_AI_Learning_Platform_v1_0.xlsx
 * (06_Home_Edition, 02_Evidence_XAI_Panel, 10_Parent_Coach 시트)에서 그대로 가져온
 * MOCK DATA이다.
 *
 * 정책 #5: "Round4의 데이터는 실제 데이터가 아니라 Mock Data로 간주한다.
 * UI와 API 테스트 용도로만 사용한다."
 *
 * 실제 서비스 데이터(활동 라이브러리, Evidence 검증 결과)는 Round3C 근거가
 * 확정(Draft → Validated)된 이후 별도 시드/마이그레이션으로 교체되어야 한다.
 * 이 파일을 실제 서비스 판단 근거로 사용하지 말 것.
 */

import { PassDomain } from '@/shared/constants/passStandards';
import { RecommendationOutput } from '@/domain/services/RecommendationService';

export interface HomeEditionMockRow {
  homePlanId: string;
  ageGrade: string;
  passDomain: PassDomain;
  todayActivity: string;
  durationMinutes: number;
  parentQuestion: string;
  parentFeedback: string;
  lifePassMission: string;
  materials: string;
  aiReason: string;
  evidenceDisplay: string; // e.g. "PASS-E0012 / ACT-P-H-001"
  evidenceCode: string;
  activityId: string;
  recordItem: string;
}

export const HOME_EDITION_MOCK: HomeEditionMockRow[] = [
  {
    homePlanId: 'HOME-P-001',
    ageGrade: '초1~2',
    passDomain: 'PLANNING',
    todayActivity: '내일 가방 챙기기 순서 정하기',
    durationMinutes: 10,
    parentQuestion: '먼저 무엇을 챙길까? 빠진 것은 없을까?',
    parentFeedback: '스스로 순서를 생각한 점이 좋았어.',
    lifePassMission: '등교 준비',
    materials: '가방, 준비물 목록',
    aiReason: 'Planning 보완과 생활 속 계획 훈련이 필요하기 때문',
    evidenceDisplay: 'PASS-E0012 / ACT-P-H-001',
    evidenceCode: 'PASS-E0012',
    activityId: 'ACT-P-H-001',
    recordItem: '완료 여부, 도움 정도',
  },
  {
    homePlanId: 'HOME-A-001',
    ageGrade: '만5~초2',
    passDomain: 'ATTENTION',
    todayActivity: '빨간 신호 멈춤 놀이',
    durationMinutes: 5,
    parentQuestion: '지금은 멈추는 신호일까?',
    parentFeedback: '규칙을 기억하고 멈춘 점이 좋았어.',
    lifePassMission: '식사 전·놀이 전',
    materials: '색 카드',
    aiReason: '선택적 주의와 억제 훈련이 필요하기 때문',
    evidenceDisplay: 'PASS-E0048 / ACT-A-H-001',
    evidenceCode: 'PASS-E0048',
    activityId: 'ACT-A-H-001',
    recordItem: '멈춤 성공 횟수',
  },
  {
    homePlanId: 'HOME-SI-001',
    ageGrade: '초1~4',
    passDomain: 'SIMULTANEOUS',
    todayActivity: '그림 보고 이야기 만들기',
    durationMinutes: 10,
    parentQuestion: '이 그림 전체에서 무슨 일이 일어났을까?',
    parentFeedback: '전체를 보고 연결해서 말한 점이 좋았어.',
    lifePassMission: '책 읽기',
    materials: '그림책',
    aiReason: '시각 통합 강점을 활용해 인지훈련 효과를 높이기 때문',
    evidenceDisplay: 'PASS-E0032 / ACT-SI-H-001',
    evidenceCode: 'PASS-E0032',
    activityId: 'ACT-SI-H-001',
    recordItem: '설명 길이, 연결성',
  },
  {
    homePlanId: 'HOME-SU-001',
    ageGrade: '만6~초2',
    passDomain: 'SUCCESSIVE',
    todayActivity: '하루 일과 순서 말하기',
    durationMinutes: 8,
    parentQuestion: '아침부터 지금까지 어떤 순서였을까?',
    parentFeedback: '순서를 잘 기억해서 말했어.',
    lifePassMission: '잠자리 대화',
    materials: '없음',
    aiReason: '순서 기억과 언어 흐름 보완에 적합하기 때문',
    evidenceDisplay: 'PASS-E0021 / ACT-SU-H-001',
    evidenceCode: 'PASS-E0021',
    activityId: 'ACT-SU-H-001',
    recordItem: '순서 오류 수',
  },
];

export interface EvidencePanelMockRow {
  recommendationId: string;
  activityName: string;
  aiReason: string;
  evidenceCode: string;
  activityCode: string;
  trainingCode: string;
  teachingCode: string;
  passDomain: PassDomain;
  executiveFunction: string;
  paperCount: number;
  evidenceLevelStars: number; // 1~5
  displayMode: string;
}

export const EVIDENCE_PANEL_MOCK: EvidencePanelMockRow[] = [
  {
    recommendationId: 'REC-0001',
    activityName: '순서 계획 카드',
    aiReason: 'Planning 점수가 낮고 순서 계획 훈련이 우선 필요하기 때문',
    evidenceCode: 'PASS-E0012',
    activityCode: 'ACT-0015',
    trainingCode: 'TR-0001',
    teachingCode: 'TS-0004',
    passDomain: 'PLANNING',
    executiveFunction: 'Planning/Monitoring',
    paperCount: 7,
    evidenceLevelStars: 5,
    displayMode: '기본 표시 + 근거 보기',
  },
  {
    recommendationId: 'REC-0002',
    activityName: '도형 완성하기',
    aiReason: 'Simultaneous 강점을 활용해 Planning 활동 진입을 쉽게 하기 때문',
    evidenceCode: 'PASS-E0032',
    activityCode: 'ACT-0104',
    trainingCode: 'TR-0041',
    teachingCode: 'TS-0001',
    passDomain: 'SIMULTANEOUS',
    executiveFunction: 'Visual Integration',
    paperCount: 12,
    evidenceLevelStars: 5,
    displayMode: '근거 보기',
  },
  {
    recommendationId: 'REC-0003',
    activityName: '숨은 규칙 찾기',
    aiReason: 'Attention과 Inhibition을 동시에 자극하는 활동이 필요하기 때문',
    evidenceCode: 'PASS-E0048',
    activityCode: 'ACT-0207',
    trainingCode: 'TR-0065',
    teachingCode: 'TS-0002',
    passDomain: 'ATTENTION',
    executiveFunction: 'Inhibition',
    paperCount: 9,
    evidenceLevelStars: 4,
    displayMode: '기본 표시 + 근거 보기',
  },
  {
    recommendationId: 'REC-0004',
    activityName: '이야기 순서 배열',
    aiReason: 'Successive Processing과 언어 순서 기억 보완에 적합하기 때문',
    evidenceCode: 'PASS-E0021',
    activityCode: 'ACT-0042',
    trainingCode: 'TR-0018',
    teachingCode: 'TS-0003',
    passDomain: 'SUCCESSIVE',
    executiveFunction: 'Working Memory',
    paperCount: 11,
    evidenceLevelStars: 5,
    displayMode: '기본 표시',
  },
];

export function findHomeEditionByDomain(domain: PassDomain): HomeEditionMockRow {
  const row = HOME_EDITION_MOCK.find((r) => r.passDomain === domain);
  // Round4 데이터셋에는 4개 PASS 영역 각각 1개 예시만 존재(정책 #5, TODO(MOCK-001)
  // 참고: docs/ASSUMPTIONS_AND_TODOS.md). 없을 경우 첫 항목으로 fallback.
  return row ?? HOME_EDITION_MOCK[0]!;
}

export function findEvidenceByDomain(domain: PassDomain): EvidencePanelMockRow {
  const row = EVIDENCE_PANEL_MOCK.find((r) => r.passDomain === domain);
  return row ?? EVIDENCE_PANEL_MOCK[0]!;
}

export function toRecommendationOutput(domain: PassDomain): RecommendationOutput {
  const home = findHomeEditionByDomain(domain);
  const evidence = findEvidenceByDomain(domain);
  return {
    recommendation: home.todayActivity,
    reason: home.aiReason,
    evidenceCode: home.evidenceCode,
    evidenceLevel: evidence.evidenceLevelStars,
    confidence: 0.0, // TODO(MOCK-002): 신뢰도 산출 공식이 문서에 없어 Placeholder로 0 고정
    activityId: home.activityId,
    isMock: true,
  };
}
