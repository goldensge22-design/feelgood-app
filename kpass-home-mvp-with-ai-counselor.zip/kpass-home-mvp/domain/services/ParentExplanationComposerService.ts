import { ParentExplanation, PassDomain } from '@/domain/entities';
import { PassResultService } from '@/services/pass/PassResultService';
import {
  IAvoidPhraseRepository,
  ICognitiveProfileRepository,
  IParentFaqRepository,
  IParentLifeCaseRepository,
} from '@/repositories/interfaces';
import { NotFoundError } from '@/shared/errors/AppError';

/**
 * "① 부모가 이해하기 쉽게 설명" 화면 컴포저.
 *
 * 원칙: 기존 요약보기를 다시 보여주는 것이 아니라, 검사 결과를 부모의 언어로
 * "번역"한다. 이 서비스는 어떤 문장도 새로 생성하지 않고, 아래 4개의 이미
 * 존재하는 소스만 조합한다:
 *   1) pass_profile (priority_domain / strength_domain / dominance_type)
 *   2) 81 Cognitive Profile (profile_code)
 *   3) 생활 사례 라이브러리(home_ai_parent_life_case)
 *   4) "하면 안 되는 말" / FAQ 라이브러리
 *
 * 화면 구성(지시서 순서 그대로):
 *  1. 우리 아이는 어떤 아이인가요?      -> childDescription
 *  2. 학교에서는 이렇게 보일 수 있습니다 -> schoolBehavior
 *  3. 집에서는 이렇게 보일 수 있습니다   -> homeBehavior
 *  4. 부모는 이렇게 도와주세요           -> parentGuidance
 *  5. 하면 안 되는 말                    -> avoidPhrases
 *  6. 부모들이 가장 많이 하는 질문(FAQ)  -> faqs
 *  7. 인지훈련 플래너 바로가기           -> weeklyPlannerLink
 *  8. 인지+정서훈련 바로가기             -> cognitiveEmotionalProgramLink
 */
export class ParentExplanationComposerService {
  constructor(
    private readonly passResultService: PassResultService,
    private readonly cognitiveProfileRepo: ICognitiveProfileRepository,
    private readonly lifeCaseRepo: IParentLifeCaseRepository,
    private readonly avoidPhraseRepo: IAvoidPhraseRepository,
    private readonly faqRepo: IParentFaqRepository,
  ) {}

  async composeForStudent(studentId: number): Promise<ParentExplanation> {
    const result = await this.passResultService.getLatestResult(studentId);
    const analysis = this.passResultService.buildAnalysis(result);

    const priorityDomain = analysis.priorityDomain as PassDomain | null;
    if (!priorityDomain) {
      throw new NotFoundError(
        '우선훈련영역(priority_domain)',
        '이 학생의 pass_profile에 priority_domain이 없어 Home AI 상담사를 구성할 수 없습니다.',
      );
    }

    const cognitiveProfile = await this.cognitiveProfileRepo.resolveFromScores({
      planning: result.planning,
      attention: result.attention,
      simultaneous: result.simultaneous,
      successive: result.successive,
    });
    const profileCode =
      `${cognitiveProfile.planningLevel}${cognitiveProfile.attentionLevel}` +
      `${cognitiveProfile.simultaneousLevel}${cognitiveProfile.successiveLevel}`;

    const [lifeCase, avoidPhrase, faqs] = await Promise.all([
      this.lifeCaseRepo.findByDomain(priorityDomain),
      this.avoidPhraseRepo.findByDomain(priorityDomain),
      this.faqRepo.listByDomain(priorityDomain),
    ]);

    if (!lifeCase) {
      throw new NotFoundError(
        '생활 사례 라이브러리',
        `priority_domain=${priorityDomain}에 대한 home_ai_parent_life_case 데이터가 없습니다. (라이브러리 확장 필요)`,
      );
    }

    let parentGuidance = lifeCase.parentGuidance;
    const strengthDomain = analysis.strengthDomain as PassDomain | null;
    if (strengthDomain) {
      parentGuidance += ` 그리고 아이가 강점을 보이는 ${this.labelOf(strengthDomain)} 영역을 함께 활용하면 자신감을 유지하는 데 도움이 됩니다.`;
    }

    return {
      studentId,
      profileCode,
      priorityDomain,
      strengthDomain,
      childDescription: lifeCase.childDescription,
      schoolBehavior: lifeCase.schoolBehavior,
      homeBehavior: lifeCase.homeBehavior,
      parentGuidance,
      avoidPhrases: avoidPhrase ? [avoidPhrase] : [],
      faqs,
      weeklyPlannerLink: { href: `/students/${studentId}`, label: '인지훈련 플래너 바로가기' },
      cognitiveEmotionalProgramLink: {
        // NOTE: '인지+정서훈련 프로그램'은 이 MVP 코드베이스 밖의 기존 결과지 기능이다.
        // 실제 서비스에서는 개발자가 이 href를 기존 결과지의 해당 화면 경로로 교체한다.
        href: `/students/${studentId}/cognitive-emotional-training`,
        label: '인지+정서훈련 바로가기',
      },
    };
  }

  private labelOf(domain: PassDomain): string {
    const labels: Record<PassDomain, string> = {
      PLANNING: '계획(Planning)',
      ATTENTION: '주의집중(Attention)',
      SIMULTANEOUS: '동시처리(Simultaneous)',
      SUCCESSIVE: '순차처리(Successive)',
    };
    return labels[domain];
  }
}
