/**
 * AI 추천 엔진 인터페이스.
 *
 * 지시서 §9 "AI 규칙":
 *   - RecommendationService Interface 사용
 *   - Placeholder 구현
 *   - 반환값: recommendation, reason, evidenceCode, evidenceLevel, confidence
 *
 * 정책 #4: 이 인터페이스의 구현체는 반드시 Placeholder여야 하며, 실제 PASS
 * 알고리즘/실제 AI 추천/실제 Evidence 생성 로직을 포함해서는 안 된다.
 * (Round3C AI Rule Engine, Adaptive Learning, Learning Path, Personalization
 * Engine은 모두 Draft/미평가 상태이므로 알고리즘으로 구현할 근거 자체가 없음)
 *
 * 향후 실제 AI 엔진이 준비되면 이 인터페이스를 그대로 유지한 채
 * PlaceholderRecommendationService를 RealRecommendationService로 교체하기만
 * 하면 되도록 설계되었다(의존성 역전).
 */

/**
 * AI 추천 엔진 인터페이스.
 *
 * [2024 리팩토링 갱신] 지시서 §9의 "Placeholder 정책"은 PASS Cognitive Training
 * Library(400개, 근거 기반)가 구축되면서 해제되었다. 이제 LibraryRecommendationService가
 * 이 인터페이스의 실제 구현체이며, PlaceholderRecommendationService는 테스트/데모
 * 목적으로만 유지한다.
 *
 * 불변 원칙(그대로 유지):
 *   - AI는 런타임에 새 훈련을 생성하지 않는다.
 *   - 반드시 PASS Cognitive Training Library(pass_training_program)에 저장된
 *     프로그램 중에서만 선택한다.
 *   - 반환값: recommendation, reason, evidenceCode, evidenceLevel, confidence
 */

export interface RecommendationInput {
  studentId: number;
  resultId: number;
  passDomain: 'PLANNING' | 'ATTENTION' | 'SIMULTANEOUS' | 'SUCCESSIVE';
  ageBand: string; // age_band_mapping.age_code, 예: '8-10'
  environment: 'HOME' | 'TEACHER_INDIVIDUAL' | 'TEACHER_GROUP' | 'TEACHER_CLASS';
  /**
   * 같은 계획(예: 주간 계획) 내에서 이미 배정된 program_id들. 엔진은 이 목록을
   * 1순위로 회피하되(다양성 확보), 후보가 소진되면 재사용을 허용한다
   * (스케줄을 비워두지 않기 위함 — Library에 후보 자체가 없을 때만 예외 발생).
   */
  excludeProgramIds?: string[];
}

export interface RecommendationOutput {
  recommendation: string; // 추천 프로그램명 (program_name)
  reason: string; // 추천 이유 (XAI) — 81 Profile / 난이도 이력 / 근거 수준을 포함
  evidenceCode: string | null; // 연결된 논문 ID들 ('P003;P041')
  evidenceLevel: number | null; // 1~5 환산 근거 강도 (direct=5 / indirect=3 / theoretical=1), null이면 근거 없음(발생해서는 안 됨)
  confidence: number; // 0~1
  programId: string | null; // pass_training_program.program_id
  /** @deprecated programId를 사용할 것. 하위호환을 위해 유지. */
  activityId: string | null;
  isMock: boolean; // Library 기반 실제 추천이면 false. Placeholder 구현체만 true를 반환한다.
}

export interface DailyPrescriptionOutput {
  date: string; // ISO date
  items: RecommendationOutput[]; // 오늘의 활동 (최대 3개)
  parentQuestion: string;
  parentPraise: string;
  lifePassMission: string;
  isMock: boolean;
}

export interface RecommendationService {
  /**
   * 단일 PASS 영역에 대한 추천을 생성한다.
   */
  recommendForDomain(input: RecommendationInput): Promise<RecommendationOutput>;

  /**
   * 오늘의 인지훈련 처방(가정 인지훈련용)을 생성한다. UI Flow Slide 7 "가정학습용 화면" 대응 문구를 인지훈련 기준으로 갱신.
   */
  generateDailyPrescription(studentId: number, resultId: number): Promise<DailyPrescriptionOutput>;
}
