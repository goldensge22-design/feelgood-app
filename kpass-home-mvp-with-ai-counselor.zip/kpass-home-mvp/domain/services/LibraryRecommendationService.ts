import {
  DailyPrescriptionOutput,
  RecommendationInput,
  RecommendationOutput,
  RecommendationService,
} from '@/domain/services/RecommendationService';
import {
  IAgeBandMappingRepository,
  ICognitiveProfileRepository,
  IDifficultyMappingRepository,
  IPassResultRepository,
  IStudentRepository,
  ITrainingHistoryRepository,
  ITrainingProgramRepository,
} from '@/repositories/interfaces';
import { TrainingProgram } from '@/domain/entities';
import { calculateAgeInYears } from '@/shared/utils/ageBand';

const EVIDENCE_LEVEL_SCORE: Record<string, number> = {
  direct_evidence: 5,
  indirect_evidence: 3,
  theoretical_evidence: 1,
};

const DOMAIN_ORDER = ['PLANNING', 'ATTENTION', 'SIMULTANEOUS', 'SUCCESSIVE'] as const;

/**
 * Program Recommendation Engine (실제 구현체) — Home AI(Weekly Planner)와
 * Teacher AI가 동일하게 공유하는 단일 엔진.
 *
 * 선택 기준: 81 Cognitive Profile x Age x Difficulty x Training History x
 * Weakness Priority x Strength Support. PASS Cognitive Training Library
 * (pass_training_program)에 이미 저장된 프로그램들 중에서만 "선택"하며,
 * 어떤 경우에도 새 프로그램 텍스트를 합성/생성하지 않는다.
 */
export class LibraryRecommendationService implements RecommendationService {
  constructor(
    private readonly trainingProgramRepo: ITrainingProgramRepository,
    private readonly profileRepo: ICognitiveProfileRepository,
    private readonly historyRepo: ITrainingHistoryRepository,
    private readonly passResultRepo: IPassResultRepository,
    private readonly studentRepo: IStudentRepository,
    private readonly ageBandMappingRepo: IAgeBandMappingRepository,
    private readonly difficultyMappingRepo: IDifficultyMappingRepository,
  ) {}

  async recommendForDomain(input: RecommendationInput): Promise<RecommendationOutput> {
    const result = await this.passResultRepo.findById(input.resultId);
    if (!result) {
      throw new Error(`pass_result를 찾을 수 없습니다: resultId=${input.resultId}`);
    }

    const profile = await this.profileRepo.resolveFromScores({
      planning: result.planning,
      attention: result.attention,
      simultaneous: result.simultaneous,
      successive: result.successive,
    });

    const difficultyLevel = await this.resolveDifficulty(input.studentId, input.passDomain);

    const recentHistory = await this.historyRepo.listRecentByStudentAndDomain(
      input.studentId,
      input.passDomain,
      20,
    );
    const recentProgramIds = new Set(
      recentHistory
        .filter((h) => h.performedAt.getTime() > Date.now() - 14 * 24 * 60 * 60 * 1000)
        .map((h) => h.programId),
    );

    let candidates = await this.trainingProgramRepo.findCandidates({
      passDomain: input.passDomain,
      ageCode: input.ageBand,
      difficultyLevel,
      approvalStatusIn: ['approved', 'draft_pending_review'],
    });

    if (candidates.length === 0) {
      throw new Error(
        `PASS Cognitive Training Library에 조건에 맞는 프로그램이 없습니다: ` +
          `domain=${input.passDomain}, age=${input.ageBand}, level=${difficultyLevel}. ` +
          `(라이브러리 확장 필요 — 절대 런타임 생성으로 대체하지 않는다)`,
      );
    }

    // 최근 2주 내 수행한 프로그램은 1순위에서 제외 (반복훈련 매너리즘 방지)
    const notRecentlyUsed = candidates.filter((c) => !recentProgramIds.has(c.programId));
    if (notRecentlyUsed.length > 0) {
      candidates = notRecentlyUsed;
    }

    // 같은 계획 내 이미 배정된 프로그램 회피 (예: 주간 계획에서 동일 영역이 여러 번
    // 배정될 때 같은 프로그램이 반복되지 않도록). 후보가 소진되면 재사용 허용.
    if (input.excludeProgramIds?.length) {
      const excludeSet = new Set(input.excludeProgramIds);
      const notExcluded = candidates.filter((c) => !excludeSet.has(c.programId));
      if (notExcluded.length > 0) {
        candidates = notExcluded;
      }
    }

    const isWeakness = profile.priorityDomain === input.passDomain;
    const isStrength = profile.strengthDomain === input.passDomain;

    const chosen = this.pickBySubFunctionRotation(
      candidates,
      recentHistory.map((h) => h.programId),
    );

    return this.toOutput(chosen, {
      isWeakness,
      isStrength,
      difficultyLevel,
      profileCode: `${profile.planningLevel}${profile.attentionLevel}${profile.simultaneousLevel}${profile.successiveLevel}`,
    });
  }

  async generateDailyPrescription(studentId: number, resultId: number): Promise<DailyPrescriptionOutput> {
    const result = await this.passResultRepo.findById(resultId);
    if (!result) {
      throw new Error(`pass_result를 찾을 수 없습니다: resultId=${resultId}`);
    }

    const profile = await this.profileRepo.resolveFromScores({
      planning: result.planning,
      attention: result.attention,
      simultaneous: result.simultaneous,
      successive: result.successive,
    });

    const orderedDomains = [
      profile.priorityDomain,
      ...DOMAIN_ORDER.filter((d) => d !== profile.priorityDomain),
    ].filter((d): d is (typeof DOMAIN_ORDER)[number] => Boolean(d));

    const ageCode = await this.resolveAgeCode(studentId);

    const items: RecommendationOutput[] = [];
    for (const domain of orderedDomains.slice(0, 3)) {
      const item = await this.recommendForDomain({
        studentId,
        resultId,
        passDomain: domain,
        ageBand: ageCode,
        environment: 'HOME',
      });
      items.push(item);
    }

    return {
      date: new Date().toISOString().slice(0, 10),
      items,
      parentQuestion: '오늘 활동 중 어떤 부분이 제일 재미있었어? 어떤 부분이 어려웠어?',
      parentPraise: '스스로 방법을 찾아내려고 노력한 점이 정말 멋져요!',
      lifePassMission: `오늘 배운 ${profile.priorityDomain ?? '인지'} 전략을 집안일이나 놀이에서 한 번 사용해보기`,
      isMock: false,
    };
  }

  /** studentId의 만 나이를 계산해 age_band_mapping에서 age_code를 조회한다. 매핑이 없으면 예외(추측 대체 금지). */
  async resolveAgeCode(studentId: number): Promise<string> {
    const student = await this.studentRepo.findById(studentId);
    if (!student) {
      throw new Error(`student를 찾을 수 없습니다: ${studentId}`);
    }
    if (!student.birthDate) {
      throw new Error(`student.birthDate가 없어 연령대를 계산할 수 없습니다: studentId=${studentId}`);
    }
    const ageInYears = calculateAgeInYears(new Date(student.birthDate));
    const band = await this.ageBandMappingRepo.resolveAgeCode(ageInYears);
    if (!band) {
      throw new Error(`age_band_mapping에 만 ${ageInYears}세에 대한 구간이 없습니다.`);
    }
    return band.ageCode;
  }

  /**
   * 난이도 조정: 해당 PASS 영역의 최근 이력 평균 성공률을, 최근 사용한 난이도의
   * difficulty_mapping 임계값(promote/demote)과 비교해 승급/유지/강등을 결정한다.
   * 이력이 없으면 Level 3(표준)에서 시작한다.
   */
  private async resolveDifficulty(
    studentId: number,
    passDomain: RecommendationInput['passDomain'],
  ): Promise<number> {
    const recent = await this.historyRepo.listRecentByStudentAndDomain(studentId, passDomain, 5);
    if (recent.length === 0) return 3;

    const currentLevel = recent[0]!.difficultyLevel ?? 3;
    const avgSuccess = recent.reduce((sum, h) => sum + (h.successRate ?? 0), 0) / recent.length;

    const thresholds = await this.difficultyMappingRepo.getByLevel(currentLevel);
    if (!thresholds) {
      throw new Error(`difficulty_mapping에 Level ${currentLevel}에 대한 임계값이 없습니다.`);
    }

    if (avgSuccess >= thresholds.promoteThreshold) {
      return Math.min(5, currentLevel + 1);
    }
    if (avgSuccess < thresholds.demoteThreshold) {
      return Math.max(1, currentLevel - 1);
    }
    return currentLevel;
  }

  /** 같은 sub_cognitive_function을 최근에 이미 했다면 다른 하위기능을 우선한다(커버리지 확보) */
  private pickBySubFunctionRotation(
    candidates: TrainingProgram[],
    recentProgramIds: string[],
  ): TrainingProgram {
    const recentSet = new Set(recentProgramIds.slice(0, 5));
    const notRecent = candidates.filter((c) => !recentSet.has(c.programId));
    const pool = notRecent.length > 0 ? notRecent : candidates;
    // program_id 사전순 결정론적 선택 (동일 입력 -> 동일 출력, 재현 가능한 추천)
    return [...pool].sort((a, b) => a.programId.localeCompare(b.programId))[0]!;
  }

  private toOutput(
    program: TrainingProgram,
    ctx: { isWeakness: boolean; isStrength: boolean; difficultyLevel: number; profileCode: string },
  ): RecommendationOutput {
    const evidenceLevels = program.evidenceRefs.map((e) => EVIDENCE_LEVEL_SCORE[e.evidenceLevel] ?? 1);
    const evidenceLevel = evidenceLevels.length > 0 ? Math.max(...evidenceLevels) : null;
    const confidence = Math.min(1, 0.5 + (evidenceLevel ?? 0) * 0.1);

    const reasonParts = [
      `학생의 81 Cognitive Profile(${ctx.profileCode}) 기준 ${program.passDomain} 영역이 ` +
        (ctx.isWeakness ? '보완이 필요한 약점 영역' : ctx.isStrength ? '강점 영역(심화 유지)' : '균형 발달 영역') +
        '으로 분류되었습니다.',
      `현재 Level ${ctx.difficultyLevel} 난이도, 하위기능 '${program.subCognitiveFunction}'을(를) 다룹니다.`,
      program.evidenceRefs.length > 0
        ? `근거: ${program.evidenceRefs.map((e) => `${e.paperCode}(${e.evidenceLevel})`).join(', ')}`
        : '근거 논문 없음(발생 시 라이브러리 데이터 오류)',
    ];

    return {
      recommendation: program.programName,
      reason: reasonParts.join(' '),
      evidenceCode: program.evidenceRefs.map((e) => e.paperCode).join(';') || null,
      evidenceLevel,
      confidence,
      programId: program.programId,
      activityId: program.programId, // 하위호환 별칭
      isMock: false,
    };
  }
}
