import { PassDomain, StudentUnderstanding } from '@/domain/entities';
import { PassResultService } from '@/services/pass/PassResultService';
import { ICognitiveProfileRepository, ITeacherStrategyRepository } from '@/repositories/interfaces';
import { NotFoundError } from '@/shared/errors/AppError';

/**
 * "① 학생 이해하기" 화면 컴포저(선생님용 AI).
 * ParentExplanationComposerService와 동일한 원칙 — 텍스트를 새로 생성하지 않고
 * home_ai_teacher_strategy 라이브러리 + 81 Cognitive Profile만 조합한다.
 */
export class StudentUnderstandingComposerService {
  constructor(
    private readonly passResultService: PassResultService,
    private readonly cognitiveProfileRepo: ICognitiveProfileRepository,
    private readonly teacherStrategyRepo: ITeacherStrategyRepository,
  ) {}

  async composeForStudent(studentId: number): Promise<StudentUnderstanding> {
    const result = await this.passResultService.getLatestResult(studentId);
    const analysis = this.passResultService.buildAnalysis(result);

    const priorityDomain = analysis.priorityDomain as PassDomain | null;
    if (!priorityDomain) {
      throw new NotFoundError(
        '우선훈련영역(priority_domain)',
        '이 학생의 pass_profile에 priority_domain이 없어 학생 이해하기 화면을 구성할 수 없습니다.',
      );
    }

    const cognitiveProfile = await this.cognitiveProfileRepo.resolveFromScores({
      planning: result.planning,
      attention: result.attention,
      simultaneous: result.simultaneous,
      successive: result.successive,
    });
    const profileCode =
      `${cognitiveProfile.planningLevel}${cognitiveProfile.attentionLevel}` +
      `${cognitiveProfile.simultaneousLevel}${cognitiveProfile.successiveLevel}`;

    const strategy = await this.teacherStrategyRepo.findByDomain(priorityDomain);
    if (!strategy) {
      throw new NotFoundError(
        '교사 전략 라이브러리',
        `priority_domain=${priorityDomain}에 대한 home_ai_teacher_strategy 데이터가 없습니다. (라이브러리 확장 필요)`,
      );
    }

    return {
      studentId,
      profileCode,
      priorityDomain,
      strengthDomain: analysis.strengthDomain as PassDomain | null,
      characteristic: strategy.characteristic,
      classroomBehavior: strategy.classroomBehavior,
      strengthUtilization: strategy.strengthUtilization,
      supportStrategy: strategy.supportStrategy,
      teacherQuestions: strategy.teacherQuestions,
      observationChecklist: strategy.observationChecklist,
      weeklyPlannerLink: { href: `/students/${studentId}`, label: '인지훈련 플래너로 연결' },
      cognitiveEmotionalProgramLink: {
        href: `/students/${studentId}/cognitive-emotional-training`,
        label: '인지+정서훈련으로 연결',
      },
    };
  }
}
