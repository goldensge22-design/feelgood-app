# domain/interfaces

현재 Home MVP는 도메인 서비스 인터페이스를 `domain/services/RecommendationService.ts`에
직접 두고 있어 이 폴더는 비어 있다. Repository 인터페이스는 `repositories/interfaces`에
있다. 향후 도메인 서비스가 늘어나 인터페이스 파일을 분리해야 할 때 사용할 자리로
남겨둔다(§5 폴더 구조를 임의로 삭제하지 않기 위함).
