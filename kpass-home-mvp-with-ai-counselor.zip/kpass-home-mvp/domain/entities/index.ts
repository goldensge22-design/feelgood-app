/**
 * 도메인 엔티티 타입.
 * DB 접근 기술(Kysely)과 독립적으로 서비스/컨트롤러 계층에서 사용하는 타입.
 * db/types.ts(Kysely 테이블 정의)와 필드 구성을 1:1로 맞추되, camelCase로 노출한다.
 */

export interface Student {
  studentId: number;
  organizationId: number;
  classId: number | null;
  name: string;
  birthDate: Date | null;
  grade: number | null;
}

export interface PassResult {
  resultId: number;
  studentId: number;
  planning: number;
  attention: number;
  simultaneous: number;
  successive: number;
  totalIndex: number;
  testedAt: Date;
}

export interface PassProfile {
  profileId: number;
  resultId: number;
  dominanceType: string | null;
  strengthDomain: string | null;
  priorityDomain: string | null;
  aiSummary: string | null;
}

export interface Activity {
  activityId: string;
  activityName: string;
  passDomain: string | null;
  environment: string | null;
  ageBand: string | null;
  level: number | null;
}

export interface Recommendation {
  recommendationId: number;
  studentId: number;
  resultId: number | null;
  activityId: string | null;
  reason: string | null;
  confidenceScore: number | null;
}

export interface DailyLearningPlan {
  planId: number;
  studentId: number;
  date: Date;
  environment: string | null;
  status: string | null;
}

export interface ActivityLog {
  logId: number;
  studentId: number;
  activityId: string;
  completedAt: Date;
  score: number | null;
  memo: string | null;
}

export interface GrowthReport {
  reportId: number;
  studentId: number;
  periodStart: Date;
  periodEnd: Date;
  summary: string | null;
  nextRecommendation: string | null;
}

export interface UserAccount {
  userId: number;
  organizationId: number;
  email: string;
  role: string;
  status: string;
}

/**
 * PASS Cognitive Training Library의 프로그램 1건.
 * Home AI / Teacher AI는 이 타입의 인스턴스만 화면에 노출한다 (런타임 생성 금지).
 */
export interface TrainingProgram {
  programId: string;
  programName: string;
  passDomain: 'PLANNING' | 'ATTENTION' | 'SIMULTANEOUS' | 'SUCCESSIVE';
  subCognitiveFunction: string;
  targetAge: string;
  recommendedUser: string | null;
  difficultyLevel: number;
  duration: string | null;
  groupSize: string | null;
  materials: string | null;
  trainingGoal: string | null;
  expectedCognitiveChange: string | null;
  expectedBehavioralChange: string | null;
  schoolChange: string | null;
  homeConnectionGoal: string | null;
  environment: string | null;
  safetyNotes: string | null;
  procedureIntro: string | null;
  procedureInstruction: string | null;
  procedureDemo: string | null;
  procedureActivity: string | null;
  procedureFeedback: string | null;
  teacherScriptIntro: string | null;
  teacherScriptActivity: string | null;
  teacherQuestions: string | null;
  encouragementScript: string | null;
  closingScript: string | null;
  observationChecklist: Record<string, string> | null;
  difficultyAdjustment: Record<string, string> | null;
  homeActivity5min: string | null;
  homeActivity10min: string | null;
  homeActivity15min: string | null;
  parentQuestion: string | null;
  parentFeedback: string | null;
  rewardRule: string | null;
  successRule: string | null;
  failRule: string | null;
  repeatRule: string | null;
  reassessment4week: string | null;
  reassessment8week: string | null;
  reassessment12week: string | null;
  caution: string | null;
  evidenceRefs: Array<{
    paperCode: string;
    evidenceLevel: 'direct_evidence' | 'indirect_evidence' | 'theoretical_evidence';
  }>;
  version: string;
  approvalStatus: 'draft_pending_review' | 'approved' | 'retired';
}

export interface CognitiveProfile81 {
  profileCode: string;
  planningLevel: 'H' | 'M' | 'L';
  attentionLevel: 'H' | 'M' | 'L';
  simultaneousLevel: 'H' | 'M' | 'L';
  successiveLevel: 'H' | 'M' | 'L';
  priorityDomain: string | null;
  strengthDomain: string | null;
}

export interface TrainingHistoryEntry {
  historyId: number;
  studentId: number;
  programId: string;
  performedAt: Date;
  successRate: number | null;
  outcome: 'SUCCESS' | 'PARTIAL' | 'FAIL' | null;
  passDomain: 'PLANNING' | 'ATTENTION' | 'SIMULTANEOUS' | 'SUCCESSIVE' | null;
  difficultyLevel: number | null;
}

export interface DifficultyLevelInfo {
  level: number;
  label: string | null;
  promoteThreshold: number;
  demoteThreshold: number;
}

export interface AgeBandInfo {
  ageCode: string;
  ageLabel: string;
  tool: string;
  minAge: number;
  maxAge: number;
}

/** Home AI = Weekly Planner AI. 대화형 챗봇이 아니며, 아래 엔티티만 다룬다. */
export interface WeeklyTrainingPlanItem {
  itemId: number;
  planId: number;
  programId: string;
  programName: string;
  passDomain: 'PLANNING' | 'ATTENTION' | 'SIMULTANEOUS' | 'SUCCESSIVE';
  dayIndex: number; // 1(월)~5(금)
  dayDate: Date;
  orderInDay: number;
  trainingGoal: string;
  duration: string | null;
  parentGuidance: string;
  isSupplementary: boolean;
  isCompleted: boolean;
  completedAt: Date | null;
}

export interface WeeklyTrainingPlan {
  planId: number;
  studentId: number;
  resultId: number;
  profileCode: string;
  ageCode: string;
  weekStartDate: Date;
  weekEndDate: Date;
  status: 'ACTIVE' | 'COMPLETED' | 'ARCHIVED';
  domainWeights: Record<string, number>;
  items: WeeklyTrainingPlanItem[];
}

export interface HomeTrainingLogEntry {
  logId: number;
  itemId: number;
  studentId: number;
  successRate: number;
  outcome: 'SUCCESS' | 'PARTIAL' | 'FAIL';
  parentMemo: string | null;
  childReaction: string | null;
  loggedAt: Date;
}

/**
 * Home AI 상담사(AI Coach) 도메인.
 *
 * 원칙: 결과지(요약보기 · 인지훈련 플래너 · 인지+정서훈련 프로그램)는 그대로
 * 유지되는 기존 기능이며, Home AI 상담사는 그 세 기능을 "연결"하는 Hub이다.
 * ① 부모가 이해하기 쉽게 설명 / ② 학생 이해하기 는 아래 콘텐츠 라이브러리와
 * 81 Cognitive Profile, PASS Cognitive Training Library만 조합해 구성하며
 * 어떤 텍스트도 런타임에 새로 생성하지 않는다.
 * ③ 부모 AI 상담 / ④ 교사 AI 상담 만 생성형 AI(HomeAiCounselorChatService)를
 * 사용하며, 항상 기존 인지훈련 플래너 또는 인지+정서훈련 프로그램으로 연결한다.
 */
export type PassDomain = 'PLANNING' | 'ATTENTION' | 'SIMULTANEOUS' | 'SUCCESSIVE';

export interface ParentFaqEntry {
  faqId: string;
  priorityDomain: PassDomain | null;
  question: string;
  answer: string;
}

export interface ParentLifeCase {
  caseId: string;
  priorityDomain: PassDomain;
  childDescription: string;
  schoolBehavior: string;
  homeBehavior: string;
  parentGuidance: string;
}

export interface AvoidPhraseEntry {
  phraseId: string;
  priorityDomain: PassDomain;
  phrase: string;
  why: string;
  insteadSay: string;
}

export interface TeacherStrategyTemplate {
  templateId: string;
  priorityDomain: PassDomain;
  characteristic: string;
  classroomBehavior: string;
  strengthUtilization: string;
  supportStrategy: string;
  teacherQuestions: string[];
  observationChecklist: string[];
}

/** ① 부모가 이해하기 쉽게 설명 — 결과지를 부모의 언어로 번역한 화면 */
export interface ParentExplanation {
  studentId: number;
  profileCode: string;
  priorityDomain: PassDomain | null;
  strengthDomain: PassDomain | null;
  childDescription: string;
  schoolBehavior: string;
  homeBehavior: string;
  parentGuidance: string;
  avoidPhrases: AvoidPhraseEntry[];
  faqs: ParentFaqEntry[];
  weeklyPlannerLink: { href: string; label: string };
  cognitiveEmotionalProgramLink: { href: string; label: string };
}

/** ① 학생 이해하기 — 교사용 결과지 번역 화면 */
export interface StudentUnderstanding {
  studentId: number;
  profileCode: string;
  priorityDomain: PassDomain | null;
  strengthDomain: PassDomain | null;
  characteristic: string;
  classroomBehavior: string;
  strengthUtilization: string;
  supportStrategy: string;
  teacherQuestions: string[];
  observationChecklist: string[];
  weeklyPlannerLink: { href: string; label: string };
  cognitiveEmotionalProgramLink: { href: string; label: string };
}

export type HomeAiAudience = 'PARENT' | 'TEACHER';

export interface HomeAiChatLog {
  logId: number;
  studentId: number;
  requestedByUserId: number;
  audience: HomeAiAudience;
  userMessage: string;
  aiResponse: string;
  linkedProgramId: string | null;
  createdAt: Date;
}

export interface HomeAiChatResult {
  reply: string;
  linkedProgramId: string | null;
  weeklyPlannerLink: { href: string; label: string };
  cognitiveEmotionalProgramLink: { href: string; label: string };
  remainingToday: number;
  dailyLimit: number;
}

export interface MonthlyReport {
  reportId: number;
  studentId: number;
  reportMonth: string; // 'YYYY-MM'
  domainChange: Record<string, { week1Avg: number | null; week4Avg: number | null; delta: number | null }>;
  completionRate: number;
  strengthMaintained: string[];
  weaknessProgress: { domain: string | null; improvementRate: number | null };
  nextMonthRecommendation: string;
  generatedAt: Date;
}
