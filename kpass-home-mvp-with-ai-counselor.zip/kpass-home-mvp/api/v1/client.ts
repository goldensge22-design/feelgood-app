'use client';

import { ApiErrorResponse, ApiResponse } from '@/shared/response/ApiResponse';

const BASE_URL = '/api/v1';

export class ApiClientError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly httpStatus: number,
  ) {
    super(message);
    this.name = 'ApiClientError';
  }
}

function getStoredAccessToken(): string | null {
  if (typeof window === 'undefined') return null;
  return window.localStorage.getItem('kpass_access_token');
}

async function request<T>(
  path: string,
  options: RequestInit = {},
  withAuth = true,
): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (withAuth) {
    const token = getStoredAccessToken();
    if (token) headers.Authorization = `Bearer ${token}`;
  }

  const res = await fetch(`${BASE_URL}${path}`, { ...options, headers });

  if (res.headers.get('content-type')?.includes('application/pdf')) {
    // PDF 등 바이너리 응답은 호출부에서 별도 처리
    return (await res.blob()) as unknown as T;
  }

  const body = (await res.json()) as ApiResponse<T>;

  if (!body.success) {
    const errBody = (body as ApiErrorResponse).error;
    throw new ApiClientError(errBody.code, errBody.message, res.status);
  }

  return body.data;
}

export const apiClient = {
  get: <T>(path: string) => request<T>(path, { method: 'GET' }),
  post: <T>(path: string, data?: unknown, withAuth = true) =>
    request<T>(path, { method: 'POST', body: data ? JSON.stringify(data) : undefined }, withAuth),
  patch: <T>(path: string, data?: unknown) =>
    request<T>(path, { method: 'PATCH', body: data ? JSON.stringify(data) : undefined }),
  postNoAuth: <T>(path: string, data?: unknown) =>
    request<T>(path, { method: 'POST', body: data ? JSON.stringify(data) : undefined }, false),
};

export async function downloadPdf(path: string): Promise<Blob> {
  const token = getStoredAccessToken();
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  });
  if (!res.ok) {
    throw new ApiClientError('DOWNLOAD_FAILED', 'PDF 다운로드에 실패했습니다.', res.status);
  }
  return res.blob();
}
