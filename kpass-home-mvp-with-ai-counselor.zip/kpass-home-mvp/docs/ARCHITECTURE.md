# Architecture

## 스택
- **Framework**: Next.js 14 (App Router) — 지시서 §5 폴더 구조(`app/`, `components/`,
  `features/`, `services/`, `repositories/`, `api/`, `domain/`, `shared/`,
  `assets/`, `tests/`, `docs/`)와 자연스럽게 대응.
- **언어**: TypeScript strict mode
- **DB**: PostgreSQL + Kysely(순수 TS SQL 빌더, 네이티브 바이너리 불필요)
- **인증**: JWT (Access/Refresh), RBAC 미들웨어(`shared/middleware/withAuth.ts`)
- **PDF**: pdf-lib + fontkit (Noto Sans KR 임베딩)
- **API 문서화**: OpenAPI 3.0 정적 스펙 + Swagger UI (`/docs`)
- **테스트**: Jest (unit + integration)

## 레이어 구조 (Clean Architecture)

```
app/api/v1/**        → HTTP 진입점(Route Handler). 인증·검증만 담당, 로직 없음.
  ↓
services/**           → 애플리케이션 서비스(비즈니스 유스케이스). Repository/도메인
                         서비스 인터페이스에만 의존.
  ↓
domain/**              → 순수 도메인 규칙(엔티티 타입, RecommendationService 인터페이스,
                          Mock 데이터). 프레임워크/DB 비의존.
  ↓
repositories/**         → interfaces(포트) + kysely(어댑터). DB 접근은 이 계층에만 존재.
  ↓
db/**                   → SQL 마이그레이션 + Kysely 테이블 타입(스키마 단일 진실 공급원)
```

의존성 방향은 항상 `app → services → domain → repositories(interfaces)`이며,
구체 구현(Kysely, JWT 등)은 `shared/config/container.ts` 한 곳에서만 조립된다
(의존성 역전, 지시서 §10 DI).

## RecommendationService 의존성 역전 (정책 #4)

```
domain/services/RecommendationService.ts      (interface)
        ↑ implements
services/recommendation/PlaceholderRecommendationService.ts
        ↑ uses (Mock Data)
domain/services/mock/round4HomeEditionMock.ts
```

향후 실제 AI 엔진이 준비되면 `RealRecommendationService`를 같은 인터페이스로
구현하고 `shared/config/container.ts`의 한 줄만 교체하면 된다. 서비스/API
계층은 전혀 수정할 필요가 없다.

## 인증 흐름

1. `POST /api/v1/auth/login` → `AuthService.login()` → `UserAccountRepository`로
   이메일 조회 → `CredentialVerifier`(Placeholder, TODO(DB-001)) → JWT 발급
2. 이후 모든 Home API는 `withAuth()` 래퍼로 보호되며, `role`이 `PARENT`/`STUDENT`가
   아니면 403 (정책 #1: Teacher/Admin 완전 배제)

## 부모-자녀 데이터 접근 통제 (TODO(DB-002))

`organization_id`를 가족 단위 키로 사용한다. 모든 학생 조회 API는
`StudentService.getStudentOrThrow(studentId, auth.organizationId)`를 거쳐,
JWT의 organizationId와 studentId의 organization_id가 일치하는지 검증한다
(다른 가족의 학생 데이터 접근 차단).

## 오류 처리 (지시서 §11)

모든 API Route Handler는 `withAuth()`(인증 필요 시) 또는 개별 try/catch를 통해
`shared/errors/handleApiError.ts`로 수렴한다. `AppError` 하위 클래스만 클라이언트에
code/message를 노출하며, 예상치 못한 예외는 스택트레이스 없이
"일시적인 오류가 발생했습니다"로 마스킹된다.

## 왜 Prisma가 아닌 Kysely인가

`docs/ASSUMPTIONS_AND_TODOS.md`의 "ORM 선택" 항목 참고. 결론적으로 네이티브
엔진 바이너리 다운로드가 전혀 없어 오프라인/제한된 네트워크 환경을 포함한
모든 환경에서 빌드가 보장된다.
