# 가정/TODO 로그 (ASSUMPTIONS & TODOs)

이 문서는 6개 원본 문서(ERD, 기능명세서, 디자인 시스템, UI Flow, Research Framework
Round3C, Round4)에 없는 내용을 구현하며 남긴 모든 판단 지점을 기록한다.
지시서 §8 "질문하지 않는다. 추정하지 않는다. 문서에 없는 내용은 TODO와
Placeholder를 사용한다"에 따라, 모르는 것을 임의로 채우지 않고 아래처럼
명시적으로 표시했다.

## DB-001: 인증 credential 컬럼 없음
- **문제**: ERD `user_account` 테이블에 password_hash 등 인증 정보 컬럼이 없음.
- **처리**: `services/auth/CredentialVerifier.ts`에 Placeholder 검증(상태=ACTIVE +
  4자 이상이면 통과) 적용. 실제 배포 전 다음이 필요함:
  1. `user_account`에 `password_hash VARCHAR(255)` 컬럼 추가 마이그레이션 작성
  2. `bcryptjs`(이미 의존성에 포함됨, 현재 미사용)로 해시 비교 로직 교체
  3. 비밀번호 재설정/가입 플로우 추가 설계 필요(문서에 없음)

## DB-002: 부모-자녀 연결 테이블 없음 (parent_profile)
- **문제**: ERD Overview에 `parent_profile`이 언급되나 실제 필드 정의가 없음.
- **처리**: `organization(org_type='HOME')`을 "가족 단위"로 사용. 같은
  organization_id를 공유하는 `user_account(role='PARENT')`와 `student`를
  부모-자녀 관계로 간주(`db/migrations/0001_init.sql`, `StudentService` 참고).
- **한계**: 이혼 가정, 조부모 보호자 등 다대다 관계는 표현 불가. 실제 서비스
  전 별도 `parent_student_map` 같은 테이블 설계가 필요하며, 이는 ERD 변경이므로
  기획 확인 후 진행해야 한다.

## DB-003: reassessment 테이블 없음
- **문제**: GR-005(재검사 시점 추천), Round4 GM-0004에 재검사 로직이 언급되나
  ERD에 저장 테이블이 없음.
- **처리**: `growth_report.next_recommendation` 텍스트 필드에 안내 문구만 저장.
  스케줄링/알림 발송 기능은 구현하지 않음(`GrowthReportService.reassessmentNote`).

## MOCK-001: PASS 4개 영역당 Round4 예시 활동이 1개뿐
- **문제**: `06_Home_Edition` 시트에 PLANNING/ATTENTION/SIMULTANEOUS/SUCCESSIVE
  각 1건씩, 총 4건만 존재. "오늘의 활동 3개"를 매일 다르게 제공할 수 없음.
- **처리**: `PlaceholderRecommendationService`가 같은 4건을 항상 반환(정책 #5
  Mock Data 취급 명시, `isMock: true`). 실제 서비스 전 활동 라이브러리 확충 필요.

## MOCK-002: 신뢰도(confidence) 산출 공식 없음
- **문제**: `recommendation.confidence_score`, XAI-006에 필드는 있으나 계산식이
  문서에 없음.
- **처리**: Placeholder로 항상 `0` 반환 (`round4HomeEditionMock.ts`
  `toRecommendationOutput`). 실제 알고리즘은 정책 #4에 따라 구현 금지 대상이기도 함.

## API-001: 표준 Response/ErrorResponse 스키마 없음
- **문제**: 지시서 §7에 "표준 응답 사용"만 명시, 스키마 정의 없음.
- **처리**: `shared/response/ApiResponse.ts`에 `{ success, data }` /
  `{ success:false, error:{code,message} }` 형태로 확정. REST 업계 관례를 따름.

## HOME-006 / HOME-PLAN-004w: 주간 미션 · 4주 계획 로직 없음
- **문제**: Round4 Home Edition에 "주간 미션", "4주 계획"이 언급되나 반복
  스케줄링 로직/저장 구조가 없고, ERD에도 주/월 단위 테이블이 없음
  (`daily_learning_plan`은 일 단위만 존재).
- **처리**: `HomeDashboardService`가 안내 문구만 반환. 실제 반복 스케줄 기능은
  구현하지 않음.

## PDF-001: 결과지 정식 레이아웃 디자인 없음
- **문제**: UI Flow에 "결과지 출력" 언급만 있고 실제 PDF 레이아웃 디자인이 없음.
- **처리**: `ReportPdfService`가 Design System 컬러 토큰만 반영한 기본 1페이지
  레이아웃으로 구현. 정식 디자인 확정 시 좌표만 교체하면 되도록 섹션 함수로 분리함.
- **폰트**: Noto Sans KR(OFL 라이선스, Google Fonts 배포)을 `assets/fonts/`에
  포함하여 한글이 깨지지 않도록 임베딩함. 폰트 파일이 없을 경우 StandardFonts로
  폴백하며, 이 경우 한글이 렌더링되지 않으므로 배포 전 폰트 파일 존재를 반드시 확인.

## SCOPE-001: UI Flow의 Admin MVP 화면은 완전히 제외
- **문제**: `KPASS_UI_Flow_v1_1.pptx` Slide 12 MVP Screen List에 "Admin AI
  맞춤학습 메인"이 포함되어 있었음(1차 분석 보고서 §1 참고).
- **처리**: 정책 #1/#2에 따라 Admin 관련 화면·API·서비스는 이 프로젝트에 전혀
  포함하지 않음. Home MVP 완료 후 별도 프로젝트에서 다룰 것.

## ORM 선택: Prisma → Kysely 전환
- **문제**: 이 개발 환경의 네트워크 정책상 Prisma의 쿼리/스키마 엔진 바이너리
  다운로드 도메인(binaries.prisma.sh)에 접근할 수 없어 `prisma generate`/
  `next build` 검증이 불가능했음.
- **처리**: 순수 TypeScript 기반 SQL 빌더인 Kysely + `pg` 드라이버로 교체.
  네이티브 바이너리 다운로드가 전혀 없어 어떤 네트워크 환경에서도 빌드가
  보장된다. Repository 인터페이스(`repositories/interfaces`)는 애초에 ORM을
  캡슐화하도록 설계되어 있었으므로, 이 교체가 서비스/도메인 계층에는 영향을
  주지 않았다. `db/migrations/0001_init.sql`이 ERD를 그대로 반영한 단일 진실
  공급원(source of truth)이다.
