# PASS Cognitive Training Library — 리팩토링 아키텍처 (Phase 1)

이 문서는 기존 `docs/ARCHITECTURE.md`(Clean Architecture 레이어 구조)를 대체하지 않고,
그 위에 얹히는 **PASS Cognitive Training Library 리팩토링**을 설명한다.

## 0. 무엇이 바뀌었나 (요약)

| 이전 | 이후 |
|---|---|
| `activity` 테이블(요약형, 필드 5개) | `pass_training_program`(56개 필드, Manual v1.0 전체 반영) |
| `PlaceholderRecommendationService` (Mock, `isMock: true` 고정) | `LibraryRecommendationService` (Library 기반 실제 선택, `isMock: false`) |
| Home AI만 존재, Teacher AI 없음 | Home AI + Teacher AI(개인/그룹/학급) 모두 동일 엔진 공유 |
| 추천 로직이 무엇을 근거로 하는지 코드에 명시 안 됨 | 81 Profile x Age x Difficulty x History x Weakness/Strength 로 문서화 |

## 1. 파이프라인

```mermaid
flowchart LR
  A[PASS Assessment\nK-PASS / D-CAS] --> B[AI Brain Analysis\nPassResultService.buildAnalysis]
  B --> C[(PASS Cognitive Training Library\npass_training_program, 400건)]
  B --> D[Program Recommendation Engine\nLibraryRecommendationService]
  C --> D
  D --> E[Home AI\nHomeDashboardService]
  D --> F[Teacher AI\nTeacherDashboardService]
  E --> G[부모 화면]
  F --> H[교사 화면: 학생별/그룹별/학급별]
```

**핵심 불변 조건**: `Program Recommendation Engine`은 C(Library)에서만 읽는다. Home AI/Teacher AI는
Engine의 출력(`RecommendationOutput`)만 렌더링하며, 절대 자체적으로 프로그램 텍스트를 만들지 않는다.
이 조건은 `LibraryRecommendationService`가 `RecommendationInput`을 받아 후보가 0건이면 즉시 예외를
던지도록 구현되어 있다(런타임 생성으로 대체 금지 — `tests/unit/LibraryRecommendationService.test.ts` 참고).

## 2. ERD (추가/변경된 테이블만)

```mermaid
erDiagram
  PASS_TRAINING_PROGRAM ||--o{ PROGRAM_REFERENCE_PAPER : "근거 논문"
  RESEARCH_PAPER ||--o{ PROGRAM_REFERENCE_PAPER : "paper_code"
  STUDENT ||--o{ TRAINING_HISTORY : "수행 이력"
  PASS_TRAINING_PROGRAM ||--o{ TRAINING_HISTORY : "수행 대상"
  COGNITIVE_PROFILE_81 ||--o{ RECOMMENDATION : "프로파일 근거"
  PASS_TRAINING_PROGRAM ||--o{ RECOMMENDATION : "추천된 프로그램"
  AGE_BAND_MAPPING ||--o{ PASS_TRAINING_PROGRAM : "target_age 표준화"
  DIFFICULTY_MAPPING ||--o{ PASS_TRAINING_PROGRAM : "difficulty_level 임계값"

  PASS_TRAINING_PROGRAM {
    string program_id PK
    string pass_domain
    string sub_cognitive_function
    string target_age
    int difficulty_level
    string approval_status
  }
  PROGRAM_REFERENCE_PAPER {
    bigint id PK
    string program_id FK
    string paper_code FK
    string evidence_level
  }
  COGNITIVE_PROFILE_81 {
    string profile_code PK
    string planning_level
    string attention_level
    string simultaneous_level
    string successive_level
    string priority_domain
    string strength_domain
  }
  TRAINING_HISTORY {
    bigint history_id PK
    bigint student_id FK
    string program_id FK
    decimal success_rate
    string outcome
  }
```

## 3. 추천 시퀀스 (Teacher AI — 학생별 예시)

```mermaid
sequenceDiagram
  participant UI as TeacherRecommendationView
  participant API as /api/v1/teacher/students/{id}/recommendation
  participant TDS as TeacherDashboardService
  participant PRS as PassResultService
  participant ENG as LibraryRecommendationService
  participant REPO as TrainingProgramRepository
  participant DB as pass_training_program (Library)

  UI->>API: GET ?ageBand=8-10
  API->>TDS: getStudentRecommendation(studentId, ageBand)
  TDS->>PRS: getLatestResult(studentId)
  PRS-->>TDS: PassResult(4개 표준점수)
  TDS->>ENG: recommendForDomain(input)
  ENG->>ENG: resolveFromScores -> 81 Profile 코드
  ENG->>ENG: resolveDifficulty (History 기반 승급/강등)
  ENG->>REPO: findCandidates(domain, age, difficulty)
  REPO->>DB: SELECT ... WHERE domain/age/difficulty
  DB-->>REPO: TrainingProgram[]
  REPO-->>ENG: TrainingProgram[]
  ENG->>ENG: 최근 이력 제외 + sub_function 로테이션 선택
  ENG-->>TDS: RecommendationOutput (isMock=false)
  TDS-->>API: StudentRecommendationCard
  API-->>UI: 200 OK
```

## 4. 확장성 (400 → 600 → 1000 → 2000)

- 스키마는 이미 `pass_domain / target_age / difficulty_level` 인덱스로 조회하므로,
  신규 프로그램은 `db/seed-data/*.json`에 행을 추가하고 `db/seedTrainingLibrary.ts`를
  재실행하는 것만으로 반영된다.
- `LibraryRecommendationService`, `TrainingProgramRepository`, JSON Schema,
  API 계약(`RecommendationOutput`) 중 어느 것도 프로그램 개수에 의존하지 않는다.
- 새 PASS 하위영역이나 연령대를 추가하려면 `age_band_mapping` / 프로그램 데이터에만
  행을 추가하면 되고, 서비스 코드 변경은 필요 없다(단, `pass_domain` 4종 자체를
  늘리는 것은 PASS 이론 범위를 벗어나므로 별도 설계 검토가 필요하다).

## 5. 이번 리팩토링에서 완료한 것 (Phase 1)

1. `PASS_Theory_100_Key_Papers.xlsx` → `db/seed-data/research_papers_100.json` 변환
2. `PASS_Cognitive_Training_Standard_Manual_v1.0.docx` 템플릿의 전 필드를 반영한
   `pass_training_program` 스키마 설계 + JSON Schema(`schemas/pass_training_program.schema.json`)
3. 400개 프로그램 생성기(`generate_library.py`) — Planning/Attention/Simultaneous/Successive
   각 100개, 연령 5구간 x 난이도 5단계 균형, 전 항목 근거논문 연결(direct/indirect/theoretical),
   중복 0건 (검증: `tests/unit/PassTrainingLibrary.integrity.test.ts`)
4. DB 마이그레이션(`0002_pass_training_library.sql`), Kysely 타입(`db/types.ts`),
   Repository(`TrainingProgramRepository.ts`), 81 Profile 매핑, Age/Difficulty 매핑,
   Training History 테이블
5. `LibraryRecommendationService` — 81 Profile x Age x Difficulty x History x
   Weakness/Strength 로 Library에서만 선택하는 실제 엔진. `PlaceholderRecommendationService`를
   DI 컨테이너에서 교체(`shared/config/container.ts`)
6. Teacher AI 신규 구축: `TeacherDashboardService`(개인/그룹/학급),
   API 라우트 2개, `TeacherRecommendationView` 화면, `/app/teacher/students/[studentId]`
7. Home AI는 인터페이스 재사용 설계 덕분에 **코드 변경 없이** 새 엔진으로 자동 전환됨
8. 단위 테스트 2종(엔진 로직 / 라이브러리 데이터 무결성)

## 6. Home AI = Weekly Planner AI (신규)

Home AI는 대화형 챗봇이 아니다. 검사 결과 -> 81 Cognitive Profile -> 주간 훈련 계획
자동 설계 -> 이행 기록 -> 다음 주 자동 재설계 -> 4주 월간 리포트, 이 파이프라인만
수행하며, Teacher AI와 동일한 `LibraryRecommendationService`를 통해서만
`pass_training_program`에서 훈련을 선택한다.

```mermaid
sequenceDiagram
  participant UI as WeeklyPlannerView
  participant API as POST /api/v1/home/plans/weekly
  participant WPS as WeeklyPlannerService
  participant PROF as CognitiveProfileRepository
  participant ENG as LibraryRecommendationService
  participant PLANREPO as HomeTrainingPlanRepository
  participant DB as pass_training_program (Library)

  UI->>API: studentId, weekStartDate(월요일)
  API->>WPS: generateWeeklyPlan(studentId, weekStartDate)
  WPS->>PROF: resolveFromScores(4개 표준점수)
  PROF-->>WPS: 81 Profile(priorityDomain, strengthDomain)
  WPS->>WPS: computeDomainWeights (약점多/강점少, 반복실패시 보조훈련 +1)
  WPS->>WPS: 가중 라운드로빈으로 10~15개 슬롯을 5일(2~3개/일)에 배분
  loop 슬롯마다
    WPS->>ENG: recommendForDomain(domain, age, excludeProgramIds)
    ENG->>DB: findCandidates(domain, age, difficulty)
    DB-->>ENG: TrainingProgram[]
    ENG-->>WPS: RecommendationOutput(programId 등)
  end
  WPS->>PLANREPO: create(plan + items 스냅샷)
  PLANREPO-->>WPS: WeeklyTrainingPlan
  WPS-->>API: WeeklyTrainingPlan
  API-->>UI: 201 Created
```

**다음 주 자동 재설계 규칙** (`computeDomainWeights` / `resolveDifficulty` 공용):
- 이행도 높음(성공률 ≥ `difficulty_mapping.promote_threshold`) → 해당 영역 다음 추천 시 난이도 +1
- 이행도 낮음(< `demote_threshold`) → 난이도 유지 또는 -1
- 특정 영역이 2주 연속(각 7일 버킷) 평균 성공률이 `demote_threshold` 미만 → 그 다음 주 계획에서
  해당 영역에 보조 훈련 세션 1개 추가(`is_supplementary=true`로 표시)

**API 5종**: `POST /api/v1/home/plans/weekly`, `GET /api/v1/home/plans/current`,
`PATCH /api/v1/home/plans/items/{itemId}/complete`, `POST /api/v1/home/reports/monthly`,
`GET /api/v1/home/reports/{month}` — 모두 `app/api/v1/home/**`에 구현.

**DB 4종**: `home_training_plan`, `home_training_plan_item`, `home_training_log`,
`home_monthly_report` — `0003_home_weekly_planner.sql`. 어떤 테이블도 `activity`를
참조하지 않으며, `home_training_plan_item.program_id`는 항상 `pass_training_program`을
참조한다(라이브러리 변경에 영향받지 않도록 goal/duration/guidance는 생성 시점 스냅샷으로 저장).

## 7. Phase 2 로드맵 (갱신 — Weekly Planner 반영 후)

- [x] **age_code 정확 계산**: `student.birthDate` 기반 `calculateAgeInYears` + `age_band_mapping` 조회로 교체 완료(더 이상 하드코딩 없음)
- [x] **difficulty_mapping 테이블 실사용**: `LibraryRecommendationService.resolveDifficulty`와 `WeeklyPlannerService.hasRepeatedFailure` 모두 실제 테이블 조회로 승급/강등/보조훈련 판단
- [x] **training_history 영역별 조회**: `pass_domain`/`difficulty_level` 컬럼 추가, `listRecentByStudentAndDomain`으로 도메인별 정확한 이력 기반 난이도 조정
- [x] **Home AI = Weekly Planner AI 구현**: `home_training_plan/_item/_log`, `home_monthly_report` 4개 테이블, `WeeklyPlannerService`, API 5종, UI 2종 완료
- [ ] **DB 실제 연결 검증**: `npm install && npm run db:migrate && npm run db:seed:library && npm test` 로컬 실행 검증 (이 환경엔 Node/Postgres가 없어 최종 실행 확인은 못함)
- [ ] **TEACHER 역할/인증 실제 발급**: 라우트는 `['TEACHER']`로 막아뒀으나 계정 발급/조직 스코프 검증은 별도 구현 필요
- [ ] **activity/activity_evidence_map 완전 제거**: `0004_drop_legacy_activity.sql`(모든 참조가 pass_training_program으로 이전 확인된 후 실행)
- [ ] **HomeDashboardService(일일 처방) 정리**: 하위호환용으로 남겨뒀으나, Home AI가 Weekly Planner로 재정의된 이상 실제로 필요 없다면 제거 검토
- [ ] **통합 테스트**: `tests/integration/`에 `/api/v1/home/plans/*`, `/api/v1/home/reports/*` e2e 테스트 추가
- [ ] **주간 계획 자동 갱신 스케줄러**: 현재는 부모가 "이번 주 계획 만들기" 버튼을 눌러야 생성됨. 매주 월요일 자동 생성(cron/Job)은 미구현
- [ ] **승인 워크플로**: `approval_status`가 전부 `draft_pending_review`로 시딩됨. 실제 서비스 반영 전 검토위원 승인 프로세스(Manual §15) 연결 필요
