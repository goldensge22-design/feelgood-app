# Architecture Review / Code Review / Refactoring / Performance

Home MVP 완료 후 진행한 최종 점검 기록.

## Architecture Review

- **레이어 분리**: `app/api` → `services` → `domain`/`repositories(interface)` →
  `repositories/kysely`(구현) 의존 방향이 일관되게 유지됨. 서비스 계층이
  Kysely/`pg`를 직접 import하지 않음(전부 Repository 인터페이스 경유) → DB
  구현체 교체가 서비스 코드에 영향 없음(실제로 Prisma→Kysely 전환 시 검증됨).
- **DI**: `shared/config/container.ts` 단일 조립 지점. 테스트에서 모든 서비스가
  인터페이스 mock으로 격리 가능함을 확인(unit test 6종 통과).
- **AI 경계**: `RecommendationService` 인터페이스가 `domain/`에 위치하고, 유일한
  구현체가 `PlaceholderRecommendationService`임을 코드 검색으로 재확인 —
  PASS 점수를 기반으로 한 조건 분기(if/switch)가 추천 로직 내부에 존재하지
  않음(정책 #4 위반 없음).
- **결론**: 구조적 결함 없음. 다음 확장(실제 AI 엔진, Teacher/Admin 모듈)이
  기존 레이어를 깨지 않고 추가될 수 있는 형태.

## Code Review

발견 및 조치한 항목:

1. **중복 에러 핸들링** — `activity-logs/route.ts` POST 핸들러가 `withAuth`
   내부 에러 처리와 별개로 자체 try/catch를 갖고 있어 중복이었음 → 제거,
   다른 라우트와 일관된 패턴으로 통일.
2. **취약한 self-referential 타입** — `PassResultRepository.attachProfile`이
   `ReturnType<typeof this.selectResult>`를 사용해 타입 추론이 깨지기 쉬웠음 →
   `Selectable<PassResultTable>` 명시 타입으로 교체.
3. **미사용 import** — `PlaceholderRecommendationService.ts`의
   `findHomeEditionByDomain` 미사용 → 제거(ESLint 경고 0건 확정).
4. **JWT 타입 캐스팅** — `jsonwebtoken`의 `expiresIn` 타입이 `string`이 아닌
   `number | StringValue`라 컴파일 에러 발생 → `SignOptions['expiresIn']`로
   명시적 캐스팅.
5. **Kysely 날짜 비교 타입 불일치** — `where('date', '=', string)`이 컬럼의
   select 타입(`Date`)과 맞지 않아 컴파일 에러 → 문자열 대신 `Date` 객체로 통일.

모든 항목 수정 후 `npm run typecheck` / `npm run lint` 0 error 0 warning 확인.

## Refactoring

- **ORM 교체 (Prisma → Kysely)**: 최대 규모 리팩토링. 네트워크 제약으로 Prisma
  엔진 바이너리를 받을 수 없어 빌드 검증이 불가능했던 문제를 근본적으로
  해결하기 위해, Repository 구현체만 교체(인터페이스·서비스·API 계층은 무변경).
  자세한 배경은 `docs/ASSUMPTIONS_AND_TODOS.md`의 "ORM 선택" 항목 참고.
- **DB 접근 단일화**: 모든 SQL은 `repositories/kysely/index.ts`에만 존재.
  서비스/도메인 계층에 SQL 문자열이나 테이블명이 노출되지 않음.

## Performance Optimization (지시서 §14: Lazy Loading / Pagination / Caching / N+1 방지)

- **N+1 방지**: `PassResultRepository`는 결과 1건 + 프로필 1건으로 총 2개
  쿼리만 실행(반복문 내 쿼리 없음). `HomeDashboardService`도 학생 1명당
  고정된 쿼리 수(결과 조회 1 + 추천 기록 1 + 일일계획 upsert 1)로 동작.
- **Pagination 대비**: `activity_log`, `recommendation`, `daily_learning_plan`,
  `pass_result`, `growth_report`의 `listByStudent` 계열 조회에 `LIMIT 50`을
  추가하여 이력이 누적되어도 응답이 무한정 커지지 않도록 함. 실제 페이지네이션
  (offset/cursor 파라미터)은 화면에 "더보기"가 필요해지는 시점에 추가하도록
  TODO로 남김 — 현재 화면(오늘의 처방, 최근 10건 표시)에서는 불필요.
- **인덱스**: `db/migrations/0001_init.sql`에 모든 FK 컬럼에 인덱스 생성
  (student_id, organization_id, activity_id 등) — 조회 패턴(학생별 조회)과 일치.
- **Lazy Loading**: `app/docs/page.tsx`의 Swagger UI는 `next/dynamic`으로
  `ssr:false` 지연 로딩되어 초기 번들에 포함되지 않음.
- **Caching**: 이 MVP 범위에서는 캐싱 대상(반복 조회 비용이 큰 연산)이
  없음 — Mock 데이터는 이미 메모리 상수라 캐싱 불필요. 실제 AI 엔진 연동 시
  추천 결과 캐싱 레이어 추가를 권장(TODO, 문서 없음이라 미구현).

## 최종 검증 결과

| 항목 | 결과 |
|---|---|
| `npm run typecheck` | 0 errors |
| `npm run lint` | 0 errors, 0 warnings |
| `npm test` | 16/16 passed |
| `npm run build` | 성공 (11개 라우트 생성) |
| 실제 PostgreSQL 대상 `db:migrate` + `db:seed` | 성공 |
| 실제 서버 기동 후 E2E curl 테스트 (로그인→학생선택→검사결과→AI분석→오늘의처방→활동기록→성장리포트→PDF) | 전부 200/201, PDF 한글 정상 렌더링 확인 |
| 미인증 접근 (`Authorization` 헤더 없음) | 401 반환 확인 (RBAC 동작) |
