# Home AI 상담사 (AI Coach)

이번 작업 범위: **K-PASS Home AI의 "AI 상담사"만** 구현했다. 오늘의 미션 / 주간
성장관리 / 월간 성장관리는 이번 범위에 포함되지 않는다(기존 기능 그대로 유지).

## 이 기능이 하는 일

Home AI 상담사는 새로운 훈련 기능이 아니라, **기존 결과지(요약보기 · 인지훈련
플래너 · 인지+정서훈련 프로그램)를 연결하는 Hub**다.

```
결과지 → Home AI → (학부모 | 선생님) → 설명/이해 → (필요 시) AI 상담
                                              ↓
                          인지훈련 플래너 / 인지+정서훈련 프로그램으로 연결
```

- **① 부모가 이해하기 쉽게 설명 / ① 학생 이해하기**: 생성형 AI를 사용하지 않는다.
  기존 결과지(`pass_profile`), 81 Cognitive Profile, 그리고 이번에 추가한
  콘텐츠 라이브러리(생활 사례 / 하면 안 되는 말 / FAQ / 교사 전략)를 **조합만**
  해서 보여준다.
- **② 부모 AI 상담 / ② 교사 AI 상담**: Home AI 상담사 안에서 **유일하게 생성형
  AI(Anthropic API)를 사용하는 부분**이다. 자유 질문에 답하되, 새 훈련을
  만들지 않도록 시스템 프롬프트로 강제하고, 답변 끝에 항상 인지훈련 플래너 또는
  인지+정서훈련 프로그램 링크를 포함한다. **하루 10회로 제한**된다
  (`HOME_AI_CHAT_DAILY_LIMIT`, `shared/constants/homeAiCounselor.ts`).

## 새로 추가된 것들

| 영역 | 파일 |
|---|---|
| DB 마이그레이션 | `db/migrations/0004_home_ai_counselor.sql` |
| 콘텐츠 시드 데이터 | `db/seed-data/home_ai_parent_faq.json`, `home_ai_parent_life_case.json`, `home_ai_avoid_phrases.json`, `home_ai_teacher_strategy.json` |
| 시드 스크립트 | `db/seedHomeAiCounselor.ts` (`npm run db:seed:homeai`) |
| 도메인 엔티티 | `domain/entities/index.ts` 하단 `Home AI 상담사` 섹션 |
| 비생성형 컴포저 | `domain/services/ParentExplanationComposerService.ts`, `StudentUnderstandingComposerService.ts` |
| 생성형 상담 서비스 | `services/home-ai/HomeAiCounselorChatService.ts` |
| Repository | `repositories/kysely/HomeAiCounselorRepository.ts` |
| API | `app/api/v1/students/[studentId]/home-ai/parent/{explanation,chat}`, `app/api/v1/teacher/students/[studentId]/home-ai/{understanding,chat}` |
| 화면 | `features/home-ai-counselor/**`, `app/students/[studentId]/home-ai/page.tsx`, `app/teacher/students/[studentId]/home-ai/page.tsx` |
| 진입 버튼 | `app/students/[studentId]/page.tsx`, `app/teacher/students/[studentId]/page.tsx` — 인지훈련 플래너/추천 바로 위 "🦉 Home AI" 버튼 |

## 실행 전 준비

```bash
npm run db:migrate        # 0004_home_ai_counselor.sql 포함 실행
npm run db:seed:homeai    # FAQ/생활사례/하면안되는말/교사전략 라이브러리 적재
```

`.env`에 다음을 추가해야 부모/교사 AI 상담(생성형 AI)이 동작한다. 없어도 나머지
화면(부모가 이해하기 쉽게 설명, 학생 이해하기, 인지훈련 플래너 등)은 정상 동작한다.

```
ANTHROPIC_API_KEY="..."
ANTHROPIC_MODEL="claude-sonnet-4-5"   # 필요 시 조직에서 사용하는 모델명으로 교체
```

## 실제 서비스(service.feel-good.io) 결과지와 연결하기

이 저장소는 K-PASS Home AI Teacher MVP(별도 Next.js 앱)이며, 실제 운영 중인
결과지 화면(우측 하단 마스코트 버튼 → 현재 "학습·진로 가이드")과는 별개
코드베이스다. 그 버튼/팝업을 "Home AI 상담사"로 교체하는 작업은 이 문서의
API 4종(`/home-ai/parent/explanation`, `/home-ai/parent/chat`,
`/home-ai/teacher/understanding`, `/home-ai/teacher/chat`)을 그대로 호출하거나,
`features/home-ai-counselor/**` 컴포넌트를 해당 프로젝트로 옮겨 붙이는 방식으로
개발자가 별도 진행한다. 이 문서와 코드가 그 작업의 참조 구현이다.

## 지켜진 원칙 (지시서 그대로)

- 요약보기 / 인지훈련 플래너 / 인지+정서훈련 프로그램 기존 기능은 전혀 수정하지
  않았다(코드도, 라우트도 그대로).
- 오늘의 미션 / 주간 성장관리 / 월간 성장관리는 이번 범위에서 건드리지 않았다.
- ①/① 화면은 어떤 텍스트도 런타임에 생성하지 않는다 — 항상 라이브러리 조합.
- ②/② 화면(생성형 AI)은 새 훈련을 만들지 않고, 항상 기존 인지훈련
  플래너/인지+정서훈련 프로그램으로 연결하도록 시스템 프롬프트에 강제한다.
- AI 사용량은 하루 10회로 제한되며, `home_ai_chat_log` 테이블이 유일한 근거다.
