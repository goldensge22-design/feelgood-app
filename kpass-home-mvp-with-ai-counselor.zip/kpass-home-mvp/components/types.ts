export interface PassProfileAnalysisDto {
  planning: { score: number; band: 'LOW' | 'MID' | 'HIGH' };
  attention: { score: number; band: 'LOW' | 'MID' | 'HIGH' };
  simultaneous: { score: number; band: 'LOW' | 'MID' | 'HIGH' };
  successive: { score: number; band: 'LOW' | 'MID' | 'HIGH' };
  totalIndex: number;
  priorityDomain: string | null;
  strengthDomain: string | null;
  dominanceType: string | null;
  aiSummary: string | null;
}

export interface RecommendationOutputDto {
  recommendation: string;
  reason: string;
  evidenceCode: string | null;
  evidenceLevel: number | null;
  confidence: number;
  programId: string | null;
  activityId: string | null;
  isMock: boolean;
}

export interface DailyPrescriptionDto {
  date: string;
  items: RecommendationOutputDto[];
  parentQuestion: string;
  parentPraise: string;
  lifePassMission: string;
  isMock: boolean;
}

export interface WeeklyTrainingPlanItemDto {
  itemId: number;
  planId: number;
  programId: string;
  programName: string;
  passDomain: 'PLANNING' | 'ATTENTION' | 'SIMULTANEOUS' | 'SUCCESSIVE';
  dayIndex: number;
  dayDate: string;
  orderInDay: number;
  trainingGoal: string;
  duration: string | null;
  parentGuidance: string;
  isSupplementary: boolean;
  isCompleted: boolean;
  completedAt: string | null;
}

export interface WeeklyTrainingPlanDto {
  planId: number;
  studentId: number;
  resultId: number;
  profileCode: string;
  ageCode: string;
  weekStartDate: string;
  weekEndDate: string;
  status: 'ACTIVE' | 'COMPLETED' | 'ARCHIVED';
  domainWeights: Record<string, number>;
  items: WeeklyTrainingPlanItemDto[];
}

export interface MonthlyReportDto {
  reportId: number;
  studentId: number;
  reportMonth: string;
  domainChange: Record<string, { week1Avg: number | null; week4Avg: number | null; delta: number | null }>;
  completionRate: number;
  strengthMaintained: string[];
  weaknessProgress: { domain: string | null; improvementRate: number | null };
  nextMonthRecommendation: string;
  generatedAt: string;
}

export interface StudentDto {
  studentId: number;
  name: string;
  grade: number | null;
  birthDate: string | null;
}

export interface ActivityLogDto {
  logId: number;
  studentId: number;
  activityId: string;
  completedAt: string;
  score: string | null;
  memo: string | null;
}

export interface GrowthDashboardDto {
  completionRate: number;
  recentLogs: ActivityLogDto[];
  latestReport: { reportId: number; summary: string; nextRecommendation: string } | null;
  reassessmentNote: string;
}

// ---------------------------------------------------------------------
// Home AI 상담사(AI Coach) DTO
// ---------------------------------------------------------------------
export type PassDomainDto = 'PLANNING' | 'ATTENTION' | 'SIMULTANEOUS' | 'SUCCESSIVE';

export interface LinkDto {
  href: string;
  label: string;
}

export interface ParentFaqEntryDto {
  faqId: string;
  priorityDomain: PassDomainDto | null;
  question: string;
  answer: string;
}

export interface AvoidPhraseEntryDto {
  phraseId: string;
  priorityDomain: PassDomainDto;
  phrase: string;
  why: string;
  insteadSay: string;
}

export interface ParentExplanationDto {
  studentId: number;
  profileCode: string;
  priorityDomain: PassDomainDto | null;
  strengthDomain: PassDomainDto | null;
  childDescription: string;
  schoolBehavior: string;
  homeBehavior: string;
  parentGuidance: string;
  avoidPhrases: AvoidPhraseEntryDto[];
  faqs: ParentFaqEntryDto[];
  weeklyPlannerLink: LinkDto;
  cognitiveEmotionalProgramLink: LinkDto;
}

export interface StudentUnderstandingDto {
  studentId: number;
  profileCode: string;
  priorityDomain: PassDomainDto | null;
  strengthDomain: PassDomainDto | null;
  characteristic: string;
  classroomBehavior: string;
  strengthUtilization: string;
  supportStrategy: string;
  teacherQuestions: string[];
  observationChecklist: string[];
  weeklyPlannerLink: LinkDto;
  cognitiveEmotionalProgramLink: LinkDto;
}

export interface HomeAiChatResultDto {
  reply: string;
  linkedProgramId: string | null;
  weeklyPlannerLink: LinkDto;
  cognitiveEmotionalProgramLink: LinkDto;
  remainingToday: number;
  dailyLimit: number;
}

export interface HomeAiChatMessage {
  role: 'user' | 'assistant';
  text: string;
}
