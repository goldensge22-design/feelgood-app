import { PassProfileAnalysisDto } from '@/components/types';

const DOMAIN_LABELS: Record<string, string> = {
  planning: 'Planning (계획)',
  attention: 'Attention (주의)',
  simultaneous: 'Simultaneous (동시처리)',
  successive: 'Successive (순차처리)',
};

const BAND_LABELS: Record<string, string> = { LOW: '낮음', MID: '중간', HIGH: '높음' };
const BAND_CLASS: Record<string, string> = {
  LOW: 'kp-badge kp-badge-low',
  MID: 'kp-badge kp-badge-mid',
  HIGH: 'kp-badge kp-badge-high',
};

export function PassProfileCard({ analysis }: { analysis: PassProfileAnalysisDto }): JSX.Element {
  const rows: Array<[keyof typeof DOMAIN_LABELS, { score: number; band: string }]> = [
    ['planning', analysis.planning],
    ['attention', analysis.attention],
    ['simultaneous', analysis.simultaneous],
    ['successive', analysis.successive],
  ];

  return (
    <div className="kp-card">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <strong>PASS 프로파일</strong>
        <span className="kp-caption">총지표 {analysis.totalIndex}</span>
      </div>
      <div style={{ marginTop: 12 }}>
        {rows.map(([key, d]) => (
          <div
            key={key}
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '8px 0',
              borderBottom: '1px solid var(--color-border)',
            }}
          >
            <span className="kp-caption" style={{ fontSize: 14, color: 'var(--color-text)' }}>
              {DOMAIN_LABELS[key]}
            </span>
            <span style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <span className="kp-caption">{d.score}점</span>
              <span className={BAND_CLASS[d.band]}>{BAND_LABELS[d.band]}</span>
            </span>
          </div>
        ))}
      </div>
      {analysis.priorityDomain ? (
        <p className="kp-caption" style={{ marginTop: 12 }}>
          우선훈련영역: <strong>{analysis.priorityDomain}</strong>
        </p>
      ) : null}
      {analysis.aiSummary ? <p style={{ marginTop: 8, fontSize: 14 }}>{analysis.aiSummary}</p> : null}
    </div>
  );
}
