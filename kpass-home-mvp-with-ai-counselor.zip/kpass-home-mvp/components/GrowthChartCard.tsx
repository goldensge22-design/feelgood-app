'use client';

import { RadarChart, PolarGrid, PolarAngleAxis, Radar, ResponsiveContainer } from 'recharts';
import { PassProfileAnalysisDto, GrowthDashboardDto } from '@/components/types';

interface Props {
  analysis: PassProfileAnalysisDto;
  growth: GrowthDashboardDto;
}

/**
 * Design System Slide 7 "Growth Components":
 * PASS Radar Chart / Activity Completion Bar / Weekly Progress / Reassessment Recommendation
 */
export function GrowthChartCard({ analysis, growth }: Props): JSX.Element {
  const radarData = [
    { domain: 'Planning', score: analysis.planning.score },
    { domain: 'Attention', score: analysis.attention.score },
    { domain: 'Simultaneous', score: analysis.simultaneous.score },
    { domain: 'Successive', score: analysis.successive.score },
  ];

  return (
    <div className="kp-card">
      <strong style={{ color: 'var(--color-secondary)' }}>PASS 영역 변화</strong>
      <div style={{ width: '100%', height: 220, marginTop: 8 }}>
        <ResponsiveContainer>
          <RadarChart data={radarData} outerRadius="75%">
            <PolarGrid />
            <PolarAngleAxis dataKey="domain" tick={{ fontSize: 11 }} />
            <Radar
              dataKey="score"
              stroke="var(--color-primary)"
              fill="var(--color-primary)"
              fillOpacity={0.35}
            />
          </RadarChart>
        </ResponsiveContainer>
      </div>

      <div style={{ marginTop: 12 }}>
        <p className="kp-caption">활동 수행률</p>
        <div
          style={{
            height: 10,
            borderRadius: 6,
            background: 'var(--color-border)',
            overflow: 'hidden',
            marginTop: 4,
          }}
        >
          <div
            style={{
              height: '100%',
              width: `${growth.completionRate}%`,
              background: 'var(--color-secondary)',
            }}
          />
        </div>
        <p style={{ marginTop: 4, fontSize: 13 }}>{growth.completionRate}%</p>
      </div>

      <div
        className="kp-card"
        style={{ background: 'var(--color-warning-yellow)', border: 'none', marginTop: 12, marginBottom: 0 }}
      >
        <p style={{ margin: 0, fontSize: 13 }}>{growth.reassessmentNote}</p>
      </div>
    </div>
  );
}
