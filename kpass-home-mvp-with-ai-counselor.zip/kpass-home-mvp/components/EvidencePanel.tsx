import { RecommendationOutputDto } from '@/components/types';

interface Props {
  item: RecommendationOutputDto | null;
  onClose: () => void;
}

/**
 * Design System Slide 6 "Evidence Panel"
 * 기본: 쉬운 추천 근거 / 상세: Evidence Code, 논문 수, 근거 수준, 대표 논문
 * 부모용 화면이므로 "쉬운 설명" 모드로 표시한다(§사용자별 표시 규칙).
 */
export function EvidencePanel({ item, onClose }: Props): JSX.Element | null {
  if (!item) return null;

  return (
    <div className="kp-modal-backdrop" onClick={onClose}>
      <div className="kp-modal-sheet" onClick={(e) => e.stopPropagation()}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h3 style={{ margin: 0, color: 'var(--color-primary)' }}>왜 추천했나요?</h3>
          <button
            className="kp-btn-ghost"
            style={{ border: 'none', background: 'none', fontSize: 18 }}
            onClick={onClose}
            type="button"
            aria-label="닫기"
          >
            ✕
          </button>
        </div>

        <p style={{ fontSize: 15, marginTop: 12 }}>{item.reason}</p>

        <div className="kp-card" style={{ background: 'var(--color-evidence-blue)', border: 'none' }}>
          <p className="kp-caption" style={{ marginBottom: 6 }}>근거 정보</p>
          <p style={{ margin: '4px 0' }}>
            Evidence Code: <strong>{item.evidenceCode ?? '미평가'}</strong>
          </p>
          <p style={{ margin: '4px 0' }}>
            근거 수준: <strong>{item.evidenceLevel ? '★'.repeat(item.evidenceLevel) : '미평가'}</strong>
          </p>
          {item.activityId ? (
            <p style={{ margin: '4px 0' }}>
              Activity Code: <strong>{item.activityId}</strong>
            </p>
          ) : null}
        </div>

        <p className="kp-caption" style={{ marginTop: 8 }}>
          ※ 이 추천은 Mock Data 기반 예시이며, 실제 검증된 최종 추천이 아닙니다.
        </p>

        <button className="kp-btn kp-btn-primary" style={{ marginTop: 12 }} onClick={onClose} type="button">
          확인
        </button>
      </div>
    </div>
  );
}
