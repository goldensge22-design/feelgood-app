import { RecommendationOutputDto } from '@/components/types';

interface Props {
  item: RecommendationOutputDto;
  onShowEvidence: (item: RecommendationOutputDto) => void;
  onStart: (item: RecommendationOutputDto) => void;
}

/**
 * Design System Slide 5 "AI Recommendation Card"
 * 상단: 추천 활동명 / 중단: 추천 이유 / 하단: PASS 영역·난이도·예상시간
 * 버튼: 시작하기 / 근거 보기 / 다음 추천
 */
export function AIRecommendationCard({ item, onShowEvidence, onStart }: Props): JSX.Element {
  return (
    <div className="kp-card">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <strong style={{ fontSize: 16 }}>{item.recommendation}</strong>
        {item.isMock ? <span className="kp-badge kp-badge-mock">AI 예시(Mock)</span> : null}
      </div>
      <p style={{ fontSize: 14, color: 'var(--color-text-muted)', margin: '8px 0' }}>{item.reason}</p>
      <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
        {item.evidenceLevel !== null ? (
          <span className="kp-badge">근거 {'★'.repeat(item.evidenceLevel)}</span>
        ) : null}
        {item.evidenceCode ? <span className="kp-badge">{item.evidenceCode}</span> : null}
      </div>
      <div style={{ display: 'flex', gap: 8 }}>
        <button className="kp-btn kp-btn-primary" onClick={() => onStart(item)} type="button">
          시작하기
        </button>
        <button className="kp-btn kp-btn-secondary" onClick={() => onShowEvidence(item)} type="button">
          근거 보기
        </button>
      </div>
    </div>
  );
}
