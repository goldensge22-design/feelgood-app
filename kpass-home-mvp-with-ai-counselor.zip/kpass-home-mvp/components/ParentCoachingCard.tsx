interface Props {
  parentQuestion: string;
  parentPraise: string;
  lifePassMission: string;
}

export function ParentCoachingCard({ parentQuestion, parentPraise, lifePassMission }: Props): JSX.Element {
  return (
    <div className="kp-card">
      <strong style={{ color: 'var(--color-secondary)' }}>인지훈련 부모 코칭</strong>
      <div style={{ marginTop: 10 }}>
        <p className="kp-caption">오늘의 인지훈련 부모 질문</p>
        <p style={{ margin: '4px 0 12px' }}>{parentQuestion}</p>
        <p className="kp-caption">칭찬 문장</p>
        <p style={{ margin: '4px 0 12px' }}>{parentPraise}</p>
        <p className="kp-caption">생활 속 PASS</p>
        <p style={{ margin: '4px 0' }}>{lifePassMission}</p>
      </div>
    </div>
  );
}
