import { ActivityLogDto } from '@/components/types';

export function ActivityCard({ log }: { log: ActivityLogDto }): JSX.Element {
  const dateStr = new Date(log.completedAt).toLocaleDateString('ko-KR');
  return (
    <div className="kp-card" style={{ marginBottom: 8 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <strong style={{ fontSize: 14 }}>인지훈련 · {log.activityId}</strong>
        <span className="kp-caption">{dateStr}</span>
      </div>
      <div style={{ marginTop: 6, display: 'flex', gap: 8, alignItems: 'center' }}>
        {log.score !== null ? <span className="kp-badge">인지훈련 수행률 {log.score}%</span> : null}
      </div>
      {log.memo ? <p style={{ marginTop: 6, fontSize: 13 }}>{log.memo}</p> : null}
    </div>
  );
}
