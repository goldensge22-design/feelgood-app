'use client';

import { useCallback, useEffect, useState } from 'react';
import { apiClient, ApiClientError } from '@/api/v1/client';

interface StudentRecommendationCardDto {
  studentId: number;
  studentName: string;
  passDomain: string;
  programId: string | null;
  programName: string;
  reason: string;
  evidenceLevel: number | null;
  confidence: number;
}

/**
 * Teacher AI 대시보드 - 학생별 탭.
 * Design System 원칙(AIRecommendationCard와 동일한 어휘)을 재사용하되,
 * 교사 화면 전용 레이아웃(학생 선택 + 근거 배지)을 사용한다.
 *
 * 데이터 흐름: 이 컴포넌트는 프로그램을 절대 직접 생성하지 않는다.
 * /api/v1/teacher/students/{id}/recommendation -> TeacherDashboardService ->
 * LibraryRecommendationService -> pass_training_program (Library) 순으로만 조회한다.
 */
export function TeacherRecommendationView({
  studentId,
  ageBand = '8-10',
}: {
  studentId: number;
  ageBand?: string;
}): JSX.Element {
  const [card, setCard] = useState<StudentRecommendationCardDto | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await apiClient.get<StudentRecommendationCardDto>(
        `/teacher/students/${studentId}/recommendation?ageBand=${ageBand}`,
      );
      setCard(data);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '추천을 불러오지 못했습니다.');
    } finally {
      setLoading(false);
    }
  }, [studentId, ageBand]);

  useEffect(() => {
    void load();
  }, [load]);

  if (loading) return <div className="kp-card">불러오는 중...</div>;
  if (error) return <div className="kp-card kp-badge-mock">{error}</div>;
  if (!card) return <div className="kp-card">추천 데이터가 없습니다.</div>;

  return (
    <div className="kp-card">
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <strong style={{ fontSize: 16 }}>{card.studentName}</strong>
        <span className="kp-badge">{card.passDomain}</span>
      </div>
      <p style={{ fontSize: 15, fontWeight: 600, margin: '8px 0 4px' }}>{card.programName}</p>
      <p style={{ fontSize: 14, color: 'var(--color-text-muted)' }}>{card.reason}</p>
      <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
        {card.evidenceLevel !== null ? (
          <span className="kp-badge">근거 {'★'.repeat(card.evidenceLevel)}</span>
        ) : null}
        <span className="kp-badge">신뢰도 {(card.confidence * 100).toFixed(0)}%</span>
        {card.programId ? <span className="kp-badge">{card.programId}</span> : null}
      </div>
    </div>
  );
}
