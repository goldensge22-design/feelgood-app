'use client';

import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { apiClient, ApiClientError, downloadPdf } from '@/api/v1/client';
import { PassProfileCard } from '@/components/PassProfileCard';
import { AIRecommendationCard } from '@/components/AIRecommendationCard';
import { EvidencePanel } from '@/components/EvidencePanel';
import { ParentCoachingCard } from '@/components/ParentCoachingCard';
import { DailyPrescriptionDto, PassProfileAnalysisDto, RecommendationOutputDto } from '@/components/types';

interface PassResultResponse {
  result: { resultId: number };
  analysis: PassProfileAnalysisDto;
}

export function HomeDashboard({ studentId }: { studentId: number }): JSX.Element {
  const [passResult, setPassResult] = useState<PassResultResponse | null>(null);
  const [dashboard, setDashboard] = useState<{ prescription: DailyPrescriptionDto } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [evidenceItem, setEvidenceItem] = useState<RecommendationOutputDto | null>(null);
  const [recordingId, setRecordingId] = useState<string | null>(null);
  const [downloadingPdf, setDownloadingPdf] = useState(false);

  const load = useCallback(async () => {
    setError(null);
    try {
      const [pr, hd] = await Promise.all([
        apiClient.get<PassResultResponse>(`/students/${studentId}/pass-result`),
        apiClient.get<{ prescription: DailyPrescriptionDto }>(
          `/students/${studentId}/home-dashboard`,
        ),
      ]);
      setPassResult(pr);
      setDashboard(hd);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '데이터를 불러오지 못했습니다.');
    }
  }, [studentId]);

  useEffect(() => {
    void load();
  }, [load]);

  const handleStart = async (item: RecommendationOutputDto): Promise<void> => {
    if (!item.activityId) return;
    setRecordingId(item.activityId);
    try {
      await apiClient.post(`/students/${studentId}/activity-logs`, {
        activityId: item.activityId,
        score: 100,
        memo: '가정에서 활동을 완료했습니다.',
      });
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '기록에 실패했습니다.');
    } finally {
      setRecordingId(null);
    }
  };

  const handleDownloadPdf = async (): Promise<void> => {
    setDownloadingPdf(true);
    try {
      const blob = await downloadPdf(`/students/${studentId}/report/pdf`);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `kpass_home_report_${studentId}.pdf`;
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'PDF 다운로드에 실패했습니다.');
    } finally {
      setDownloadingPdf(false);
    }
  };

  if (error) return <p className="kp-error-text">{error}</p>;
  if (!passResult || !dashboard) return <div className="kp-loading">불러오는 중...</div>;

  return (
    <div>
      <PassProfileCard analysis={passResult.analysis} />

      <div className="kp-section-title" style={{ padding: 0, marginTop: 8 }}>
        오늘의 인지훈련
      </div>
      {dashboard.prescription.items.map((item, idx) => (
        <AIRecommendationCard
          key={`${item.activityId ?? idx}`}
          item={item}
          onShowEvidence={setEvidenceItem}
          onStart={handleStart}
        />
      ))}
      {recordingId ? <p className="kp-caption">기록 저장 중...</p> : null}

      <ParentCoachingCard
        parentQuestion={dashboard.prescription.parentQuestion}
        parentPraise={dashboard.prescription.parentPraise}
        lifePassMission={dashboard.prescription.lifePassMission}
      />

      <button
        className="kp-btn kp-btn-secondary"
        type="button"
        onClick={handleDownloadPdf}
        disabled={downloadingPdf}
        style={{ marginBottom: 12 }}
      >
        {downloadingPdf ? 'PDF 생성 중...' : '결과지 PDF 다운로드'}
      </button>

      <Link href={`/students/${studentId}/growth`} className="kp-btn kp-btn-ghost" style={{ display: 'block', textAlign: 'center' }}>
        인지기능 성장 리포트 보기
      </Link>

      <EvidencePanel item={evidenceItem} onClose={() => setEvidenceItem(null)} />
    </div>
  );
}
