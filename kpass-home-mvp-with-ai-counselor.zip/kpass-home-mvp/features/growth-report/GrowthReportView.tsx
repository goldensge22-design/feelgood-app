'use client';

import { useEffect, useState } from 'react';
import { apiClient, ApiClientError } from '@/api/v1/client';
import { GrowthChartCard } from '@/components/GrowthChartCard';
import { ActivityCard } from '@/components/ActivityCard';
import { GrowthDashboardDto, PassProfileAnalysisDto } from '@/components/types';

export function GrowthReportView({ studentId }: { studentId: number }): JSX.Element {
  const [analysis, setAnalysis] = useState<PassProfileAnalysisDto | null>(null);
  const [growth, setGrowth] = useState<GrowthDashboardDto | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([
      apiClient.get<{ analysis: PassProfileAnalysisDto }>(`/students/${studentId}/pass-result`),
      apiClient.get<GrowthDashboardDto>(`/students/${studentId}/growth-report`),
    ])
      .then(([pr, gr]) => {
        setAnalysis(pr.analysis);
        setGrowth(gr);
      })
      .catch((err) => {
        setError(err instanceof ApiClientError ? err.message : '인지기능 성장 리포트를 불러오지 못했습니다.');
      });
  }, [studentId]);

  if (error) return <p className="kp-error-text">{error}</p>;
  if (!analysis || !growth) return <div className="kp-loading">불러오는 중...</div>;

  return (
    <div>
      <div className="kp-section-title" style={{ padding: 0 }}>
        인지기능 성장 리포트
      </div>

      <GrowthChartCard analysis={analysis} growth={growth} />

      <div className="kp-section-title" style={{ padding: 0, marginTop: 8 }}>
        최근 인지훈련 기록
      </div>
      {growth.recentLogs.length === 0 ? (
        <p className="kp-empty">아직 기록된 인지훈련이 없습니다.</p>
      ) : (
        growth.recentLogs.map((log) => <ActivityCard key={log.logId} log={log} />)
      )}
    </div>
  );
}
