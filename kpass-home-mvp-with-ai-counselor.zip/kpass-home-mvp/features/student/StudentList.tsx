'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { apiClient, ApiClientError } from '@/api/v1/client';
import { StudentDto } from '@/components/types';

export function StudentList(): JSX.Element {
  const [students, setStudents] = useState<StudentDto[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiClient
      .get<StudentDto[]>('/students')
      .then(setStudents)
      .catch((err) => {
        setError(err instanceof ApiClientError ? err.message : '학생 목록을 불러오지 못했습니다.');
      });
  }, []);

  if (error) return <p className="kp-error-text">{error}</p>;
  if (!students) return <div className="kp-loading">불러오는 중...</div>;
  if (students.length === 0) {
    return <p className="kp-empty">등록된 자녀 정보가 없습니다. 기관에 문의해주세요.</p>;
  }

  return (
    <div>
      {students.map((s) => (
        <Link
          key={s.studentId}
          href={`/students/${s.studentId}`}
          className="kp-student-tile"
          style={{ textDecoration: 'none', color: 'inherit' }}
        >
          <div>
            <strong>{s.name}</strong>
            <p className="kp-caption" style={{ margin: '4px 0 0' }}>
              {s.grade ? `${s.grade}학년` : '학년 정보 없음'}
            </p>
          </div>
          <span aria-hidden>›</span>
        </Link>
      ))}
    </div>
  );
}
