'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { apiClient, ApiClientError } from '@/api/v1/client';
import { StudentUnderstandingDto } from '@/components/types';

export function StudentUnderstandingView({ studentId }: { studentId: number }): JSX.Element {
  const [data, setData] = useState<StudentUnderstandingDto | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiClient
      .get<StudentUnderstandingDto>(`/teacher/students/${studentId}/home-ai/understanding`)
      .then(setData)
      .catch((err) => {
        setError(err instanceof ApiClientError ? err.message : '학생 이해하기 자료를 불러오지 못했습니다.');
      });
  }, [studentId]);

  if (error) return <p className="kp-error-text">{error}</p>;
  if (!data) return <div className="kp-loading">불러오는 중...</div>;

  return (
    <div>
      <div className="kp-card">
        <p className="kp-section-title" style={{ padding: 0 }}>
          학생 특징
        </p>
        <p>{data.characteristic}</p>
      </div>

      <div className="kp-card">
        <p className="kp-section-title" style={{ padding: 0 }}>
          수업에서 보이는 모습
        </p>
        <p>{data.classroomBehavior}</p>
      </div>

      <div className="kp-card">
        <p className="kp-section-title" style={{ padding: 0 }}>
          강점 활용
        </p>
        <p>{data.strengthUtilization}</p>
      </div>

      <div className="kp-card">
        <p className="kp-section-title" style={{ padding: 0 }}>
          보완 전략
        </p>
        <p>{data.supportStrategy}</p>
      </div>

      <div className="kp-card">
        <p className="kp-section-title" style={{ padding: 0 }}>
          교사용 발문
        </p>
        <ul style={{ paddingLeft: 20, margin: 0 }}>
          {data.teacherQuestions.map((q) => (
            <li key={q}>{q}</li>
          ))}
        </ul>
      </div>

      <div className="kp-card">
        <p className="kp-section-title" style={{ padding: 0 }}>
          관찰 체크리스트
        </p>
        <ul style={{ paddingLeft: 20, margin: 0 }}>
          {data.observationChecklist.map((c) => (
            <li key={c}>{c}</li>
          ))}
        </ul>
      </div>

      <div className="kp-card">
        <Link href={data.weeklyPlannerLink.href} className="kp-btn kp-btn-primary" style={{ marginBottom: 8 }}>
          {data.weeklyPlannerLink.label}
        </Link>
        <Link href={data.cognitiveEmotionalProgramLink.href} className="kp-btn kp-btn-secondary">
          {data.cognitiveEmotionalProgramLink.label}
        </Link>
      </div>
    </div>
  );
}
