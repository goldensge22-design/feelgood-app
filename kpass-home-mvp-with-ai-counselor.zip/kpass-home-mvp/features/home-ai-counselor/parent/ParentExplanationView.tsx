'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { apiClient, ApiClientError } from '@/api/v1/client';
import { ParentExplanationDto } from '@/components/types';

export function ParentExplanationView({ studentId }: { studentId: number }): JSX.Element {
  const [data, setData] = useState<ParentExplanationDto | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [openFaq, setOpenFaq] = useState<string | null>(null);

  useEffect(() => {
    apiClient
      .get<ParentExplanationDto>(`/students/${studentId}/home-ai/parent/explanation`)
      .then(setData)
      .catch((err) => {
        setError(err instanceof ApiClientError ? err.message : '설명을 불러오지 못했습니다.');
      });
  }, [studentId]);

  if (error) return <p className="kp-error-text">{error}</p>;
  if (!data) return <div className="kp-loading">불러오는 중...</div>;

  return (
    <div>
      <div className="kp-card">
        <p className="kp-section-title" style={{ padding: 0 }}>
          우리 아이는 어떤 아이인가요?
        </p>
        <p>{data.childDescription}</p>
      </div>

      <div className="kp-card">
        <p className="kp-section-title" style={{ padding: 0 }}>
          학교에서는 이렇게 보일 수 있습니다
        </p>
        <p>{data.schoolBehavior}</p>
      </div>

      <div className="kp-card">
        <p className="kp-section-title" style={{ padding: 0 }}>
          집에서는 이렇게 보일 수 있습니다
        </p>
        <p>{data.homeBehavior}</p>
      </div>

      <div className="kp-card">
        <p className="kp-section-title" style={{ padding: 0 }}>
          부모는 이렇게 도와주세요
        </p>
        <p>{data.parentGuidance}</p>
      </div>

      {data.avoidPhrases.length > 0 && (
        <div className="kp-card">
          <p className="kp-section-title" style={{ padding: 0 }}>
            하면 안 되는 말
          </p>
          {data.avoidPhrases.map((p) => (
            <div key={p.phraseId} style={{ marginBottom: 10 }}>
              <p style={{ margin: '0 0 4px', fontWeight: 600 }}>&ldquo;{p.phrase}&rdquo;</p>
              <p className="kp-caption" style={{ margin: '0 0 4px' }}>
                {p.why}
              </p>
              <p style={{ margin: 0 }}>대신 이렇게 말해보세요: {p.insteadSay}</p>
            </div>
          ))}
        </div>
      )}

      {data.faqs.length > 0 && (
        <div className="kp-card">
          <p className="kp-section-title" style={{ padding: 0 }}>
            부모들이 가장 많이 하는 질문
          </p>
          {data.faqs.map((f) => (
            <div key={f.faqId} style={{ marginBottom: 8 }}>
              <button
                type="button"
                className="kp-btn kp-btn-ghost"
                style={{ justifyContent: 'space-between' }}
                onClick={() => setOpenFaq(openFaq === f.faqId ? null : f.faqId)}
              >
                <span>{f.question}</span>
                <span aria-hidden>{openFaq === f.faqId ? '−' : '+'}</span>
              </button>
              {openFaq === f.faqId && (
                <p className="kp-caption" style={{ padding: '8px 4px 0' }}>
                  {f.answer}
                </p>
              )}
            </div>
          ))}
        </div>
      )}

      <div className="kp-card">
        <Link href={data.weeklyPlannerLink.href} className="kp-btn kp-btn-primary" style={{ marginBottom: 8 }}>
          {data.weeklyPlannerLink.label}
        </Link>
        <Link href={data.cognitiveEmotionalProgramLink.href} className="kp-btn kp-btn-secondary">
          {data.cognitiveEmotionalProgramLink.label}
        </Link>
      </div>
    </div>
  );
}
