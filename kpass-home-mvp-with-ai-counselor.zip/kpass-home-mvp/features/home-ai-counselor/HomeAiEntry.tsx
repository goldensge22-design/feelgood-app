'use client';

export interface HomeAiMenuItem {
  key: string;
  label: string;
  description: string;
  onSelect: () => void;
}

/**
 * Home AI 상담사 첫 화면.
 * "Home AI는 새로운 기능이 아니다 — 기존 결과지/인지훈련 플래너/인지+정서훈련
 * 프로그램을 연결하는 AI Hub이다"라는 지시서 원칙을 그대로 반영해, 이 화면
 * 자체는 아무 데이터도 불러오지 않고 다음 화면으로 안내만 한다.
 */
export function HomeAiEntry({ menuItems }: { menuItems: HomeAiMenuItem[] }): JSX.Element {
  return (
    <div>
      <div className="kp-card kp-homeai-greeting">
        <div className="kp-homeai-owl" aria-hidden>
          🦉
        </div>
        <p className="kp-homeai-greeting-text">
          안녕하세요.
          <br />
          검사 결과를 생활 속에서 어떻게 활용하면 좋은지 도와드리겠습니다.
        </p>
      </div>

      <div>
        {menuItems.map((item) => (
          <button
            key={item.key}
            type="button"
            className="kp-card kp-homeai-menu-item"
            onClick={item.onSelect}
          >
            <span className="kp-homeai-menu-label">{item.label}</span>
            <span className="kp-caption">{item.description}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
