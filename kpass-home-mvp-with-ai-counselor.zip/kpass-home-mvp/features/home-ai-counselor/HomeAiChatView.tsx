'use client';

import { useState } from 'react';
import Link from 'next/link';
import { apiClient, ApiClientError } from '@/api/v1/client';
import { HomeAiChatMessage, HomeAiChatResultDto } from '@/components/types';

export function HomeAiChatView({
  postPath,
  title,
  placeholder,
  examplePrompts,
}: {
  postPath: string;
  title: string;
  placeholder: string;
  examplePrompts: string[];
}): JSX.Element {
  const [messages, setMessages] = useState<HomeAiChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [links, setLinks] = useState<HomeAiChatResultDto | null>(null);
  const [remaining, setRemaining] = useState<{ used: number; limit: number } | null>(null);

  async function send(text: string): Promise<void> {
    const trimmed = text.trim();
    if (!trimmed || sending) return;

    setSending(true);
    setError(null);
    setMessages((prev) => [...prev, { role: 'user', text: trimmed }]);
    setInput('');

    try {
      const result = await apiClient.post<HomeAiChatResultDto>(postPath, { message: trimmed });
      setMessages((prev) => [...prev, { role: 'assistant', text: result.reply }]);
      setLinks(result);
      setRemaining({ used: result.dailyLimit - result.remainingToday, limit: result.dailyLimit });
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : 'AI 상담 중 오류가 발생했습니다.');
    } finally {
      setSending(false);
    }
  }

  return (
    <div>
      <div className="kp-section-title" style={{ padding: 0 }}>
        {title}
      </div>

      {remaining && (
        <p className="kp-caption" style={{ marginBottom: 8 }}>
          오늘 {remaining.used}/{remaining.limit}회 사용
        </p>
      )}

      {messages.length === 0 && (
        <div className="kp-card">
          <p className="kp-caption" style={{ marginBottom: 8 }}>
            이렇게 물어보실 수 있어요
          </p>
          {examplePrompts.map((p) => (
            <button
              key={p}
              type="button"
              className="kp-btn kp-btn-ghost"
              style={{ marginBottom: 8 }}
              onClick={() => send(p)}
              disabled={sending}
            >
              {p}
            </button>
          ))}
        </div>
      )}

      <div className="kp-homeai-chat-log">
        {messages.map((m, idx) => (
          <div
            key={idx}
            className={m.role === 'user' ? 'kp-homeai-bubble kp-homeai-bubble-user' : 'kp-homeai-bubble kp-homeai-bubble-ai'}
          >
            {m.text}
          </div>
        ))}
        {sending && <div className="kp-homeai-bubble kp-homeai-bubble-ai kp-caption">답변을 준비하고 있어요...</div>}
      </div>

      {error && <p className="kp-error-text">{error}</p>}

      {links && (
        <div className="kp-card">
          <Link href={links.weeklyPlannerLink.href} className="kp-btn kp-btn-secondary" style={{ marginBottom: 8 }}>
            {links.weeklyPlannerLink.label}
          </Link>
          <Link href={links.cognitiveEmotionalProgramLink.href} className="kp-btn kp-btn-ghost">
            {links.cognitiveEmotionalProgramLink.label}
          </Link>
        </div>
      )}

      <form
        onSubmit={(e) => {
          e.preventDefault();
          send(input);
        }}
        className="kp-homeai-chat-input-row"
      >
        <input
          className="kp-input"
          style={{ marginBottom: 0 }}
          placeholder={placeholder}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={sending}
          maxLength={500}
        />
        <button type="submit" className="kp-btn kp-btn-primary" disabled={sending || !input.trim()}>
          보내기
        </button>
      </form>
    </div>
  );
}
