'use client';

import { useCallback, useEffect, useState } from 'react';
import { apiClient, ApiClientError } from '@/api/v1/client';
import { MonthlyReportDto } from '@/components/types';

const DOMAIN_LABEL: Record<string, string> = {
  PLANNING: 'Planning(계획)',
  ATTENTION: 'Attention(주의)',
  SIMULTANEOUS: 'Simultaneous(동시처리)',
  SUCCESSIVE: 'Successive(순차처리)',
};

function currentMonth(): string {
  return new Date().toISOString().slice(0, 7);
}

export function MonthlyReportView({ studentId }: { studentId: number }): JSX.Element {
  const [month, setMonth] = useState(currentMonth());
  const [report, setReport] = useState<MonthlyReportDto | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await apiClient.get<MonthlyReportDto>(`/home/reports/${month}?studentId=${studentId}`);
      setReport(data);
    } catch (err) {
      if (err instanceof ApiClientError && err.httpStatus === 404) {
        setReport(null);
      } else {
        setError(err instanceof ApiClientError ? err.message : '리포트를 불러오지 못했습니다.');
      }
    } finally {
      setLoading(false);
    }
  }, [studentId, month]);

  useEffect(() => {
    void load();
  }, [load]);

  const handleGenerate = async (): Promise<void> => {
    setGenerating(true);
    setError(null);
    try {
      const data = await apiClient.post<MonthlyReportDto>('/home/reports/monthly', { studentId, month });
      setReport(data);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '리포트 생성에 실패했습니다.');
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="kp-card">
      <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 12 }}>
        <input type="month" value={month} onChange={(e) => setMonth(e.target.value)} />
        <button className="kp-btn kp-btn-primary" onClick={handleGenerate} disabled={generating} type="button">
          {generating ? '집계 중...' : '이번 달 리포트 생성/갱신'}
        </button>
      </div>

      {loading ? <p>불러오는 중...</p> : null}
      {error ? <p style={{ color: 'crimson' }}>{error}</p> : null}

      {report ? (
        <div>
          <p>
            <strong>이행률: {report.completionRate}%</strong>
          </p>
          <table style={{ width: '100%', fontSize: 13, marginBottom: 12 }}>
            <thead>
              <tr>
                <th align="left">영역</th>
                <th align="right">1주차 평균</th>
                <th align="right">4주차 평균</th>
                <th align="right">변화</th>
              </tr>
            </thead>
            <tbody>
              {Object.entries(report.domainChange).map(([domain, change]) => (
                <tr key={domain}>
                  <td>{DOMAIN_LABEL[domain] ?? domain}</td>
                  <td align="right">{change.week1Avg ?? '-'}</td>
                  <td align="right">{change.week4Avg ?? '-'}</td>
                  <td align="right">{change.delta ?? '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <p>강점 유지 영역: {report.strengthMaintained.map((d) => DOMAIN_LABEL[d] ?? d).join(', ') || '없음'}</p>
          <p>
            약점 보완 진행도:{' '}
            {report.weaknessProgress.domain
              ? `${DOMAIN_LABEL[report.weaknessProgress.domain] ?? report.weaknessProgress.domain} (${report.weaknessProgress.improvementRate ?? '-'}점)`
              : '해당 없음'}
          </p>
          <p style={{ marginTop: 8 }}>{report.nextMonthRecommendation}</p>
        </div>
      ) : !loading ? (
        <p>{month}에 대한 리포트가 아직 없습니다. 위 버튼으로 생성하세요.</p>
      ) : null}
    </div>
  );
}
