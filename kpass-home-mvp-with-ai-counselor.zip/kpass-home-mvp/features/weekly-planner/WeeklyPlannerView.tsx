'use client';

import { useCallback, useEffect, useState } from 'react';
import { apiClient, ApiClientError } from '@/api/v1/client';
import { WeeklyTrainingPlanDto, WeeklyTrainingPlanItemDto } from '@/components/types';

const DAY_LABELS = ['', '월', '화', '수', '목', '금'];

function nextMonday(): string {
  const today = new Date();
  const day = today.getDay(); // 0=일 .. 6=토
  const daysUntilMonday = (8 - day) % 7; // 오늘이 월요일이면 0(오늘), 그 외엔 다음 월요일까지 일수
  const monday = new Date(today);
  monday.setDate(today.getDate() + daysUntilMonday);
  return monday.toISOString().slice(0, 10);
}

/**
 * Home AI = Weekly Planner AI 화면.
 * 대화형 UI가 아니라, PASS Cognitive Training Library에서 선택된 주간 계획을
 * 표(5일 x 2~3개)로 보여주고 완료 기록만 입력받는다.
 */
export function WeeklyPlannerView({ studentId }: { studentId: number }): JSX.Element {
  const [plan, setPlan] = useState<WeeklyTrainingPlanDto | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [completingItemId, setCompletingItemId] = useState<number | null>(null);

  const loadCurrentPlan = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await apiClient.get<WeeklyTrainingPlanDto>(`/home/plans/current?studentId=${studentId}`);
      setPlan(data);
    } catch (err) {
      if (err instanceof ApiClientError && err.httpStatus === 404) {
        setPlan(null);
      } else {
        setError(err instanceof ApiClientError ? err.message : '계획을 불러오지 못했습니다.');
      }
    } finally {
      setLoading(false);
    }
  }, [studentId]);

  useEffect(() => {
    void loadCurrentPlan();
  }, [loadCurrentPlan]);

  const handleGenerate = async (): Promise<void> => {
    setGenerating(true);
    setError(null);
    try {
      const data = await apiClient.post<WeeklyTrainingPlanDto>('/home/plans/weekly', {
        studentId,
        weekStartDate: nextMonday(),
      });
      setPlan(data);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '주간 계획 생성에 실패했습니다.');
    } finally {
      setGenerating(false);
    }
  };

  const handleComplete = async (
    item: WeeklyTrainingPlanItemDto,
    successRate: number,
    outcome: 'SUCCESS' | 'PARTIAL' | 'FAIL',
    parentMemo: string,
    childReaction: string,
  ): Promise<void> => {
    setCompletingItemId(item.itemId);
    try {
      await apiClient.patch(`/home/plans/items/${item.itemId}/complete`, {
        successRate,
        outcome,
        parentMemo: parentMemo || null,
        childReaction: childReaction || null,
      });
      await loadCurrentPlan();
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : '이행 기록 저장에 실패했습니다.');
    } finally {
      setCompletingItemId(null);
    }
  };

  if (loading) return <div className="kp-card">불러오는 중...</div>;

  if (!plan) {
    return (
      <div className="kp-card">
        <p>이번 주 훈련 계획이 아직 없습니다.</p>
        <button className="kp-btn kp-btn-primary" onClick={handleGenerate} disabled={generating} type="button">
          {generating ? '설계 중...' : '이번 주 계획 만들기'}
        </button>
        {error ? <p style={{ color: 'crimson', marginTop: 8 }}>{error}</p> : null}
      </div>
    );
  }

  const itemsByDay = new Map<number, WeeklyTrainingPlanItemDto[]>();
  for (const item of plan.items) {
    const list = itemsByDay.get(item.dayIndex) ?? [];
    list.push(item);
    itemsByDay.set(item.dayIndex, list);
  }

  return (
    <div>
      <div className="kp-card" style={{ marginBottom: 12 }}>
        <strong>{plan.weekStartDate} ~ {plan.weekEndDate}</strong>
        <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>
          81 Cognitive Profile: {plan.profileCode} · 연령대: {plan.ageCode}
        </p>
      </div>
      {error ? <p style={{ color: 'crimson' }}>{error}</p> : null}
      {[1, 2, 3, 4, 5].map((day) => (
        <div key={day} className="kp-card" style={{ marginBottom: 12 }}>
          <strong>{DAY_LABELS[day]}요일</strong>
          {(itemsByDay.get(day) ?? []).map((item) => (
            <PlanItemRow
              key={item.itemId}
              item={item}
              busy={completingItemId === item.itemId}
              onComplete={handleComplete}
            />
          ))}
        </div>
      ))}
    </div>
  );
}

function PlanItemRow({
  item,
  busy,
  onComplete,
}: {
  item: WeeklyTrainingPlanItemDto;
  busy: boolean;
  onComplete: (
    item: WeeklyTrainingPlanItemDto,
    successRate: number,
    outcome: 'SUCCESS' | 'PARTIAL' | 'FAIL',
    parentMemo: string,
    childReaction: string,
  ) => void;
}): JSX.Element {
  const [open, setOpen] = useState(false);
  const [successRate, setSuccessRate] = useState(80);
  const [outcome, setOutcome] = useState<'SUCCESS' | 'PARTIAL' | 'FAIL'>('SUCCESS');
  const [parentMemo, setParentMemo] = useState('');
  const [childReaction, setChildReaction] = useState('');

  return (
    <div style={{ borderTop: '1px solid var(--color-border, #eee)', padding: '8px 0' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <span className="kp-badge">{item.passDomain}</span>
          {item.isSupplementary ? <span className="kp-badge kp-badge-mock">보조훈련</span> : null}
          <strong style={{ marginLeft: 6 }}>{item.programName}</strong>
        </div>
        {item.isCompleted ? (
          <span className="kp-badge">완료</span>
        ) : (
          <button className="kp-btn" onClick={() => setOpen((v) => !v)} type="button">
            기록하기
          </button>
        )}
      </div>
      <p style={{ fontSize: 13, color: 'var(--color-text-muted)' }}>{item.trainingGoal}</p>
      <p style={{ fontSize: 12, color: 'var(--color-text-muted)' }}>{item.duration} · {item.parentGuidance}</p>

      {open && !item.isCompleted ? (
        <div style={{ marginTop: 8, display: 'flex', flexDirection: 'column', gap: 6 }}>
          <label>
            성공률: {successRate}%
            <input
              type="range"
              min={0}
              max={100}
              value={successRate}
              onChange={(e) => setSuccessRate(Number(e.target.value))}
            />
          </label>
          <select value={outcome} onChange={(e) => setOutcome(e.target.value as typeof outcome)}>
            <option value="SUCCESS">성공</option>
            <option value="PARTIAL">부분 성공</option>
            <option value="FAIL">실패</option>
          </select>
          <input
            placeholder="부모 메모"
            value={parentMemo}
            onChange={(e) => setParentMemo(e.target.value)}
          />
          <input
            placeholder="아이 반응"
            value={childReaction}
            onChange={(e) => setChildReaction(e.target.value)}
          />
          <button
            className="kp-btn kp-btn-primary"
            disabled={busy}
            onClick={() => onComplete(item, successRate, outcome, parentMemo, childReaction)}
            type="button"
          >
            {busy ? '저장 중...' : '완료 기록 저장'}
          </button>
        </div>
      ) : null}
    </div>
  );
}
