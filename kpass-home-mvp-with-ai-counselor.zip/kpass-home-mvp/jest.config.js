const nextJest = require('next/jest');

const createJestConfig = nextJest({ dir: './' });

/** @type {import('jest').Config} */
const customJestConfig = {
  setupFilesAfterEnv: ['<rootDir>/tests/jest.setup.ts'],
  moduleDirectories: ['node_modules', '<rootDir>'],
  moduleNameMapper: {
    '^@/app/(.*)$': '<rootDir>/app/$1',
    '^@/components/(.*)$': '<rootDir>/components/$1',
    '^@/features/(.*)$': '<rootDir>/features/$1',
    '^@/services/(.*)$': '<rootDir>/services/$1',
    '^@/repositories/(.*)$': '<rootDir>/repositories/$1',
    '^@/api/(.*)$': '<rootDir>/api/$1',
    '^@/domain/(.*)$': '<rootDir>/domain/$1',
    '^@/shared/(.*)$': '<rootDir>/shared/$1',
    '^@/assets/(.*)$': '<rootDir>/assets/$1',
    '^@/db/(.*)$': '<rootDir>/db/$1',
  },
  testEnvironment: 'jsdom',
  testPathIgnorePatterns: ['<rootDir>/.next/', '<rootDir>/node_modules/'],
  collectCoverageFrom: [
    'domain/**/*.ts',
    'services/**/*.ts',
    'repositories/**/*.ts',
    'shared/**/*.ts',
    '!**/*.d.ts',
  ],
};

module.exports = createJestConfig(customJestConfig);
