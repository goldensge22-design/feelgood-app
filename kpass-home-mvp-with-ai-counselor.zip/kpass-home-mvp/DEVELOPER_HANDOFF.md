# DEVELOPER HANDOFF

이 문서는 K-PASS Home AI Teacher(MVP) 코드베이스를 새로 인수받는 개발자를
위한 요약 문서다. 상세 내용은 각 절에서 링크하는 문서를 함께 참고한다.

---

## 1. 프로젝트 개요

- **제품**: FeelGood EduTech K-PASS AI Platform의 1단계 산출물 —
  **가정용(Home) AI Teacher MVP**.
- **핵심 사용자 흐름**: 로그인 → 학생 선택 → 검사 결과(HOME AI TEACHER
  결과지) → 오늘의 처방/주간 훈련 계획 → 활동 기록 → 성장 리포트.
- **범위**: Home(부모/학생) + Teacher 최소 화면만 포함. Kindergarten /
  School / Admin / Hospital / University / Enterprise 기능은 **의도적으로
  제외**되어 있다(`docs/ASSUMPTIONS_AND_TODOS.md` `SCOPE-001`).
- **가장 중요한 제품 원칙**: K-PASS 검사는 검사 종료 시점에 이미 81개의
  Cognitive Profile을 생성한다. HOME AI TEACHER는 이 값을 재분석/재계산하지
  않고, PASS Cognitive Training Library에서 Recommendation Engine이 선택한
  프로그램만 추천한다(LLM이 훈련 콘텐츠를 직접 생성하지 않는다). 자세한
  내용은 [`README.md`](README.md)의 "HOME AI TEACHER 역할" 절 참고.

## 2. 아키텍처

Clean Architecture 4계층 + Repository Pattern + DI. 의존성 방향은 항상
단방향이다:

```
app/api/v1/**  (HTTP 진입점, 인증·검증만)
      ↓
services/**    (애플리케이션 유스케이스)
      ↓
domain/**      (순수 도메인 규칙, 프레임워크/DB 비의존)
      ↓
repositories/** (interfaces + kysely 구현체 — DB 접근은 이 계층에만 존재)
      ↓
db/**          (SQL 마이그레이션 + Kysely 타입, 스키마 단일 진실 공급원)
```

- **스택**: Next.js 14(App Router) · TypeScript strict · PostgreSQL +
  Kysely(ORM 아님, 순수 TS SQL 빌더) · JWT 인증/RBAC · pdf-lib(결과지 PDF)
  · Jest.
- **왜 Prisma가 아닌 Kysely인가**: 개발 환경 네트워크 정책상 Prisma 엔진
  바이너리를 받을 수 없어, 네이티브 바이너리가 필요 없는 Kysely로 전환했다
  (`docs/ASSUMPTIONS_AND_TODOS.md` "ORM 선택" 항목). Repository 인터페이스가
  ORM을 캡슐화하도록 설계되어 있어 이 교체가 서비스/도메인 계층에 영향을
  주지 않았다.
- **Recommendation Layer**: `domain/services/RecommendationService.ts`
  (interface) → `LibraryRecommendationService`(실제 구현, `isMock: false`)가
  `pass_training_program`(PASS Cognitive Training Library, 400건)에서만
  프로그램을 선택한다. Home AI와 Teacher AI가 이 엔진을 공유한다. 상세
  시퀀스/ERD는 [`docs/PASS_TRAINING_LIBRARY_ARCHITECTURE.md`](docs/PASS_TRAINING_LIBRARY_ARCHITECTURE.md)
  참고.
- **인증/권한**: `shared/middleware/withAuth.ts`가 JWT 검증 + role
  체크(PARENT/STUDENT vs TEACHER)를 수행하고, `StudentService`가
  `organization_id` 기준으로 가족/기관 스코프를 검증한다
  (`docs/ARCHITECTURE.md` 참고). 단, 비밀번호 검증은 아직 Placeholder다
  (아래 3절 참고).
- 전체 상세는 [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md)와
  [`docs/REVIEW.md`](docs/REVIEW.md)(Architecture/Code Review, Refactoring,
  Performance 점검 기록)를 참고.

## 3. 개발자가 해야 하는 작업

전체 목록과 세부 절차는 [`DEVELOPMENT_CHECKLIST.md`](DEVELOPMENT_CHECKLIST.md)에
정리되어 있다. 배포 전 반드시 처리해야 하는 핵심 항목만 요약하면:

1. **인증 완성** — `services/auth/CredentialVerifier.ts`의 Placeholder를
   제거하고 bcrypt 기반 실제 비밀번호 해시 검증으로 교체(`password_hash`
   컬럼 마이그레이션 포함). Teacher Role / Organization Scope 검증 재확인.
2. **자동화** — 주간 훈련 계획을 매주 자동 생성하는 Weekly Auto Scheduler
   구현(현재는 API 호출 시점에만 계획이 생성됨). 훈련 프로그램 Approval
   Workflow(현재 `approval_status` 필드만 존재, UI/API 없음) 구현.
3. **보안** — JWT 시크릿 교체, 에러 노출 정책, CORS/Rate limiting 등
   Production Security Check 항목 전부 처리.
4. **검증** — DB 마이그레이션/시드가 빈 환경에서 문제없이 도는지, 전체
   테스트/타입체크/린트가 통과하는지 확인.

이 외에도 `docs/ASSUMPTIONS_AND_TODOS.md`에 원본 기획 문서에 없어 TODO로
남겨둔 판단 지점(예: 부모-자녀 다대다 관계 미지원, 재검사 스케줄링 미저장,
신뢰도 산출 공식 없음 등)이 전부 기록되어 있으니 기능 확장 전 반드시
읽어볼 것.

## 4. GitHub 업로드 순서

1. `.gitignore`가 적용되어 있는지 확인(이 저장소에는 이미 포함되어 있음 —
   `.env`, `node_modules/`, `.next/`, `coverage/`, `dist/`, `logs/`, IDE
   설정 등을 제외한다).
2. 로컬에서 `git status`로 추적되지 않아야 할 파일(빌드 산출물, `.env` 등)이
   없는지 확인.
   ```bash
   git status
   ```
3. 원격 저장소 초기화 및 최초 커밋.
   ```bash
   git init                     # 이미 초기화되어 있다면 생략
   git add .
   git commit -m "chore: initial import of K-PASS Home AI Teacher MVP"
   git branch -M main
   git remote add origin <YOUR_GITHUB_REPO_URL>
   git push -u origin main
   ```
4. 푸시 후 GitHub 저장소에서 `.env`나 비밀키가 포함되지 않았는지 웹에서
   재확인.
5. 브랜치 보호 규칙(선택) 및 협업 규칙(PR 리뷰 등) 설정.
6. 이후 작업은 `DEVELOPMENT_CHECKLIST.md`의 "GitHub 업로드 체크리스트"
   항목을 참고해 매 배포 전 반복 점검한다.

## 5. 배포 전 체크리스트

요약(전체 항목은 [`DEVELOPMENT_CHECKLIST.md`](DEVELOPMENT_CHECKLIST.md)의
"배포 체크리스트" 절 참고):

- [ ] 프로덕션 `DATABASE_URL` 및 JWT 시크릿 등 모든 환경변수 설정 완료
- [ ] `npm run db:migrate` → `npm run db:seed` (필요 시 `db:seed:library`)
      정상 수행 확인
- [ ] `npm run typecheck` / `npm run lint` / `npm test` 전부 통과
- [ ] `npm run build` 경고 없이 성공
- [ ] 인증(bcrypt), Teacher Role, Organization Scope 검증 완료(3절 참고)
- [ ] Weekly Auto Scheduler, Approval Workflow 반영 여부 확인
- [ ] 배포 후 로그인 → 학생 선택 → 결과지(HOME AI TEACHER) → 주간 플래너 →
      활동 기록 → 성장 리포트 → PDF 다운로드 전 구간 스모크 테스트
- [ ] 모니터링/에러 트래킹 연동(현재 미포함)
- [ ] 롤백 절차 확인(마이그레이션 되돌리기 포함)

---

관련 문서 인덱스는 [`README.md`](README.md)의 "문서" 절을 참고한다.
