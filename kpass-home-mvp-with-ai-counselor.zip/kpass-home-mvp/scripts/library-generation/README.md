# Library Generation Script

`generate_library.py`는 db/seed-data/pass_training_library_400.json을 생성한 원본 스크립트다.

## 600/1000/2000개로 확장하는 방법
1. `AGE_BANDS`, `DIFFICULTY`, 또는 각 도메인의 `sub_functions`에 항목을 추가한다
   (예: sub_functions를 4개 -> 8개로 늘리면 도메인당 100 -> 200개, 전체 800개).
2. `python3 generate_library.py` 재실행 -> `pass_training_library_400.json` 갱신
   (파일명은 유지되나 내용이 갱신됨; 대량 확장 시 파일명을 바꾸고
   `db/seedTrainingLibrary.ts`의 import 경로를 함께 갱신할 것)
3. 결과를 `db/seed-data/`로 복사 후 `npm run db:seed:library` 실행
4. `tests/unit/PassTrainingLibrary.integrity.test.ts`의 하드코딩된 개수(400, 80 등)를
   새 목표치로 갱신

## 근거 논문 갱신
`papers.json`은 `PASS_Theory_100_Key_Papers.xlsx`를 그대로 변환한 것이다. 논문이
추가되면 엑셀을 갱신한 뒤 동일한 변환(연도순 시트 -> paper_id 'P001'.. 순번 부여)을
다시 실행한다.
