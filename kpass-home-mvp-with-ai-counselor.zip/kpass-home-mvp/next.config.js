/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  eslint: {
    dirs: ['app', 'components', 'features', 'services', 'repositories', 'api', 'domain', 'shared'],
  },
  experimental: {
    serverComponentsExternalPackages: ['pg', 'bcryptjs', 'pdf-lib', '@pdf-lib/fontkit'],
  },
};

module.exports = nextConfig;
