# DEVELOPMENT CHECKLIST

이 문서는 현재 MVP 코드베이스에서 **실제 프로덕션 배포 전 반드시 처리해야
하는 남은 작업**을 체크리스트 형태로 정리한다. 각 항목은 관련 코드 위치와
근거 문서(`docs/ASSUMPTIONS_AND_TODOS.md`)를 함께 표기한다.

> 표시 규칙: `[ ]` 미완료 · `[x]` 완료. 이 저장소의 현재 상태 기준으로
> 작성되었으며, 실제 완료 시 담당자가 체크박스를 갱신한다.

---

## 1. 인증 (Authentication)

- [ ] **CredentialVerifier Placeholder 제거**
  - 대상: `services/auth/CredentialVerifier.ts`
  - 현재 `PlaceholderCredentialVerifier`는 `status === 'ACTIVE'` +
    비밀번호 4자 이상이면 무조건 통과시킨다. **실제 비밀번호 검증을
    수행하지 않는다.**
  - 근거: `docs/ASSUMPTIONS_AND_TODOS.md` `DB-001`
- [ ] **bcrypt 인증 적용**
  - `bcryptjs`는 이미 `package.json` 의존성에 포함되어 있으나 미사용 상태.
  - `user_account` 테이블에 `password_hash VARCHAR(255)` 컬럼 추가
    마이그레이션 작성 (`db/migrations/000X_add_password_hash.sql`).
  - `PlaceholderCredentialVerifier`를 `bcrypt.compare(plainPassword,
    passwordHash)` 기반 구현으로 교체.
  - 회원가입/비밀번호 재설정 플로우 설계 및 구현(현재 원본 문서에 없어
    미구현 상태).
- [ ] **Teacher Role 검증**
  - `shared/middleware/withAuth.ts`의 role 체크가 Home(PARENT/STUDENT)
    경로와 Teacher 경로에 모두 올바르게 적용되는지 재검증.
  - `app/teacher/**`, `app/api/v1/teacher/**` 전 구간에 대해 `TEACHER`
    이외의 role이 403을 반환하는지 통합 테스트로 확인.
- [ ] **Organization Scope 검증**
  - `StudentService.getStudentOrThrow(studentId, auth.organizationId)`가
    모든 학생 조회 API 경로(`/api/v1/students/**`, `/api/v1/home/**`)에서
    예외 없이 호출되는지 코드 리뷰.
  - 다른 가족/기관의 studentId로 접근 시 403/404가 반환되는지 통합
    테스트 케이스 추가(현재 단위 테스트만 존재하는 경로가 있는지 확인).

## 2. 자동화 / 운영 기능

- [ ] **Weekly Auto Scheduler**
  - 현재 `WeeklyPlannerService`는 API 호출 시점에만 주간 계획을
    (재)생성한다. 매주 자동 실행되는 배치/Cron이 없음.
  - 배포 환경에 맞는 스케줄러(예: Vercel Cron, node-cron, 외부 스케줄러
    + 내부 API 호출) 설계 및 적용 필요.
  - 실패 시 재시도/알림 정책 정의 필요(문서 원본에 명시 없음 — 별도
    기획 확인 필요).
- [ ] **Approval Workflow**
  - `pass_training_program.approval_status` 필드는 존재하나, 이를
    변경/조회하는 UI 또는 API가 없음.
  - 신규/수정 프로그램이 검수자 승인 전에는 추천 후보(`findCandidates`)에
    포함되지 않도록 `TrainingProgramRepository` 쿼리에 상태 필터 추가
    여부 확인.
  - 승인 권한을 가진 Role(예: `ADMIN`/`REVIEWER`) 정의는 현재 프로젝트
    범위(정책 #1/#2, Home/Teacher MVP만 포함)를 벗어나므로 별도 설계
    검토 필요.

## 3. 보안 (Production Security Check)

- [ ] `.env`의 `JWT_ACCESS_SECRET` / `JWT_REFRESH_SECRET`을 강력한 랜덤
  값으로 교체(현재 `change-me-*` 플레이스홀더).
- [ ] `NODE_ENV=production`에서 상세 에러 스택트레이스가 클라이언트에
  노출되지 않는지 확인(`shared/errors/handleApiError.ts`).
- [ ] CORS/Rate limiting 정책 검토 및 적용(현재 명시적 설정 없음).
- [ ] `docker-compose.yml`의 DB 비밀번호(`kpass_password`)가 프로덕션에
  그대로 사용되지 않도록 별도 secret 관리 체계 적용.
- [ ] 의존성 취약점 점검(`npm audit`) 및 조치.
- [ ] `pdf-lib`/`fontkit`으로 생성되는 결과지 PDF에 민감정보(다른 학생
  정보 등)가 섞여 나가지 않는지 재검증.

## 4. 데이터베이스

- [ ] **DB Migration 확인**
  - `npm run db:migrate`가 빈 DB에서 오류 없이 끝까지 수행되는지 확인.
  - `db/migrations/0001_init.sql`, `0002_pass_training_library.sql` 및
    이후 추가되는 모든 마이그레이션이 순서대로 idempotent하게 적용되는지
    검증.
- [ ] **Seed 확인**
  - `npm run db:seed`, `npm run db:seed:library` 실행 후 데모 로그인
    (`parent@example.com`)과 학생 목록/결과지 조회가 정상 동작하는지 확인.
  - `pass_training_program` 400건, `research_paper` 100건이 중복 없이
    적재되었는지 `tests/unit/PassTrainingLibrary.integrity.test.ts`로 검증.

## 5. 테스트

- [ ] **Test 확인**
  - `npm test`(unit + integration) 전체 통과 확인.
  - `npm run test:coverage`로 핵심 서비스(`LibraryRecommendationService`,
    `WeeklyPlannerService`, `AuthService`, `StudentService`) 커버리지 확인.
  - `npm run typecheck`, `npm run lint` 오류 0건 확인.

## 6. GitHub 업로드 체크리스트

- [ ] `.gitignore` 적용 확인 — `.env`, `node_modules/`, `.next/`,
  `coverage/`, `dist/`, `logs/`, IDE 설정 파일이 `git status`에 나타나지
  않는지 확인.
- [ ] `git status`로 실수로 포함된 빌드 산출물/민감 파일이 없는지 재확인.
- [ ] 커밋 히스토리에 실제 비밀키/비밀번호가 포함된 적이 없는지 확인
  (있다면 `git filter-repo` 등으로 정리 후 업로드).
- [ ] `README.md`의 클론/설치 가이드를 새 클론 환경에서 그대로 따라
  실행해 문제가 없는지 최종 리허설(dry-run).
- [ ] 라이선스 파일 필요 여부 확인(현재 미포함, 사내/비공개 저장소 여부에
  따라 결정).

## 7. 배포 체크리스트

- [ ] 프로덕션 `DATABASE_URL`이 실제 운영 PostgreSQL을 가리키는지 확인.
- [ ] 프로덕션 환경변수(위 "보안" 항목 포함)가 모두 설정되었는지 확인.
- [ ] `npm run build`가 프로덕션 빌드 환경에서 경고 없이 성공하는지 확인.
- [ ] `npm run db:migrate`를 배포 파이프라인에 포함(신규 마이그레이션
  자동 적용).
- [ ] 배포 후 스모크 테스트: 로그인 → 학생 선택 → 결과지(HOME AI TEACHER)
  → 주간 플래너 → 활동 기록 → 성장 리포트 → PDF 다운로드 전 구간 수동 확인.
- [ ] Weekly Auto Scheduler(2번 항목)가 배포 환경에서 실제로 트리거되는지
  확인.
- [ ] 롤백 절차 문서화(마이그레이션 되돌리기 포함).
- [ ] 모니터링/로그 수집(에러 트래킹) 연동 여부 확인 — 현재 프로젝트에는
  포함되어 있지 않음.
