# K-PASS Home AI Teacher (MVP)

FeelGood EduTech K-PASS AI Platform의 1단계 산출물. **가정용(Home AI Teacher)
MVP만** 구현되어 있으며, Kindergarten/School/Admin/Hospital/University/
Enterprise 기능은 정책상 포함하지 않는다. (Teacher AI는 동일 추천 엔진을
공유하는 최소 화면만 별도로 존재한다. 자세한 내용은
[`docs/PASS_TRAINING_LIBRARY_ARCHITECTURE.md`](docs/PASS_TRAINING_LIBRARY_ARCHITECTURE.md) 참고.)

전체 완료 기준(지시서 §17): **로그인 → 학생 선택 → 검사 결과 → AI 분석 →
오늘의 처방 → 활동 기록 → 성장 리포트** — 이 흐름은 실제 PostgreSQL과 연결된
상태로 end-to-end 검증되었다.

## 목차

- [프로젝트 구조](#프로젝트-구조)
- [HOME AI TEACHER 역할](#home-ai-teacher-역할)
- [Recommendation Layer 구조](#recommendation-layer-구조)
- [PASS Cognitive Training Library 구조](#pass-cognitive-training-library-구조)
- [개발환경 구축](#개발환경-구축)
- [실행 방법](#실행-방법)
- [환경변수 설명](#환경변수-설명)
- [문서](#문서)
- [정책 준수 요약](#정책-준수-요약)
- [알려진 제약](#알려진-제약-문서-원본의-한계)

---

## 프로젝트 구조

Clean Architecture 레이어 구조를 따르며, 의존성 방향은 항상
`app → services → domain → repositories(interfaces) → db` 이다.

```
kpass-home-mvp/
├── app/                        # Next.js 14 App Router (진입점)
│   ├── api/v1/                 # Route Handler (HTTP 진입점, 인증·검증만 담당)
│   │   ├── auth/                #   로그인 / 토큰 재발급
│   │   ├── students/            #   학생 조회, PASS 결과, 홈 대시보드, 활동 기록, 리포트
│   │   ├── home/plans/          #   주간 훈련 계획(Weekly Planner) CRUD
│   │   ├── home/reports/        #   4주 월간 리포트
│   │   ├── teacher/              #   Teacher AI 추천(개인/그룹)
│   │   └── openapi/              #   OpenAPI 3.0 스펙 (Swagger UI 데이터 소스)
│   ├── login/                   # 로그인 화면
│   ├── students/                # 학생 선택 → 결과/주간 플래너 → HOME AI TEACHER → 성장 리포트
│   ├── teacher/                 # Teacher AI 최소 화면
│   └── docs/                    # Swagger UI (/docs)
├── components/                  # 결과지 하위 프레젠테이션 컴포넌트(PassProfileCard 등)
├── features/                    # 화면 단위 컨테이너 컴포넌트('use client')
│   ├── auth/                     #   AuthContext, RequireAuth, LoginForm
│   ├── student/                  #   학생 목록
│   ├── home-dashboard/           #   HOME AI TEACHER 결과지 화면(PASS 결과 + 오늘의 처방)
│   ├── weekly-planner/           #   주간 인지훈련 플래너 + 월간 리포트
│   ├── growth-report/            #   성장 리포트
│   └── teacher-dashboard/        #   Teacher AI 추천 화면
├── domain/                       # 프레임워크/DB 비의존 순수 도메인 계층
│   ├── entities/                 #   도메인 엔티티 타입
│   ├── interfaces/                #   포트(인터페이스) 정의
│   └── services/                  #   RecommendationService 인터페이스,
│                                   #   LibraryRecommendationService(실제 추천 엔진)
├── services/                      # 애플리케이션 서비스(유스케이스), Repository/도메인
│   ├── auth/                       #   AuthService, CredentialVerifier
│   ├── pass/                        #   StudentService, PassResultService
│   ├── recommendation/              #   HomeDashboardService, WeeklyPlannerService,
│   │                                 #   TeacherDashboardService
│   ├── growth/                       #   GrowthReportService
│   └── report/                        #   ReportPdfService (결과지 PDF)
├── repositories/                  # DB 접근은 이 계층에만 존재
│   ├── interfaces/                 #   포트(Repository 인터페이스)
│   └── kysely/                      #   Kysely 어댑터 구현체
├── db/                              # 스키마 단일 진실 공급원(Single Source of Truth)
│   ├── migrations/                   #   SQL 마이그레이션 (0001_init.sql, 0002_...)
│   ├── seed-data/                     #   시드용 JSON(연구논문 100건, 훈련 프로그램 400건 등)
│   ├── seed.ts                         #   기본 데모 데이터 시드
│   ├── seedTrainingLibrary.ts           #   PASS Training Library(400 프로그램) 시드
│   ├── migrate.ts                       #   마이그레이션 실행 스크립트
│   └── types.ts                          #   Kysely 테이블 타입
├── shared/                           # 횡단 관심사
│   ├── config/                        #   DI 컨테이너(container.ts), env, db 커넥션
│   ├── middleware/                     #   withAuth (JWT 검증 + RBAC)
│   ├── errors/                          #   AppError 계층, handleApiError
│   └── response/                        #   표준 ApiResponse 포맷
├── schemas/                           # JSON Schema (pass_training_program 등)
├── scripts/library-generation/         # 400개 훈련 프로그램 생성 스크립트
├── tests/                              # Jest (unit + integration)
├── docs/                                # 아키텍처/가정/리뷰 문서
├── docker-compose.yml / Dockerfile
├── .env.example
├── DEVELOPMENT_CHECKLIST.md             # 배포 전 남은 작업 체크리스트 (신규)
├── DEVELOPER_HANDOFF.md                 # 개발자 인수인계 문서 (신규)
└── README.md
```

---

## HOME AI TEACHER 역할

**HOME AI TEACHER는 대화형 챗봇이 아니다.** 검사 결과를 근거로 이미 만들어진
훈련 프로그램을 "추천"만 하는 자동화된 처방/플래너 시스템이다.

### 가장 중요한 원칙

> **K-PASS 검사는 검사 종료 시점에 이미 81개의 Cognitive Profile을 생성한다.**

- HOME AI TEACHER는 **81개 인지 특성(Cognitive Profile)을 다시 분석하지 않는다.**
- **PASS 점수를 다시 계산하지 않는다.**
- **새로운 Profile을 생성하지 않는다.**
- **LLM이 훈련을 생성하지 않는다.**
- 훈련은 반드시 **PASS Cognitive Training Library**에 이미 존재하는
  Program만 추천한다(런타임에 텍스트를 새로 만드는 것은 금지되어 있으며,
  `LibraryRecommendationService`는 후보가 0건이면 즉시 예외를 던지도록
  구현되어 있다 — `tests/unit/LibraryRecommendationService.test.ts` 참고).

즉, "81 Cognitive Profile 생성"과 "훈련 프로그램 추천"은 **서로 다른 시점,
서로 다른 책임**을 가진다: 전자는 K-PASS 검사 엔진이 검사 종료 시 1회
확정하는 값이고, 후자는 HOME AI TEACHER(정확히는 아래 Recommendation
Layer)가 그 확정된 값을 **읽기만** 해서 매주 실행하는 매칭 로직이다.

### 전체 Flow

```
K-PASS Assessment
      ↓
PASS Score
      ↓
81 Cognitive Profile              ← 검사 종료 시점에 이미 생성 완료 (재생성 금지)
      ↓
Recommendation Engine             ← 81 Profile을 "읽기만" 함
      ↓
PASS Cognitive Training Library   ← 여기서만 Program을 선택 (신규 생성 금지)
      ↓
Weekly Plan
      ↓
Daily Training
      ↓
Progress Tracking
      ↓
Next Week Recommendation
      ↓
Monthly Report
```

### 화면 ↔ 코드 매핑

| Flow 단계 | 주요 코드 |
|---|---|
| K-PASS Assessment / PASS Score / 81 Cognitive Profile | `services/pass/PassResultService.ts`, `cognitive_profile_81` 테이블 |
| 결과지(HOME AI TEACHER 진입 화면) | `features/home-dashboard/HomeDashboard.tsx`, `app/students/[studentId]/home-ai-teacher/page.tsx` |
| Recommendation Engine | `domain/services/LibraryRecommendationService.ts` |
| PASS Cognitive Training Library | `db/seed-data/*.json` → `pass_training_program` 테이블 |
| Weekly Plan / Daily Training | `services/recommendation/WeeklyPlannerService.ts`, `features/weekly-planner/WeeklyPlannerView.tsx` |
| Progress Tracking | `home_training_log` 테이블, 활동 기록 API |
| Next Week Recommendation | `WeeklyPlannerService`(이력 기반 승급/강등) |
| Monthly Report | `services/growth/GrowthReportService.ts`, `features/weekly-planner/MonthlyReportView.tsx` |

---

## Recommendation Layer 구조

Recommendation Layer는 **의존성 역전(Dependency Inversion)** 으로 설계되어
있어, 추천 로직 구현체를 언제든 교체할 수 있다. Home AI와 Teacher AI는
**동일한 인터페이스와 동일한 엔진**을 공유한다.

```
domain/services/RecommendationService.ts        (interface, 계약만 정의)
        ↑ implements
domain/services/LibraryRecommendationService.ts  (Library 기반 실제 추천 엔진)
        ↑ reads only from
db: pass_training_program (PASS Cognitive Training Library, 400건)
```

- **입력**: 81 Cognitive Profile 코드, 연령(Age Band), 최근 수행 이력
  (History), 강점/약점(Weakness/Strength).
- **선택 로직**: `resolveFromScores`(점수 → 81 Profile 코드) →
  `resolveDifficulty`(이력 기반 난이도 승급/강등) →
  `findCandidates(domain, age, difficulty)`(Library 조회) → 최근 이력 제외 +
  하위 인지 기능(sub_cognitive_function) 로테이션 선택.
- **불변 조건**: Engine은 Library(`pass_training_program`)에서만 읽는다.
  Home AI/Teacher AI는 Engine의 출력(`RecommendationOutput`)만 화면에
  렌더링하며, 절대 자체적으로 프로그램 텍스트를 생성하지 않는다.
- **과거 구현과의 관계**: 초기 MVP는 `PlaceholderRecommendationService`
  (Mock 4건, `isMock: true`)만 존재했다. 현재는 `LibraryRecommendationService`
  (`isMock: false`)가 DI 컨테이너(`shared/config/container.ts`)에서 이를
  대체했으며, 실제 AI 알고리즘이 준비되면 같은 인터페이스로 새 구현체를
  추가하고 컨테이너 한 줄만 교체하면 된다. 서비스/API/화면 계층은 수정할
  필요가 없다.

Teacher AI(`TeacherDashboardService`)와 Home AI(`HomeDashboardService`,
`WeeklyPlannerService`) 모두 이 계층을 통해서만 프로그램을 추천받는다.

---

## PASS Cognitive Training Library 구조

`pass_training_program` 테이블(400건, 56개 필드)이 훈련 콘텐츠의 유일한
출처다. 상세 스키마·생성 근거·확장 절차는
[`docs/PASS_TRAINING_LIBRARY_ARCHITECTURE.md`](docs/PASS_TRAINING_LIBRARY_ARCHITECTURE.md)
에 전체 문서화되어 있다. 핵심만 요약하면:

- **분류 축**: `pass_domain`(Planning/Attention/Simultaneous/Successive,
  각 100개) × `target_age`(5개 연령 구간) × `difficulty_level`(5단계).
- **근거**: 모든 프로그램은 `program_reference_paper`를 통해
  `research_paper`(PASS Theory 핵심 논문 100편)와 direct/indirect/theoretical
  근거 수준으로 연결된다 — Evidence 패널에서 근거 논문을 바로 확인할 수 있다.
- **무결성**: 중복 0건, 전 항목 근거 연결 여부는
  `tests/unit/PassTrainingLibrary.integrity.test.ts`로 검증된다.
- **확장 방법(400 → 600 → 1000 → 2000)**: `db/seed-data/*.json`에 행을
  추가하고 `npm run db:seed:library`를 재실행하면 된다. 서비스 코드,
  Repository, API 계약(`RecommendationOutput`) 중 어느 것도 프로그램
  개수에 의존하지 않는다. 단, PASS 4개 도메인 자체를 늘리는 것은 PASS
  이론 범위를 벗어나므로 별도 설계 검토가 필요하다.
- **승인 상태(`approval_status`)**: 프로그램마다 승인 상태 필드를 보유하고
  있으나, 현재 승인 워크플로(UI/API)는 구현되어 있지 않다 — 남은 작업은
  [`DEVELOPMENT_CHECKLIST.md`](DEVELOPMENT_CHECKLIST.md)를 참고.

---

## 개발환경 구축

### 사전 준비물

- Node.js 18 이상
- PostgreSQL 16 (로컬 설치 또는 Docker)

### 1) 의존성 설치

```bash
npm install
```

### 2) 환경변수 설정

```bash
cp .env.example .env
# 필요 시 .env 값 수정 (환경변수 상세는 아래 "환경변수 설명" 참고)
```

### 3) 데이터베이스 마이그레이션

PostgreSQL이 기동된 상태에서(`DATABASE_URL`이 가리키는 DB) 실행한다.
`db/migrations/*.sql`을 순서대로 적용한다.

```bash
npm run db:migrate
```

### 4) 시드 데이터 투입

```bash
npm run db:seed            # 데모 계정 및 기본 데이터
npm run db:seed:library    # PASS Cognitive Training Library(400 프로그램) + 근거논문 100건
```

데모 계정: `parent@example.com` / 4자 이상 아무 비밀번호
(`TODO(DB-001)` — 비밀번호 검증이 Placeholder임, 아래 [알려진 제약](#알려진-제약-문서-원본의-한계) 참고)

### 5) 테스트

```bash
npm test              # Jest (unit + integration) 전체 실행
npm run test:watch    # watch 모드
npm run test:coverage # 커버리지 리포트
```

### 6) 타입/린트 검사

```bash
npm run typecheck
npm run lint
```

---

## 실행 방법

### 로컬 개발 서버

```bash
npm run dev
```

`http://localhost:3000` 에서 앱을, `http://localhost:3000/docs` 에서
API 문서(Swagger UI)를 확인할 수 있다.

### 프로덕션 빌드/실행

```bash
npm run build
npm run start
```

### Docker (앱 + PostgreSQL 한 번에 기동)

```bash
cp .env.example .env   # 필요 시 값 수정
docker compose up --build
```

`docker-compose.yml`의 `app` 서비스는 기동 시 `npm run db:migrate` →
`npm run start` 순서로 자동 실행된다(시드는 별도 실행 필요:
`docker compose exec app npm run db:seed`).

### 스크립트 요약

| 명령 | 설명 |
|---|---|
| `npm run dev` | 개발 서버 |
| `npm run build` | 프로덕션 빌드 |
| `npm run start` | 프로덕션 서버 |
| `npm run typecheck` | TypeScript strict 검사 |
| `npm run lint` / `lint:fix` | ESLint |
| `npm run format` | Prettier |
| `npm test` / `test:watch` / `test:coverage` | Jest |
| `npm run db:migrate` | SQL 마이그레이션 적용 (`db/migrations/*.sql`) |
| `npm run db:seed` | 데모 데이터 시드 |
| `npm run db:seed:library` | PASS Training Library(400 프로그램) 시드 |
| `npm run docker:up` / `docker:down` | Docker Compose 기동/종료 |

---

## 환경변수 설명

`.env.example`을 복사해 `.env`로 사용한다. 모든 값은 로컬/개발 기본값이며,
실배포 전 반드시 교체해야 한다(아래 표 및
[`DEVELOPMENT_CHECKLIST.md`](DEVELOPMENT_CHECKLIST.md)의 "Production Security
Check" 참고).

| 변수 | 필수 | 설명 | 기본값(예시) |
|---|---|---|---|
| `DATABASE_URL` | ✅ | PostgreSQL 연결 문자열 (`shared/config/db.ts`가 읽음) | `postgresql://kpass:kpass_password@localhost:5432/kpass_home` |
| `JWT_ACCESS_SECRET` | ✅ | Access Token 서명 비밀키. **배포 전 강력한 랜덤 값으로 교체 필수** | `change-me-access-secret` |
| `JWT_REFRESH_SECRET` | ✅ | Refresh Token 서명 비밀키. **배포 전 강력한 랜덤 값으로 교체 필수** | `change-me-refresh-secret` |
| `JWT_ACCESS_TTL` | 선택 | Access Token 만료 기간 | `15m` |
| `JWT_REFRESH_TTL` | 선택 | Refresh Token 만료 기간 | `7d` |
| `NODE_ENV` | 선택 | `development` / `production` / `test` | `development` |

> **주의(TODO-AUTH-001)**: 현재 인증 credential 검증은
> `services/auth/CredentialVerifier.ts`의 Placeholder 구현을 사용한다
> (`bcryptjs`는 의존성에 포함되어 있으나 아직 실제 해시 비교에 연결되지
> 않음). 배포 전 반드시 `DEVELOPMENT_CHECKLIST.md`의 인증 관련 항목을
> 완료해야 한다.

---

## 문서

- [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) — 레이어 구조, 의존성 방향, 인증/RBAC
- [`docs/PASS_TRAINING_LIBRARY_ARCHITECTURE.md`](docs/PASS_TRAINING_LIBRARY_ARCHITECTURE.md) — PASS Cognitive Training Library 및 Recommendation Layer 상세 설계
- [`docs/ASSUMPTIONS_AND_TODOS.md`](docs/ASSUMPTIONS_AND_TODOS.md) — 원본 문서에 없어
  Placeholder/TODO로 처리한 모든 지점의 근거와 후속 조치
- [`docs/REVIEW.md`](docs/REVIEW.md) — Architecture/Code Review, Refactoring, 성능 점검 기록
- [`docs/HOME_AI_COUNSELOR.md`](docs/HOME_AI_COUNSELOR.md) — Home AI 상담사(AI Coach) 기능 설명 및 개발자 연동 가이드(신규)
- [`DEVELOPMENT_CHECKLIST.md`](DEVELOPMENT_CHECKLIST.md) — 배포 전 남은 작업 체크리스트(신규)
- [`DEVELOPER_HANDOFF.md`](DEVELOPER_HANDOFF.md) — 개발자 인수인계 문서(신규)
- `/docs` (앱 실행 후) — Swagger UI (OpenAPI 3.0)

## 정책 준수 요약

- **정책 #1/#2/#9**: Home MVP 외 어떤 기능도 구현하지 않음. UI Flow 문서의
  Admin 화면은 의도적으로 제외(`docs/ASSUMPTIONS_AND_TODOS.md` SCOPE-001).
- **정책 #3**: ERD에 없는 `parent_profile`/`reassessment` 테이블을 만들지 않고,
  기존 필드(`organization.org_type`)만으로 해석(TODO(DB-002)).
- **정책 #4**: `RecommendationService` 인터페이스는 `LibraryRecommendationService`
  (실제 Library 기반 추천, `isMock: false`)로 구현되어 있으며, 과거
  `PlaceholderRecommendationService`(Mock, `isMock: true`)는 DI 컨테이너에서
  대체되었다. LLM이 훈련 콘텐츠 자체를 생성하는 로직은 존재하지 않는다.
- **정책 #5**: 아직 Mock으로 남아있는 추천 응답에는 `isMock: true`가
  포함되며, 프론트엔드는 "AI 예시(Mock)" 배지를 표시한다.
- **정책 #6**: `app/globals.css`가 `KPASS_Design_System_v1_1.pptx`의 컬러
  토큰(#1F4E78 등)·타이포그래피를 그대로 사용.
- **정책 #7**: Clean Architecture, Repository Pattern, DI(`shared/config/container.ts`),
  TypeScript strict, ESLint/Prettier, 표준 예외 처리, JWT/RBAC, 테스트, Docker
  모두 적용.

## 알려진 제약 (문서 원본의 한계)

`docs/ASSUMPTIONS_AND_TODOS.md`에 전체 목록이 있다. 요약:

1. 인증 credential 컬럼이 ERD에 없어 비밀번호 검증이 Placeholder임(TODO(DB-001)).
2. Round4 활동 데이터가 PASS 영역당 1건뿐이라 실제 서비스에는 콘텐츠 확충이 필요함(MOCK-001).
3. 신뢰도(confidence) 산출 공식이 문서에 없어 항상 0을 반환함(MOCK-002).
4. 주간 미션·4주 계획은 저장 구조가 없어 안내 문구만 제공함(HOME-006).
5. `pass_training_program.approval_status`는 필드만 존재하고 승인 워크플로 UI/API는
   미구현임 — 상세 작업 목록은 [`DEVELOPMENT_CHECKLIST.md`](DEVELOPMENT_CHECKLIST.md) 참고.

배포 전 남은 모든 작업의 체크리스트는 [`DEVELOPMENT_CHECKLIST.md`](DEVELOPMENT_CHECKLIST.md)를,
프로젝트 인수인계 개요는 [`DEVELOPER_HANDOFF.md`](DEVELOPER_HANDOFF.md)를 참고한다.
