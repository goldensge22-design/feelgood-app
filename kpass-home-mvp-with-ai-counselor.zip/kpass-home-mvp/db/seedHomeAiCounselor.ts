/* eslint-disable no-console */
import { db } from '@/shared/config/db';
import faqs from './seed-data/home_ai_parent_faq.json';
import lifeCases from './seed-data/home_ai_parent_life_case.json';
import avoidPhrases from './seed-data/home_ai_avoid_phrases.json';
import teacherStrategies from './seed-data/home_ai_teacher_strategy.json';

/**
 * Home AI 상담사(AI Coach) 콘텐츠 라이브러리 시드 스크립트.
 *
 * seedTrainingLibrary.ts와 동일한 원칙: 이 스크립트는 "데이터 적재"만 수행한다.
 * AI를 호출해 콘텐츠를 생성하지 않으며, 부모/교사 화면은 오직 여기서 적재된
 * 행(row)만 조합해서 보여준다.
 */

async function seedFaqs(): Promise<void> {
  for (const row of faqs) {
    await db
      .insertInto('home_ai_parent_faq')
      .values({
        faq_id: row.faqId,
        priority_domain: row.priorityDomain,
        question: row.question,
        answer: row.answer,
      })
      .onConflict((oc) =>
        oc.column('faq_id').doUpdateSet({
          question: (eb) => eb.ref('excluded.question'),
          answer: (eb) => eb.ref('excluded.answer'),
        }),
      )
      .execute();
  }
  console.log(`home_ai_parent_faq: ${faqs.length} rows upserted`);
}

async function seedLifeCases(): Promise<void> {
  for (const row of lifeCases) {
    await db
      .insertInto('home_ai_parent_life_case')
      .values({
        case_id: row.caseId,
        priority_domain: row.priorityDomain as 'PLANNING' | 'ATTENTION' | 'SIMULTANEOUS' | 'SUCCESSIVE',
        child_description: row.childDescription,
        school_behavior: row.schoolBehavior,
        home_behavior: row.homeBehavior,
        parent_guidance: row.parentGuidance,
      })
      .onConflict((oc) =>
        oc.column('case_id').doUpdateSet({
          child_description: (eb) => eb.ref('excluded.child_description'),
        }),
      )
      .execute();
  }
  console.log(`home_ai_parent_life_case: ${lifeCases.length} rows upserted`);
}

async function seedAvoidPhrases(): Promise<void> {
  for (const row of avoidPhrases) {
    await db
      .insertInto('home_ai_avoid_phrase')
      .values({
        phrase_id: row.phraseId,
        priority_domain: row.priorityDomain as 'PLANNING' | 'ATTENTION' | 'SIMULTANEOUS' | 'SUCCESSIVE',
        phrase: row.phrase,
        why: row.why,
        instead_say: row.insteadSay,
      })
      .onConflict((oc) =>
        oc.column('phrase_id').doUpdateSet({
          phrase: (eb) => eb.ref('excluded.phrase'),
        }),
      )
      .execute();
  }
  console.log(`home_ai_avoid_phrase: ${avoidPhrases.length} rows upserted`);
}

async function seedTeacherStrategies(): Promise<void> {
  for (const row of teacherStrategies) {
    await db
      .insertInto('home_ai_teacher_strategy')
      .values({
        template_id: row.templateId,
        priority_domain: row.priorityDomain as 'PLANNING' | 'ATTENTION' | 'SIMULTANEOUS' | 'SUCCESSIVE',
        characteristic: row.characteristic,
        classroom_behavior: row.classroomBehavior,
        strength_utilization: row.strengthUtilization,
        support_strategy: row.supportStrategy,
        teacher_questions: JSON.stringify(row.teacherQuestions),
        observation_checklist: JSON.stringify(row.observationChecklist),
      })
      .onConflict((oc) =>
        oc.column('template_id').doUpdateSet({
          characteristic: (eb) => eb.ref('excluded.characteristic'),
        }),
      )
      .execute();
  }
  console.log(`home_ai_teacher_strategy: ${teacherStrategies.length} rows upserted`);
}

async function main(): Promise<void> {
  await seedFaqs();
  await seedLifeCases();
  await seedAvoidPhrases();
  await seedTeacherStrategies();
  console.log('Home AI 상담사 콘텐츠 라이브러리 seed complete.');
}

main()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
