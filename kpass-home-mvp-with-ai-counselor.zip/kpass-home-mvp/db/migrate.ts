/* eslint-disable no-console */
import { Pool } from 'pg';
import fs from 'fs';
import path from 'path';

async function main(): Promise<void> {
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const migrationsDir = path.join(__dirname, 'migrations');
  const files = fs
    .readdirSync(migrationsDir)
    .filter((f) => f.endsWith('.sql'))
    .sort();

  const client = await pool.connect();
  try {
    await client.query(
      'CREATE TABLE IF NOT EXISTS __migrations (name VARCHAR(255) PRIMARY KEY, applied_at TIMESTAMP NOT NULL DEFAULT now())',
    );

    for (const file of files) {
      const already = await client.query('SELECT 1 FROM __migrations WHERE name = $1', [file]);
      if (already.rowCount && already.rowCount > 0) {
        console.log(`SKIP  ${file} (이미 적용됨)`);
        continue;
      }
      const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf-8');
      console.log(`APPLY ${file}`);
      await client.query('BEGIN');
      try {
        await client.query(sql);
        await client.query('INSERT INTO __migrations(name) VALUES ($1)', [file]);
        await client.query('COMMIT');
      } catch (err) {
        await client.query('ROLLBACK');
        throw err;
      }
    }
    console.log('마이그레이션 완료.');
  } finally {
    client.release();
    await pool.end();
  }
}

main().catch((err) => {
  console.error('마이그레이션 실패:', err);
  process.exit(1);
});
