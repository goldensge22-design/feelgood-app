/* eslint-disable no-console */
import { db } from '@/shared/config/db';
import papers from './seed-data/research_papers_100.json';
import library from './seed-data/pass_training_library_400.json';
import profiles81 from './seed-data/cognitive_profile_81.json';
import ageBands from './seed-data/age_band_mapping.json';
import difficultyLevels from './seed-data/difficulty_mapping.json';

/**
 * PASS Cognitive Training Library 시드 스크립트.
 *
 * 중요: 이 스크립트는 "데이터 적재"만 수행한다. 어떤 형태로든 AI를 호출하여
 * 프로그램을 생성하지 않는다 (지시서 원칙: "AI는 런타임에서 새로운 훈련을
 * 생성하지 않는다"). 400개 -> 600/1000/2000개로 확장할 때도 이 스크립트에
 * 새 JSON 파일을 추가로 로드하는 것만으로 확장되며, 로직 변경이 필요 없다.
 */

interface PaperSeed {
  paper_id: string; // 'P001'
  authors: string;
  title: string;
  venue: string;
  category: string;
  year: number;
  influence_summary: string;
  source_link: string;
}

interface ProgramSeed {
  program_id: string;
  program_name: string;
  pass_domain: string;
  sub_cognitive_function: string;
  target_age: string;
  reference_paper_id: string; // 'P001;P002' (';' 구분)
  evidence_level: string; // 'direct_evidence;indirect_evidence' (paper_id 순서 매칭)
  [key: string]: unknown;
}

async function seedResearchPapers(): Promise<void> {
  for (const p of papers as PaperSeed[]) {
    await db
      .insertInto('research_paper')
      .values({
        title: p.title,
        authors: p.authors,
        year: p.year,
        pdf_url: null,
        doi: null,
        paper_code: p.paper_id,
        category: p.category,
        influence_summary: p.influence_summary,
        source_link: p.source_link,
      })
      .onConflict((oc) => oc.column('paper_code').doUpdateSet({
        title: (eb) => eb.ref('excluded.title'),
      }))
      .execute();
  }
  console.log(`research_paper: ${papers.length} rows upserted`);
}

async function seedTrainingLibrary(): Promise<void> {
  const items = library as ProgramSeed[];
  for (const item of items) {
    const { reference_paper_id, evidence_level, ...rest } = item;

    await db
      .insertInto('pass_training_program')
      .values({
        ...(rest as Record<string, unknown>),
        pass_domain: rest.pass_domain as 'PLANNING' | 'ATTENTION' | 'SIMULTANEOUS' | 'SUCCESSIVE',
        observation_checklist: JSON.parse(rest.observation_checklist as string),
        difficulty_adjustment: JSON.parse(rest.difficulty_adjustment as string),
      } as never)
      .onConflict((oc) => oc.column('program_id').doUpdateSet({
        program_name: (eb) => eb.ref('excluded.program_name'),
        updated_at: new Date(),
      }))
      .execute();

    const paperIds = reference_paper_id.split(';');
    const levels = evidence_level.split(';');
    for (let i = 0; i < paperIds.length; i += 1) {
      await db
        .insertInto('program_reference_paper')
        .values({
          program_id: item.program_id,
          paper_code: paperIds[i],
          evidence_level: (levels[i] ?? levels[0]) as
            | 'direct_evidence'
            | 'indirect_evidence'
            | 'theoretical_evidence',
        })
        .onConflict((oc) => oc.columns(['program_id', 'paper_code']).doNothing())
        .execute();
    }
  }
  console.log(`pass_training_program: ${items.length} rows upserted`);
}

async function seedProfiles(): Promise<void> {
  for (const row of profiles81) {
    await db
      .insertInto('cognitive_profile_81')
      .values(row as never)
      .onConflict((oc) => oc.column('profile_code').doNothing())
      .execute();
  }
  console.log(`cognitive_profile_81: ${profiles81.length} rows upserted`);
}

async function seedAgeAndDifficulty(): Promise<void> {
  for (const row of ageBands) {
    await db
      .insertInto('age_band_mapping')
      .values(row as never)
      .onConflict((oc) => oc.column('age_code').doNothing())
      .execute();
  }
  for (const row of difficultyLevels) {
    await db
      .insertInto('difficulty_mapping')
      .values(row as never)
      .onConflict((oc) => oc.column('difficulty_level').doNothing())
      .execute();
  }
  console.log(`age_band_mapping: ${ageBands.length}, difficulty_mapping: ${difficultyLevels.length}`);
}

async function main(): Promise<void> {
  await seedResearchPapers();
  await seedProfiles();
  await seedAgeAndDifficulty();
  await seedTrainingLibrary();
  console.log('PASS Cognitive Training Library seed complete.');
}

main()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
