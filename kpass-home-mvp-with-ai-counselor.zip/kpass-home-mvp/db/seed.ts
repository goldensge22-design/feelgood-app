/* eslint-disable no-console */
import { db } from '@/shared/config/db';

/**
 * 개발/테스트용 시드 스크립트.
 * org_type='HOME' 조직을 "가족 단위"로 사용하는 TODO(DB-002) 설계를 반영한다.
 */
async function main(): Promise<void> {
  const org = await db
    .insertInto('organization')
    .values({ name: '김민준 가정', org_type: 'HOME' })
    .onConflict((oc) => oc.doNothing())
    .returningAll()
    .executeTakeFirst();

  const organizationId =
    org?.organization_id ??
    (await db
      .selectFrom('organization')
      .select('organization_id')
      .where('name', '=', '김민준 가정')
      .executeTakeFirstOrThrow()).organization_id;

  await db
    .insertInto('user_account')
    .values({
      organization_id: organizationId,
      email: 'parent@example.com',
      role: 'PARENT',
      status: 'ACTIVE',
    })
    .onConflict((oc) => oc.column('email').doNothing())
    .execute();

  const existingStudent = await db
    .selectFrom('student')
    .select('student_id')
    .where('organization_id', '=', organizationId)
    .where('name', '=', '김민준')
    .executeTakeFirst();

  const studentId =
    existingStudent?.student_id ??
    (
      await db
        .insertInto('student')
        .values({
          organization_id: organizationId,
          name: '김민준',
          birth_date: new Date('2018-05-14'),
          grade: 2,
        })
        .returning('student_id')
        .executeTakeFirstOrThrow()
    ).student_id;

  const existingResult = await db
    .selectFrom('pass_result')
    .select('result_id')
    .where('student_id', '=', studentId)
    .executeTakeFirst();

  const resultId =
    existingResult?.result_id ??
    (
      await db
        .insertInto('pass_result')
        .values({
          student_id: studentId,
          planning: 82,
          attention: 91,
          simultaneous: 108,
          successive: 88,
          total_index: 92,
          tested_at: new Date(),
        })
        .returning('result_id')
        .executeTakeFirstOrThrow()
    ).result_id;

  await db
    .insertInto('pass_profile')
    .values({
      result_id: resultId,
      dominance_type: '우뇌우세형',
      strength_domain: 'SIMULTANEOUS',
      priority_domain: 'PLANNING',
      ai_summary:
        '계획을 세우기 전 바로 행동하는 경향이 있어, 순서 계획 활동을 우선 추천합니다. (Round4 예시 문구, Mock)',
    })
    .onConflict((oc) => oc.column('result_id').doNothing())
    .execute();

  const activities = [
    { activity_id: 'ACT-P-H-001', activity_name: '내일 가방 챙기기 순서 정하기', pass_domain: 'PLANNING', environment: 'HOME', age_band: '초1~2', level: 1 },
    { activity_id: 'ACT-A-H-001', activity_name: '빨간 신호 멈춤 놀이', pass_domain: 'ATTENTION', environment: 'HOME', age_band: '만5~초2', level: 1 },
    { activity_id: 'ACT-SI-H-001', activity_name: '그림 보고 이야기 만들기', pass_domain: 'SIMULTANEOUS', environment: 'HOME', age_band: '초1~4', level: 2 },
    { activity_id: 'ACT-SU-H-001', activity_name: '하루 일과 순서 말하기', pass_domain: 'SUCCESSIVE', environment: 'HOME', age_band: '만6~초2', level: 1 },
  ];
  for (const a of activities) {
    await db.insertInto('activity').values(a).onConflict((oc) => oc.column('activity_id').doNothing()).execute();
  }

  const papers = [
    { paper_id: 1, title: 'Planning Strategy Training in Early Elementary Students', year: 2018 },
    { paper_id: 2, title: 'Selective Attention Training via Signal Games', year: 2019 },
  ];
  for (const p of papers) {
    await db.insertInto('research_paper').values(p).onConflict((oc) => oc.column('paper_id').doNothing()).execute();
  }

  const evidenceCodes = [
    { evidence_code: 'PASS-E0012', paper_id: 1, evidence_level: 5, summary: 'Planning 전략 훈련 근거 (Mock)' },
    { evidence_code: 'PASS-E0048', paper_id: 2, evidence_level: 4, summary: '선택적 주의 훈련 근거 (Mock)' },
    { evidence_code: 'PASS-E0032', paper_id: 1, evidence_level: 5, summary: '시각 통합 근거 (Mock)' },
    { evidence_code: 'PASS-E0021', paper_id: 2, evidence_level: 5, summary: '순차처리 근거 (Mock)' },
  ];
  for (const e of evidenceCodes) {
    await db
      .insertInto('evidence_code')
      .values(e)
      .onConflict((oc) => oc.column('evidence_code').doNothing())
      .execute();
  }

  console.log('Seed 완료: parent@example.com / 비밀번호는 4자 이상 아무 값 (TODO(DB-001) 참고)');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await db.destroy();
  });
