-- =====================================================================
-- 0004_home_ai_counselor.sql
-- Home AI 상담사(AI Coach) — 결과지(요약보기/인지훈련 플래너/인지+정서훈련
-- 프로그램)와 사용자를 "연결"만 하는 Hub. 이 마이그레이션이 추가하는 모든
-- 테이블은 콘텐츠 라이브러리(읽기 전용, 시드로만 채움) 또는 상담 로그이며,
-- 어떤 테이블도 새 훈련 프로그램을 정의하지 않는다 — 훈련은 항상
-- pass_training_program을 참조/선택할 뿐이다.
-- =====================================================================

-- ---------------------------------------------------------------------
-- (1) 부모용 FAQ 라이브러리 — "부모가 이해하기 쉽게 설명"의 6번 섹션
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS home_ai_parent_faq (
  faq_id          VARCHAR(30) PRIMARY KEY,
  priority_domain VARCHAR(20) CHECK (priority_domain IN ('PLANNING','ATTENTION','SIMULTANEOUS','SUCCESSIVE')),
  question        TEXT NOT NULL,
  answer          TEXT NOT NULL
);

-- ---------------------------------------------------------------------
-- (2) 부모용 생활 사례 라이브러리 — "학교에서/집에서 이렇게 보일 수 있어요"
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS home_ai_parent_life_case (
  case_id           VARCHAR(30) PRIMARY KEY,
  priority_domain   VARCHAR(20) NOT NULL CHECK (priority_domain IN ('PLANNING','ATTENTION','SIMULTANEOUS','SUCCESSIVE')),
  child_description TEXT NOT NULL,
  school_behavior   TEXT NOT NULL,
  home_behavior     TEXT NOT NULL,
  parent_guidance   TEXT NOT NULL,
  UNIQUE(priority_domain)
);

-- ---------------------------------------------------------------------
-- (3) "하면 안 되는 말" 라이브러리
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS home_ai_avoid_phrase (
  phrase_id       VARCHAR(30) PRIMARY KEY,
  priority_domain VARCHAR(20) NOT NULL CHECK (priority_domain IN ('PLANNING','ATTENTION','SIMULTANEOUS','SUCCESSIVE')),
  phrase          TEXT NOT NULL,
  why             TEXT NOT NULL,
  instead_say     TEXT NOT NULL,
  UNIQUE(priority_domain)
);

-- ---------------------------------------------------------------------
-- (4) 선생님용 학생 이해하기 전략 라이브러리
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS home_ai_teacher_strategy (
  template_id           VARCHAR(30) PRIMARY KEY,
  priority_domain        VARCHAR(20) NOT NULL CHECK (priority_domain IN ('PLANNING','ATTENTION','SIMULTANEOUS','SUCCESSIVE')),
  characteristic          TEXT NOT NULL,
  classroom_behavior      TEXT NOT NULL,
  strength_utilization    TEXT NOT NULL,
  support_strategy        TEXT NOT NULL,
  teacher_questions        JSONB NOT NULL, -- string[]
  observation_checklist    JSONB NOT NULL, -- string[]
  UNIQUE(priority_domain)
);

-- ---------------------------------------------------------------------
-- (5) Home AI 상담(생성형 AI) 로그 — 부모 AI 상담 / 교사 AI 상담 공용.
-- 하루 10회 제한(정책)의 근거 데이터이자 상담 이력이다. 여기 저장된 값은
-- "상담 내용"일 뿐 새 훈련 프로그램 정의가 아니며, linked_program_id는
-- 항상 pass_training_program을 참조한다(있을 경우).
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS home_ai_chat_log (
  log_id              BIGSERIAL PRIMARY KEY,
  student_id          BIGINT      NOT NULL REFERENCES student(student_id),
  requested_by_user_id BIGINT     NOT NULL REFERENCES user_account(user_id),
  audience            VARCHAR(10) NOT NULL CHECK (audience IN ('PARENT','TEACHER')),
  user_message         TEXT        NOT NULL,
  ai_response          TEXT        NOT NULL,
  linked_program_id     VARCHAR(40) REFERENCES pass_training_program(program_id),
  created_at            TIMESTAMP   NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_haicl_rate_limit
  ON home_ai_chat_log(requested_by_user_id, audience, created_at);
CREATE INDEX IF NOT EXISTS idx_haicl_student ON home_ai_chat_log(student_id);
