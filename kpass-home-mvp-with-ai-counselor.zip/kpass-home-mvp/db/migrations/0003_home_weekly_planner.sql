-- =====================================================================
-- 0003_home_weekly_planner.sql
-- Home AI = Weekly Planner AI (챗봇 아님)
--
-- 이 마이그레이션은 두 가지를 한다:
--   (A) training_history에 pass_domain을 추가해, 추천 엔진이 "영역별" 이력을
--       조회할 수 있게 한다 (기존에는 전체 이력만 조회 가능해 난이도 조정이
--       영역을 구분하지 못했다 — 정확성 결함 수정).
--   (B) Weekly Planner 전용 4개 테이블을 추가한다. 어떤 테이블도 activity를
--       참조하지 않으며, 모두 pass_training_program만 참조한다.
-- =====================================================================

-- ---------------------------------------------------------------------
-- (A) training_history 영역 컬럼 보강
-- ---------------------------------------------------------------------
ALTER TABLE training_history
  ADD COLUMN IF NOT EXISTS pass_domain VARCHAR(20)
    CHECK (pass_domain IN ('PLANNING','ATTENTION','SIMULTANEOUS','SUCCESSIVE')),
  ADD COLUMN IF NOT EXISTS difficulty_level SMALLINT CHECK (difficulty_level BETWEEN 1 AND 5);

-- 기존 행(있다면) 채우기: pass_training_program 조인으로 역채움
UPDATE training_history th
SET pass_domain = p.pass_domain, difficulty_level = p.difficulty_level
FROM pass_training_program p
WHERE th.program_id = p.program_id AND th.pass_domain IS NULL;

CREATE INDEX IF NOT EXISTS idx_th_student_domain ON training_history(student_id, pass_domain);

-- ---------------------------------------------------------------------
-- (B-1) 주간 훈련 계획 (한 학생당 한 주에 1개, 상태로 관리)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS home_training_plan (
  plan_id             BIGSERIAL PRIMARY KEY,
  student_id          BIGINT      NOT NULL REFERENCES student(student_id),
  result_id           BIGINT      NOT NULL REFERENCES pass_result(result_id),
  profile_code        VARCHAR(10) NOT NULL REFERENCES cognitive_profile_81(profile_code),
  age_code            VARCHAR(10) NOT NULL REFERENCES age_band_mapping(age_code),
  week_start_date     DATE        NOT NULL, -- 월요일
  week_end_date       DATE        NOT NULL, -- 금요일
  status              VARCHAR(20) NOT NULL DEFAULT 'ACTIVE'
                        CHECK (status IN ('ACTIVE','COMPLETED','ARCHIVED')),
  domain_weights      JSONB       NOT NULL, -- 이번 주 영역별 배정 세션 수(XAI 근거 보존용)
  created_at          TIMESTAMP   NOT NULL DEFAULT now(),
  UNIQUE(student_id, week_start_date)
);
CREATE INDEX IF NOT EXISTS idx_htp_student_status ON home_training_plan(student_id, status);

-- ---------------------------------------------------------------------
-- (B-2) 주간 계획의 개별 훈련 항목 (하루 2~3개, program_id는 Library만 참조)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS home_training_plan_item (
  item_id           BIGSERIAL PRIMARY KEY,
  plan_id           BIGINT      NOT NULL REFERENCES home_training_plan(plan_id),
  program_id        VARCHAR(40) NOT NULL REFERENCES pass_training_program(program_id),
  pass_domain       VARCHAR(20) NOT NULL CHECK (pass_domain IN ('PLANNING','ATTENTION','SIMULTANEOUS','SUCCESSIVE')),
  day_index          SMALLINT    NOT NULL CHECK (day_index BETWEEN 1 AND 5), -- 1=월 .. 5=금
  day_date           DATE        NOT NULL,
  order_in_day        SMALLINT    NOT NULL,
  training_goal        TEXT        NOT NULL, -- program.training_goal 복사(스냅샷, 라이브러리 변경에도 계획 이력 불변)
  duration              VARCHAR(30),
  parent_guidance       TEXT        NOT NULL, -- program.home_activity_* + parent_question 조합 스냅샷
  is_supplementary      BOOLEAN     NOT NULL DEFAULT false, -- 반복 실패 영역 보조훈련 여부
  is_completed           BOOLEAN     NOT NULL DEFAULT false,
  completed_at            TIMESTAMP,
  UNIQUE(plan_id, day_index, order_in_day)
);
CREATE INDEX IF NOT EXISTS idx_htpi_plan ON home_training_plan_item(plan_id);
CREATE INDEX IF NOT EXISTS idx_htpi_program ON home_training_plan_item(program_id);

-- ---------------------------------------------------------------------
-- (B-3) 이행 기록 (완료 여부/성공률/부모 메모/아이 반응)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS home_training_log (
  log_id           BIGSERIAL PRIMARY KEY,
  item_id          BIGINT      NOT NULL REFERENCES home_training_plan_item(item_id),
  student_id       BIGINT      NOT NULL REFERENCES student(student_id),
  success_rate     DECIMAL(5,2) NOT NULL CHECK (success_rate BETWEEN 0 AND 100),
  outcome          VARCHAR(20) NOT NULL CHECK (outcome IN ('SUCCESS','PARTIAL','FAIL')),
  parent_memo      TEXT,
  child_reaction   TEXT,
  logged_at        TIMESTAMP   NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_htl_student ON home_training_log(student_id);
CREATE INDEX IF NOT EXISTS idx_htl_item ON home_training_log(item_id);

-- ---------------------------------------------------------------------
-- (B-4) 4주 월간 리포트
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS home_monthly_report (
  report_id                 BIGSERIAL PRIMARY KEY,
  student_id                 BIGINT      NOT NULL REFERENCES student(student_id),
  report_month                VARCHAR(7)  NOT NULL, -- 'YYYY-MM'
  domain_change                JSONB       NOT NULL, -- {"PLANNING": {"week1Avg":.., "week4Avg":.., "delta":..}, ...}
  completion_rate              DECIMAL(5,2) NOT NULL,
  strength_maintained          JSONB       NOT NULL, -- ["SUCCESSIVE"] 형태
  weakness_progress            JSONB       NOT NULL, -- {"domain":"PLANNING","improvementRate":12.5}
  next_month_recommendation    TEXT        NOT NULL,
  generated_at                  TIMESTAMP   NOT NULL DEFAULT now(),
  UNIQUE(student_id, report_month)
);
CREATE INDEX IF NOT EXISTS idx_hmr_student ON home_monthly_report(student_id);
