-- =====================================================================
-- 0002_pass_training_library.sql
-- PASS Cognitive Training Library + Program Recommendation Engine
--
-- 목적:
--   기존 activity 테이블(요약형)을 PASS_Cognitive_Training_Standard_Manual
--   v1.0의 전체 필드를 담는 pass_training_program 테이블로 확장하고,
--   81 Cognitive Profile x Age x Difficulty x Training History 기반
--   추천에 필요한 매핑 테이블을 추가한다.
--
--   Home AI / Teacher AI는 이 테이블들만 조회한다(런타임 생성 금지).
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. PASS Cognitive Training Library (핵심 테이블, 400 -> 확장 가능)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pass_training_program (
  program_id                  VARCHAR(40)  PRIMARY KEY,
  program_name                VARCHAR(200) NOT NULL,
  pass_domain                 VARCHAR(20)  NOT NULL CHECK (pass_domain IN ('PLANNING','ATTENTION','SIMULTANEOUS','SUCCESSIVE')),
  sub_cognitive_function      VARCHAR(200) NOT NULL,
  target_age                  VARCHAR(50)  NOT NULL,
  recommended_user            TEXT,
  difficulty_level            SMALLINT     NOT NULL CHECK (difficulty_level BETWEEN 1 AND 5),
  duration                    VARCHAR(30),
  group_size                  VARCHAR(50),
  materials                   TEXT,

  training_goal                TEXT,
  expected_cognitive_change    TEXT,
  expected_behavioral_change   TEXT,
  school_change                TEXT,
  home_connection_goal         TEXT,

  pass_theory_rationale        TEXT,
  luria_rationale               TEXT,
  executive_function_rationale  TEXT,
  working_memory_rationale      TEXT,
  attention_control_rationale   TEXT,
  research_evidence             TEXT,
  reference_paper_id            TEXT,   -- ';' 구분 다중 참조 (program_reference 테이블과 병행)
  reference_title                TEXT,
  reference_authors              TEXT,
  reference_year                 TEXT,
  evidence_level                 TEXT,  -- direct_evidence;indirect_evidence;theoretical_evidence (paper_id 순서 매칭)

  environment                    VARCHAR(100),
  safety_notes                   TEXT,

  procedure_intro                TEXT,
  procedure_instruction          TEXT,
  procedure_demo                 TEXT,
  procedure_activity             TEXT,
  procedure_feedback             TEXT,

  teacher_script_intro           TEXT,
  teacher_script_activity        TEXT,
  teacher_questions              TEXT,
  encouragement_script           TEXT,
  closing_script                 TEXT,

  observation_checklist          JSONB,
  difficulty_adjustment          JSONB,

  home_activity_5min             TEXT,
  home_activity_10min            TEXT,
  home_activity_15min            TEXT,
  parent_question                TEXT,
  parent_feedback                TEXT,

  ai_prompt                      TEXT,  -- library_lookup_only 참조 문자열. 절대 런타임 생성 프롬프트 아님.
  reward_rule                    TEXT,
  success_rule                   TEXT,
  fail_rule                      TEXT,
  repeat_rule                    TEXT,

  reassessment_4week             TEXT,
  reassessment_8week             TEXT,
  reassessment_12week            TEXT,

  caution                        TEXT,
  version                        VARCHAR(20) NOT NULL DEFAULT '1.0',
  approval_status                VARCHAR(30) NOT NULL DEFAULT 'draft_pending_review'
                                  CHECK (approval_status IN ('draft_pending_review','approved','retired')),

  created_at                     TIMESTAMP NOT NULL DEFAULT now(),
  updated_at                     TIMESTAMP NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_ptp_domain      ON pass_training_program(pass_domain);
CREATE INDEX IF NOT EXISTS idx_ptp_age         ON pass_training_program(target_age);
CREATE INDEX IF NOT EXISTS idx_ptp_difficulty  ON pass_training_program(difficulty_level);
CREATE INDEX IF NOT EXISTS idx_ptp_approval    ON pass_training_program(approval_status);
-- 확장(600/1000/2000) 시에도 동일 인덱스로 조회 성능 유지 -> 로직 변경 불필요

-- ---------------------------------------------------------------------
-- 1-b. research_paper 테이블 보강: PASS_Theory_100_Key_Papers.xlsx의
--      안정적 문자열 ID(P001~P100)를 저장할 컬럼 추가 (기존 BIGSERIAL PK 유지)
-- ---------------------------------------------------------------------
ALTER TABLE research_paper
  ADD COLUMN IF NOT EXISTS paper_code VARCHAR(10) UNIQUE, -- P001..P100 (엑셀 원본 순번 기준)
  ADD COLUMN IF NOT EXISTS category   VARCHAR(50),
  ADD COLUMN IF NOT EXISTS influence_summary TEXT,
  ADD COLUMN IF NOT EXISTS source_link TEXT;

-- ---------------------------------------------------------------------
-- 2. 프로그램 <-> 논문 정규화 매핑 (research_evidence 근거 추적용)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS program_reference_paper (
  id                BIGSERIAL PRIMARY KEY,
  program_id        VARCHAR(40) NOT NULL REFERENCES pass_training_program(program_id),
  paper_code        VARCHAR(20) NOT NULL REFERENCES research_paper(paper_code) DEFERRABLE INITIALLY DEFERRED,
  evidence_level    VARCHAR(20) NOT NULL CHECK (evidence_level IN ('direct_evidence','indirect_evidence','theoretical_evidence')),
  UNIQUE(program_id, paper_code)
);
CREATE INDEX IF NOT EXISTS idx_prp_program ON program_reference_paper(program_id);

-- ---------------------------------------------------------------------
-- 3. 81 Cognitive Profile Mapping
--    (Planning/Attention/Simultaneous/Successive 각 상/중/하 3단계 => 3^4 = 81)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cognitive_profile_81 (
  profile_code      VARCHAR(10) PRIMARY KEY, -- 예: HHLM (P=High,A=High,S=Low,Sc=Mid)
  planning_level    VARCHAR(1) NOT NULL CHECK (planning_level IN ('H','M','L')),
  attention_level   VARCHAR(1) NOT NULL CHECK (attention_level IN ('H','M','L')),
  simultaneous_level VARCHAR(1) NOT NULL CHECK (simultaneous_level IN ('H','M','L')),
  successive_level  VARCHAR(1) NOT NULL CHECK (successive_level IN ('H','M','L')),
  priority_domain   VARCHAR(20),  -- 가장 낮은 영역(약점) - 자동 계산되어 저장
  strength_domain   VARCHAR(20),  -- 가장 높은 영역(강점) - 자동 계산되어 저장
  description       TEXT
);

-- ---------------------------------------------------------------------
-- 4. Age Mapping (연령대 <-> target_age 문자열 표준화)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS age_band_mapping (
  age_code    VARCHAR(10) PRIMARY KEY,   -- '5-7','8-10','11-13','14-16','17-19'
  age_label   VARCHAR(50) NOT NULL,
  tool        VARCHAR(20) NOT NULL,      -- K-PASS / D-CAS / K-PASS/D-CAS
  min_age     SMALLINT NOT NULL,
  max_age     SMALLINT NOT NULL
);

-- ---------------------------------------------------------------------
-- 5. Difficulty Mapping (Level 1~5 <-> 승급/강등 임계값)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS difficulty_mapping (
  difficulty_level  SMALLINT PRIMARY KEY CHECK (difficulty_level BETWEEN 1 AND 5),
  label             VARCHAR(50),
  promote_threshold DECIMAL(5,2) NOT NULL DEFAULT 80.00, -- 성공률 % 승급 기준
  demote_threshold  DECIMAL(5,2) NOT NULL DEFAULT 50.00  -- 성공률 % 강등 기준
);

-- ---------------------------------------------------------------------
-- 6. Training History Mapping (학생별 프로그램 수행 이력 -> 추천 엔진 입력)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS training_history (
  history_id     BIGSERIAL PRIMARY KEY,
  student_id     BIGINT      NOT NULL REFERENCES student(student_id),
  program_id     VARCHAR(40) NOT NULL REFERENCES pass_training_program(program_id),
  performed_at   TIMESTAMP   NOT NULL DEFAULT now(),
  success_rate   DECIMAL(5,2),          -- 0~100
  outcome        VARCHAR(20),           -- SUCCESS/PARTIAL/FAIL
  notes          TEXT
);
CREATE INDEX IF NOT EXISTS idx_th_student ON training_history(student_id);
CREATE INDEX IF NOT EXISTS idx_th_program ON training_history(program_id);

-- ---------------------------------------------------------------------
-- 7. recommendation 테이블 확장: activity_id -> program_id 참조로 전환
--    (기존 activity 테이블/activity_id 컬럼은 하위호환을 위해 당분간 유지,
--     신규 로직은 program_id만 사용한다. 완전 제거는 별도 마이그레이션 0003에서.)
-- ---------------------------------------------------------------------
ALTER TABLE recommendation
  ADD COLUMN IF NOT EXISTS program_id VARCHAR(40) REFERENCES pass_training_program(program_id),
  ADD COLUMN IF NOT EXISTS profile_code VARCHAR(10) REFERENCES cognitive_profile_81(profile_code),
  ADD COLUMN IF NOT EXISTS recommended_for VARCHAR(20) NOT NULL DEFAULT 'HOME' -- HOME/TEACHER_INDIVIDUAL/TEACHER_GROUP/TEACHER_CLASS
    CHECK (recommended_for IN ('HOME','TEACHER_INDIVIDUAL','TEACHER_GROUP','TEACHER_CLASS')),
  ADD COLUMN IF NOT EXISTS engine_version VARCHAR(20) NOT NULL DEFAULT 'rec-engine-1.0';

CREATE INDEX IF NOT EXISTS idx_recommendation_program ON recommendation(program_id);
