-- =============================================================================
-- K-PASS Home AI Teacher MVP - Initial Schema
-- 원본: KPASS_Database_Specification_ERD_v1_1.xlsx (ERD_Mermaid 시트 기준)
--
-- 정책(2026-07-02 확정):
--   ERD에 정의된 테이블/필드만 구현한다. parent_profile, teacher_profile,
--   dcas_result, reassessment 등 00_ERD_Overview 시트에 "언급만" 되고 실제 필드
--   정의가 없는 테이블은 생성하지 않는다.
--
-- TODO(DB-001): user_account에 인증 credential 컬럼이 ERD에 없음. 실제 배포 전
--   password_hash 컬럼 추가 및 services/auth/CredentialVerifier.ts 교체 필요.
-- TODO(DB-002): parent-child 연결 테이블이 ERD에 없어, organization(org_type='HOME')을
--   가족 단위로 사용한다. 자세한 내용은 docs/ASSUMPTIONS_AND_TODOS.md 참고.
-- TODO(DB-003): reassessment 테이블이 ERD에 없어 growth_report.next_recommendation
--   텍스트 필드로만 재검사 안내를 표현한다.
-- =============================================================================

CREATE TABLE IF NOT EXISTS organization (
  organization_id BIGSERIAL PRIMARY KEY,
  name             VARCHAR(100) NOT NULL,
  org_type         VARCHAR(30)  NOT NULL, -- KINDERGARTEN/SCHOOL/HOME/CLINIC
  created_at       TIMESTAMP    NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS user_account (
  user_id         BIGSERIAL PRIMARY KEY,
  organization_id BIGINT       NOT NULL REFERENCES organization(organization_id),
  email           VARCHAR(150) NOT NULL UNIQUE,
  role            VARCHAR(30)  NOT NULL, -- ADMIN/TEACHER/PARENT/STUDENT
  status          VARCHAR(20)  NOT NULL  -- ACTIVE/INACTIVE
);
CREATE INDEX IF NOT EXISTS idx_user_account_org ON user_account(organization_id);

-- ERD에 정의되어 있으나 Home MVP 범위 밖(유치원/학교 전용). FK 무결성을 위해서만 존재.
CREATE TABLE IF NOT EXISTS class_group (
  class_id        BIGSERIAL PRIMARY KEY,
  organization_id BIGINT      NOT NULL REFERENCES organization(organization_id),
  name            VARCHAR(80) NOT NULL,
  grade           INT,
  age_band        VARCHAR(30)
);
CREATE INDEX IF NOT EXISTS idx_class_group_org ON class_group(organization_id);

CREATE TABLE IF NOT EXISTS student (
  student_id      BIGSERIAL PRIMARY KEY,
  organization_id BIGINT       NOT NULL REFERENCES organization(organization_id),
  class_id        BIGINT       REFERENCES class_group(class_id),
  name            VARCHAR(100) NOT NULL,
  birth_date      DATE,
  grade           INT
);
CREATE INDEX IF NOT EXISTS idx_student_org ON student(organization_id);
CREATE INDEX IF NOT EXISTS idx_student_class ON student(class_id);

CREATE TABLE IF NOT EXISTS pass_result (
  result_id    BIGSERIAL PRIMARY KEY,
  student_id   BIGINT    NOT NULL REFERENCES student(student_id),
  planning     INT       NOT NULL,
  attention    INT       NOT NULL,
  simultaneous INT       NOT NULL,
  successive   INT       NOT NULL,
  total_index  INT       NOT NULL,
  tested_at    TIMESTAMP NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_pass_result_student ON pass_result(student_id);

CREATE TABLE IF NOT EXISTS pass_profile (
  profile_id      BIGSERIAL PRIMARY KEY,
  result_id       BIGINT      NOT NULL UNIQUE REFERENCES pass_result(result_id),
  dominance_type  VARCHAR(30),
  strength_domain VARCHAR(30),
  priority_domain VARCHAR(30),
  ai_summary      TEXT
);

CREATE TABLE IF NOT EXISTS research_paper (
  paper_id BIGSERIAL PRIMARY KEY,
  title    TEXT NOT NULL,
  authors  TEXT,
  year     INT,
  doi      VARCHAR(150),
  pdf_url  TEXT
);

CREATE TABLE IF NOT EXISTS evidence_code (
  evidence_code  VARCHAR(30) PRIMARY KEY,
  paper_id       BIGINT REFERENCES research_paper(paper_id),
  evidence_level INT, -- 1~5
  summary        TEXT
);
CREATE INDEX IF NOT EXISTS idx_evidence_code_paper ON evidence_code(paper_id);

CREATE TABLE IF NOT EXISTS activity (
  activity_id   VARCHAR(30) PRIMARY KEY,
  activity_name VARCHAR(150) NOT NULL,
  pass_domain   VARCHAR(30),
  environment   VARCHAR(30), -- KINDERGARTEN/SCHOOL/HOME
  age_band      VARCHAR(30),
  level         INT
);

CREATE TABLE IF NOT EXISTS activity_evidence_map (
  map_id            BIGSERIAL PRIMARY KEY,
  activity_id       VARCHAR(30) NOT NULL REFERENCES activity(activity_id),
  evidence_code     VARCHAR(30) NOT NULL REFERENCES evidence_code(evidence_code),
  relationship_type VARCHAR(50) -- supports/derived_from
);
CREATE INDEX IF NOT EXISTS idx_aem_activity ON activity_evidence_map(activity_id);
CREATE INDEX IF NOT EXISTS idx_aem_evidence ON activity_evidence_map(evidence_code);

CREATE TABLE IF NOT EXISTS training_method (
  training_id VARCHAR(30) PRIMARY KEY,
  name        VARCHAR(150) NOT NULL,
  description TEXT
);

CREATE TABLE IF NOT EXISTS teaching_strategy (
  strategy_id VARCHAR(30) PRIMARY KEY,
  name        VARCHAR(150) NOT NULL,
  description TEXT
);

CREATE TABLE IF NOT EXISTS recommendation (
  recommendation_id BIGSERIAL PRIMARY KEY,
  student_id        BIGINT NOT NULL REFERENCES student(student_id),
  result_id         BIGINT REFERENCES pass_result(result_id),
  activity_id       VARCHAR(30) REFERENCES activity(activity_id),
  reason            TEXT,
  confidence_score  DECIMAL(5, 2)
);
CREATE INDEX IF NOT EXISTS idx_recommendation_student ON recommendation(student_id);

CREATE TABLE IF NOT EXISTS ai_rule (
  rule_id        VARCHAR(30) PRIMARY KEY,
  condition_json JSONB,
  action_json    JSONB,
  priority       INT,
  is_active      BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS prompt_template (
  prompt_id     VARCHAR(30) PRIMARY KEY,
  prompt_type   VARCHAR(50), -- TEACHER/PARENT/XAI/REPORT
  template_text TEXT,
  version       VARCHAR(20)
);

CREATE TABLE IF NOT EXISTS daily_learning_plan (
  plan_id     BIGSERIAL PRIMARY KEY,
  student_id  BIGINT      NOT NULL REFERENCES student(student_id),
  date        DATE        NOT NULL,
  environment VARCHAR(30), -- HOME/SCHOOL/KG
  status      VARCHAR(20)  -- 생성/완료
);
CREATE INDEX IF NOT EXISTS idx_dlp_student ON daily_learning_plan(student_id);

CREATE TABLE IF NOT EXISTS activity_log (
  log_id       BIGSERIAL PRIMARY KEY,
  student_id   BIGINT      NOT NULL REFERENCES student(student_id),
  activity_id  VARCHAR(30) NOT NULL REFERENCES activity(activity_id),
  completed_at TIMESTAMP   NOT NULL,
  score        DECIMAL(5, 2),
  memo         TEXT
);
CREATE INDEX IF NOT EXISTS idx_activity_log_student ON activity_log(student_id);
CREATE INDEX IF NOT EXISTS idx_activity_log_activity ON activity_log(activity_id);

CREATE TABLE IF NOT EXISTS growth_report (
  report_id           BIGSERIAL PRIMARY KEY,
  student_id          BIGINT    NOT NULL REFERENCES student(student_id),
  period_start        DATE      NOT NULL,
  period_end          DATE      NOT NULL,
  summary              TEXT,
  next_recommendation  TEXT
);
CREATE INDEX IF NOT EXISTS idx_growth_report_student ON growth_report(student_id);
