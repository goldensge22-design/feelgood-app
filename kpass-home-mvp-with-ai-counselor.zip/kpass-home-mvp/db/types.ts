import { ColumnType, Generated } from 'kysely';

type Timestamp = ColumnType<Date, Date | string, Date | string>;
type DateOnly = ColumnType<Date, Date | string, Date | string>;

export interface OrganizationTable {
  organization_id: Generated<number>;
  name: string;
  org_type: string;
  created_at: Generated<Timestamp>;
}

export interface UserAccountTable {
  user_id: Generated<number>;
  organization_id: number;
  email: string;
  role: string;
  status: string;
}

export interface ClassGroupTable {
  class_id: Generated<number>;
  organization_id: number;
  name: string;
  grade: number | null;
  age_band: string | null;
}

export interface StudentTable {
  student_id: Generated<number>;
  organization_id: number;
  class_id: number | null;
  name: string;
  birth_date: DateOnly | null;
  grade: number | null;
}

export interface PassResultTable {
  result_id: Generated<number>;
  student_id: number;
  planning: number;
  attention: number;
  simultaneous: number;
  successive: number;
  total_index: number;
  tested_at: Timestamp;
}

export interface PassProfileTable {
  profile_id: Generated<number>;
  result_id: number;
  dominance_type: string | null;
  strength_domain: string | null;
  priority_domain: string | null;
  ai_summary: string | null;
}

export interface ResearchPaperTable {
  paper_id: Generated<number>;
  title: string;
  authors: string | null;
  year: number | null;
  doi: string | null;
  pdf_url: string | null;
  // 0002 마이그레이션 추가분: PASS_Theory_100_Key_Papers.xlsx 안정 ID
  paper_code: string | null; // 'P001'..'P100'
  category: string | null;
  influence_summary: string | null;
  source_link: string | null;
}

/**
 * PASS Cognitive Training Library — 지시서(리팩토링) 핵심 테이블.
 * PASS_Cognitive_Training_Standard_Manual_v1.0.docx의 전체 필드를 그대로 반영한다.
 * Home AI / Teacher AI는 이 테이블만 조회하며, 절대 런타임에 새 행을 생성하지 않는다.
 */
export interface PassTrainingProgramTable {
  program_id: string;
  program_name: string;
  pass_domain: 'PLANNING' | 'ATTENTION' | 'SIMULTANEOUS' | 'SUCCESSIVE';
  sub_cognitive_function: string;
  target_age: string;
  recommended_user: string | null;
  difficulty_level: number; // 1~5
  duration: string | null;
  group_size: string | null;
  materials: string | null;

  training_goal: string | null;
  expected_cognitive_change: string | null;
  expected_behavioral_change: string | null;
  school_change: string | null;
  home_connection_goal: string | null;

  pass_theory_rationale: string | null;
  luria_rationale: string | null;
  executive_function_rationale: string | null;
  working_memory_rationale: string | null;
  attention_control_rationale: string | null;
  research_evidence: string | null;
  reference_paper_id: string | null;
  reference_title: string | null;
  reference_authors: string | null;
  reference_year: string | null;
  evidence_level: string | null;

  environment: string | null;
  safety_notes: string | null;

  procedure_intro: string | null;
  procedure_instruction: string | null;
  procedure_demo: string | null;
  procedure_activity: string | null;
  procedure_feedback: string | null;

  teacher_script_intro: string | null;
  teacher_script_activity: string | null;
  teacher_questions: string | null;
  encouragement_script: string | null;
  closing_script: string | null;

  observation_checklist: unknown | null; // JSONB
  difficulty_adjustment: unknown | null; // JSONB

  home_activity_5min: string | null;
  home_activity_10min: string | null;
  home_activity_15min: string | null;
  parent_question: string | null;
  parent_feedback: string | null;

  ai_prompt: string | null; // library_lookup_only 참조 문자열 (런타임 생성 프롬프트 아님)
  reward_rule: string | null;
  success_rule: string | null;
  fail_rule: string | null;
  repeat_rule: string | null;

  reassessment_4week: string | null;
  reassessment_8week: string | null;
  reassessment_12week: string | null;

  caution: string | null;
  version: Generated<string>;
  approval_status: Generated<'draft_pending_review' | 'approved' | 'retired'>;

  created_at: Generated<Timestamp>;
  updated_at: Generated<Timestamp>;
}

export interface ProgramReferencePaperTable {
  id: Generated<number>;
  program_id: string;
  paper_code: string;
  evidence_level: 'direct_evidence' | 'indirect_evidence' | 'theoretical_evidence';
}

export interface CognitiveProfile81Table {
  profile_code: string; // 예: 'HHLM'
  planning_level: 'H' | 'M' | 'L';
  attention_level: 'H' | 'M' | 'L';
  simultaneous_level: 'H' | 'M' | 'L';
  successive_level: 'H' | 'M' | 'L';
  priority_domain: string | null;
  strength_domain: string | null;
  description: string | null;
}

export interface AgeBandMappingTable {
  age_code: string;
  age_label: string;
  tool: string;
  min_age: number;
  max_age: number;
}

export interface DifficultyMappingTable {
  difficulty_level: number;
  label: string | null;
  promote_threshold: Generated<string>; // DECIMAL -> string via pg driver
  demote_threshold: Generated<string>;
}

export interface TrainingHistoryTable {
  history_id: Generated<number>;
  student_id: number;
  program_id: string;
  performed_at: Generated<Timestamp>;
  success_rate: number | null;
  outcome: 'SUCCESS' | 'PARTIAL' | 'FAIL' | null;
  notes: string | null;
  // 0003 마이그레이션 추가분: 영역별/난이도별 이력 조회를 위한 비정규화 컬럼
  pass_domain: 'PLANNING' | 'ATTENTION' | 'SIMULTANEOUS' | 'SUCCESSIVE' | null;
  difficulty_level: number | null;
}

/**
 * Home AI = Weekly Planner AI 전용 테이블 (0003 마이그레이션)
 * 챗봇이 아니며, 이 테이블들은 오직 pass_training_program을 스냅샷 참조한다.
 */
export interface HomeTrainingPlanTable {
  plan_id: Generated<number>;
  student_id: number;
  result_id: number;
  profile_code: string;
  age_code: string;
  week_start_date: DateOnly;
  week_end_date: DateOnly;
  status: Generated<'ACTIVE' | 'COMPLETED' | 'ARCHIVED'>;
  domain_weights: unknown; // JSONB: Record<PassDomain, number>
  created_at: Generated<Timestamp>;
}

export interface HomeTrainingPlanItemTable {
  item_id: Generated<number>;
  plan_id: number;
  program_id: string;
  pass_domain: 'PLANNING' | 'ATTENTION' | 'SIMULTANEOUS' | 'SUCCESSIVE';
  day_index: number; // 1~5
  day_date: DateOnly;
  order_in_day: number;
  training_goal: string;
  duration: string | null;
  parent_guidance: string;
  is_supplementary: Generated<boolean>;
  is_completed: Generated<boolean>;
  completed_at: Timestamp | null;
}

export interface HomeTrainingLogTable {
  log_id: Generated<number>;
  item_id: number;
  student_id: number;
  success_rate: number;
  outcome: 'SUCCESS' | 'PARTIAL' | 'FAIL';
  parent_memo: string | null;
  child_reaction: string | null;
  logged_at: Generated<Timestamp>;
}

export interface HomeMonthlyReportTable {
  report_id: Generated<number>;
  student_id: number;
  report_month: string; // 'YYYY-MM'
  domain_change: unknown; // JSONB
  completion_rate: number;
  strength_maintained: unknown; // JSONB
  weakness_progress: unknown; // JSONB
  next_month_recommendation: string;
  generated_at: Generated<Timestamp>;
}

export interface EvidenceCodeTable {
  evidence_code: string;
  paper_id: number | null;
  evidence_level: number | null;
  summary: string | null;
}

export interface ActivityTable {
  activity_id: string;
  activity_name: string;
  pass_domain: string | null;
  environment: string | null;
  age_band: string | null;
  level: number | null;
}

export interface ActivityEvidenceMapTable {
  map_id: Generated<number>;
  activity_id: string;
  evidence_code: string;
  relationship_type: string | null;
}

export interface TrainingMethodTable {
  training_id: string;
  name: string;
  description: string | null;
}

export interface TeachingStrategyTable {
  strategy_id: string;
  name: string;
  description: string | null;
}

export interface RecommendationTable {
  recommendation_id: Generated<number>;
  student_id: number;
  result_id: number | null;
  activity_id: string | null; // deprecated: 0003에서 제거 예정, 하위호환용
  reason: string | null;
  confidence_score: number | null;
  // 0002 마이그레이션 추가분
  program_id: string | null; // pass_training_program.program_id — 신규 로직은 이 컬럼만 사용
  profile_code: string | null; // cognitive_profile_81.profile_code
  recommended_for: Generated<'HOME' | 'TEACHER_INDIVIDUAL' | 'TEACHER_GROUP' | 'TEACHER_CLASS'>;
  engine_version: Generated<string>;
}

export interface AiRuleTable {
  rule_id: string;
  condition_json: unknown | null;
  action_json: unknown | null;
  priority: number | null;
  is_active: Generated<boolean>;
}

export interface PromptTemplateTable {
  prompt_id: string;
  prompt_type: string | null;
  template_text: string | null;
  version: string | null;
}

export interface DailyLearningPlanTable {
  plan_id: Generated<number>;
  student_id: number;
  date: DateOnly;
  environment: string | null;
  status: string | null;
}

export interface ActivityLogTable {
  log_id: Generated<number>;
  student_id: number;
  activity_id: string;
  completed_at: Timestamp;
  score: number | null;
  memo: string | null;
}

export interface GrowthReportTable {
  report_id: Generated<number>;
  student_id: number;
  period_start: DateOnly;
  period_end: DateOnly;
  summary: string | null;
  next_recommendation: string | null;
}

// 0004 마이그레이션: Home AI 상담사(AI Coach) 콘텐츠 라이브러리 + 상담 로그
export interface HomeAiParentFaqTable {
  faq_id: string;
  priority_domain: string | null;
  question: string;
  answer: string;
}

export interface HomeAiParentLifeCaseTable {
  case_id: string;
  priority_domain: string;
  child_description: string;
  school_behavior: string;
  home_behavior: string;
  parent_guidance: string;
}

export interface HomeAiAvoidPhraseTable {
  phrase_id: string;
  priority_domain: string;
  phrase: string;
  why: string;
  instead_say: string;
}

export interface HomeAiTeacherStrategyTable {
  template_id: string;
  priority_domain: string;
  characteristic: string;
  classroom_behavior: string;
  strength_utilization: string;
  support_strategy: string;
  teacher_questions: unknown; // JSONB string[]
  observation_checklist: unknown; // JSONB string[]
}

export interface HomeAiChatLogTable {
  log_id: Generated<number>;
  student_id: number;
  requested_by_user_id: number;
  audience: string; // 'PARENT' | 'TEACHER'
  user_message: string;
  ai_response: string;
  linked_program_id: string | null;
  created_at: Generated<Timestamp>;
}

export interface Database {
  organization: OrganizationTable;
  user_account: UserAccountTable;
  class_group: ClassGroupTable;
  student: StudentTable;
  pass_result: PassResultTable;
  pass_profile: PassProfileTable;
  research_paper: ResearchPaperTable;
  evidence_code: EvidenceCodeTable;
  activity: ActivityTable; // deprecated: pass_training_program으로 대체, 0003에서 제거 예정
  activity_evidence_map: ActivityEvidenceMapTable; // deprecated
  training_method: TrainingMethodTable;
  teaching_strategy: TeachingStrategyTable;
  recommendation: RecommendationTable;
  ai_rule: AiRuleTable;
  prompt_template: PromptTemplateTable;
  daily_learning_plan: DailyLearningPlanTable;
  activity_log: ActivityLogTable;
  growth_report: GrowthReportTable;
  // 0002 마이그레이션: PASS Cognitive Training Library
  pass_training_program: PassTrainingProgramTable;
  program_reference_paper: ProgramReferencePaperTable;
  cognitive_profile_81: CognitiveProfile81Table;
  age_band_mapping: AgeBandMappingTable;
  difficulty_mapping: DifficultyMappingTable;
  training_history: TrainingHistoryTable;
  // 0003 마이그레이션: Home AI Weekly Planner
  home_training_plan: HomeTrainingPlanTable;
  home_training_plan_item: HomeTrainingPlanItemTable;
  home_training_log: HomeTrainingLogTable;
  home_monthly_report: HomeMonthlyReportTable;
  // 0004 마이그레이션: Home AI 상담사(AI Coach)
  home_ai_parent_faq: HomeAiParentFaqTable;
  home_ai_parent_life_case: HomeAiParentLifeCaseTable;
  home_ai_avoid_phrase: HomeAiAvoidPhraseTable;
  home_ai_teacher_strategy: HomeAiTeacherStrategyTable;
  home_ai_chat_log: HomeAiChatLogTable;
}
