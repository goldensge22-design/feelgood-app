/**
 * @jest-environment node
 */
import { NextRequest } from 'next/server';

const loginMock = jest.fn();

jest.mock('@/shared/config/container', () => ({
  getContainer: () => ({
    authService: { login: loginMock },
  }),
}));

describe('POST /api/v1/auth/login (integration)', () => {
  beforeEach(() => {
    loginMock.mockReset();
  });

  it('유효한 부모 계정으로 로그인하면 200과 토큰을 반환한다', async () => {
    loginMock.mockResolvedValue({
      accessToken: 'access.token.value',
      refreshToken: 'refresh.token.value',
      user: { userId: 1, organizationId: 1, email: 'parent@example.com', role: 'PARENT' },
    });

    const { POST } = await import('@/app/api/v1/auth/login/route');

    const req = new NextRequest('http://localhost/api/v1/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: 'parent@example.com', password: 'password1' }),
      headers: { 'content-type': 'application/json' },
    });

    const res = await POST(req);
    const json = await res.json();

    expect(res.status).toBe(200);
    expect(json.success).toBe(true);
    expect(json.data.accessToken).toBe('access.token.value');
    expect(loginMock).toHaveBeenCalledWith('parent@example.com', 'password1');
  });

  it('인증 서비스가 UnauthorizedError를 던지면 401을 반환한다', async () => {
    const { UnauthorizedError } = await import('@/shared/errors/AppError');
    loginMock.mockRejectedValue(new UnauthorizedError('이메일 또는 비밀번호가 올바르지 않습니다.'));

    const { POST } = await import('@/app/api/v1/auth/login/route');

    const req = new NextRequest('http://localhost/api/v1/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: 'nobody@example.com', password: 'password1' }),
      headers: { 'content-type': 'application/json' },
    });

    const res = await POST(req);
    expect(res.status).toBe(401);
  });

  it('잘못된 요청 형식이면 400을 반환한다 (Zod 검증)', async () => {
    const { POST } = await import('@/app/api/v1/auth/login/route');

    const req = new NextRequest('http://localhost/api/v1/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: 'not-an-email' }),
      headers: { 'content-type': 'application/json' },
    });

    const res = await POST(req);
    expect(res.status).toBe(400);
    expect(loginMock).not.toHaveBeenCalled();
  });
});
