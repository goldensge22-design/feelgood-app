import { HomeDashboardService } from '@/services/recommendation/HomeDashboardService';
import { PassResultService } from '@/services/pass/PassResultService';
import { PlaceholderRecommendationService } from '@/services/recommendation/PlaceholderRecommendationService';
import { IDailyLearningPlanRepository, IRecommendationRepository, IPassResultRepository, PassResultWithProfile } from '@/repositories/interfaces';

function makeResult(): PassResultWithProfile {
  return {
    resultId: 1,
    studentId: 1,
    planning: 82,
    attention: 91,
    simultaneous: 108,
    successive: 88,
    totalIndex: 92,
    testedAt: new Date(),
    profile: {
      profileId: 1,
      resultId: 1,
      dominanceType: '우뇌우세형',
      strengthDomain: 'SIMULTANEOUS',
      priorityDomain: 'PLANNING',
      aiSummary: 'summary',
    },
  } as PassResultWithProfile;
}

describe('HomeDashboardService', () => {
  it('오늘의 처방을 생성하고 recommendation/daily_learning_plan을 기록한다', async () => {
    const passResultRepo: IPassResultRepository = {
      findLatestByStudent: jest.fn().mockResolvedValue(makeResult()),
      findById: jest.fn(),
      listByStudent: jest.fn(),
    };
    const passResultService = new PassResultService(passResultRepo);
    const recommendationService = new PlaceholderRecommendationService();

    const recommendationRepo: IRecommendationRepository = {
      create: jest.fn().mockResolvedValue({}),
      listByStudent: jest.fn(),
    };
    const dailyPlanRepo: IDailyLearningPlanRepository = {
      upsertToday: jest.fn().mockResolvedValue({}),
      markCompleted: jest.fn(),
      listByStudent: jest.fn(),
    };

    const service = new HomeDashboardService(
      passResultService,
      recommendationService,
      recommendationRepo,
      dailyPlanRepo,
    );

    const dashboard = await service.getDashboard(1);

    expect(dashboard.prescription.isMock).toBe(true);
    expect(dashboard.analysis.planning.band).toBe('LOW');
    expect(dailyPlanRepo.upsertToday).toHaveBeenCalledWith(1, 'HOME');
    expect(recommendationRepo.create).toHaveBeenCalled();
  });
});
