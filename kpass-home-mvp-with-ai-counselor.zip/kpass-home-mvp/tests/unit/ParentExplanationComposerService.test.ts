import { ParentExplanationComposerService } from '@/domain/services/ParentExplanationComposerService';
import { PassResultService } from '@/services/pass/PassResultService';
import {
  IAvoidPhraseRepository,
  ICognitiveProfileRepository,
  IParentFaqRepository,
  IParentLifeCaseRepository,
  IPassResultRepository,
  PassResultWithProfile,
} from '@/repositories/interfaces';

function makeResult(): PassResultWithProfile {
  return {
    resultId: 1,
    studentId: 1,
    planning: 82, // LOW -> priorityDomain
    attention: 100,
    simultaneous: 100,
    successive: 125, // HIGH -> strengthDomain
    totalIndex: 100,
    testedAt: new Date(),
    profile: {
      profileId: 1,
      resultId: 1,
      dominanceType: '균형형',
      strengthDomain: 'SUCCESSIVE',
      priorityDomain: 'PLANNING',
      aiSummary: null,
    },
  } as PassResultWithProfile;
}

describe('ParentExplanationComposerService', () => {
  it('결과지·81 Profile·생활 사례/FAQ 라이브러리만 조합해 부모용 설명을 구성한다', async () => {
    const passResultRepo: IPassResultRepository = {
      findLatestByStudent: jest.fn().mockResolvedValue(makeResult()),
      findById: jest.fn(),
      listByStudent: jest.fn(),
    };
    const passResultService = new PassResultService(passResultRepo);

    const cognitiveProfileRepo: ICognitiveProfileRepository = {
      findByCode: jest.fn(),
      resolveFromScores: jest.fn().mockResolvedValue({
        profileCode: 'LMMH',
        planningLevel: 'L',
        attentionLevel: 'M',
        simultaneousLevel: 'M',
        successiveLevel: 'H',
        priorityDomain: 'PLANNING',
        strengthDomain: 'SUCCESSIVE',
      }),
    };

    const lifeCaseRepo: IParentLifeCaseRepository = {
      findByDomain: jest.fn().mockResolvedValue({
        caseId: 'LIFE-PLANNING-01',
        priorityDomain: 'PLANNING',
        childDescription: '설명',
        schoolBehavior: '학교',
        homeBehavior: '집',
        parentGuidance: '도움말',
      }),
    };

    const avoidPhraseRepo: IAvoidPhraseRepository = {
      findByDomain: jest.fn().mockResolvedValue({
        phraseId: 'AVOID-PLANNING-01',
        priorityDomain: 'PLANNING',
        phrase: '왜 이렇게 계획도 없이 하니?',
        why: '이유',
        insteadSay: '대신 표현',
      }),
    };

    const faqRepo: IParentFaqRepository = {
      listAll: jest.fn(),
      listByDomain: jest.fn().mockResolvedValue([
        { faqId: 'FAQ-GEN-01', priorityDomain: null, question: 'Q1', answer: 'A1' },
      ]),
    };

    const service = new ParentExplanationComposerService(
      passResultService,
      cognitiveProfileRepo,
      lifeCaseRepo,
      avoidPhraseRepo,
      faqRepo,
    );

    const explanation = await service.composeForStudent(1);

    expect(explanation.priorityDomain).toBe('PLANNING');
    expect(explanation.strengthDomain).toBe('SUCCESSIVE');
    expect(explanation.profileCode).toBe('LMMH');
    expect(explanation.childDescription).toBe('설명');
    expect(explanation.avoidPhrases).toHaveLength(1);
    expect(explanation.faqs).toHaveLength(1);
    // 강점 영역 활용 문구가 텍스트 생성이 아니라 기존 문구에 덧붙는 조합인지 확인
    expect(explanation.parentGuidance).toContain('도움말');
    expect(explanation.parentGuidance).toContain('순차처리(Successive)');
    expect(explanation.weeklyPlannerLink.href).toBe('/students/1');
    expect(explanation.cognitiveEmotionalProgramLink.href).toBe('/students/1/cognitive-emotional-training');
  });

  it('priority_domain이 없으면 추측하지 않고 예외를 던진다', async () => {
    const noProfileResult = { ...makeResult(), profile: null } as PassResultWithProfile;
    const passResultRepo: IPassResultRepository = {
      findLatestByStudent: jest.fn().mockResolvedValue(noProfileResult),
      findById: jest.fn(),
      listByStudent: jest.fn(),
    };
    const passResultService = new PassResultService(passResultRepo);

    const service = new ParentExplanationComposerService(
      passResultService,
      { findByCode: jest.fn(), resolveFromScores: jest.fn() },
      { findByDomain: jest.fn() },
      { findByDomain: jest.fn() },
      { listAll: jest.fn(), listByDomain: jest.fn() },
    );

    await expect(service.composeForStudent(1)).rejects.toThrow();
  });
});
