import { LibraryRecommendationService } from '@/domain/services/LibraryRecommendationService';
import { TrainingProgram } from '@/domain/entities';

function makeProgram(overrides: Partial<TrainingProgram> = {}): TrainingProgram {
  return {
    programId: 'PLAN-0507-L3-1',
    programName: '[Planning] 전략수립 훈련 - 만 5~7세 Lv.3',
    passDomain: 'PLANNING',
    subCognitiveFunction: '전략수립',
    targetAge: '만 5~7세(유아~초1)',
    recommendedUser: null,
    difficultyLevel: 3,
    duration: '30분',
    groupSize: '소집단(3~6인)',
    materials: '과제 카드',
    trainingGoal: '전략수립 능력 향상',
    expectedCognitiveChange: null,
    expectedBehavioralChange: null,
    schoolChange: null,
    homeConnectionGoal: null,
    environment: null,
    safetyNotes: null,
    procedureIntro: null,
    procedureInstruction: null,
    procedureDemo: null,
    procedureActivity: null,
    procedureFeedback: null,
    teacherScriptIntro: null,
    teacherScriptActivity: null,
    teacherQuestions: null,
    encouragementScript: null,
    closingScript: null,
    observationChecklist: null,
    difficultyAdjustment: null,
    homeActivity5min: '5분 카드놀이',
    homeActivity10min: '10분 활동지',
    homeActivity15min: '15분 실생활 과제',
    parentQuestion: '오늘 뭐가 어려웠어?',
    parentFeedback: '잘했어!',
    rewardRule: null,
    successRule: null,
    failRule: null,
    repeatRule: null,
    reassessment4week: null,
    reassessment8week: null,
    reassessment12week: null,
    caution: null,
    evidenceRefs: [{ paperCode: 'P001', evidenceLevel: 'direct_evidence' }],
    version: '1.0',
    approvalStatus: 'approved',
    ...overrides,
  };
}

describe('LibraryRecommendationService', () => {
  const trainingProgramRepo = {
    findById: jest.fn(),
    findCandidates: jest.fn().mockResolvedValue([makeProgram()]),
    count: jest.fn(),
  };
  const profileRepo = {
    findByCode: jest.fn(),
    resolveFromScores: jest.fn().mockResolvedValue({
      profileCode: 'LMMH',
      planningLevel: 'L',
      attentionLevel: 'M',
      simultaneousLevel: 'M',
      successiveLevel: 'H',
      priorityDomain: 'PLANNING',
      strengthDomain: 'SUCCESSIVE',
    }),
  };
  const historyRepo = {
    listByStudentAndProgram: jest.fn(),
    listRecentByStudent: jest.fn(),
    listRecentByStudentAndDomain: jest.fn().mockResolvedValue([]),
    record: jest.fn(),
  };
  const passResultRepo = {
    findLatestByStudent: jest.fn(),
    findById: jest.fn().mockResolvedValue({
      resultId: 1,
      studentId: 1,
      planning: 82,
      attention: 100,
      simultaneous: 100,
      successive: 125,
      totalIndex: 100,
      testedAt: new Date(),
      profile: null,
    }),
    listByStudent: jest.fn(),
  };
  const studentRepo = {
    findById: jest.fn().mockResolvedValue({
      studentId: 1,
      organizationId: 1,
      classId: null,
      name: '김민준',
      birthDate: new Date('2018-01-01'),
      grade: null,
    }),
    findByOrganization: jest.fn(),
    belongsToOrganization: jest.fn(),
  };
  const ageBandMappingRepo = {
    resolveAgeCode: jest.fn().mockResolvedValue({
      ageCode: '5-7',
      ageLabel: '만 5~7세(유아~초1)',
      tool: 'K-PASS',
      minAge: 5,
      maxAge: 7,
    }),
  };
  const difficultyMappingRepo = {
    getByLevel: jest.fn().mockResolvedValue({
      level: 3,
      label: 'Level 3 (표준)',
      promoteThreshold: 80,
      demoteThreshold: 50,
    }),
  };

  const service = new LibraryRecommendationService(
    trainingProgramRepo as never,
    profileRepo as never,
    historyRepo as never,
    passResultRepo as never,
    studentRepo as never,
    ageBandMappingRepo as never,
    difficultyMappingRepo as never,
  );

  it('never returns isMock=true (Library 기반 실제 추천)', async () => {
    const result = await service.recommendForDomain({
      studentId: 1,
      resultId: 1,
      passDomain: 'PLANNING',
      ageBand: '5-7',
      environment: 'HOME',
    });
    expect(result.isMock).toBe(false);
  });

  it('오직 repository가 반환한 프로그램만 추천한다 (런타임 생성 없음)', async () => {
    const result = await service.recommendForDomain({
      studentId: 1,
      resultId: 1,
      passDomain: 'PLANNING',
      ageBand: '5-7',
      environment: 'HOME',
    });
    expect(result.programId).toBe('PLAN-0507-L3-1');
    expect(trainingProgramRepo.findCandidates).toHaveBeenCalled();
  });

  it('후보가 없으면 조용히 생성하지 않고 즉시 에러를 던진다', async () => {
    trainingProgramRepo.findCandidates.mockResolvedValueOnce([]);
    await expect(
      service.recommendForDomain({
        studentId: 1,
        resultId: 1,
        passDomain: 'ATTENTION',
        ageBand: '17-19',
        environment: 'HOME',
      }),
    ).rejects.toThrow(/Library에 조건에 맞는 프로그램이 없습니다/);
  });

  it('evidenceRefs가 있으면 evidenceLevel과 evidenceCode를 채운다', async () => {
    const result = await service.recommendForDomain({
      studentId: 1,
      resultId: 1,
      passDomain: 'PLANNING',
      ageBand: '5-7',
      environment: 'HOME',
    });
    expect(result.evidenceLevel).toBe(5);
    expect(result.evidenceCode).toBe('P001');
  });

  it('이력이 없으면 Level 3(표준)에서 시작한다', async () => {
    historyRepo.listRecentByStudentAndDomain.mockResolvedValueOnce([]);
    await service.recommendForDomain({
      studentId: 1,
      resultId: 1,
      passDomain: 'PLANNING',
      ageBand: '5-7',
      environment: 'HOME',
    });
    expect(trainingProgramRepo.findCandidates).toHaveBeenCalledWith(
      expect.objectContaining({ difficultyLevel: 3 }),
    );
  });

  it('평균 성공률이 promoteThreshold 이상이면 난이도를 승급한다', async () => {
    historyRepo.listRecentByStudentAndDomain.mockResolvedValueOnce([
      {
        historyId: 1,
        studentId: 1,
        programId: 'x',
        performedAt: new Date(),
        successRate: 90,
        outcome: 'SUCCESS',
        passDomain: 'PLANNING',
        difficultyLevel: 3,
      },
      {
        historyId: 2,
        studentId: 1,
        programId: 'x',
        performedAt: new Date(),
        successRate: 85,
        outcome: 'SUCCESS',
        passDomain: 'PLANNING',
        difficultyLevel: 3,
      },
    ]);
    await service.recommendForDomain({
      studentId: 1,
      resultId: 1,
      passDomain: 'PLANNING',
      ageBand: '5-7',
      environment: 'HOME',
    });
    expect(trainingProgramRepo.findCandidates).toHaveBeenCalledWith(
      expect.objectContaining({ difficultyLevel: 4 }),
    );
  });

  it('평균 성공률이 demoteThreshold 미만이면 난이도를 강등한다', async () => {
    historyRepo.listRecentByStudentAndDomain.mockResolvedValueOnce([
      {
        historyId: 1,
        studentId: 1,
        programId: 'x',
        performedAt: new Date(),
        successRate: 30,
        outcome: 'FAIL',
        passDomain: 'PLANNING',
        difficultyLevel: 3,
      },
    ]);
    await service.recommendForDomain({
      studentId: 1,
      resultId: 1,
      passDomain: 'PLANNING',
      ageBand: '5-7',
      environment: 'HOME',
    });
    expect(trainingProgramRepo.findCandidates).toHaveBeenCalledWith(
      expect.objectContaining({ difficultyLevel: 2 }),
    );
  });

  it('generateDailyPrescription은 최대 3개 항목을 반환하며 isMock=false', async () => {
    const result = await service.generateDailyPrescription(1, 1);
    expect(result.items.length).toBeLessThanOrEqual(3);
    expect(result.isMock).toBe(false);
  });

  it('resolveAgeCode는 student.birthDate가 없으면 예외를 던진다(추측 대체 금지)', async () => {
    studentRepo.findById.mockResolvedValueOnce({
      studentId: 2,
      organizationId: 1,
      classId: null,
      name: '이서연',
      birthDate: null,
      grade: null,
    });
    await expect(service.resolveAgeCode(2)).rejects.toThrow(/birthDate가 없어/);
  });
});
