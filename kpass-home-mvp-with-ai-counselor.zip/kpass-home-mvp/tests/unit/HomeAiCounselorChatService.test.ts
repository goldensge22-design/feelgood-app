import { HomeAiCounselorChatService } from '@/services/home-ai/HomeAiCounselorChatService';
import { PassResultService } from '@/services/pass/PassResultService';
import {
  IAvoidPhraseRepository,
  IHomeAiChatLogRepository,
  IParentFaqRepository,
  IParentLifeCaseRepository,
  IPassResultRepository,
  ITeacherStrategyRepository,
  PassResultWithProfile,
} from '@/repositories/interfaces';
import { RecommendationService } from '@/domain/services/RecommendationService';
import { HOME_AI_CHAT_DAILY_LIMIT } from '@/shared/constants/homeAiCounselor';

function makeResult(): PassResultWithProfile {
  return {
    resultId: 1,
    studentId: 1,
    planning: 82,
    attention: 100,
    simultaneous: 100,
    successive: 125,
    totalIndex: 100,
    testedAt: new Date(),
    profile: {
      profileId: 1,
      resultId: 1,
      dominanceType: '균형형',
      strengthDomain: 'SUCCESSIVE',
      priorityDomain: 'PLANNING',
      aiSummary: null,
    },
  } as PassResultWithProfile;
}

function makeService(overrides?: { chatLogRepo?: Partial<IHomeAiChatLogRepository> }) {
  const passResultRepo: IPassResultRepository = {
    findLatestByStudent: jest.fn().mockResolvedValue(makeResult()),
    findById: jest.fn(),
    listByStudent: jest.fn(),
  };
  const passResultService = new PassResultService(passResultRepo);

  const recommendationService: RecommendationService = {
    recommendForDomain: jest.fn(),
    generateDailyPrescription: jest.fn().mockResolvedValue({
      date: '2026-07-07',
      items: [
        {
          recommendation: '순서 카드 놀이',
          reason: 'PLANNING 영역 보완',
          evidenceCode: 'P001',
          evidenceLevel: 5,
          confidence: 0.9,
          programId: 'PLAN-001',
          activityId: 'PLAN-001',
          isMock: false,
        },
      ],
      parentQuestion: '',
      parentPraise: '',
      lifePassMission: '',
      isMock: false,
    }),
  };

  const chatLogRepo: IHomeAiChatLogRepository = {
    create: jest.fn().mockResolvedValue({}),
    countTodayByUser: jest.fn().mockResolvedValue(0),
    ...overrides?.chatLogRepo,
  };

  const parentFaqRepo: IParentFaqRepository = { listAll: jest.fn(), listByDomain: jest.fn().mockResolvedValue([]) };
  const parentLifeCaseRepo: IParentLifeCaseRepository = { findByDomain: jest.fn().mockResolvedValue(null) };
  const avoidPhraseRepo: IAvoidPhraseRepository = { findByDomain: jest.fn().mockResolvedValue(null) };
  const teacherStrategyRepo: ITeacherStrategyRepository = { findByDomain: jest.fn().mockResolvedValue(null) };

  const service = new HomeAiCounselorChatService(
    passResultService,
    recommendationService,
    chatLogRepo,
    parentFaqRepo,
    parentLifeCaseRepo,
    avoidPhraseRepo,
    teacherStrategyRepo,
  );

  return { service, chatLogRepo, recommendationService };
}

describe('HomeAiCounselorChatService', () => {
  const originalFetch = global.fetch;
  const originalApiKey = process.env.ANTHROPIC_API_KEY;

  beforeEach(() => {
    process.env.ANTHROPIC_API_KEY = 'test-key';
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: async () => ({
        content: [{ type: 'text', text: '숙제 전 순서를 함께 정해보세요. 인지훈련 플래너를 확인해보세요.' }],
      }),
    }) as unknown as typeof fetch;
  });

  afterEach(() => {
    global.fetch = originalFetch;
    process.env.ANTHROPIC_API_KEY = originalApiKey;
    jest.clearAllMocks();
  });

  it('하루 사용량이 한도 미만이면 상담을 생성하고 로그를 남긴다', async () => {
    const { service, chatLogRepo } = makeService();

    const result = await service.chat({
      studentId: 1,
      requestedByUserId: 10,
      audience: 'PARENT',
      message: '숙제를 너무 싫어해요',
    });

    expect(result.reply).toContain('인지훈련 플래너');
    expect(result.linkedProgramId).toBe('PLAN-001');
    expect(result.remainingToday).toBe(HOME_AI_CHAT_DAILY_LIMIT - 1);
    expect(chatLogRepo.create).toHaveBeenCalledWith(
      expect.objectContaining({ studentId: 1, requestedByUserId: 10, audience: 'PARENT' }),
    );
  });

  it('하루 10회를 모두 사용했으면 RateLimitError를 던지고 AI를 호출하지 않는다', async () => {
    const { service } = makeService({
      chatLogRepo: { countTodayByUser: jest.fn().mockResolvedValue(HOME_AI_CHAT_DAILY_LIMIT) },
    });

    await expect(
      service.chat({ studentId: 1, requestedByUserId: 10, audience: 'PARENT', message: '질문' }),
    ).rejects.toThrow();
    expect(global.fetch).not.toHaveBeenCalled();
  });

  it('빈 메시지는 검증 오류로 거부한다', async () => {
    const { service } = makeService();
    await expect(
      service.chat({ studentId: 1, requestedByUserId: 10, audience: 'PARENT', message: '   ' }),
    ).rejects.toThrow();
  });
});
