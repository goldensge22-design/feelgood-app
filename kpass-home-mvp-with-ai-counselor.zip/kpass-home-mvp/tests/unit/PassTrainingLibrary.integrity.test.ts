import library from '@/db/seed-data/pass_training_library_400.json';

interface ProgramSeed {
  program_id: string;
  pass_domain: string;
  target_age: string;
  difficulty_level: number;
  reference_paper_id: string;
  evidence_level: string;
  approval_status: string;
}

const programs = library as unknown as ProgramSeed[];

describe('PASS Cognitive Training Library (400-program seed)', () => {
  it('정확히 400개 프로그램을 포함한다', () => {
    expect(programs.length).toBe(400);
  });

  it('program_id는 모두 고유하다', () => {
    const ids = new Set(programs.map((p) => p.program_id));
    expect(ids.size).toBe(400);
  });

  it('PASS 4개 영역이 각각 100개씩 균형을 이룬다', () => {
    const byDomain: Record<string, number> = {};
    for (const p of programs) byDomain[p.pass_domain] = (byDomain[p.pass_domain] ?? 0) + 1;
    expect(byDomain).toEqual({
      PLANNING: 100,
      ATTENTION: 100,
      SIMULTANEOUS: 100,
      SUCCESSIVE: 100,
    });
  });

  it('연령대 5개 구간이 각각 80개씩(=100x4/5) 균형을 이룬다', () => {
    const byAge: Record<string, number> = {};
    for (const p of programs) byAge[p.target_age] = (byAge[p.target_age] ?? 0) + 1;
    expect(Object.values(byAge).every((n) => n === 80)).toBe(true);
    expect(Object.keys(byAge).length).toBe(5);
  });

  it('난이도 Level 1~5가 각각 80개씩 균형을 이룬다', () => {
    const byLevel: Record<number, number> = {};
    for (const p of programs) byLevel[p.difficulty_level] = (byLevel[p.difficulty_level] ?? 0) + 1;
    expect(byLevel).toEqual({ 1: 80, 2: 80, 3: 80, 4: 80, 5: 80 });
  });

  it('모든 프로그램은 최소 1개 이상의 근거 논문(reference_paper_id)을 가진다', () => {
    expect(programs.every((p) => p.reference_paper_id && p.reference_paper_id.length > 0)).toBe(true);
  });

  it('evidence_level 항목 수는 reference_paper_id 항목 수와 일치한다', () => {
    for (const p of programs) {
      const paperCount = p.reference_paper_id.split(';').length;
      const levelCount = p.evidence_level.split(';').length;
      expect(levelCount).toBe(paperCount);
    }
  });

  it('evidence_level 값은 direct/indirect/theoretical 중 하나만 사용한다', () => {
    const allowed = new Set(['direct_evidence', 'indirect_evidence', 'theoretical_evidence']);
    for (const p of programs) {
      for (const lvl of p.evidence_level.split(';')) {
        expect(allowed.has(lvl)).toBe(true);
      }
    }
  });

  it('모든 프로그램은 approval_status가 정의된 값이다 (승인 워크플로 필드 누락 방지)', () => {
    const allowed = new Set(['draft_pending_review', 'approved', 'retired']);
    expect(programs.every((p) => allowed.has(p.approval_status))).toBe(true);
  });
});
