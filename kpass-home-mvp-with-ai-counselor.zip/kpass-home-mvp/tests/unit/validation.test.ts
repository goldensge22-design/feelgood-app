import { loginSchema, parseOrThrow, parseIntParamOrThrow } from '@/shared/utils/validation';
import { ValidationError } from '@/shared/errors/AppError';

describe('validation utils', () => {
  it('parseOrThrow는 유효한 입력을 그대로 반환한다', () => {
    const result = parseOrThrow(loginSchema, { email: 'a@b.com', password: '1234' });
    expect(result.email).toBe('a@b.com');
  });

  it('parseOrThrow는 잘못된 입력에 ValidationError를 던진다', () => {
    expect(() => parseOrThrow(loginSchema, { email: 'not-an-email', password: '1' })).toThrow(
      ValidationError,
    );
  });

  it('parseIntParamOrThrow는 양의 정수만 허용한다', () => {
    expect(parseIntParamOrThrow('42', 'studentId')).toBe(42);
    expect(() => parseIntParamOrThrow('abc', 'studentId')).toThrow(ValidationError);
    expect(() => parseIntParamOrThrow('-1', 'studentId')).toThrow(ValidationError);
  });
});
