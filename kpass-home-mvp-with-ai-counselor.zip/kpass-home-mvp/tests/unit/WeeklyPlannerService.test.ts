import { WeeklyPlannerService } from '@/services/recommendation/WeeklyPlannerService';
import { WeeklyTrainingPlan } from '@/domain/entities';

describe('WeeklyPlannerService', () => {
  const passResultService = {
    getLatestResult: jest.fn().mockResolvedValue({
      resultId: 1,
      studentId: 1,
      planning: 82, // LOW -> priorityDomain
      attention: 100,
      simultaneous: 100,
      successive: 125, // HIGH -> strengthDomain
      totalIndex: 100,
      testedAt: new Date(),
      profile: null,
    }),
    getResultById: jest.fn(),
  };

  let recommendCallCount = 0;
  const recommendationService = {
    recommendForDomain: jest.fn().mockImplementation(async (input) => {
      recommendCallCount += 1;
      // excludeProgramIds를 반영해 매번 다른 프로그램을 돌려주는 스텁(엔진의 다양성 확보 흉내)
      const seq = (input.excludeProgramIds?.length ?? 0) + 1;
      const programId = `${input.passDomain.slice(0, 4)}-${seq}`;
      return {
        recommendation: `${input.passDomain} 훈련 ${seq}`,
        reason: `${input.passDomain} 영역 추천 사유`,
        evidenceCode: 'P001',
        evidenceLevel: 5,
        confidence: 0.9,
        programId,
        activityId: programId,
        isMock: false,
      };
    }),
    generateDailyPrescription: jest.fn(),
  };

  const createdPlans: unknown[] = [];
  const planRepo = {
    create: jest.fn().mockImplementation(async (input) => {
      const plan: WeeklyTrainingPlan = {
        planId: 1,
        studentId: input.studentId,
        resultId: input.resultId,
        profileCode: input.profileCode,
        ageCode: input.ageCode,
        weekStartDate: input.weekStartDate,
        weekEndDate: input.weekEndDate,
        status: 'ACTIVE',
        domainWeights: input.domainWeights,
        items: input.items.map((it: Record<string, unknown>, idx: number) => ({
          itemId: idx + 1,
          planId: 1,
          ...it,
        })),
      };
      createdPlans.push(plan);
      return plan;
    }),
    findById: jest.fn(),
    findActiveByStudent: jest.fn(),
    listByStudentInRange: jest.fn(),
    markStatus: jest.fn(),
    findItemById: jest.fn(),
    markItemCompleted: jest.fn(),
  };

  const logRepo = {
    create: jest.fn().mockResolvedValue({
      logId: 1,
      itemId: 1,
      studentId: 1,
      successRate: 90,
      outcome: 'SUCCESS',
      parentMemo: null,
      childReaction: null,
      loggedAt: new Date(),
    }),
    listByStudentInRange: jest.fn().mockResolvedValue([]),
  };

  const monthlyReportRepo = {
    upsert: jest.fn(),
    findByStudentAndMonth: jest.fn(),
  };

  const historyRepo = {
    listByStudentAndProgram: jest.fn(),
    listRecentByStudent: jest.fn(),
    listRecentByStudentAndDomain: jest.fn().mockResolvedValue([]), // 이력 없음 -> 반복실패 없음, Level 3 시작
    record: jest.fn(),
  };

  const profileRepo = {
    findByCode: jest.fn().mockResolvedValue({
      profileCode: 'LMMH',
      planningLevel: 'L',
      attentionLevel: 'M',
      simultaneousLevel: 'M',
      successiveLevel: 'H',
      priorityDomain: 'PLANNING',
      strengthDomain: 'SUCCESSIVE',
    }),
    resolveFromScores: jest.fn().mockResolvedValue({
      profileCode: 'LMMH',
      planningLevel: 'L',
      attentionLevel: 'M',
      simultaneousLevel: 'M',
      successiveLevel: 'H',
      priorityDomain: 'PLANNING',
      strengthDomain: 'SUCCESSIVE',
    }),
  };

  const studentRepo = {
    findById: jest.fn().mockResolvedValue({
      studentId: 1,
      organizationId: 1,
      classId: null,
      name: '김민준',
      birthDate: new Date('2018-01-01'),
      grade: null,
    }),
    findByOrganization: jest.fn(),
    belongsToOrganization: jest.fn(),
  };

  const ageBandMappingRepo = {
    resolveAgeCode: jest.fn().mockResolvedValue({
      ageCode: '5-7',
      ageLabel: '만 5~7세(유아~초1)',
      tool: 'K-PASS',
      minAge: 5,
      maxAge: 7,
    }),
  };

  const difficultyMappingRepo = {
    getByLevel: jest.fn().mockResolvedValue({
      level: 3,
      label: 'Level 3 (표준)',
      promoteThreshold: 80,
      demoteThreshold: 50,
    }),
  };

  const trainingProgramRepo = {
    findById: jest.fn().mockResolvedValue({
      programId: 'x',
      programName: '더미 프로그램',
      passDomain: 'PLANNING',
      subCognitiveFunction: '전략수립',
      targetAge: '만 5~7세(유아~초1)',
      recommendedUser: null,
      difficultyLevel: 3,
      duration: '30분',
      groupSize: null,
      materials: null,
      trainingGoal: '전략수립 능력 향상',
      expectedCognitiveChange: null,
      expectedBehavioralChange: null,
      schoolChange: null,
      homeConnectionGoal: null,
      environment: null,
      safetyNotes: null,
      procedureIntro: null,
      procedureInstruction: null,
      procedureDemo: null,
      procedureActivity: null,
      procedureFeedback: null,
      teacherScriptIntro: null,
      teacherScriptActivity: null,
      teacherQuestions: null,
      encouragementScript: null,
      closingScript: null,
      observationChecklist: null,
      difficultyAdjustment: null,
      homeActivity5min: '5분 활동',
      homeActivity10min: '10분 활동',
      homeActivity15min: '15분 활동',
      parentQuestion: '오늘 뭐가 어려웠어?',
      parentFeedback: '잘했어!',
      rewardRule: null,
      successRule: null,
      failRule: null,
      repeatRule: null,
      reassessment4week: null,
      reassessment8week: null,
      reassessment12week: null,
      caution: null,
      evidenceRefs: [{ paperCode: 'P001', evidenceLevel: 'direct_evidence' }],
      version: '1.0',
      approvalStatus: 'approved',
    }),
    findCandidates: jest.fn(),
    count: jest.fn(),
  };

  const service = new WeeklyPlannerService(
    passResultService as never,
    recommendationService as never,
    planRepo as never,
    logRepo as never,
    monthlyReportRepo as never,
    historyRepo as never,
    profileRepo as never,
    studentRepo as never,
    ageBandMappingRepo as never,
    difficultyMappingRepo as never,
    trainingProgramRepo as never,
  );

  beforeEach(() => {
    recommendCallCount = 0;
    createdPlans.length = 0;
    planRepo.create.mockClear();
    recommendationService.recommendForDomain.mockClear();
  });

  it('주간 계획은 오직 recommendationService(Library 엔진)를 통해서만 프로그램을 선택한다', async () => {
    const plan = await service.generateWeeklyPlan(1, new Date('2026-07-06T00:00:00Z'));
    expect(recommendationService.recommendForDomain).toHaveBeenCalled();
    expect(plan.items.length).toBeGreaterThanOrEqual(10);
    expect(plan.items.length).toBeLessThanOrEqual(15);
  });

  it('주 5일, 하루 2~3개로 배분된다', async () => {
    const plan = await service.generateWeeklyPlan(1, new Date('2026-07-06T00:00:00Z'));
    const perDay = new Map<number, number>();
    for (const item of plan.items) {
      perDay.set(item.dayIndex, (perDay.get(item.dayIndex) ?? 0) + 1);
    }
    expect(perDay.size).toBe(5);
    for (const count of perDay.values()) {
      expect(count).toBeGreaterThanOrEqual(2);
      expect(count).toBeLessThanOrEqual(3);
    }
  });

  it('약점 영역(priorityDomain)에 가장 많은 세션이 배정된다', async () => {
    const plan = await service.generateWeeklyPlan(1, new Date('2026-07-06T00:00:00Z'));
    const weights = plan.domainWeights as Record<string, number>;
    expect(weights.PLANNING).toBeGreaterThan(weights.SUCCESSIVE); // 약점 > 강점
  });

  it('같은 영역 내에서 동일 프로그램이 반복되지 않도록 excludeProgramIds를 누적 전달한다', async () => {
    await service.generateWeeklyPlan(1, new Date('2026-07-06T00:00:00Z'));
    const planningCalls = recommendationService.recommendForDomain.mock.calls.filter(
      ([input]: [{ passDomain: string }]) => input.passDomain === 'PLANNING',
    );
    expect(planningCalls.length).toBeGreaterThan(1);
    // 두 번째 호출부터는 excludeProgramIds가 채워져 있어야 한다
    expect(planningCalls[1][0].excludeProgramIds.length).toBeGreaterThan(0);
  });

  it('completeItem은 이행 기록을 남기고 공유 training_history에도 기록한다', async () => {
    planRepo.findItemById.mockResolvedValueOnce({
      itemId: 10,
      planId: 1,
      programId: 'PLAN-0507-L3-1',
      programName: '전략수립 훈련',
      passDomain: 'PLANNING',
      dayIndex: 1,
      dayDate: new Date(),
      orderInDay: 1,
      trainingGoal: '전략수립',
      duration: '30분',
      parentGuidance: '가이드',
      isSupplementary: false,
      isCompleted: false,
      completedAt: null,
    });
    planRepo.findById.mockResolvedValueOnce({
      planId: 1,
      studentId: 1,
      resultId: 1,
      profileCode: 'LMMH',
      ageCode: '5-7',
      weekStartDate: new Date(),
      weekEndDate: new Date(),
      status: 'ACTIVE',
      domainWeights: {},
      items: [],
    });
    planRepo.markItemCompleted.mockResolvedValueOnce({
      itemId: 10,
      planId: 1,
      programId: 'PLAN-0507-L3-1',
      programName: '전략수립 훈련',
      passDomain: 'PLANNING',
      dayIndex: 1,
      dayDate: new Date(),
      orderInDay: 1,
      trainingGoal: '전략수립',
      duration: '30분',
      parentGuidance: '가이드',
      isSupplementary: false,
      isCompleted: true,
      completedAt: new Date(),
    });

    await service.completeItem(10, {
      successRate: 90,
      outcome: 'SUCCESS',
      parentMemo: '잘함',
      childReaction: '재밌어함',
    });

    expect(logRepo.create).toHaveBeenCalledWith(
      expect.objectContaining({ itemId: 10, successRate: 90, outcome: 'SUCCESS' }),
    );
    expect(historyRepo.record).toHaveBeenCalledWith(
      expect.objectContaining({
        studentId: 1,
        programId: 'PLAN-0507-L3-1',
        passDomain: 'PLANNING',
        successRate: 90,
      }),
    );
  });

  it('generateMonthlyReport는 해당 월에 계획이 없으면 예외를 던진다(허위 데이터 생성 금지)', async () => {
    planRepo.listByStudentInRange.mockResolvedValueOnce([]);
    await expect(service.generateMonthlyReport(1, '2026-07')).rejects.toThrow(
      /주간 훈련 계획이 없습니다/,
    );
  });
});
