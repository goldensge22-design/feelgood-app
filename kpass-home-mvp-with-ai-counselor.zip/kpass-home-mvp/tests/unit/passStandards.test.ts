import { classifyPassScore, PASS_SCORE_THRESHOLDS } from '@/shared/constants/passStandards';

describe('classifyPassScore', () => {
  it('returns LOW when score <= 85', () => {
    expect(classifyPassScore(85)).toBe('LOW');
    expect(classifyPassScore(0)).toBe('LOW');
    expect(classifyPassScore(PASS_SCORE_THRESHOLDS.LOW_MAX)).toBe('LOW');
  });

  it('returns MID when 86 <= score <= 119', () => {
    expect(classifyPassScore(86)).toBe('MID');
    expect(classifyPassScore(100)).toBe('MID');
    expect(classifyPassScore(119)).toBe('MID');
  });

  it('returns HIGH when score >= 120', () => {
    expect(classifyPassScore(120)).toBe('HIGH');
    expect(classifyPassScore(160)).toBe('HIGH');
  });
});
