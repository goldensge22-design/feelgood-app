import { AuthService } from '@/services/auth/AuthService';
import { IUserAccountRepository } from '@/repositories/interfaces';
import { ICredentialVerifier } from '@/services/auth/CredentialVerifier';
import { UnauthorizedError } from '@/shared/errors/AppError';
import { UserAccount } from '@/domain/entities';

function makeUser(overrides: Partial<UserAccount> = {}): UserAccount {
  return {
    userId: 1,
    organizationId: 1,
    email: 'parent@example.com',
    role: 'PARENT',
    status: 'ACTIVE',
    ...overrides,
  } as UserAccount;
}

describe('AuthService', () => {
  it('로그인 성공 시 accessToken/refreshToken을 발급한다', async () => {
    const userRepo: IUserAccountRepository = {
      findByEmail: jest.fn().mockResolvedValue(makeUser()),
      findById: jest.fn(),
    };
    const verifier: ICredentialVerifier = { verify: jest.fn().mockResolvedValue(true) };
    const service = new AuthService(userRepo, verifier);

    const result = await service.login('parent@example.com', 'password1');
    expect(result.accessToken).toBeTruthy();
    expect(result.refreshToken).toBeTruthy();
    expect(result.user.role).toBe('PARENT');
  });

  it('TEACHER/ADMIN 역할은 로그인이 거부된다 (정책 #1)', async () => {
    const userRepo: IUserAccountRepository = {
      findByEmail: jest.fn().mockResolvedValue(makeUser({ role: 'ADMIN' })),
      findById: jest.fn(),
    };
    const verifier: ICredentialVerifier = { verify: jest.fn().mockResolvedValue(true) };
    const service = new AuthService(userRepo, verifier);

    await expect(service.login('admin@example.com', 'password1')).rejects.toBeInstanceOf(
      UnauthorizedError,
    );
  });

  it('존재하지 않는 사용자는 UnauthorizedError', async () => {
    const userRepo: IUserAccountRepository = {
      findByEmail: jest.fn().mockResolvedValue(null),
      findById: jest.fn(),
    };
    const verifier: ICredentialVerifier = { verify: jest.fn() };
    const service = new AuthService(userRepo, verifier);

    await expect(service.login('nobody@example.com', 'password1')).rejects.toBeInstanceOf(
      UnauthorizedError,
    );
  });
});
