import { PlaceholderRecommendationService } from '@/services/recommendation/PlaceholderRecommendationService';

describe('PlaceholderRecommendationService', () => {
  const service = new PlaceholderRecommendationService();

  it('recommendForDomain always returns isMock=true (정책 #4/#5)', async () => {
    const result = await service.recommendForDomain({
      studentId: 1,
      resultId: 1,
      passDomain: 'PLANNING',
      ageBand: '초1~2',
      environment: 'HOME',
    });
    expect(result.isMock).toBe(true);
    expect(result.recommendation).toBeTruthy();
    expect(result.reason).toBeTruthy();
  });

  it('generateDailyPrescription returns at most 3 items and isMock=true', async () => {
    const result = await service.generateDailyPrescription(1, 1);
    expect(result.isMock).toBe(true);
    expect(result.items.length).toBeLessThanOrEqual(3);
    expect(result.items.every((i) => i.isMock)).toBe(true);
    expect(result.parentQuestion).toBeTruthy();
  });

  it('returns different mock content per PASS domain', async () => {
    const planning = await service.recommendForDomain({
      studentId: 1,
      resultId: 1,
      passDomain: 'PLANNING',
      ageBand: '초1~2',
      environment: 'HOME',
    });
    const attention = await service.recommendForDomain({
      studentId: 1,
      resultId: 1,
      passDomain: 'ATTENTION',
      ageBand: '초1~2',
      environment: 'HOME',
    });
    expect(planning.recommendation).not.toEqual(attention.recommendation);
  });
});
