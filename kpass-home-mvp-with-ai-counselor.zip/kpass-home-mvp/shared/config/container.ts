import {
  ActivityLogRepository,
  ActivityRepository,
  DailyLearningPlanRepository,
  GrowthReportRepository,
  PassResultRepository,
  RecommendationRepository,
  StudentRepository,
  UserAccountRepository,
} from '@/repositories/kysely';
import {
  AgeBandMappingRepository,
  CognitiveProfileRepository,
  DifficultyMappingRepository,
  TrainingHistoryRepository,
  TrainingProgramRepository,
} from '@/repositories/kysely/TrainingProgramRepository';
import {
  HomeMonthlyReportRepository,
  HomeTrainingLogRepository,
  HomeTrainingPlanRepository,
} from '@/repositories/kysely/HomeTrainingPlanRepository';
import {
  AvoidPhraseRepository,
  HomeAiChatLogRepository,
  ParentFaqRepository,
  ParentLifeCaseRepository,
  TeacherStrategyRepository,
} from '@/repositories/kysely/HomeAiCounselorRepository';
import { PlaceholderCredentialVerifier } from '@/services/auth/CredentialVerifier';
import { AuthService } from '@/services/auth/AuthService';
import { StudentService } from '@/services/pass/StudentService';
import { PassResultService } from '@/services/pass/PassResultService';
import { LibraryRecommendationService } from '@/domain/services/LibraryRecommendationService';
import { ParentExplanationComposerService } from '@/domain/services/ParentExplanationComposerService';
import { StudentUnderstandingComposerService } from '@/domain/services/StudentUnderstandingComposerService';
import { HomeDashboardService } from '@/services/recommendation/HomeDashboardService';
import { WeeklyPlannerService } from '@/services/recommendation/WeeklyPlannerService';
import { TeacherDashboardService } from '@/services/recommendation/TeacherDashboardService';
import { HomeAiCounselorChatService } from '@/services/home-ai/HomeAiCounselorChatService';
import { ActivityLogService } from '@/services/growth/ActivityLogService';
import { GrowthReportService } from '@/services/growth/GrowthReportService';
import { ReportPdfService } from '@/services/report/ReportPdfService';

/**
 * 경량 DI 컨테이너.
 * NestJS 등 프레임워크 없이 지시서 §10 "DI" 요구사항을 만족하기 위해, 모든
 * 서비스는 생성자 주입(constructor injection)으로 Repository/Service 인터페이스에만
 * 의존하고, 구체 구현체는 여기 한 곳에서만 조립한다.
 *
 * [리팩토링] PlaceholderRecommendationService -> LibraryRecommendationService로 교체.
 * Home AI는 이제 "Weekly Planner AI"로 재정의된다(대화형 챗봇 아님):
 * WeeklyPlannerService가 신규 주 진입점이며, 기존 HomeDashboardService(일일 처방)는
 * 하위호환을 위해 남겨두되 두 서비스 모두 동일한 recommendationService
 * (LibraryRecommendationService)만 사용한다 — Home AI가 임의로 훈련을 생성하는 경로는
 * 존재하지 않는다.
 */
class Container {
  // Repositories
  readonly userAccountRepo = new UserAccountRepository();
  readonly studentRepo = new StudentRepository();
  readonly passResultRepo = new PassResultRepository();
  readonly activityRepo = new ActivityRepository(); // deprecated: pass_training_program으로 대체됨. 신규 로직에서 사용 금지.
  readonly recommendationRepo = new RecommendationRepository();
  readonly dailyLearningPlanRepo = new DailyLearningPlanRepository();
  readonly activityLogRepo = new ActivityLogRepository();
  readonly growthReportRepo = new GrowthReportRepository();

  // PASS Cognitive Training Library repositories
  readonly trainingProgramRepo = new TrainingProgramRepository();
  readonly cognitiveProfileRepo = new CognitiveProfileRepository();
  readonly trainingHistoryRepo = new TrainingHistoryRepository();
  readonly ageBandMappingRepo = new AgeBandMappingRepository();
  readonly difficultyMappingRepo = new DifficultyMappingRepository();

  // Home AI (Weekly Planner) repositories
  readonly homeTrainingPlanRepo = new HomeTrainingPlanRepository();
  readonly homeTrainingLogRepo = new HomeTrainingLogRepository();
  readonly homeMonthlyReportRepo = new HomeMonthlyReportRepository();

  // Home AI 상담사(AI Coach) 콘텐츠 라이브러리 + 상담 로그 repositories
  readonly parentFaqRepo = new ParentFaqRepository();
  readonly parentLifeCaseRepo = new ParentLifeCaseRepository();
  readonly avoidPhraseRepo = new AvoidPhraseRepository();
  readonly teacherStrategyRepo = new TeacherStrategyRepository();
  readonly homeAiChatLogRepo = new HomeAiChatLogRepository();

  // Cross-cutting
  readonly credentialVerifier = new PlaceholderCredentialVerifier();
  readonly recommendationService = new LibraryRecommendationService(
    this.trainingProgramRepo,
    this.cognitiveProfileRepo,
    this.trainingHistoryRepo,
    this.passResultRepo,
    this.studentRepo,
    this.ageBandMappingRepo,
    this.difficultyMappingRepo,
  );

  // Application services
  readonly authService = new AuthService(this.userAccountRepo, this.credentialVerifier);
  readonly studentService = new StudentService(this.studentRepo);
  readonly passResultService = new PassResultService(this.passResultRepo);

  /** @deprecated Home AI의 신규 주 진입점은 weeklyPlannerService이다. 하위호환용으로만 유지. */
  readonly homeDashboardService = new HomeDashboardService(
    this.passResultService,
    this.recommendationService,
    this.recommendationRepo,
    this.dailyLearningPlanRepo,
  );

  readonly weeklyPlannerService = new WeeklyPlannerService(
    this.passResultService,
    this.recommendationService,
    this.homeTrainingPlanRepo,
    this.homeTrainingLogRepo,
    this.homeMonthlyReportRepo,
    this.trainingHistoryRepo,
    this.cognitiveProfileRepo,
    this.studentRepo,
    this.ageBandMappingRepo,
    this.difficultyMappingRepo,
    this.trainingProgramRepo,
  );

  readonly teacherDashboardService = new TeacherDashboardService(
    this.passResultService,
    this.recommendationService,
    this.recommendationRepo,
    this.studentRepo,
  );
  // Home AI 상담사(AI Coach): 결과지(요약보기/인지훈련 플래너/인지+정서훈련)를
  // 연결하는 Hub. ①/② 번은 비생성형 컴포저, ③/④ 번(상담)만 생성형 AI를 사용한다.
  readonly parentExplanationComposerService = new ParentExplanationComposerService(
    this.passResultService,
    this.cognitiveProfileRepo,
    this.parentLifeCaseRepo,
    this.avoidPhraseRepo,
    this.parentFaqRepo,
  );
  readonly studentUnderstandingComposerService = new StudentUnderstandingComposerService(
    this.passResultService,
    this.cognitiveProfileRepo,
    this.teacherStrategyRepo,
  );
  readonly homeAiCounselorChatService = new HomeAiCounselorChatService(
    this.passResultService,
    this.recommendationService,
    this.homeAiChatLogRepo,
    this.parentFaqRepo,
    this.parentLifeCaseRepo,
    this.avoidPhraseRepo,
    this.teacherStrategyRepo,
  );

  readonly activityLogService = new ActivityLogService(this.activityLogRepo);
  readonly growthReportService = new GrowthReportService(
    this.activityLogRepo,
    this.growthReportRepo,
  );
  readonly reportPdfService = new ReportPdfService();
}

let instance: Container | undefined;

export function getContainer(): Container {
  if (!instance) {
    instance = new Container();
  }
  return instance;
}
