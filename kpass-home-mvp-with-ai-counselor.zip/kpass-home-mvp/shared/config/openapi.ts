/**
 * OpenAPI 3.0 스펙.
 * 지시서 §7 "Swagger 자동 생성" 요구사항 구현. Next.js API Routes는 런타임에
 * 소스 JSDoc을 읽을 수 없으므로(번들링됨), 라우트 핸들러 상단의 @openapi 주석과
 * 1:1로 동기화된 정적 스펙을 유지한다. 라우트 추가/변경 시 이 파일도 함께 갱신한다.
 */
export const openApiSpec = {
  openapi: '3.0.3',
  info: {
    title: 'K-PASS Home AI Teacher API',
    version: 'v1',
    description:
      'K-PASS Home AI Teacher MVP REST API. AI 추천/근거 관련 응답은 모두 ' +
      'Mock Data(정책 #5) 기반이며 isMock 필드로 명시됩니다.',
  },
  servers: [{ url: '/api/v1' }],
  components: {
    securitySchemes: {
      bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' },
    },
    schemas: {
      ApiErrorResponse: {
        type: 'object',
        properties: {
          success: { type: 'boolean', example: false },
          error: {
            type: 'object',
            properties: {
              code: { type: 'string' },
              message: { type: 'string' },
            },
          },
        },
      },
    },
  },
  paths: {
    '/auth/login': {
      post: {
        tags: ['Auth'],
        summary: '부모/학생 로그인',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['email', 'password'],
                properties: {
                  email: { type: 'string', format: 'email' },
                  password: { type: 'string', minLength: 4 },
                },
              },
            },
          },
        },
        responses: {
          '200': { description: 'Access/Refresh Token 발급 성공' },
          '401': { description: '인증 실패' },
        },
      },
    },
    '/auth/refresh': {
      post: {
        tags: ['Auth'],
        summary: 'Access Token 재발급',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['refreshToken'],
                properties: { refreshToken: { type: 'string' } },
              },
            },
          },
        },
        responses: { '200': { description: '재발급 성공' } },
      },
    },
    '/students': {
      get: {
        tags: ['Student'],
        summary: '내 자녀(학생) 목록 조회',
        security: [{ bearerAuth: [] }],
        responses: { '200': { description: '학생 목록' } },
      },
    },
    '/students/{studentId}/pass-result': {
      get: {
        tags: ['PASS'],
        summary: '최신 K-PASS 검사 결과 + AI Brain Analysis',
        security: [{ bearerAuth: [] }],
        parameters: [
          { name: 'studentId', in: 'path', required: true, schema: { type: 'integer' } },
        ],
        responses: { '200': { description: '검사 결과 및 분석' }, '404': { description: '결과 없음' } },
      },
    },
    '/students/{studentId}/home-dashboard': {
      get: {
        tags: ['Home'],
        summary: '가정 인지훈련 처방 (오늘의 인지훈련/부모 질문/부모 칭찬/생활 속 PASS)',
        security: [{ bearerAuth: [] }],
        parameters: [
          { name: 'studentId', in: 'path', required: true, schema: { type: 'integer' } },
        ],
        responses: { '200': { description: 'Mock Data 기반 가정 인지훈련 처방' } },
      },
    },
    '/students/{studentId}/activity-logs': {
      get: {
        tags: ['Growth'],
        summary: '활동 수행 기록 목록',
        security: [{ bearerAuth: [] }],
        parameters: [
          { name: 'studentId', in: 'path', required: true, schema: { type: 'integer' } },
        ],
        responses: { '200': { description: '기록 목록' } },
      },
      post: {
        tags: ['Growth'],
        summary: '활동 완료 기록',
        security: [{ bearerAuth: [] }],
        parameters: [
          { name: 'studentId', in: 'path', required: true, schema: { type: 'integer' } },
        ],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['activityId'],
                properties: {
                  activityId: { type: 'string' },
                  score: { type: 'number', minimum: 0, maximum: 100, nullable: true },
                  memo: { type: 'string', nullable: true },
                },
              },
            },
          },
        },
        responses: { '201': { description: '기록 완료' } },
      },
    },
    '/students/{studentId}/growth-report': {
      get: {
        tags: ['Growth'],
        summary: '성장 리포트 대시보드',
        security: [{ bearerAuth: [] }],
        parameters: [
          { name: 'studentId', in: 'path', required: true, schema: { type: 'integer' } },
        ],
        responses: { '200': { description: '성장 리포트 데이터' } },
      },
    },
    '/students/{studentId}/report/pdf': {
      get: {
        tags: ['Report'],
        summary: '가정 인지훈련 결과지 PDF 다운로드',
        security: [{ bearerAuth: [] }],
        parameters: [
          { name: 'studentId', in: 'path', required: true, schema: { type: 'integer' } },
        ],
        responses: {
          '200': {
            description: 'PDF 파일',
            content: { 'application/pdf': { schema: { type: 'string', format: 'binary' } } },
          },
        },
      },
    },
    '/students/{studentId}/home-ai/parent/explanation': {
      get: {
        tags: ['HomeAiCounselor'],
        summary: 'Home AI 상담사 - 부모가 이해하기 쉽게 설명',
        security: [{ bearerAuth: [] }],
        parameters: [
          { name: 'studentId', in: 'path', required: true, schema: { type: 'integer' } },
        ],
        responses: { '200': { description: '부모용 결과지 번역 화면 데이터' } },
      },
    },
    '/students/{studentId}/home-ai/parent/chat': {
      post: {
        tags: ['HomeAiCounselor'],
        summary: 'Home AI 상담사 - 부모 AI 상담(생성형 AI, 하루 10회 제한)',
        security: [{ bearerAuth: [] }],
        parameters: [
          { name: 'studentId', in: 'path', required: true, schema: { type: 'integer' } },
        ],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: { type: 'object', properties: { message: { type: 'string' } }, required: ['message'] },
            },
          },
        },
        responses: {
          '200': { description: 'AI 상담 응답 + 인지훈련 플래너/인지+정서훈련 연결 링크' },
          '429': { description: '하루 10회 사용량 초과' },
        },
      },
    },
    '/teacher/students/{studentId}/home-ai/understanding': {
      get: {
        tags: ['HomeAiCounselor'],
        summary: 'Home AI 상담사 - 학생 이해하기',
        security: [{ bearerAuth: [] }],
        parameters: [
          { name: 'studentId', in: 'path', required: true, schema: { type: 'integer' } },
        ],
        responses: { '200': { description: '교사용 결과지 번역 화면 데이터' } },
      },
    },
    '/teacher/students/{studentId}/home-ai/chat': {
      post: {
        tags: ['HomeAiCounselor'],
        summary: 'Home AI 상담사 - 교사 AI 상담(생성형 AI, 하루 10회 제한)',
        security: [{ bearerAuth: [] }],
        parameters: [
          { name: 'studentId', in: 'path', required: true, schema: { type: 'integer' } },
        ],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: { type: 'object', properties: { message: { type: 'string' } }, required: ['message'] },
            },
          },
        },
        responses: {
          '200': { description: 'AI 상담 응답 + 인지훈련 플래너/인지+정서훈련 연결 링크' },
          '429': { description: '하루 10회 사용량 초과' },
        },
      },
    },
  },
} as const;
