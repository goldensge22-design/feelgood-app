import { Kysely, PostgresDialect } from 'kysely';
import { Pool } from 'pg';
import { Database } from '@/db/types';

declare global {
  // eslint-disable-next-line no-var
  var __db: Kysely<Database> | undefined;
}

function createDb(): Kysely<Database> {
  const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    max: 10,
  });

  return new Kysely<Database>({
    dialect: new PostgresDialect({ pool }),
  });
}

/**
 * Next.js 개발 모드 hot-reload 시 커넥션 풀 중복 생성을 방지하기 위한 싱글톤.
 */
export const db: Kysely<Database> = global.__db ?? createDb();

if (process.env.NODE_ENV !== 'production') {
  global.__db = db;
}
