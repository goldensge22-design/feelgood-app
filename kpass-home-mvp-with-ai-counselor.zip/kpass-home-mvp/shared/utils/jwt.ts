import jwt, { SignOptions } from 'jsonwebtoken';
import { config } from '@/shared/config/env';
import { UnauthorizedError } from '@/shared/errors/AppError';

export interface AccessTokenPayload {
  userId: number;
  organizationId: number;
  role: string;
  email: string;
}

export interface RefreshTokenPayload {
  userId: number;
  tokenVersion: number;
}

export function signAccessToken(payload: AccessTokenPayload): string {
  const options: SignOptions = { expiresIn: config.jwt.accessTtl as SignOptions['expiresIn'] };
  return jwt.sign(payload, config.jwt.accessSecret, options);
}

export function signRefreshToken(payload: RefreshTokenPayload): string {
  const options: SignOptions = { expiresIn: config.jwt.refreshTtl as SignOptions['expiresIn'] };
  return jwt.sign(payload, config.jwt.refreshSecret, options);
}

export function verifyAccessToken(token: string): AccessTokenPayload {
  try {
    return jwt.verify(token, config.jwt.accessSecret) as AccessTokenPayload;
  } catch {
    throw new UnauthorizedError('토큰이 유효하지 않거나 만료되었습니다.');
  }
}

export function verifyRefreshToken(token: string): RefreshTokenPayload {
  try {
    return jwt.verify(token, config.jwt.refreshSecret) as RefreshTokenPayload;
  } catch {
    throw new UnauthorizedError('Refresh Token이 유효하지 않거나 만료되었습니다.');
  }
}

export function extractBearerToken(authHeader: string | null): string {
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    throw new UnauthorizedError('Authorization 헤더가 필요합니다.');
  }
  return authHeader.slice('Bearer '.length).trim();
}
