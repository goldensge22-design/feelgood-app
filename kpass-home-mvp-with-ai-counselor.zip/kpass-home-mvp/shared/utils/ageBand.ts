/**
 * 만 나이 계산. LibraryRecommendationService, WeeklyPlannerService에서
 * age_band_mapping 조회 전 공통으로 사용한다.
 */
export function calculateAgeInYears(birthDate: Date, asOf: Date = new Date()): number {
  let age = asOf.getFullYear() - birthDate.getFullYear();
  const monthDiff = asOf.getMonth() - birthDate.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && asOf.getDate() < birthDate.getDate())) {
    age -= 1;
  }
  return age;
}
