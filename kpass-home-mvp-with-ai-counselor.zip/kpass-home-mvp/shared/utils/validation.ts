import { z } from 'zod';
import { ValidationError } from '@/shared/errors/AppError';

export const loginSchema = z.object({
  email: z.string().email('올바른 이메일 형식이 아닙니다.'),
  password: z.string().min(4, '비밀번호는 4자 이상이어야 합니다.'),
});

export const refreshSchema = z.object({
  refreshToken: z.string().min(1, 'refreshToken이 필요합니다.'),
});

export const activityLogCreateSchema = z.object({
  activityId: z.string().min(1, 'activityId가 필요합니다.'),
  score: z.number().min(0).max(100).nullable().optional(),
  memo: z.string().max(1000).nullable().optional(),
});

export const growthReportCreateSchema = z.object({
  periodStart: z.string().datetime().or(z.string().date()),
  periodEnd: z.string().datetime().or(z.string().date()),
  summary: z.string().min(1),
  nextRecommendation: z.string().min(1),
});

// ---------------------------------------------------------------------
// Home AI (Weekly Planner) 스키마
// ---------------------------------------------------------------------
export const weeklyPlanCreateSchema = z.object({
  studentId: z.number().int().positive(),
  weekStartDate: z.string().date('weekStartDate는 YYYY-MM-DD 형식이어야 합니다.'),
});

export const planItemCompleteSchema = z.object({
  successRate: z.number().min(0).max(100),
  outcome: z.enum(['SUCCESS', 'PARTIAL', 'FAIL']),
  parentMemo: z.string().max(1000).nullable().optional(),
  childReaction: z.string().max(1000).nullable().optional(),
});

export const monthlyReportGenerateSchema = z.object({
  studentId: z.number().int().positive(),
  month: z.string().regex(/^\d{4}-\d{2}$/, 'month는 YYYY-MM 형식이어야 합니다.'),
});

// ---------------------------------------------------------------------
// Home AI 상담사(AI Coach) 스키마
// ---------------------------------------------------------------------
export const homeAiChatSchema = z.object({
  message: z.string().min(1, '상담 내용을 입력해주세요.').max(500, '상담 내용은 500자 이내로 입력해주세요.'),
});

export function parseOrThrow<T>(schema: z.ZodType<T>, payload: unknown): T {
  const result = schema.safeParse(payload);
  if (!result.success) {
    throw new ValidationError('입력값이 올바르지 않습니다.', result.error.flatten());
  }
  return result.data;
}

export function parseIntParamOrThrow(value: string, fieldName: string): number {
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed <= 0) {
    throw new ValidationError(`${fieldName}은(는) 올바른 ID 형식이 아닙니다.`);
  }
  return parsed;
}
