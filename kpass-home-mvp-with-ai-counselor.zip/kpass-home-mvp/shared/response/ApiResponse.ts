/**
 * 표준 API 응답 포맷.
 * 지시서 §7 "표준 응답(Response, ErrorResponse) 사용" 요구사항에 대한 구현.
 * 원본 문서에 정확한 스키마가 없어(누락) 업계 표준 REST 컨벤션으로 확정함.
 */

export interface ApiSuccessResponse<T> {
  success: true;
  data: T;
  meta?: Record<string, unknown>;
}

export interface ApiErrorBody {
  code: string;
  message: string;
  details?: unknown;
}

export interface ApiErrorResponse {
  success: false;
  error: ApiErrorBody;
}

export type ApiResponse<T> = ApiSuccessResponse<T> | ApiErrorResponse;

export function ok<T>(data: T, meta?: Record<string, unknown>): ApiSuccessResponse<T> {
  return { success: true, data, ...(meta ? { meta } : {}) };
}

export function fail(code: string, message: string, details?: unknown): ApiErrorResponse {
  return {
    success: false,
    error: { code, message, ...(details !== undefined ? { details } : {}) },
  };
}
