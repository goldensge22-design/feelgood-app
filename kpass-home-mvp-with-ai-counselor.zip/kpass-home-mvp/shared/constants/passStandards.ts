/**
 * K-PASS / D-CAS 표준점수 분류 기준.
 * 출처: 프로젝트 고정 표준(문서 6종에는 명시적 표로 존재하지 않으나, Round4
 * 01_AI_Brain_Analysis 예시(Planning 82→낮음, Attention 91→평균 범위)와 Round3C
 * AI-RULE-001/002의 "Score < 85" 임계값과 일치하는 고정 규칙).
 *
 * 하(Low): SS <= 85
 * 중(Mid): 86 <= SS <= 119
 * 상(High): SS >= 120
 */
export const PASS_SCORE_THRESHOLDS = {
  LOW_MAX: 85,
  MID_MIN: 86,
  MID_MAX: 119,
  HIGH_MIN: 120,
} as const;

export type PassBandLevel = 'LOW' | 'MID' | 'HIGH';

export function classifyPassScore(score: number): PassBandLevel {
  if (score <= PASS_SCORE_THRESHOLDS.LOW_MAX) return 'LOW';
  if (score >= PASS_SCORE_THRESHOLDS.HIGH_MIN) return 'HIGH';
  return 'MID';
}

export const PASS_DOMAINS = ['PLANNING', 'ATTENTION', 'SIMULTANEOUS', 'SUCCESSIVE'] as const;
export type PassDomain = (typeof PASS_DOMAINS)[number];

export const USER_ROLES = {
  PARENT: 'PARENT',
  STUDENT: 'STUDENT',
  TEACHER: 'TEACHER',
  // ADMIN은 ERD 상 role 값으로 존재하나 이 MVP 범위에서는 사용/인가하지 않는다.
} as const;

export const ORG_TYPE_HOME = 'HOME';

export const ENVIRONMENT_HOME = 'HOME';
