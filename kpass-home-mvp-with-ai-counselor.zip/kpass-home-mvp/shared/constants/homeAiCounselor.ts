/**
 * Home AI 상담사(AI Coach) 정책 상수.
 * "AI 사용은 하루 10회 생성으로 제한한다" — 부모 AI 상담 / 교사 AI 상담 각각 별도 한도.
 */
export const HOME_AI_CHAT_DAILY_LIMIT = 10;
