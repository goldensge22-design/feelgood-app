import { NextRequest, NextResponse } from 'next/server';
import { AccessTokenPayload, extractBearerToken, verifyAccessToken } from '@/shared/utils/jwt';
import { ForbiddenError } from '@/shared/errors/AppError';
import { handleApiError } from '@/shared/errors/handleApiError';

export type AuthenticatedHandler<Ctx = unknown> = (
  req: NextRequest,
  auth: AccessTokenPayload,
  ctx: Ctx,
) => Promise<NextResponse>;

/**
 * RBAC 인증 가드.
 * 지시서 §15 "JWT / RBAC" 요구사항 구현.
 * 이 MVP는 정책 #1에 따라 PARENT/STUDENT 역할만 허용한다. TEACHER/ADMIN 토큰이
 * 들어와도 이 가드가 있는 모든 Home API에서 거부된다.
 */
export function withAuth<Ctx = unknown>(
  handler: AuthenticatedHandler<Ctx>,
  allowedRoles: readonly string[] = ['PARENT', 'STUDENT'],
) {
  return async (req: NextRequest, ctx: Ctx): Promise<NextResponse> => {
    try {
      const token = extractBearerToken(req.headers.get('authorization'));
      const payload = verifyAccessToken(token);

      if (!allowedRoles.includes(payload.role)) {
        throw new ForbiddenError('이 API에 접근할 권한이 없습니다.');
      }

      return await handler(req, payload, ctx);
    } catch (error) {
      return handleApiError(error);
    }
  };
}
