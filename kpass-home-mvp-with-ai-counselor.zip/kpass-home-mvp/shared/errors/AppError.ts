/**
 * 공통 Exception 계층.
 * 지시서 §11 "예외는 공통 Exception Handler에서 처리한다. 사용자에게 내부 오류를
 * 노출하지 않는다."의 구현 기반.
 */

export class AppError extends Error {
  public readonly code: string;
  public readonly httpStatus: number;
  public readonly details?: unknown;

  constructor(code: string, message: string, httpStatus: number, details?: unknown) {
    super(message);
    this.name = 'AppError';
    this.code = code;
    this.httpStatus = httpStatus;
    this.details = details;
  }
}

export class ValidationError extends AppError {
  constructor(message = '입력값이 올바르지 않습니다.', details?: unknown) {
    super('VALIDATION_ERROR', message, 400, details);
    this.name = 'ValidationError';
  }
}

export class UnauthorizedError extends AppError {
  constructor(message = '인증이 필요합니다.') {
    super('UNAUTHORIZED', message, 401);
    this.name = 'UnauthorizedError';
  }
}

export class ForbiddenError extends AppError {
  constructor(message = '접근 권한이 없습니다.') {
    super('FORBIDDEN', message, 403);
    this.name = 'ForbiddenError';
  }
}

export class NotFoundError extends AppError {
  constructor(resource = '리소스', message?: string) {
    super('NOT_FOUND', message ?? `${resource}를 찾을 수 없습니다.`, 404);
    this.name = 'NotFoundError';
  }
}

export class ConflictError extends AppError {
  constructor(message = '이미 존재하는 데이터입니다.') {
    super('CONFLICT', message, 409, undefined);
    this.name = 'ConflictError';
  }
}

/**
 * Home AI 상담사(부모 AI 상담 / 교사 AI 상담)의 "하루 10회 생성" 제한 초과 시 사용.
 */
export class RateLimitError extends AppError {
  constructor(message = '오늘 사용 가능한 AI 상담 횟수를 모두 사용했습니다. 내일 다시 시도해주세요.') {
    super('RATE_LIMIT_EXCEEDED', message, 429);
    this.name = 'RateLimitError';
  }
}

/**
 * 문서에 정의되지 않아 실제 구현이 불가능한 지점을 명시적으로 표시하기 위한 예외.
 * 지시서 §3 "문서에 없는 기능 추가 금지" / §8 "질문하지 않는다. 추정하지 않는다."
 * 를 지키기 위해, 추측 구현 대신 이 예외 + TODO 주석을 사용한다.
 */
export class NotImplementedPlaceholderError extends AppError {
  constructor(featureTodoId: string, message: string) {
    super('NOT_IMPLEMENTED_PLACEHOLDER', `[${featureTodoId}] ${message}`, 501);
    this.name = 'NotImplementedPlaceholderError';
  }
}

export function isAppError(err: unknown): err is AppError {
  return err instanceof AppError;
}
