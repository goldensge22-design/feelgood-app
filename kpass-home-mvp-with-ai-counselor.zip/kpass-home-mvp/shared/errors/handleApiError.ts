import { NextResponse } from 'next/server';
import { isAppError } from '@/shared/errors/AppError';
import { fail } from '@/shared/response/ApiResponse';

/**
 * 공통 Exception Handler.
 * 모든 app/api/v1/** route handler는 이 함수를 통해 에러를 응답으로 변환한다.
 * 내부 스택트레이스나 원본 에러 메시지는 절대 클라이언트에 노출하지 않는다(§11).
 */
export function handleApiError(error: unknown): NextResponse {
  if (isAppError(error)) {
    // eslint-disable-next-line no-console
    console.error(`[AppError] ${error.code} ${error.message}`, error.details ?? '');
    return NextResponse.json(fail(error.code, error.message, error.details), {
      status: error.httpStatus,
    });
  }

  // eslint-disable-next-line no-console
  console.error('[UnhandledError]', error);
  return NextResponse.json(
    fail('INTERNAL_SERVER_ERROR', '일시적인 오류가 발생했습니다. 잠시 후 다시 시도해주세요.'),
    { status: 500 },
  );
}
