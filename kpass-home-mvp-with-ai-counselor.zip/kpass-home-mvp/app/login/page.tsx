import { LoginForm } from '@/features/auth/LoginForm';

export default function LoginPage(): JSX.Element {
  return (
    <>
      <header className="kp-app-header">
        <h1>K-PASS 인지훈련 AI 코치</h1>
        <p>우리 아이 맞춤 인지훈련 처방을 확인하세요</p>
      </header>
      <div className="kp-section">
        <LoginForm />
      </div>
    </>
  );
}
