import { NextResponse } from 'next/server';
import { getContainer } from '@/shared/config/container';
import { ok } from '@/shared/response/ApiResponse';
import { withAuth } from '@/shared/middleware/withAuth';
import { parseIntParamOrThrow } from '@/shared/utils/validation';

interface RouteCtx {
  params: { studentId: string };
}

/**
 * @openapi
 * /api/v1/teacher/students/{studentId}/recommendation:
 *   get:
 *     summary: 교사 화면 - 학생 1인에 대한 PASS Cognitive Training Library 추천
 *     description: >
 *       Program Recommendation Engine(LibraryRecommendationService)이
 *       pass_training_program에서 선택한 프로그램만 반환한다. isMock=false.
 *     tags: [Teacher]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: ageBand
 *         schema: { type: string, example: '8-10' }
 */
export const GET = withAuth<RouteCtx>(async (req, auth, ctx) => {
  const container = getContainer();
  const studentId = parseIntParamOrThrow(ctx.params.studentId, 'studentId');
  const ageBand = new URL(req.url).searchParams.get('ageBand') ?? '8-10';

  await container.studentService.getStudentOrThrow(studentId, auth.organizationId);
  const card = await container.teacherDashboardService.getStudentRecommendation(studentId, ageBand);

  return NextResponse.json(ok(card), { status: 200 });
}, ['TEACHER']);
