import { NextResponse } from 'next/server';
import { getContainer } from '@/shared/config/container';
import { ok } from '@/shared/response/ApiResponse';
import { withAuth } from '@/shared/middleware/withAuth';
import { parseIntParamOrThrow } from '@/shared/utils/validation';

interface RouteCtx {
  params: { studentId: string };
}

/**
 * @openapi
 * /api/v1/teacher/students/{studentId}/home-ai/understanding:
 *   get:
 *     summary: Home AI 상담사 - 선생님용 AI - "학생 이해하기"
 *     description: >
 *       결과지 · 81 Cognitive Profile · 교사 전략 라이브러리만 조합한
 *       비생성형 번역 화면이다.
 *     tags: [HomeAiCounselor]
 *     security: [{ bearerAuth: [] }]
 */
export const GET = withAuth<RouteCtx>(
  async (_req, auth, ctx) => {
    const container = getContainer();
    const studentId = parseIntParamOrThrow(ctx.params.studentId, 'studentId');

    await container.studentService.getStudentOrThrow(studentId, auth.organizationId);
    const understanding = await container.studentUnderstandingComposerService.composeForStudent(studentId);

    return NextResponse.json(ok(understanding), { status: 200 });
  },
  ['TEACHER'],
);
