import { NextResponse } from 'next/server';
import { getContainer } from '@/shared/config/container';
import { ok } from '@/shared/response/ApiResponse';
import { withAuth } from '@/shared/middleware/withAuth';
import { homeAiChatSchema, parseIntParamOrThrow, parseOrThrow } from '@/shared/utils/validation';

interface RouteCtx {
  params: { studentId: string };
}

/**
 * @openapi
 * /api/v1/teacher/students/{studentId}/home-ai/chat:
 *   post:
 *     summary: Home AI 상담사 - 선생님용 AI - "교사 AI 상담" (생성형 AI, 하루 10회 제한)
 *     description: >
 *       학생 지도 전략에 대한 질문에 답한다. 새로운 훈련을 생성하지 않으며,
 *       항상 기존 인지훈련 플래너/인지+정서훈련 프로그램으로 연결한다.
 *     tags: [HomeAiCounselor]
 *     security: [{ bearerAuth: [] }]
 */
export const POST = withAuth<RouteCtx>(
  async (req, auth, ctx) => {
    const container = getContainer();
    const studentId = parseIntParamOrThrow(ctx.params.studentId, 'studentId');
    const body = parseOrThrow(homeAiChatSchema, await req.json());

    await container.studentService.getStudentOrThrow(studentId, auth.organizationId);
    const result = await container.homeAiCounselorChatService.chat({
      studentId,
      requestedByUserId: auth.userId,
      audience: 'TEACHER',
      message: body.message,
    });

    return NextResponse.json(ok(result), { status: 200 });
  },
  ['TEACHER'],
);
