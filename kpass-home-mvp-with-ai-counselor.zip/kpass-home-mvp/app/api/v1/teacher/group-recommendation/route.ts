import { NextResponse } from 'next/server';
import { getContainer } from '@/shared/config/container';
import { ok } from '@/shared/response/ApiResponse';
import { withAuth } from '@/shared/middleware/withAuth';
import { ValidationError } from '@/shared/errors/AppError';
import { PassDomain } from '@/shared/constants/passStandards';

/**
 * @openapi
 * /api/v1/teacher/group-recommendation:
 *   post:
 *     summary: 교사 화면 - 그룹(동일 약점 영역) 추천
 *     description: >
 *       Program Recommendation Engine이 pass_training_program에서 선택한
 *       프로그램 1개를 그룹 전체에 대해 반환한다. 프로그램은 생성되지 않는다.
 *     tags: [Teacher]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [studentIds, passDomain, ageBand]
 *             properties:
 *               studentIds: { type: array, items: { type: integer } }
 *               passDomain: { type: string, enum: [PLANNING, ATTENTION, SIMULTANEOUS, SUCCESSIVE] }
 *               ageBand: { type: string, example: '8-10' }
 */
export const POST = withAuth(async (req) => {
  const body = (await req.json()) as {
    studentIds?: number[];
    passDomain?: PassDomain;
    ageBand?: string;
  };

  if (!body.studentIds?.length || !body.passDomain || !body.ageBand) {
    throw new ValidationError('studentIds, passDomain, ageBand는 필수입니다.');
  }

  const container = getContainer();
  const card = await container.teacherDashboardService.getGroupRecommendation(
    body.studentIds,
    body.passDomain,
    body.ageBand,
  );

  return NextResponse.json(ok(card), { status: 200 });
}, ['TEACHER']);
