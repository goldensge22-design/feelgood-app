import { NextResponse } from 'next/server';
import { openApiSpec } from '@/shared/config/openapi';

export async function GET(): Promise<NextResponse> {
  return NextResponse.json(openApiSpec, { status: 200 });
}
