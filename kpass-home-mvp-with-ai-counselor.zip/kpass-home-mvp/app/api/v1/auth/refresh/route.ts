import { NextRequest, NextResponse } from 'next/server';
import { getContainer } from '@/shared/config/container';
import { handleApiError } from '@/shared/errors/handleApiError';
import { ok } from '@/shared/response/ApiResponse';
import { parseOrThrow, refreshSchema } from '@/shared/utils/validation';

/**
 * @openapi
 * /api/v1/auth/refresh:
 *   post:
 *     summary: Access Token 재발급
 *     tags: [Auth]
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    const body = await req.json();
    const { refreshToken } = parseOrThrow(refreshSchema, body);
    const result = await getContainer().authService.refresh(refreshToken);
    return NextResponse.json(ok(result), { status: 200 });
  } catch (error) {
    return handleApiError(error);
  }
}
