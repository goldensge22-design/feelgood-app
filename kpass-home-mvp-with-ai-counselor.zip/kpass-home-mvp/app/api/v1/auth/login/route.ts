import { NextRequest, NextResponse } from 'next/server';
import { getContainer } from '@/shared/config/container';
import { handleApiError } from '@/shared/errors/handleApiError';
import { ok } from '@/shared/response/ApiResponse';
import { loginSchema, parseOrThrow } from '@/shared/utils/validation';

/**
 * @openapi
 * /api/v1/auth/login:
 *   post:
 *     summary: 부모/학생 로그인
 *     tags: [Auth]
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    const body = await req.json();
    const { email, password } = parseOrThrow(loginSchema, body);

    const result = await getContainer().authService.login(email, password);
    return NextResponse.json(ok(result), { status: 200 });
  } catch (error) {
    return handleApiError(error);
  }
}
