import { NextResponse } from 'next/server';
import { getContainer } from '@/shared/config/container';
import { ok } from '@/shared/response/ApiResponse';
import { withAuth } from '@/shared/middleware/withAuth';
import { NotFoundError, ValidationError } from '@/shared/errors/AppError';
import { parseIntParamOrThrow } from '@/shared/utils/validation';

interface RouteCtx {
  params: { month: string };
}

/**
 * @openapi
 * /api/v1/home/reports/{month}:
 *   get:
 *     summary: Home AI(Weekly Planner) - 월간 리포트 조회
 *     tags: [Home]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: path
 *         name: month
 *         required: true
 *         schema: { type: string, example: '2026-07' }
 *       - in: query
 *         name: studentId
 *         required: true
 *         schema: { type: integer }
 */
export const GET = withAuth<RouteCtx>(async (req, auth, ctx) => {
  if (!/^\d{4}-\d{2}$/.test(ctx.params.month)) {
    throw new ValidationError('month는 YYYY-MM 형식이어야 합니다.');
  }
  const studentIdParam = new URL(req.url).searchParams.get('studentId');
  if (!studentIdParam) {
    throw new ValidationError('studentId 쿼리 파라미터가 필요합니다.');
  }
  const studentId = parseIntParamOrThrow(studentIdParam, 'studentId');

  const container = getContainer();
  await container.studentService.getStudentOrThrow(studentId, auth.organizationId);
  const report = await container.weeklyPlannerService.getMonthlyReport(studentId, ctx.params.month);
  if (!report) {
    throw new NotFoundError('월간 리포트');
  }

  return NextResponse.json(ok(report), { status: 200 });
});
