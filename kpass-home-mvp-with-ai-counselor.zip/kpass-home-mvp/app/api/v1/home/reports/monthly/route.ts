import { NextResponse } from 'next/server';
import { getContainer } from '@/shared/config/container';
import { ok } from '@/shared/response/ApiResponse';
import { withAuth } from '@/shared/middleware/withAuth';
import { monthlyReportGenerateSchema, parseOrThrow } from '@/shared/utils/validation';

/**
 * @openapi
 * /api/v1/home/reports/monthly:
 *   post:
 *     summary: Home AI(Weekly Planner) - 4주 월간 리포트 생성
 *     description: >
 *       영역별 변화, 이행률, 강점 유지, 약점 보완 진행도, 다음 달 추천 방향을
 *       해당 월의 home_training_plan/home_training_log 데이터로부터 집계한다.
 *     tags: [Home]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [studentId, month]
 *             properties:
 *               studentId: { type: integer }
 *               month: { type: string, example: '2026-07' }
 */
export const POST = withAuth(async (req, auth) => {
  const body = await req.json();
  const { studentId, month } = parseOrThrow(monthlyReportGenerateSchema, body);

  const container = getContainer();
  await container.studentService.getStudentOrThrow(studentId, auth.organizationId);
  const report = await container.weeklyPlannerService.generateMonthlyReport(studentId, month);

  return NextResponse.json(ok(report), { status: 201 });
});
