import { NextResponse } from 'next/server';
import { getContainer } from '@/shared/config/container';
import { ok } from '@/shared/response/ApiResponse';
import { withAuth } from '@/shared/middleware/withAuth';
import { parseOrThrow, weeklyPlanCreateSchema } from '@/shared/utils/validation';
import { ValidationError } from '@/shared/errors/AppError';

/**
 * @openapi
 * /api/v1/home/plans/weekly:
 *   post:
 *     summary: Home AI(Weekly Planner) - 주간 훈련 계획 생성
 *     description: >
 *       검사 결과(81 Cognitive Profile)를 기반으로 PASS Cognitive Training
 *       Library(pass_training_program)에서만 훈련을 선택해 주 5일, 하루 2~3개의
 *       주간 훈련 계획을 자동 설계한다. 챗봇이 아니며, 새 훈련을 생성하지 않는다.
 *     tags: [Home]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [studentId, weekStartDate]
 *             properties:
 *               studentId: { type: integer }
 *               weekStartDate: { type: string, format: date, example: '2026-07-06' }
 */
export const POST = withAuth(async (req, auth) => {
  const body = await req.json();
  const { studentId, weekStartDate } = parseOrThrow(weeklyPlanCreateSchema, body);

  const parsedDate = new Date(`${weekStartDate}T00:00:00Z`);
  if (parsedDate.getUTCDay() !== 1) {
    throw new ValidationError('weekStartDate는 월요일이어야 합니다.');
  }

  const container = getContainer();
  await container.studentService.getStudentOrThrow(studentId, auth.organizationId);
  const plan = await container.weeklyPlannerService.generateWeeklyPlan(studentId, parsedDate);

  return NextResponse.json(ok(plan), { status: 201 });
});
