import { NextResponse } from 'next/server';
import { getContainer } from '@/shared/config/container';
import { ok } from '@/shared/response/ApiResponse';
import { withAuth } from '@/shared/middleware/withAuth';
import { NotFoundError } from '@/shared/errors/AppError';
import { parseIntParamOrThrow, parseOrThrow, planItemCompleteSchema } from '@/shared/utils/validation';

interface RouteCtx {
  params: { itemId: string };
}

/**
 * @openapi
 * /api/v1/home/plans/items/{itemId}/complete:
 *   patch:
 *     summary: Home AI(Weekly Planner) - 훈련 항목 이행 기록(완료 여부/성공률/부모 메모/아이 반응)
 *     tags: [Home]
 *     security: [{ bearerAuth: [] }]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [successRate, outcome]
 *             properties:
 *               successRate: { type: number, minimum: 0, maximum: 100 }
 *               outcome: { type: string, enum: [SUCCESS, PARTIAL, FAIL] }
 *               parentMemo: { type: string, nullable: true }
 *               childReaction: { type: string, nullable: true }
 */
export const PATCH = withAuth<RouteCtx>(async (req, auth, ctx) => {
  const itemId = parseIntParamOrThrow(ctx.params.itemId, 'itemId');
  const body = await req.json();
  const input = parseOrThrow(planItemCompleteSchema, body);

  const container = getContainer();

  // 소유권 검증: item -> plan -> studentId가 요청자의 organization 소속인지 확인
  const item = await container.homeTrainingPlanRepo.findItemById(itemId);
  if (!item) throw new NotFoundError('훈련 항목');
  const plan = await container.homeTrainingPlanRepo.findById(item.planId);
  if (!plan) throw new NotFoundError('주간 훈련 계획');
  await container.studentService.getStudentOrThrow(plan.studentId, auth.organizationId);

  const result = await container.weeklyPlannerService.completeItem(itemId, {
    successRate: input.successRate,
    outcome: input.outcome,
    parentMemo: input.parentMemo ?? null,
    childReaction: input.childReaction ?? null,
  });

  return NextResponse.json(ok(result), { status: 200 });
});
