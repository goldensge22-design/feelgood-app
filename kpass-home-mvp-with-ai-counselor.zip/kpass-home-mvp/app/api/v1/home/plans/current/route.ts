import { NextResponse } from 'next/server';
import { getContainer } from '@/shared/config/container';
import { ok } from '@/shared/response/ApiResponse';
import { withAuth } from '@/shared/middleware/withAuth';
import { NotFoundError, ValidationError } from '@/shared/errors/AppError';
import { parseIntParamOrThrow } from '@/shared/utils/validation';

/**
 * @openapi
 * /api/v1/home/plans/current:
 *   get:
 *     summary: Home AI(Weekly Planner) - 현재 활성 주간 훈련 계획 조회
 *     tags: [Home]
 *     security: [{ bearerAuth: [] }]
 *     parameters:
 *       - in: query
 *         name: studentId
 *         required: true
 *         schema: { type: integer }
 */
export const GET = withAuth(async (req, auth) => {
  const studentIdParam = new URL(req.url).searchParams.get('studentId');
  if (!studentIdParam) {
    throw new ValidationError('studentId 쿼리 파라미터가 필요합니다.');
  }
  const studentId = parseIntParamOrThrow(studentIdParam, 'studentId');

  const container = getContainer();
  await container.studentService.getStudentOrThrow(studentId, auth.organizationId);
  const plan = await container.weeklyPlannerService.getCurrentPlan(studentId);
  if (!plan) {
    throw new NotFoundError('활성 주간 훈련 계획');
  }

  return NextResponse.json(ok(plan), { status: 200 });
});
