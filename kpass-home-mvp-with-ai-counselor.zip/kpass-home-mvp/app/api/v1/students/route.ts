import { NextResponse } from 'next/server';
import { getContainer } from '@/shared/config/container';
import { ok } from '@/shared/response/ApiResponse';
import { withAuth } from '@/shared/middleware/withAuth';

/**
 * @openapi
 * /api/v1/students:
 *   get:
 *     summary: 내 자녀(학생) 목록 조회
 *     tags: [Student]
 *     security: [{ bearerAuth: [] }]
 */
export const GET = withAuth(async (_req, auth) => {
  const students = await getContainer().studentService.listMyStudents(auth.organizationId);
  return NextResponse.json(ok(students), { status: 200 });
});
