import { NextResponse } from 'next/server';
import { getContainer } from '@/shared/config/container';
import { ok } from '@/shared/response/ApiResponse';
import { withAuth } from '@/shared/middleware/withAuth';
import { parseIntParamOrThrow } from '@/shared/utils/validation';

interface RouteCtx {
  params: { studentId: string };
}

/**
 * @openapi
 * /api/v1/students/{studentId}/home-dashboard:
 *   get:
 *     summary: 가정 인지훈련 처방(오늘의 인지훈련/부모 질문/부모 칭찬/생활 속 PASS)
 *     description: >
 *       HOME-001~HOME-006 대응. 모든 추천 필드는 isMock=true 이며
 *       PlaceholderRecommendationService(Mock Data)에서 생성된다.
 *     tags: [Home]
 *     security: [{ bearerAuth: [] }]
 */
export const GET = withAuth<RouteCtx>(async (_req, auth, ctx) => {
  const container = getContainer();
  const studentId = parseIntParamOrThrow(ctx.params.studentId, 'studentId');

  await container.studentService.getStudentOrThrow(studentId, auth.organizationId);
  const dashboard = await container.homeDashboardService.getDashboard(studentId);

  return NextResponse.json(ok(dashboard), { status: 200 });
});
