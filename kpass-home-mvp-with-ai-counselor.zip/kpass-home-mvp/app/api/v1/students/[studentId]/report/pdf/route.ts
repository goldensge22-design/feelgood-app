import { NextResponse } from 'next/server';
import { getContainer } from '@/shared/config/container';
import { withAuth } from '@/shared/middleware/withAuth';
import { parseIntParamOrThrow } from '@/shared/utils/validation';

interface RouteCtx {
  params: { studentId: string };
}

/**
 * @openapi
 * /api/v1/students/{studentId}/report/pdf:
 *   get:
 *     summary: 가정 인지훈련 결과지 PDF 다운로드
 *     tags: [Report]
 *     security: [{ bearerAuth: [] }]
 */
export const GET = withAuth<RouteCtx>(async (_req, auth, ctx) => {
  const container = getContainer();
  const studentId = parseIntParamOrThrow(ctx.params.studentId, 'studentId');

  const student = await container.studentService.getStudentOrThrow(studentId, auth.organizationId);
  const result = await container.passResultService.getLatestResult(studentId);
  const analysis = container.passResultService.buildAnalysis(result);
  const prescription = await container.recommendationService.generateDailyPrescription(
    studentId,
    result.resultId,
  );

  const pdfBytes = await container.reportPdfService.generateHomeReportPdf({
    studentName: student.name,
    ageBand: student.grade ? `${student.grade}학년` : '연령 미상',
    analysis,
    prescription,
    generatedAt: new Date(),
  });

  return new NextResponse(Buffer.from(pdfBytes), {
    status: 200,
    headers: {
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="kpass_home_report_${studentId}.pdf"`,
    },
  });
});
