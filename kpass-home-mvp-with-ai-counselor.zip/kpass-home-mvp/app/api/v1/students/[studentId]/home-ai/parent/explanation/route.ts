import { NextResponse } from 'next/server';
import { getContainer } from '@/shared/config/container';
import { ok } from '@/shared/response/ApiResponse';
import { withAuth } from '@/shared/middleware/withAuth';
import { parseIntParamOrThrow } from '@/shared/utils/validation';

interface RouteCtx {
  params: { studentId: string };
}

/**
 * @openapi
 * /api/v1/students/{studentId}/home-ai/parent/explanation:
 *   get:
 *     summary: Home AI 상담사 - 학부모용 AI - "부모가 이해하기 쉽게 설명"
 *     description: >
 *       기존 요약보기를 다시 보여주지 않는다. 결과지 · 81 Cognitive Profile ·
 *       생활 사례/FAQ 라이브러리만 조합한 비생성형 번역 화면이다.
 *     tags: [HomeAiCounselor]
 *     security: [{ bearerAuth: [] }]
 */
export const GET = withAuth<RouteCtx>(async (_req, auth, ctx) => {
  const container = getContainer();
  const studentId = parseIntParamOrThrow(ctx.params.studentId, 'studentId');

  await container.studentService.getStudentOrThrow(studentId, auth.organizationId);
  const explanation = await container.parentExplanationComposerService.composeForStudent(studentId);

  return NextResponse.json(ok(explanation), { status: 200 });
});
