import { NextResponse } from 'next/server';
import { getContainer } from '@/shared/config/container';
import { ok } from '@/shared/response/ApiResponse';
import { withAuth } from '@/shared/middleware/withAuth';
import { homeAiChatSchema, parseIntParamOrThrow, parseOrThrow } from '@/shared/utils/validation';

interface RouteCtx {
  params: { studentId: string };
}

/**
 * @openapi
 * /api/v1/students/{studentId}/home-ai/parent/chat:
 *   post:
 *     summary: Home AI 상담사 - 학부모용 AI - "부모 AI 상담" (생성형 AI, 하루 10회 제한)
 *     description: >
 *       Home AI 상담사 안에서 유일하게 생성형 AI를 사용하는 엔드포인트.
 *       새로운 훈련을 생성하지 않으며, 항상 인지훈련 플래너 또는
 *       인지+정서훈련 프로그램으로 연결되는 답변만 반환한다.
 *     tags: [HomeAiCounselor]
 *     security: [{ bearerAuth: [] }]
 */
export const POST = withAuth<RouteCtx>(async (req, auth, ctx) => {
  const container = getContainer();
  const studentId = parseIntParamOrThrow(ctx.params.studentId, 'studentId');
  const body = parseOrThrow(homeAiChatSchema, await req.json());

  await container.studentService.getStudentOrThrow(studentId, auth.organizationId);
  const result = await container.homeAiCounselorChatService.chat({
    studentId,
    requestedByUserId: auth.userId,
    audience: 'PARENT',
    message: body.message,
  });

  return NextResponse.json(ok(result), { status: 200 });
});
