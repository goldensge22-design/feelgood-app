import { NextResponse } from 'next/server';
import { getContainer } from '@/shared/config/container';
import { ok } from '@/shared/response/ApiResponse';
import { withAuth } from '@/shared/middleware/withAuth';
import { activityLogCreateSchema, parseIntParamOrThrow, parseOrThrow } from '@/shared/utils/validation';

interface RouteCtx {
  params: { studentId: string };
}

/**
 * @openapi
 * /api/v1/students/{studentId}/activity-logs:
 *   get:
 *     summary: 활동 수행 기록 목록 (GR-001 Activity Completion 이력)
 *     tags: [Growth]
 *     security: [{ bearerAuth: [] }]
 *   post:
 *     summary: 활동 완료 기록 (HOME-007 Completion Record)
 *     tags: [Growth]
 *     security: [{ bearerAuth: [] }]
 */
export const GET = withAuth<RouteCtx>(async (_req, auth, ctx) => {
  const container = getContainer();
  const studentId = parseIntParamOrThrow(ctx.params.studentId, 'studentId');
  await container.studentService.getStudentOrThrow(studentId, auth.organizationId);
  const logs = await container.activityLogService.listHistory(studentId);
  return NextResponse.json(ok(logs), { status: 200 });
});

export const POST = withAuth<RouteCtx>(async (req, auth, ctx) => {
  const container = getContainer();
  const studentId = parseIntParamOrThrow(ctx.params.studentId, 'studentId');
  await container.studentService.getStudentOrThrow(studentId, auth.organizationId);

  const body = await req.json();
  const parsed = parseOrThrow(activityLogCreateSchema, body);

  const log = await container.activityLogService.recordCompletion({
    studentId,
    activityId: parsed.activityId,
    score: parsed.score ?? null,
    memo: parsed.memo ?? null,
  });

  return NextResponse.json(ok(log), { status: 201 });
});
