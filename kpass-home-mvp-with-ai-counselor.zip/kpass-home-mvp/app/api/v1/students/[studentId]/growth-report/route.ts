import { NextResponse } from 'next/server';
import { getContainer } from '@/shared/config/container';
import { ok } from '@/shared/response/ApiResponse';
import { withAuth } from '@/shared/middleware/withAuth';
import { parseIntParamOrThrow } from '@/shared/utils/validation';

interface RouteCtx {
  params: { studentId: string };
}

/**
 * @openapi
 * /api/v1/students/{studentId}/growth-report:
 *   get:
 *     summary: 성장 리포트 대시보드 (GR-002/003/004)
 *     tags: [Growth]
 *     security: [{ bearerAuth: [] }]
 */
export const GET = withAuth<RouteCtx>(async (_req, auth, ctx) => {
  const container = getContainer();
  const studentId = parseIntParamOrThrow(ctx.params.studentId, 'studentId');
  await container.studentService.getStudentOrThrow(studentId, auth.organizationId);

  const dashboard = await container.growthReportService.getDashboard(studentId);
  return NextResponse.json(ok(dashboard), { status: 200 });
});
