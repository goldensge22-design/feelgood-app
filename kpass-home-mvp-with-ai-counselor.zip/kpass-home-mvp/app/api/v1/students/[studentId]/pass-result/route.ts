import { NextResponse } from 'next/server';
import { getContainer } from '@/shared/config/container';
import { ok } from '@/shared/response/ApiResponse';
import { withAuth } from '@/shared/middleware/withAuth';
import { parseIntParamOrThrow } from '@/shared/utils/validation';

interface RouteCtx {
  params: { studentId: string };
}

/**
 * @openapi
 * /api/v1/students/{studentId}/pass-result:
 *   get:
 *     summary: 최신 K-PASS 검사 결과 + AI Brain Analysis
 *     tags: [PASS]
 *     security: [{ bearerAuth: [] }]
 */
export const GET = withAuth<RouteCtx>(async (_req, auth, ctx) => {
  const container = getContainer();
  const studentId = parseIntParamOrThrow(ctx.params.studentId, 'studentId');

  await container.studentService.getStudentOrThrow(studentId, auth.organizationId);
  const result = await container.passResultService.getLatestResult(studentId);
  const analysis = container.passResultService.buildAnalysis(result);

  return NextResponse.json(ok({ result, analysis }), { status: 200 });
});
