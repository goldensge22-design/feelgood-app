'use client';

import { useParams } from 'next/navigation';
import Link from 'next/link';
import { RequireAuth } from '@/features/auth/RequireAuth';
import { TeacherRecommendationView } from '@/features/teacher-dashboard/TeacherRecommendationView';

export default function TeacherStudentPage(): JSX.Element {
  const params = useParams<{ studentId: string }>();
  const studentId = Number(params.studentId);

  return (
    <RequireAuth>
      <header className="kp-app-header">
        <h1>교사용 인지훈련 추천</h1>
        <p>PASS Cognitive Training Library 기반 · 학생별 추천</p>
      </header>
      <div className="kp-section">
        <Link
          href={`/teacher/students/${studentId}/home-ai`}
          className="kp-btn kp-btn-primary kp-homeai-launch-btn"
        >
          🦉 Home AI
        </Link>
        <TeacherRecommendationView studentId={studentId} />
      </div>
    </RequireAuth>
  );
}
