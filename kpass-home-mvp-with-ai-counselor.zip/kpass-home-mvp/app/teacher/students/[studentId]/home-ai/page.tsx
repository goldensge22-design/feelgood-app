'use client';

import { useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { RequireAuth } from '@/features/auth/RequireAuth';
import { HomeAiEntry } from '@/features/home-ai-counselor/HomeAiEntry';
import { StudentUnderstandingView } from '@/features/home-ai-counselor/teacher/StudentUnderstandingView';
import { HomeAiChatView } from '@/features/home-ai-counselor/HomeAiChatView';

type View = 'menu' | 'understanding' | 'chat';

/**
 * Home AI 상담사(선생님용 AI).
 * ①은 비생성형(학생 이해하기), ②만 생성형 AI(교사 AI 상담, 하루 10회 제한)를
 * 사용하며 항상 기존 인지훈련 플래너/인지+정서훈련 프로그램으로 연결한다.
 */
export default function HomeAiTeacherPage(): JSX.Element {
  const params = useParams<{ studentId: string }>();
  const studentId = Number(params.studentId);
  const [view, setView] = useState<View>('menu');

  return (
    <RequireAuth>
      <header className="kp-app-header">
        <div className="kp-app-header-row">
          <div className="kp-app-header-text">
            <h1>Home AI 상담사</h1>
            <p>학생 이해와 지도 전략을 연결해드립니다</p>
          </div>
          <Link href={`/teacher/students/${studentId}`} className="kp-btn kp-btn-header">
            인지훈련 추천
          </Link>
        </div>
      </header>
      <div className="kp-section">
        {view !== 'menu' && (
          <button type="button" className="kp-btn kp-btn-ghost" style={{ marginBottom: 16 }} onClick={() => setView('menu')}>
            ← Home AI 메뉴로
          </button>
        )}

        {view === 'menu' && (
          <HomeAiEntry
            menuItems={[
              {
                key: 'understanding',
                label: '학생 이해하기',
                description: '결과지를 수업/지도 관점으로 정리해드려요',
                onSelect: () => setView('understanding'),
              },
              {
                key: 'chat',
                label: '교사 AI 상담',
                description: '학생 지도 질문을 자유롭게 물어보세요 (하루 10회)',
                onSelect: () => setView('chat'),
              },
            ]}
          />
        )}

        {view === 'understanding' && <StudentUnderstandingView studentId={studentId} />}

        {view === 'chat' && (
          <HomeAiChatView
            postPath={`/teacher/students/${studentId}/home-ai/chat`}
            title="교사 AI 상담"
            placeholder="예: 발표를 안 합니다"
            examplePrompts={['발표를 안 합니다', '수업 집중을 못 합니다', '친구와 협력이 어렵습니다']}
          />
        )}
      </div>
    </RequireAuth>
  );
}
