import type { Metadata } from 'next';
import { AuthProvider } from '@/features/auth/AuthContext';
import './globals.css';

export const metadata: Metadata = {
  title: 'K-PASS 인지훈련 AI 코치',
  description: 'K-PASS Home AI Teacher - 가정용 맞춤 인지훈련 처방',
};

export default function RootLayout({ children }: { children: React.ReactNode }): JSX.Element {
  return (
    <html lang="ko">
      <body>
        <AuthProvider>
          <div className="kp-container">{children}</div>
        </AuthProvider>
      </body>
    </html>
  );
}
