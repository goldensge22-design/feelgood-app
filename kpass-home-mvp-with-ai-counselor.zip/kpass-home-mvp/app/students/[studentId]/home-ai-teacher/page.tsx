'use client';

import { useParams } from 'next/navigation';
import Link from 'next/link';
import { RequireAuth } from '@/features/auth/RequireAuth';
import { HomeDashboard } from '@/features/home-dashboard/HomeDashboard';

/**
 * HOME AI TEACHER 화면.
 *
 * 가장 중요한 원칙: K-PASS 검사는 검사 종료 시점에 이미 81개의 Cognitive
 * Profile을 생성한다. 이 화면은 그 값을 다시 분석하거나 재계산하지 않고,
 * PASS Cognitive Training Library에서 Recommendation Engine이 선택한
 * 프로그램만 읽어서 보여준다(LLM이 훈련을 생성하지 않음).
 *
 * Flow: K-PASS Assessment → PASS Score → 81 Cognitive Profile →
 * Recommendation Engine → PASS Cognitive Training Library → (여기서 표시)
 */
export default function HomeAiTeacherPage(): JSX.Element {
  const params = useParams<{ studentId: string }>();
  const studentId = Number(params.studentId);

  return (
    <RequireAuth>
      <header className="kp-app-header">
        <div className="kp-app-header-row">
          <div className="kp-app-header-text">
            <h1>HOME AI TEACHER</h1>
            <p>검사 결과 · 81 Cognitive Profile 기반 오늘의 인지훈련 처방</p>
          </div>
          <Link href={`/students/${studentId}`} className="kp-btn kp-btn-header">
            주간 플래너
          </Link>
        </div>
      </header>
      <div className="kp-section">
        <HomeDashboard studentId={studentId} />
      </div>
    </RequireAuth>
  );
}
