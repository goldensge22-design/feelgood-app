'use client';

import { useParams } from 'next/navigation';
import Link from 'next/link';
import { RequireAuth } from '@/features/auth/RequireAuth';
import { WeeklyPlannerView } from '@/features/weekly-planner/WeeklyPlannerView';
import { MonthlyReportView } from '@/features/weekly-planner/MonthlyReportView';

/**
 * Home AI = Weekly Planner AI.
 * 검사 결과와 81 Cognitive Profile을 기반으로 PASS Cognitive Training
 * Library(400개)에서만 훈련을 선택해 주간 계획을 자동 설계한다. 챗봇 UI가 아니다.
 */
export default function StudentDashboardPage(): JSX.Element {
  const params = useParams<{ studentId: string }>();
  const studentId = Number(params.studentId);

  return (
    <RequireAuth>
      <header className="kp-app-header">
        <div className="kp-app-header-row">
          <div className="kp-app-header-text">
            <h1>주간 인지훈련 플래너</h1>
            <p>PASS Cognitive Training Library 기반 · 자동 설계 · 챗봇 아님</p>
          </div>
          <Link href={`/students/${studentId}/home-ai-teacher`} className="kp-btn kp-btn-header">
            HOME AI TEACHER
          </Link>
        </div>
      </header>
      <div className="kp-section">
        <Link href={`/students/${studentId}/home-ai`} className="kp-btn kp-btn-primary kp-homeai-launch-btn">
          🦉 Home AI
        </Link>
        <WeeklyPlannerView studentId={studentId} />
      </div>
      <div className="kp-section">
        <h2 style={{ fontSize: 16, marginBottom: 8 }}>4주 월간 리포트</h2>
        <MonthlyReportView studentId={studentId} />
      </div>
    </RequireAuth>
  );
}
