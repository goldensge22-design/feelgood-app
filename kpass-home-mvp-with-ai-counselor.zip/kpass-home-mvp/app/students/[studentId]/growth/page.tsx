'use client';

import { useParams } from 'next/navigation';
import { RequireAuth } from '@/features/auth/RequireAuth';
import { GrowthReportView } from '@/features/growth-report/GrowthReportView';

export default function GrowthReportPage(): JSX.Element {
  const params = useParams<{ studentId: string }>();
  const studentId = Number(params.studentId);

  return (
    <RequireAuth>
      <header className="kp-app-header">
        <h1>성장 리포트</h1>
        <p>PASS 변화와 활동 수행률을 확인하세요</p>
      </header>
      <div className="kp-section">
        <GrowthReportView studentId={studentId} />
      </div>
    </RequireAuth>
  );
}
