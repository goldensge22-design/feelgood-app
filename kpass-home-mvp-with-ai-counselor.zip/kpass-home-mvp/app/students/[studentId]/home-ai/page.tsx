'use client';

import { useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { RequireAuth } from '@/features/auth/RequireAuth';
import { HomeAiEntry } from '@/features/home-ai-counselor/HomeAiEntry';
import { ParentExplanationView } from '@/features/home-ai-counselor/parent/ParentExplanationView';
import { HomeAiChatView } from '@/features/home-ai-counselor/HomeAiChatView';

type View = 'menu' | 'explanation' | 'chat';

/**
 * Home AI 상담사(학부모용 AI).
 *
 * 이 화면은 새로운 훈련/결과지 기능이 아니라, 기존 인지훈련 플래너
 * (/students/[studentId])와 인지+정서훈련 프로그램을 "연결"하는 Hub이다.
 * ①②는 비생성형(부모가 이해하기 쉽게 설명), ③만 생성형 AI(부모 AI 상담,
 * 하루 10회 제한)를 사용한다.
 */
export default function HomeAiParentPage(): JSX.Element {
  const params = useParams<{ studentId: string }>();
  const studentId = Number(params.studentId);
  const [view, setView] = useState<View>('menu');

  return (
    <RequireAuth>
      <header className="kp-app-header">
        <div className="kp-app-header-row">
          <div className="kp-app-header-text">
            <h1>Home AI 상담사</h1>
            <p>검사 결과를 생활 속 언어로 연결해드립니다</p>
          </div>
          <Link href={`/students/${studentId}`} className="kp-btn kp-btn-header">
            인지훈련 플래너
          </Link>
        </div>
      </header>
      <div className="kp-section">
        {view !== 'menu' && (
          <button type="button" className="kp-btn kp-btn-ghost" style={{ marginBottom: 16 }} onClick={() => setView('menu')}>
            ← Home AI 메뉴로
          </button>
        )}

        {view === 'menu' && (
          <HomeAiEntry
            menuItems={[
              {
                key: 'explanation',
                label: '부모가 이해하기 쉽게 설명',
                description: '검사 결과를 부모의 언어로 번역해드려요',
                onSelect: () => setView('explanation'),
              },
              {
                key: 'chat',
                label: '부모 AI 상담',
                description: '궁금한 점을 자유롭게 물어보세요 (하루 10회)',
                onSelect: () => setView('chat'),
              },
            ]}
          />
        )}

        {view === 'explanation' && <ParentExplanationView studentId={studentId} />}

        {view === 'chat' && (
          <HomeAiChatView
            postPath={`/students/${studentId}/home-ai/parent/chat`}
            title="부모 AI 상담"
            placeholder="예: 숙제를 너무 싫어해요"
            examplePrompts={['숙제를 너무 싫어해요', '친구와 자꾸 싸워요', '책을 안 읽어요', '게임만 하려고 합니다']}
          />
        )}
      </div>
    </RequireAuth>
  );
}
