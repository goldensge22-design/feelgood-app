'use client';

import { RequireAuth } from '@/features/auth/RequireAuth';
import { StudentList } from '@/features/student/StudentList';
import { useAuth } from '@/features/auth/AuthContext';

export default function StudentsPage(): JSX.Element {
  const { logout } = useAuth();
  return (
    <RequireAuth>
      <header className="kp-app-header">
        <h1>자녀 선택</h1>
        <p>인지훈련 처방을 확인할 자녀를 선택하세요</p>
      </header>
      <div className="kp-section">
        <StudentList />
        <button className="kp-btn kp-btn-ghost" onClick={logout} type="button" style={{ marginTop: 16 }}>
          로그아웃
        </button>
      </div>
    </RequireAuth>
  );
}
