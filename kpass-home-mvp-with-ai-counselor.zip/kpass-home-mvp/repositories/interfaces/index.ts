import {
  Activity,
  ActivityLog,
  AgeBandInfo,
  AvoidPhraseEntry,
  CognitiveProfile81,
  DailyLearningPlan,
  DifficultyLevelInfo,
  GrowthReport,
  HomeAiAudience,
  HomeAiChatLog,
  HomeTrainingLogEntry,
  MonthlyReport,
  ParentFaqEntry,
  ParentLifeCase,
  PassDomain,
  PassProfile,
  PassResult,
  Recommendation,
  Student,
  TeacherStrategyTemplate,
  TrainingHistoryEntry,
  TrainingProgram,
  UserAccount,
  WeeklyTrainingPlan,
  WeeklyTrainingPlanItem,
} from '@/domain/entities';

export interface IUserAccountRepository {
  findByEmail(email: string): Promise<UserAccount | null>;
  findById(userId: number): Promise<UserAccount | null>;
}

export interface IStudentRepository {
  findById(studentId: number): Promise<Student | null>;
  findByOrganization(organizationId: number): Promise<Student[]>;
  /** studentId가 해당 organizationId 소속인지 검증 (부모-자녀 접근 통제, TODO(DB-002) 참고) */
  belongsToOrganization(studentId: number, organizationId: number): Promise<boolean>;
}

export interface PassResultWithProfile extends PassResult {
  profile: PassProfile | null;
}

export interface IPassResultRepository {
  findLatestByStudent(studentId: number): Promise<PassResultWithProfile | null>;
  findById(resultId: number): Promise<PassResultWithProfile | null>;
  listByStudent(studentId: number): Promise<PassResult[]>;
}

export interface IActivityRepository {
  findById(activityId: string): Promise<Activity | null>;
}

export interface IRecommendationRepository {
  create(input: {
    studentId: number;
    resultId: number | null;
    activityId: string | null;
    reason: string | null;
    confidenceScore: number | null;
  }): Promise<Recommendation>;
  listByStudent(studentId: number): Promise<Recommendation[]>;
}

export interface IDailyLearningPlanRepository {
  upsertToday(studentId: number, environment: string): Promise<DailyLearningPlan>;
  markCompleted(planId: number): Promise<DailyLearningPlan>;
  listByStudent(studentId: number): Promise<DailyLearningPlan[]>;
}

export interface IActivityLogRepository {
  create(input: {
    studentId: number;
    activityId: string;
    score: number | null;
    memo: string | null;
  }): Promise<ActivityLog>;
  listByStudent(studentId: number): Promise<ActivityLog[]>;
}

export interface IGrowthReportRepository {
  create(input: {
    studentId: number;
    periodStart: Date;
    periodEnd: Date;
    summary: string;
    nextRecommendation: string;
  }): Promise<GrowthReport>;
  listByStudent(studentId: number): Promise<GrowthReport[]>;
  latestByStudent(studentId: number): Promise<GrowthReport | null>;
}

/**
 * PASS Cognitive Training Library 조회 전용 리포지토리.
 * 이 인터페이스에는 프로그램을 생성/수정하는 메서드를 절대 추가하지 않는다.
 * (라이브러리 확장은 시드 데이터 추가로만 이루어진다 — ADR 참고: docs/ARCHITECTURE.md)
 */
export interface ITrainingProgramRepository {
  findById(programId: string): Promise<TrainingProgram | null>;
  /** 81 Profile x Age x Difficulty x Domain 필터 조회. 추천 엔진의 유일한 데이터 소스. */
  findCandidates(filter: {
    passDomain: 'PLANNING' | 'ATTENTION' | 'SIMULTANEOUS' | 'SUCCESSIVE';
    ageCode: string; // '5-7'|'8-10'|'11-13'|'14-16'|'17-19'
    difficultyLevel: number; // 1~5
    approvalStatusIn?: Array<'draft_pending_review' | 'approved'>;
  }): Promise<TrainingProgram[]>;
  count(): Promise<number>;
}

export interface ICognitiveProfileRepository {
  findByCode(profileCode: string): Promise<CognitiveProfile81 | null>;
  /** Planning/Attention/Simultaneous/Successive 표준점수로부터 81 Profile 코드를 조회 */
  resolveFromScores(scores: {
    planning: number;
    attention: number;
    simultaneous: number;
    successive: number;
  }): Promise<CognitiveProfile81>;
}

export interface ITrainingHistoryRepository {
  listByStudentAndProgram(studentId: number, programId: string): Promise<TrainingHistoryEntry[]>;
  listRecentByStudent(studentId: number, limit: number): Promise<TrainingHistoryEntry[]>;
  /** 추천 엔진의 난이도 승급/강등 판단은 반드시 영역별로 분리되어야 한다. */
  listRecentByStudentAndDomain(
    studentId: number,
    passDomain: 'PLANNING' | 'ATTENTION' | 'SIMULTANEOUS' | 'SUCCESSIVE',
    limit: number,
  ): Promise<TrainingHistoryEntry[]>;
  record(input: {
    studentId: number;
    programId: string;
    passDomain: 'PLANNING' | 'ATTENTION' | 'SIMULTANEOUS' | 'SUCCESSIVE';
    difficultyLevel: number;
    successRate: number | null;
    outcome: 'SUCCESS' | 'PARTIAL' | 'FAIL' | null;
  }): Promise<TrainingHistoryEntry>;
}

export interface IDifficultyMappingRepository {
  getByLevel(level: number): Promise<DifficultyLevelInfo | null>;
}

export interface IAgeBandMappingRepository {
  /** 만 나이(년)로 age_band_mapping을 조회한다. 매핑이 없으면 null(추측/기본값 대체 금지). */
  resolveAgeCode(ageInYears: number): Promise<AgeBandInfo | null>;
}

/**
 * Home AI(Weekly Planner) 전용 리포지토리.
 * 이 리포지토리들 역시 프로그램을 생성하지 않는다 — home_training_plan_item은
 * 항상 pass_training_program.program_id를 참조하는 "선택 결과의 스냅샷"만 저장한다.
 */
export interface IHomeTrainingPlanRepository {
  create(input: {
    studentId: number;
    resultId: number;
    profileCode: string;
    ageCode: string;
    weekStartDate: Date;
    weekEndDate: Date;
    domainWeights: Record<string, number>;
    items: Array<{
      programId: string;
      programName: string;
      passDomain: 'PLANNING' | 'ATTENTION' | 'SIMULTANEOUS' | 'SUCCESSIVE';
      dayIndex: number;
      dayDate: Date;
      orderInDay: number;
      trainingGoal: string;
      duration: string | null;
      parentGuidance: string;
      isSupplementary: boolean;
    }>;
  }): Promise<WeeklyTrainingPlan>;
  findById(planId: number): Promise<WeeklyTrainingPlan | null>;
  findActiveByStudent(studentId: number): Promise<WeeklyTrainingPlan | null>;
  listByStudentInRange(studentId: number, from: Date, to: Date): Promise<WeeklyTrainingPlan[]>;
  markStatus(planId: number, status: 'ACTIVE' | 'COMPLETED' | 'ARCHIVED'): Promise<void>;
  findItemById(itemId: number): Promise<WeeklyTrainingPlanItem | null>;
  markItemCompleted(itemId: number): Promise<WeeklyTrainingPlanItem>;
}

export interface IHomeTrainingLogRepository {
  create(input: {
    itemId: number;
    studentId: number;
    successRate: number;
    outcome: 'SUCCESS' | 'PARTIAL' | 'FAIL';
    parentMemo: string | null;
    childReaction: string | null;
  }): Promise<HomeTrainingLogEntry>;
  listByStudentInRange(studentId: number, from: Date, to: Date): Promise<HomeTrainingLogEntry[]>;
}

export interface IHomeMonthlyReportRepository {
  upsert(input: {
    studentId: number;
    reportMonth: string;
    domainChange: MonthlyReport['domainChange'];
    completionRate: number;
    strengthMaintained: string[];
    weaknessProgress: MonthlyReport['weaknessProgress'];
    nextMonthRecommendation: string;
  }): Promise<MonthlyReport>;
  findByStudentAndMonth(studentId: number, reportMonth: string): Promise<MonthlyReport | null>;
}

/**
 * Home AI 상담사 콘텐츠 라이브러리 리포지토리들.
 * 모두 읽기 전용 — 콘텐츠는 db/seed-data/home_ai_*.json 시드로만 채워지며,
 * 이 인터페이스들에는 절대 write/generate 메서드를 추가하지 않는다.
 */
export interface IParentFaqRepository {
  listAll(): Promise<ParentFaqEntry[]>;
  listByDomain(priorityDomain: PassDomain): Promise<ParentFaqEntry[]>;
}

export interface IParentLifeCaseRepository {
  findByDomain(priorityDomain: PassDomain): Promise<ParentLifeCase | null>;
}

export interface IAvoidPhraseRepository {
  findByDomain(priorityDomain: PassDomain): Promise<AvoidPhraseEntry | null>;
}

export interface ITeacherStrategyRepository {
  findByDomain(priorityDomain: PassDomain): Promise<TeacherStrategyTemplate | null>;
}

/** 부모 AI 상담 / 교사 AI 상담(생성형 AI) 로그 + 일일 사용량 제한(하루 10회) 근거 */
export interface IHomeAiChatLogRepository {
  create(input: {
    studentId: number;
    requestedByUserId: number;
    audience: HomeAiAudience;
    userMessage: string;
    aiResponse: string;
    linkedProgramId: string | null;
  }): Promise<HomeAiChatLog>;
  /** requestedByUserId가 오늘(서버 로컬 날짜 기준) audience로 상담한 횟수 */
  countTodayByUser(requestedByUserId: number, audience: HomeAiAudience): Promise<number>;
}
