import {
  Activity,
  ActivityLog,
  DailyLearningPlan,
  GrowthReport,
  PassProfile,
  PassResult,
  Recommendation,
  Student,
  UserAccount,
} from '@/domain/entities';
import { Selectable } from 'kysely';
import {
  ActivityLogTable,
  ActivityTable,
  DailyLearningPlanTable,
  GrowthReportTable,
  PassProfileTable,
  PassResultTable,
  RecommendationTable,
  StudentTable,
  UserAccountTable,
} from '@/db/types';

function toNumberOrNull(value: unknown): number | null {
  if (value === null || value === undefined) return null;
  return typeof value === 'number' ? value : Number(value);
}

export function mapStudent(row: Selectable<StudentTable>): Student {
  return {
    studentId: Number(row.student_id),
    organizationId: Number(row.organization_id),
    classId: row.class_id === null ? null : Number(row.class_id),
    name: row.name,
    birthDate: row.birth_date ? new Date(row.birth_date as unknown as string) : null,
    grade: row.grade,
  };
}

export function mapUserAccount(row: Selectable<UserAccountTable>): UserAccount {
  return {
    userId: Number(row.user_id),
    organizationId: Number(row.organization_id),
    email: row.email,
    role: row.role,
    status: row.status,
  };
}

export function mapPassResult(row: Selectable<PassResultTable>): PassResult {
  return {
    resultId: Number(row.result_id),
    studentId: Number(row.student_id),
    planning: row.planning,
    attention: row.attention,
    simultaneous: row.simultaneous,
    successive: row.successive,
    totalIndex: row.total_index,
    testedAt: new Date(row.tested_at as unknown as string),
  };
}

export function mapPassProfile(row: Selectable<PassProfileTable>): PassProfile {
  return {
    profileId: Number(row.profile_id),
    resultId: Number(row.result_id),
    dominanceType: row.dominance_type,
    strengthDomain: row.strength_domain,
    priorityDomain: row.priority_domain,
    aiSummary: row.ai_summary,
  };
}

export function mapActivity(row: Selectable<ActivityTable>): Activity {
  return {
    activityId: row.activity_id,
    activityName: row.activity_name,
    passDomain: row.pass_domain,
    environment: row.environment,
    ageBand: row.age_band,
    level: row.level,
  };
}

export function mapRecommendation(row: Selectable<RecommendationTable>): Recommendation {
  return {
    recommendationId: Number(row.recommendation_id),
    studentId: Number(row.student_id),
    resultId: row.result_id === null ? null : Number(row.result_id),
    activityId: row.activity_id,
    reason: row.reason,
    confidenceScore: toNumberOrNull(row.confidence_score),
  };
}

export function mapDailyLearningPlan(row: Selectable<DailyLearningPlanTable>): DailyLearningPlan {
  return {
    planId: Number(row.plan_id),
    studentId: Number(row.student_id),
    date: new Date(row.date as unknown as string),
    environment: row.environment,
    status: row.status,
  };
}

export function mapActivityLog(row: Selectable<ActivityLogTable>): ActivityLog {
  return {
    logId: Number(row.log_id),
    studentId: Number(row.student_id),
    activityId: row.activity_id,
    completedAt: new Date(row.completed_at as unknown as string),
    score: toNumberOrNull(row.score),
    memo: row.memo,
  };
}

export function mapGrowthReport(row: Selectable<GrowthReportTable>): GrowthReport {
  return {
    reportId: Number(row.report_id),
    studentId: Number(row.student_id),
    periodStart: new Date(row.period_start as unknown as string),
    periodEnd: new Date(row.period_end as unknown as string),
    summary: row.summary,
    nextRecommendation: row.next_recommendation,
  };
}
