import { db } from '@/shared/config/db';
import {
  IHomeMonthlyReportRepository,
  IHomeTrainingLogRepository,
  IHomeTrainingPlanRepository,
} from '@/repositories/interfaces';
import { HomeTrainingLogEntry, MonthlyReport, WeeklyTrainingPlan, WeeklyTrainingPlanItem } from '@/domain/entities';

function toDateOnly(d: Date): string {
  return d.toISOString().slice(0, 10);
}

async function loadItems(planId: number): Promise<WeeklyTrainingPlanItem[]> {
  const rows = await db
    .selectFrom('home_training_plan_item as i')
    .innerJoin('pass_training_program as p', 'p.program_id', 'i.program_id')
    .select([
      'i.item_id',
      'i.plan_id',
      'i.program_id',
      'p.program_name',
      'i.pass_domain',
      'i.day_index',
      'i.day_date',
      'i.order_in_day',
      'i.training_goal',
      'i.duration',
      'i.parent_guidance',
      'i.is_supplementary',
      'i.is_completed',
      'i.completed_at',
    ])
    .where('i.plan_id', '=', planId)
    .orderBy('i.day_index', 'asc')
    .orderBy('i.order_in_day', 'asc')
    .execute();

  return rows.map((r) => ({
    itemId: r.item_id,
    planId: r.plan_id,
    programId: r.program_id,
    programName: r.program_name,
    passDomain: r.pass_domain,
    dayIndex: r.day_index,
    dayDate: new Date(r.day_date as unknown as string),
    orderInDay: r.order_in_day,
    trainingGoal: r.training_goal,
    duration: r.duration,
    parentGuidance: r.parent_guidance,
    isSupplementary: r.is_supplementary,
    isCompleted: r.is_completed,
    completedAt: r.completed_at ? new Date(r.completed_at as unknown as string) : null,
  }));
}

function toPlanEntity(
  row: {
    plan_id: number;
    student_id: number;
    result_id: number;
    profile_code: string;
    age_code: string;
    week_start_date: unknown;
    week_end_date: unknown;
    status: 'ACTIVE' | 'COMPLETED' | 'ARCHIVED';
    domain_weights: unknown;
  },
  items: WeeklyTrainingPlanItem[],
): WeeklyTrainingPlan {
  return {
    planId: row.plan_id,
    studentId: row.student_id,
    resultId: row.result_id,
    profileCode: row.profile_code,
    ageCode: row.age_code,
    weekStartDate: new Date(row.week_start_date as string),
    weekEndDate: new Date(row.week_end_date as string),
    status: row.status,
    domainWeights: row.domain_weights as Record<string, number>,
    items,
  };
}

export class HomeTrainingPlanRepository implements IHomeTrainingPlanRepository {
  async create(input: {
    studentId: number;
    resultId: number;
    profileCode: string;
    ageCode: string;
    weekStartDate: Date;
    weekEndDate: Date;
    domainWeights: Record<string, number>;
    items: Array<{
      programId: string;
      programName: string;
      passDomain: 'PLANNING' | 'ATTENTION' | 'SIMULTANEOUS' | 'SUCCESSIVE';
      dayIndex: number;
      dayDate: Date;
      orderInDay: number;
      trainingGoal: string;
      duration: string | null;
      parentGuidance: string;
      isSupplementary: boolean;
    }>;
  }): Promise<WeeklyTrainingPlan> {
    return db.transaction().execute(async (trx) => {
      const planRow = await trx
        .insertInto('home_training_plan')
        .values({
          student_id: input.studentId,
          result_id: input.resultId,
          profile_code: input.profileCode,
          age_code: input.ageCode,
          week_start_date: toDateOnly(input.weekStartDate),
          week_end_date: toDateOnly(input.weekEndDate),
          status: 'ACTIVE',
          domain_weights: JSON.stringify(input.domainWeights),
        })
        .returningAll()
        .executeTakeFirstOrThrow();

      for (const item of input.items) {
        await trx
          .insertInto('home_training_plan_item')
          .values({
            plan_id: planRow.plan_id,
            program_id: item.programId,
            pass_domain: item.passDomain,
            day_index: item.dayIndex,
            day_date: toDateOnly(item.dayDate),
            order_in_day: item.orderInDay,
            training_goal: item.trainingGoal,
            duration: item.duration,
            parent_guidance: item.parentGuidance,
            is_supplementary: item.isSupplementary,
          })
          .execute();
      }

      const items = await loadItems(planRow.plan_id);
      return toPlanEntity(planRow, items);
    });
  }

  async findById(planId: number): Promise<WeeklyTrainingPlan | null> {
    const row = await db
      .selectFrom('home_training_plan')
      .selectAll()
      .where('plan_id', '=', planId)
      .executeTakeFirst();
    if (!row) return null;
    const items = await loadItems(planId);
    return toPlanEntity(row, items);
  }

  async findActiveByStudent(studentId: number): Promise<WeeklyTrainingPlan | null> {
    const row = await db
      .selectFrom('home_training_plan')
      .selectAll()
      .where('student_id', '=', studentId)
      .where('status', '=', 'ACTIVE')
      .orderBy('week_start_date', 'desc')
      .executeTakeFirst();
    if (!row) return null;
    const items = await loadItems(row.plan_id);
    return toPlanEntity(row, items);
  }

  async listByStudentInRange(studentId: number, from: Date, to: Date): Promise<WeeklyTrainingPlan[]> {
    const rows = await db
      .selectFrom('home_training_plan')
      .selectAll()
      .where('student_id', '=', studentId)
      .where('week_start_date', '>=', toDateOnly(from))
      .where('week_start_date', '<=', toDateOnly(to))
      .orderBy('week_start_date', 'asc')
      .execute();

    const plans: WeeklyTrainingPlan[] = [];
    for (const row of rows) {
      const items = await loadItems(row.plan_id);
      plans.push(toPlanEntity(row, items));
    }
    return plans;
  }

  async markStatus(planId: number, status: 'ACTIVE' | 'COMPLETED' | 'ARCHIVED'): Promise<void> {
    await db.updateTable('home_training_plan').set({ status }).where('plan_id', '=', planId).execute();
  }

  async findItemById(itemId: number): Promise<WeeklyTrainingPlanItem | null> {
    const row = await db
      .selectFrom('home_training_plan_item as i')
      .innerJoin('pass_training_program as p', 'p.program_id', 'i.program_id')
      .select([
        'i.item_id',
        'i.plan_id',
        'i.program_id',
        'p.program_name',
        'i.pass_domain',
        'i.day_index',
        'i.day_date',
        'i.order_in_day',
        'i.training_goal',
        'i.duration',
        'i.parent_guidance',
        'i.is_supplementary',
        'i.is_completed',
        'i.completed_at',
      ])
      .where('i.item_id', '=', itemId)
      .executeTakeFirst();
    if (!row) return null;
    return {
      itemId: row.item_id,
      planId: row.plan_id,
      programId: row.program_id,
      programName: row.program_name,
      passDomain: row.pass_domain,
      dayIndex: row.day_index,
      dayDate: new Date(row.day_date as unknown as string),
      orderInDay: row.order_in_day,
      trainingGoal: row.training_goal,
      duration: row.duration,
      parentGuidance: row.parent_guidance,
      isSupplementary: row.is_supplementary,
      isCompleted: row.is_completed,
      completedAt: row.completed_at ? new Date(row.completed_at as unknown as string) : null,
    };
  }

  async markItemCompleted(itemId: number): Promise<WeeklyTrainingPlanItem> {
    await db
      .updateTable('home_training_plan_item')
      .set({ is_completed: true, completed_at: new Date() })
      .where('item_id', '=', itemId)
      .execute();
    const item = await this.findItemById(itemId);
    if (!item) throw new Error(`home_training_plan_item을 찾을 수 없습니다: ${itemId}`);
    return item;
  }
}

export class HomeTrainingLogRepository implements IHomeTrainingLogRepository {
  async create(input: {
    itemId: number;
    studentId: number;
    successRate: number;
    outcome: 'SUCCESS' | 'PARTIAL' | 'FAIL';
    parentMemo: string | null;
    childReaction: string | null;
  }): Promise<HomeTrainingLogEntry> {
    const row = await db
      .insertInto('home_training_log')
      .values({
        item_id: input.itemId,
        student_id: input.studentId,
        success_rate: input.successRate,
        outcome: input.outcome,
        parent_memo: input.parentMemo,
        child_reaction: input.childReaction,
      })
      .returningAll()
      .executeTakeFirstOrThrow();
    return {
      logId: row.log_id,
      itemId: row.item_id,
      studentId: row.student_id,
      successRate: Number(row.success_rate),
      outcome: row.outcome,
      parentMemo: row.parent_memo,
      childReaction: row.child_reaction,
      loggedAt: new Date(row.logged_at as unknown as string),
    };
  }

  async listByStudentInRange(studentId: number, from: Date, to: Date): Promise<HomeTrainingLogEntry[]> {
    const rows = await db
      .selectFrom('home_training_log')
      .selectAll()
      .where('student_id', '=', studentId)
      .where('logged_at', '>=', from)
      .where('logged_at', '<=', to)
      .orderBy('logged_at', 'asc')
      .execute();
    return rows.map((row) => ({
      logId: row.log_id,
      itemId: row.item_id,
      studentId: row.student_id,
      successRate: Number(row.success_rate),
      outcome: row.outcome,
      parentMemo: row.parent_memo,
      childReaction: row.child_reaction,
      loggedAt: new Date(row.logged_at as unknown as string),
    }));
  }
}

export class HomeMonthlyReportRepository implements IHomeMonthlyReportRepository {
  async upsert(input: {
    studentId: number;
    reportMonth: string;
    domainChange: MonthlyReport['domainChange'];
    completionRate: number;
    strengthMaintained: string[];
    weaknessProgress: MonthlyReport['weaknessProgress'];
    nextMonthRecommendation: string;
  }): Promise<MonthlyReport> {
    const row = await db
      .insertInto('home_monthly_report')
      .values({
        student_id: input.studentId,
        report_month: input.reportMonth,
        domain_change: JSON.stringify(input.domainChange),
        completion_rate: input.completionRate,
        strength_maintained: JSON.stringify(input.strengthMaintained),
        weakness_progress: JSON.stringify(input.weaknessProgress),
        next_month_recommendation: input.nextMonthRecommendation,
      })
      .onConflict((oc) =>
        oc.columns(['student_id', 'report_month']).doUpdateSet({
          domain_change: (eb) => eb.ref('excluded.domain_change'),
          completion_rate: (eb) => eb.ref('excluded.completion_rate'),
          strength_maintained: (eb) => eb.ref('excluded.strength_maintained'),
          weakness_progress: (eb) => eb.ref('excluded.weakness_progress'),
          next_month_recommendation: (eb) => eb.ref('excluded.next_month_recommendation'),
          generated_at: new Date(),
        }),
      )
      .returningAll()
      .executeTakeFirstOrThrow();

    return this.toEntity(row);
  }

  async findByStudentAndMonth(studentId: number, reportMonth: string): Promise<MonthlyReport | null> {
    const row = await db
      .selectFrom('home_monthly_report')
      .selectAll()
      .where('student_id', '=', studentId)
      .where('report_month', '=', reportMonth)
      .executeTakeFirst();
    return row ? this.toEntity(row) : null;
  }

  private toEntity(row: {
    report_id: number;
    student_id: number;
    report_month: string;
    domain_change: unknown;
    completion_rate: number;
    strength_maintained: unknown;
    weakness_progress: unknown;
    next_month_recommendation: string;
    generated_at: unknown;
  }): MonthlyReport {
    return {
      reportId: row.report_id,
      studentId: row.student_id,
      reportMonth: row.report_month,
      domainChange: row.domain_change as MonthlyReport['domainChange'],
      completionRate: Number(row.completion_rate),
      strengthMaintained: row.strength_maintained as string[],
      weaknessProgress: row.weakness_progress as MonthlyReport['weaknessProgress'],
      nextMonthRecommendation: row.next_month_recommendation,
      generatedAt: new Date(row.generated_at as unknown as string),
    };
  }
}
