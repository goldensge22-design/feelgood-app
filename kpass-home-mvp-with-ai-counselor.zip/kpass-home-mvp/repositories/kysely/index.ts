import { db } from '@/shared/config/db';
import { Selectable } from 'kysely';
import { PassResultTable } from '@/db/types';
import {
  IActivityLogRepository,
  IActivityRepository,
  IDailyLearningPlanRepository,
  IGrowthReportRepository,
  IPassResultRepository,
  IRecommendationRepository,
  IStudentRepository,
  IUserAccountRepository,
  PassResultWithProfile,
} from '@/repositories/interfaces';
import {
  mapActivity,
  mapActivityLog,
  mapDailyLearningPlan,
  mapGrowthReport,
  mapPassProfile,
  mapPassResult,
  mapRecommendation,
  mapStudent,
  mapUserAccount,
} from '@/repositories/kysely/mappers';

export class UserAccountRepository implements IUserAccountRepository {
  async findByEmail(email: string) {
    const row = await db
      .selectFrom('user_account')
      .selectAll()
      .where('email', '=', email)
      .executeTakeFirst();
    return row ? mapUserAccount(row) : null;
  }

  async findById(userId: number) {
    const row = await db
      .selectFrom('user_account')
      .selectAll()
      .where('user_id', '=', userId)
      .executeTakeFirst();
    return row ? mapUserAccount(row) : null;
  }
}

export class StudentRepository implements IStudentRepository {
  async findById(studentId: number) {
    const row = await db
      .selectFrom('student')
      .selectAll()
      .where('student_id', '=', studentId)
      .executeTakeFirst();
    return row ? mapStudent(row) : null;
  }

  async findByOrganization(organizationId: number) {
    const rows = await db
      .selectFrom('student')
      .selectAll()
      .where('organization_id', '=', organizationId)
      .orderBy('name', 'asc')
      .execute();
    return rows.map(mapStudent);
  }

  async belongsToOrganization(studentId: number, organizationId: number): Promise<boolean> {
    const row = await db
      .selectFrom('student')
      .select('student_id')
      .where('student_id', '=', studentId)
      .where('organization_id', '=', organizationId)
      .executeTakeFirst();
    return row !== undefined;
  }
}

export class PassResultRepository implements IPassResultRepository {
  private async attachProfile(
    resultRow: Selectable<PassResultTable> | undefined,
  ): Promise<PassResultWithProfile | null> {
    if (!resultRow) return null;
    const profileRow = await db
      .selectFrom('pass_profile')
      .selectAll()
      .where('result_id', '=', resultRow.result_id)
      .executeTakeFirst();
    const result: PassResultWithProfile = {
      ...mapPassResult(resultRow),
      profile: profileRow ? mapPassProfile(profileRow) : null,
    };
    return result;
  }

  private selectResult(studentId: number, latest: boolean) {
    let query = db.selectFrom('pass_result').selectAll().where('student_id', '=', studentId);
    if (latest) query = query.orderBy('tested_at', 'desc');
    return query.executeTakeFirst();
  }

  async findLatestByStudent(studentId: number): Promise<PassResultWithProfile | null> {
    const row = await this.selectResult(studentId, true);
    return this.attachProfile(row);
  }

  async findById(resultId: number): Promise<PassResultWithProfile | null> {
    const row = await db
      .selectFrom('pass_result')
      .selectAll()
      .where('result_id', '=', resultId)
      .executeTakeFirst();
    return this.attachProfile(row);
  }

  async listByStudent(studentId: number) {
    const rows = await db
      .selectFrom('pass_result')
      .selectAll()
      .where('student_id', '=', studentId)
      .orderBy('tested_at', 'desc')
      .limit(50)
      .execute();
    return rows.map(mapPassResult);
  }
}

export class ActivityRepository implements IActivityRepository {
  async findById(activityId: string) {
    const row = await db
      .selectFrom('activity')
      .selectAll()
      .where('activity_id', '=', activityId)
      .executeTakeFirst();
    return row ? mapActivity(row) : null;
  }
}

export class RecommendationRepository implements IRecommendationRepository {
  async create(input: {
    studentId: number;
    resultId: number | null;
    activityId: string | null;
    reason: string | null;
    confidenceScore: number | null;
  }) {
    const row = await db
      .insertInto('recommendation')
      .values({
        student_id: input.studentId,
        result_id: input.resultId,
        activity_id: input.activityId,
        reason: input.reason,
        confidence_score: input.confidenceScore,
      })
      .returningAll()
      .executeTakeFirstOrThrow();
    return mapRecommendation(row);
  }

  async listByStudent(studentId: number) {
    const rows = await db
      .selectFrom('recommendation')
      .selectAll()
      .where('student_id', '=', studentId)
      .orderBy('recommendation_id', 'desc')
      .limit(50)
      .execute();
    return rows.map(mapRecommendation);
  }
}

export class DailyLearningPlanRepository implements IDailyLearningPlanRepository {
  async upsertToday(studentId: number, environment: string) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const existing = await db
      .selectFrom('daily_learning_plan')
      .selectAll()
      .where('student_id', '=', studentId)
      .where('date', '=', today)
      .executeTakeFirst();
    if (existing) return mapDailyLearningPlan(existing);

    const row = await db
      .insertInto('daily_learning_plan')
      .values({ student_id: studentId, date: today, environment, status: '생성' })
      .returningAll()
      .executeTakeFirstOrThrow();
    return mapDailyLearningPlan(row);
  }

  async markCompleted(planId: number) {
    const row = await db
      .updateTable('daily_learning_plan')
      .set({ status: '완료' })
      .where('plan_id', '=', planId)
      .returningAll()
      .executeTakeFirstOrThrow();
    return mapDailyLearningPlan(row);
  }

  async listByStudent(studentId: number) {
    const rows = await db
      .selectFrom('daily_learning_plan')
      .selectAll()
      .where('student_id', '=', studentId)
      .orderBy('date', 'desc')
      .limit(50)
      .execute();
    return rows.map(mapDailyLearningPlan);
  }
}

export class ActivityLogRepository implements IActivityLogRepository {
  async create(input: {
    studentId: number;
    activityId: string;
    score: number | null;
    memo: string | null;
  }) {
    const row = await db
      .insertInto('activity_log')
      .values({
        student_id: input.studentId,
        activity_id: input.activityId,
        completed_at: new Date(),
        score: input.score,
        memo: input.memo,
      })
      .returningAll()
      .executeTakeFirstOrThrow();
    return mapActivityLog(row);
  }

  async listByStudent(studentId: number) {
    const rows = await db
      .selectFrom('activity_log')
      .selectAll()
      .where('student_id', '=', studentId)
      .orderBy('completed_at', 'desc')
      .limit(50)
      .execute();
    return rows.map(mapActivityLog);
  }
}

export class GrowthReportRepository implements IGrowthReportRepository {
  async create(input: {
    studentId: number;
    periodStart: Date;
    periodEnd: Date;
    summary: string;
    nextRecommendation: string;
  }) {
    const row = await db
      .insertInto('growth_report')
      .values({
        student_id: input.studentId,
        period_start: input.periodStart.toISOString().slice(0, 10),
        period_end: input.periodEnd.toISOString().slice(0, 10),
        summary: input.summary,
        next_recommendation: input.nextRecommendation,
      })
      .returningAll()
      .executeTakeFirstOrThrow();
    return mapGrowthReport(row);
  }

  async listByStudent(studentId: number) {
    const rows = await db
      .selectFrom('growth_report')
      .selectAll()
      .where('student_id', '=', studentId)
      .orderBy('period_end', 'desc')
      .limit(50)
      .execute();
    return rows.map(mapGrowthReport);
  }

  async latestByStudent(studentId: number) {
    const row = await db
      .selectFrom('growth_report')
      .selectAll()
      .where('student_id', '=', studentId)
      .orderBy('period_end', 'desc')
      .executeTakeFirst();
    return row ? mapGrowthReport(row) : null;
  }
}
