import { db } from '@/shared/config/db';
import { Selectable } from 'kysely';
import { PassTrainingProgramTable } from '@/db/types';
import {
  IAgeBandMappingRepository,
  ICognitiveProfileRepository,
  IDifficultyMappingRepository,
  ITrainingHistoryRepository,
  ITrainingProgramRepository,
} from '@/repositories/interfaces';
import { AgeBandInfo, CognitiveProfile81, DifficultyLevelInfo, TrainingProgram } from '@/domain/entities';

function toCamel(row: Selectable<PassTrainingProgramTable>): TrainingProgram {
  return {
    programId: row.program_id,
    programName: row.program_name,
    passDomain: row.pass_domain,
    subCognitiveFunction: row.sub_cognitive_function,
    targetAge: row.target_age,
    recommendedUser: row.recommended_user,
    difficultyLevel: row.difficulty_level,
    duration: row.duration,
    groupSize: row.group_size,
    materials: row.materials,
    trainingGoal: row.training_goal,
    expectedCognitiveChange: row.expected_cognitive_change,
    expectedBehavioralChange: row.expected_behavioral_change,
    schoolChange: row.school_change,
    homeConnectionGoal: row.home_connection_goal,
    environment: row.environment,
    safetyNotes: row.safety_notes,
    procedureIntro: row.procedure_intro,
    procedureInstruction: row.procedure_instruction,
    procedureDemo: row.procedure_demo,
    procedureActivity: row.procedure_activity,
    procedureFeedback: row.procedure_feedback,
    teacherScriptIntro: row.teacher_script_intro,
    teacherScriptActivity: row.teacher_script_activity,
    teacherQuestions: row.teacher_questions,
    encouragementScript: row.encouragement_script,
    closingScript: row.closing_script,
    observationChecklist: row.observation_checklist as Record<string, string> | null,
    difficultyAdjustment: row.difficulty_adjustment as Record<string, string> | null,
    homeActivity5min: row.home_activity_5min,
    homeActivity10min: row.home_activity_10min,
    homeActivity15min: row.home_activity_15min,
    parentQuestion: row.parent_question,
    parentFeedback: row.parent_feedback,
    rewardRule: row.reward_rule,
    successRule: row.success_rule,
    failRule: row.fail_rule,
    repeatRule: row.repeat_rule,
    reassessment4week: row.reassessment_4week,
    reassessment8week: row.reassessment_8week,
    reassessment12week: row.reassessment_12week,
    caution: row.caution,
    evidenceRefs: [], // findCandidates/findById에서 별도 조인 후 채움
    version: row.version,
    approvalStatus: row.approval_status,
  };
}

export class TrainingProgramRepository implements ITrainingProgramRepository {
  async findById(programId: string): Promise<TrainingProgram | null> {
    const row = await db
      .selectFrom('pass_training_program')
      .selectAll()
      .where('program_id', '=', programId)
      .executeTakeFirst();
    if (!row) return null;
    const program = toCamel(row);
    program.evidenceRefs = await this.loadEvidence(programId);
    return program;
  }

  async findCandidates(filter: {
    passDomain: 'PLANNING' | 'ATTENTION' | 'SIMULTANEOUS' | 'SUCCESSIVE';
    ageCode: string;
    difficultyLevel: number;
    approvalStatusIn?: Array<'draft_pending_review' | 'approved'>;
  }): Promise<TrainingProgram[]> {
    const ageBand = await db
      .selectFrom('age_band_mapping')
      .selectAll()
      .where('age_code', '=', filter.ageCode)
      .executeTakeFirst();

    let query = db
      .selectFrom('pass_training_program')
      .selectAll()
      .where('pass_domain', '=', filter.passDomain)
      .where('difficulty_level', '=', filter.difficultyLevel);

    if (ageBand) {
      query = query.where('target_age', '=', ageBand.age_label);
    }
    if (filter.approvalStatusIn?.length) {
      query = query.where('approval_status', 'in', filter.approvalStatusIn);
    }

    const rows = await query.execute();
    const programs = rows.map(toCamel);
    // N+1을 피하기 위해 evidence를 일괄 조회
    if (programs.length > 0) {
      const evidenceRows = await db
        .selectFrom('program_reference_paper')
        .selectAll()
        .where(
          'program_id',
          'in',
          programs.map((p) => p.programId),
        )
        .execute();
      for (const program of programs) {
        program.evidenceRefs = evidenceRows
          .filter((e) => e.program_id === program.programId)
          .map((e) => ({ paperCode: e.paper_code, evidenceLevel: e.evidence_level }));
      }
    }
    return programs;
  }

  async count(): Promise<number> {
    const result = await db
      .selectFrom('pass_training_program')
      .select(({ fn }) => [fn.countAll<number>().as('count')])
      .executeTakeFirstOrThrow();
    return Number(result.count);
  }

  private async loadEvidence(programId: string) {
    const rows = await db
      .selectFrom('program_reference_paper')
      .selectAll()
      .where('program_id', '=', programId)
      .execute();
    return rows.map((r) => ({ paperCode: r.paper_code, evidenceLevel: r.evidence_level }));
  }
}

export class CognitiveProfileRepository implements ICognitiveProfileRepository {
  async findByCode(profileCode: string): Promise<CognitiveProfile81 | null> {
    const row = await db
      .selectFrom('cognitive_profile_81')
      .selectAll()
      .where('profile_code', '=', profileCode)
      .executeTakeFirst();
    if (!row) return null;
    return {
      profileCode: row.profile_code,
      planningLevel: row.planning_level,
      attentionLevel: row.attention_level,
      simultaneousLevel: row.simultaneous_level,
      successiveLevel: row.successive_level,
      priorityDomain: row.priority_domain,
      strengthDomain: row.strength_domain,
    };
  }

  /**
   * 표준점수(SS) -> H/M/L 3단계 변환.
   * 필굿에듀테크 표준: 하(Low) SS<=85 / 중(Mid) 86~119 / 상(High) SS>=120
   */
  async resolveFromScores(scores: {
    planning: number;
    attention: number;
    simultaneous: number;
    successive: number;
  }): Promise<CognitiveProfile81> {
    const level = (ss: number): 'H' | 'M' | 'L' => {
      if (ss <= 85) return 'L';
      if (ss >= 120) return 'H';
      return 'M';
    };
    const code = `${level(scores.planning)}${level(scores.attention)}${level(scores.simultaneous)}${level(
      scores.successive,
    )}`;
    const found = await this.findByCode(code);
    if (found) return found;
    // 방어적 fallback: 매핑 테이블에 없으면(시드 누락) 즉시 표면화되도록 예외 처리
    throw new Error(`cognitive_profile_81 매핑 누락: ${code}`);
  }
}

export class TrainingHistoryRepository implements ITrainingHistoryRepository {
  private toEntity(r: {
    history_id: number;
    student_id: number;
    program_id: string;
    performed_at: unknown;
    success_rate: number | null;
    outcome: 'SUCCESS' | 'PARTIAL' | 'FAIL' | null;
    pass_domain: 'PLANNING' | 'ATTENTION' | 'SIMULTANEOUS' | 'SUCCESSIVE' | null;
    difficulty_level: number | null;
  }) {
    return {
      historyId: r.history_id,
      studentId: r.student_id,
      programId: r.program_id,
      performedAt: new Date(r.performed_at as string),
      successRate: r.success_rate,
      outcome: r.outcome,
      passDomain: r.pass_domain,
      difficultyLevel: r.difficulty_level,
    };
  }

  async listByStudentAndProgram(studentId: number, programId: string) {
    const rows = await db
      .selectFrom('training_history')
      .selectAll()
      .where('student_id', '=', studentId)
      .where('program_id', '=', programId)
      .orderBy('performed_at', 'desc')
      .execute();
    return rows.map((r) => this.toEntity(r));
  }

  async listRecentByStudent(studentId: number, limit: number) {
    const rows = await db
      .selectFrom('training_history')
      .selectAll()
      .where('student_id', '=', studentId)
      .orderBy('performed_at', 'desc')
      .limit(limit)
      .execute();
    return rows.map((r) => this.toEntity(r));
  }

  async listRecentByStudentAndDomain(
    studentId: number,
    passDomain: 'PLANNING' | 'ATTENTION' | 'SIMULTANEOUS' | 'SUCCESSIVE',
    limit: number,
  ) {
    const rows = await db
      .selectFrom('training_history')
      .selectAll()
      .where('student_id', '=', studentId)
      .where('pass_domain', '=', passDomain)
      .orderBy('performed_at', 'desc')
      .limit(limit)
      .execute();
    return rows.map((r) => this.toEntity(r));
  }

  async record(input: {
    studentId: number;
    programId: string;
    passDomain: 'PLANNING' | 'ATTENTION' | 'SIMULTANEOUS' | 'SUCCESSIVE';
    difficultyLevel: number;
    successRate: number | null;
    outcome: 'SUCCESS' | 'PARTIAL' | 'FAIL' | null;
  }) {
    const row = await db
      .insertInto('training_history')
      .values({
        student_id: input.studentId,
        program_id: input.programId,
        pass_domain: input.passDomain,
        difficulty_level: input.difficultyLevel,
        success_rate: input.successRate,
        outcome: input.outcome,
      })
      .returningAll()
      .executeTakeFirstOrThrow();
    return this.toEntity(row);
  }
}

export class DifficultyMappingRepository implements IDifficultyMappingRepository {
  async getByLevel(level: number): Promise<DifficultyLevelInfo | null> {
    const row = await db
      .selectFrom('difficulty_mapping')
      .selectAll()
      .where('difficulty_level', '=', level)
      .executeTakeFirst();
    if (!row) return null;
    return {
      level: row.difficulty_level,
      label: row.label,
      promoteThreshold: Number(row.promote_threshold),
      demoteThreshold: Number(row.demote_threshold),
    };
  }
}

export class AgeBandMappingRepository implements IAgeBandMappingRepository {
  async resolveAgeCode(ageInYears: number): Promise<AgeBandInfo | null> {
    const row = await db
      .selectFrom('age_band_mapping')
      .selectAll()
      .where('min_age', '<=', ageInYears)
      .where('max_age', '>=', ageInYears)
      .executeTakeFirst();
    if (!row) return null;
    return {
      ageCode: row.age_code,
      ageLabel: row.age_label,
      tool: row.tool,
      minAge: row.min_age,
      maxAge: row.max_age,
    };
  }
}
