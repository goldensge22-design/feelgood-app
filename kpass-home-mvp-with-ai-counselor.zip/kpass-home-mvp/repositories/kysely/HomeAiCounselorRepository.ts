import { db } from '@/shared/config/db';
import { Selectable, sql } from 'kysely';
import {
  HomeAiAvoidPhraseTable,
  HomeAiChatLogTable,
  HomeAiParentFaqTable,
  HomeAiParentLifeCaseTable,
  HomeAiTeacherStrategyTable,
} from '@/db/types';
import {
  IAvoidPhraseRepository,
  IHomeAiChatLogRepository,
  IParentFaqRepository,
  IParentLifeCaseRepository,
  ITeacherStrategyRepository,
} from '@/repositories/interfaces';
import {
  AvoidPhraseEntry,
  HomeAiAudience,
  HomeAiChatLog,
  ParentFaqEntry,
  ParentLifeCase,
  PassDomain,
  TeacherStrategyTemplate,
} from '@/domain/entities';

function mapFaq(row: Selectable<HomeAiParentFaqTable>): ParentFaqEntry {
  return {
    faqId: row.faq_id,
    priorityDomain: (row.priority_domain as PassDomain | null) ?? null,
    question: row.question,
    answer: row.answer,
  };
}

function mapLifeCase(row: Selectable<HomeAiParentLifeCaseTable>): ParentLifeCase {
  return {
    caseId: row.case_id,
    priorityDomain: row.priority_domain as PassDomain,
    childDescription: row.child_description,
    schoolBehavior: row.school_behavior,
    homeBehavior: row.home_behavior,
    parentGuidance: row.parent_guidance,
  };
}

function mapAvoidPhrase(row: Selectable<HomeAiAvoidPhraseTable>): AvoidPhraseEntry {
  return {
    phraseId: row.phrase_id,
    priorityDomain: row.priority_domain as PassDomain,
    phrase: row.phrase,
    why: row.why,
    insteadSay: row.instead_say,
  };
}

function mapTeacherStrategy(row: Selectable<HomeAiTeacherStrategyTable>): TeacherStrategyTemplate {
  return {
    templateId: row.template_id,
    priorityDomain: row.priority_domain as PassDomain,
    characteristic: row.characteristic,
    classroomBehavior: row.classroom_behavior,
    strengthUtilization: row.strength_utilization,
    supportStrategy: row.support_strategy,
    teacherQuestions: row.teacher_questions as string[],
    observationChecklist: row.observation_checklist as string[],
  };
}

function mapChatLog(row: Selectable<HomeAiChatLogTable>): HomeAiChatLog {
  return {
    logId: row.log_id,
    studentId: row.student_id,
    requestedByUserId: row.requested_by_user_id,
    audience: row.audience as HomeAiAudience,
    userMessage: row.user_message,
    aiResponse: row.ai_response,
    linkedProgramId: row.linked_program_id,
    createdAt: new Date(row.created_at as unknown as string),
  };
}

export class ParentFaqRepository implements IParentFaqRepository {
  async listAll(): Promise<ParentFaqEntry[]> {
    const rows = await db.selectFrom('home_ai_parent_faq').selectAll().execute();
    return rows.map(mapFaq);
  }

  async listByDomain(priorityDomain: PassDomain): Promise<ParentFaqEntry[]> {
    const rows = await db
      .selectFrom('home_ai_parent_faq')
      .selectAll()
      .where((eb) => eb.or([eb('priority_domain', '=', priorityDomain), eb('priority_domain', 'is', null)]))
      .execute();
    return rows.map(mapFaq);
  }
}

export class ParentLifeCaseRepository implements IParentLifeCaseRepository {
  async findByDomain(priorityDomain: PassDomain): Promise<ParentLifeCase | null> {
    const row = await db
      .selectFrom('home_ai_parent_life_case')
      .selectAll()
      .where('priority_domain', '=', priorityDomain)
      .executeTakeFirst();
    return row ? mapLifeCase(row) : null;
  }
}

export class AvoidPhraseRepository implements IAvoidPhraseRepository {
  async findByDomain(priorityDomain: PassDomain): Promise<AvoidPhraseEntry | null> {
    const row = await db
      .selectFrom('home_ai_avoid_phrase')
      .selectAll()
      .where('priority_domain', '=', priorityDomain)
      .executeTakeFirst();
    return row ? mapAvoidPhrase(row) : null;
  }
}

export class TeacherStrategyRepository implements ITeacherStrategyRepository {
  async findByDomain(priorityDomain: PassDomain): Promise<TeacherStrategyTemplate | null> {
    const row = await db
      .selectFrom('home_ai_teacher_strategy')
      .selectAll()
      .where('priority_domain', '=', priorityDomain)
      .executeTakeFirst();
    return row ? mapTeacherStrategy(row) : null;
  }
}

/**
 * 부모 AI 상담 / 교사 AI 상담(생성형 AI) 로그.
 * countTodayByUser는 "하루 10회 생성 제한" 정책의 유일한 근거이며, 서버 로컬
 * 자정 기준(created_at::date = 오늘)으로 계산한다.
 */
export class HomeAiChatLogRepository implements IHomeAiChatLogRepository {
  async create(input: {
    studentId: number;
    requestedByUserId: number;
    audience: HomeAiAudience;
    userMessage: string;
    aiResponse: string;
    linkedProgramId: string | null;
  }): Promise<HomeAiChatLog> {
    const row = await db
      .insertInto('home_ai_chat_log')
      .values({
        student_id: input.studentId,
        requested_by_user_id: input.requestedByUserId,
        audience: input.audience,
        user_message: input.userMessage,
        ai_response: input.aiResponse,
        linked_program_id: input.linkedProgramId,
      })
      .returningAll()
      .executeTakeFirstOrThrow();
    return mapChatLog(row);
  }

  async countTodayByUser(requestedByUserId: number, audience: HomeAiAudience): Promise<number> {
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);

    const result = await db
      .selectFrom('home_ai_chat_log')
      .select((eb) => eb.fn.countAll<string>().as('count'))
      .where('requested_by_user_id', '=', requestedByUserId)
      .where('audience', '=', audience)
      .where(sql<boolean>`created_at >= ${todayStart}`)
      .executeTakeFirst();

    return result ? Number(result.count) : 0;
  }
}
