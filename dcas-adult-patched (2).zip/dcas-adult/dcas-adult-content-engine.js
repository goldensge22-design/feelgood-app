/**
 * D-CAS 성인 리포트 — 개인화 엔진 (1단계: 이름 + 숫자)
 *
 * ★★★ 스코프 안내 ★★★
 * 이번 1단계는 "이름 하드코딩 제거"와 "정답률 숫자를 실제 점수로 교체"까지만
 * 다룹니다. "논리설계형 실행가" 같은 유형명, 서술형 문단, 역사적 인물 매칭은
 * K-PASS처럼 축 조합(7종) 기반 콘텐츠 뱅크가 별도로 필요합니다 — 성인 커리어
 * 맥락에 맞는 문구를 새로 설계해야 해서 이번 패스에는 포함하지 않았습니다.
 * 지금은 기존 문구(순차처리+계획력 조합 기준 "논리설계형 실행가")가 그대로
 * 남아있으니, 다른 점수 조합의 사용자에게는 유형명이 실제와 안 맞을 수 있다는
 * 점을 감안해 주세요.
 *
 * ===== D-CAS와 K-PASS의 중요한 차이 =====
 * D-CAS는 "또래 대비 백분위"가 아니라 "정답률(%)" 그 자체를 점수로 씁니다.
 * 그래서 K-PASS처럼 정규분포로 백분위를 재계산하는 로직이 없습니다 —
 * PROFILE.scores에 들어오는 값을 그대로 화면에 반영하기만 합니다.
 *
 * ===== PROFILE 계약 =====
 *   const PROFILE = window.__TEST_PROFILE__ || DEFAULT_PROFILE;
 * K-PASS와 동일한 계약이라 verify-personalization.js를 그대로 재사용합니다.
 */
(function (global) {

  const DEFAULT_PROFILE = {
    fullName: '박준서',
    givenName: '준서',
    genderKey: 'M',
    ageYears: 20,
    gradeLabel: '대학교 2학년',
    testDate: { y: 2026, m: 8, d: 23 },
    scores: { P: 84, A: 71, S: 66, Q: 91 } // 정답률(%) 그대로. 규준/백분위 아님.
  };
  const PROFILE = (typeof window !== 'undefined' && window.__TEST_PROFILE__) || DEFAULT_PROFILE;

  const AXIS_LABEL = { P: '계획력', A: '주의력', S: '동시처리', Q: '순차처리' };
  // 레이더 SVG 좌표 계산 — 원본 파일의 실제 좌표(반경 27~95, 중심 150,150)를 역산해 재사용
  const RADAR_CX = 150, RADAR_CY = 150;
  const RADAR_ANGLES = { P: 0, S: 90, Q: 180, A: 270 }; // 상=계획 우=동시 하=순차 좌=주의 (원본 배치 유지)
  function radarPoint(pct, angleDeg) {
    // 원본 91%가 반경(150,68)~(150,171) 즉 82px 만큼 이동 → 91% 대비 약 90px/100 스케일로 역산
    const r = 20 + (pct / 100) * 75; // 20~95 범위, 원본 91%→약 88 근사치와 유사하게 보정
    const rad = (angleDeg * Math.PI) / 180;
    return { x: RADAR_CX + r * Math.sin(rad), y: RADAR_CY - r * Math.cos(rad) };
  }

  function byId(id) { return document.getElementById(id); }
  function setText(id, text) { const el = byId(id); if (el) el.textContent = text; }
  function setHTML(id, html) { const el = byId(id); if (el) el.innerHTML = html; }
  function hasBatchim(str) {
    const ch = str.charCodeAt(str.length - 1);
    if (ch < 0xAC00 || ch > 0xD7A3) return false;
    return (ch - 0xAC00) % 28 !== 0;
  }
  function josa(word, pair) {
    const map = { '은는': ['은', '는'], '이가': ['이', '가'], '을를': ['을', '를'] };
    const [withB, withoutB] = map[pair];
    return word + (hasBatchim(word) ? withB : withoutB);
  }

  function applyIdentity() {
    // {{FULLNAME}} / {{GIVEN}} 플레이스홀더를 실제 값으로 전역 치환
    // (SECTIONS가 innerHTML로 꽂힌 뒤 실행되어야 하므로 render() 마지막에 호출)
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
    const toFix = [];
    let node;
    while ((node = walker.nextNode())) {
      if (node.nodeValue.indexOf('{{FULLNAME}}') !== -1 || node.nodeValue.indexOf('{{GIVEN}}') !== -1) {
        toFix.push(node);
      }
    }
    toFix.forEach(function (n) {
      n.nodeValue = n.nodeValue
        .replace(/\{\{FULLNAME\}\}/g, PROFILE.fullName)
        .replace(/\{\{GIVEN\}\}/g, PROFILE.givenName);
    });
    // title, attribute 등 텍스트노드 밖에 있는 것도 처리
    if (document.title.indexOf('{{FULLNAME}}') !== -1) {
      document.title = document.title.replace(/\{\{FULLNAME\}\}/g, PROFILE.fullName);
    }
    // t-meta (성별·나이·학년·검사일) — HEADER.meta는 정적 문자열이라 별도로 덮어씀
    const genderLabel = PROFILE.genderKey === 'F' ? '여' : '남';
    const dateStr = PROFILE.testDate.y + '.' + String(PROFILE.testDate.m).padStart(2,'0') + '.' + String(PROFILE.testDate.d).padStart(2,'0');
    setText('t-meta', genderLabel + ' · 만 ' + PROFILE.ageYears + '세 (' + PROFILE.gradeLabel + ') · 성인 진로직무 트랙 · ' + dateStr);
  }

  function applyScores() {
    const s = PROFILE.scores;
    // 레이더 SVG 텍스트 + 폴리곤
    ['P', 'A', 'S', 'Q'].forEach(function (k) {
      const el = byId('pf-radar-' + k);
      if (el) el.textContent = AXIS_LABEL[k] + ' ' + s[k] + '%';
    });
    const poly = byId('pf-radarpoly');
    if (poly) {
      const pts = ['P', 'S', 'Q', 'A'].map(function (k) {
        const p = radarPoint(s[k], RADAR_ANGLES[k]);
        return p.x.toFixed(1) + ',' + p.y.toFixed(1);
      }).join(' ');
      poly.setAttribute('points', pts);
    }
    // 4개 하위척도 막대
    ['P', 'A', 'S', 'Q'].forEach(function (k) {
      const bar = byId('pf-bar-' + k);
      if (bar) bar.style.width = s[k] + '%';
      setText('pf-barval-' + k, s[k] + '%');
    });
    // 강점 키워드 매핑표 (라벨+정답률만 갱신, "보완중" 표시는 등급 기준 필요 — 2단계에서)
    ['P', 'A', 'S', 'Q'].forEach(function (k) {
      const row = byId('pf-strengthrow-' + k);
      if (row) row.textContent = AXIS_LABEL[k] + ' ' + s[k] + '%';
    });
    // ★ pf-toppct-note ("전체 응시자 상위 8% 수준")는 정답률→응시자 순위 변환에
    //   실제 규준 데이터가 필요해 이번 패스에서 값을 바꾸지 않았습니다.
  }

  function applyCombo() {
    if (typeof DCasComboBank === 'undefined') return;
    const g = DCasComboBank.getCombo(PROFILE.scores);
    const combo = g.combo;
    const vars = { weak: g.weakAxisLabel, name: PROFILE.givenName };
    setText('pf-herotag', '인지 나침반 · ' + combo.code);
    setText('pf-herotype', combo.heroType);
    setText('pf-oneliner', DCasComboBank.fill(combo.oneliner, vars));
    const chipsEl = byId('pf-chips');
    if (chipsEl) chipsEl.innerHTML = combo.chips.map(function (c) { return '<span class="chip">' + c + '</span>'; }).join('');
    setText('pf-workstyle', combo.workStyle);
    setText('pf-collabstyle', combo.collabStyle);
    // opinion 문단: "{이름} 님은 ..." 형태로 직접 조립
    const opinionEl = byId('pf-opinion');
    if (opinionEl) opinionEl.textContent = PROFILE.givenName + ' 님은 ' + DCasComboBank.fill(combo.opinion, vars);
    // 역사적 인물 카드
    const figureCard = byId('pf-figurecard');
    if (figureCard && combo.figure) {
      figureCard.innerHTML = '<h4>🌟 이런 인물과 닮은 점이 있어요</h4><p>' +
        combo.figure.name + (hasBatchim(combo.figure.name) ? '은' : '는') + ' ' + DCasComboBank.fill(combo.figure.why, { name: PROFILE.givenName }) + '</p>';
    }
  }

  function applyJobs() {
    if (typeof DCasJobEngine === 'undefined' || typeof window.JOB_POOL === 'undefined') return null;
    const majorSelect = byId('majorSelect');
    const majorName = (majorSelect && majorSelect.value) || '컴퓨터공학과';
    const ranked = DCasJobEngine.rankJobsForMajor(PROFILE.scores, majorName, window.JOB_POOL);
    const container = byId('pf-jobcards');
    if (!ranked) {
      if (container) container.innerHTML = '<div class="tip-box">이 학과는 아직 직무 매칭 데이터가 연결되지 않았어요. (' + majorName + ')</div>';
      return null;
    }
    const top5 = ranked.slice(0, 5);
    const medalClass = ['r1', 'r2', 'r3', 'r4', 'r5'];
    if (container) {
      container.innerHTML = top5.map(function (item, i) {
        return '<div class="dept-card">' +
          '<div class="rank" style="display:flex;align-items:center;gap:8px;"><span class="rank-medal ' + medalClass[i] + '">' + (i + 1) + '</span>RANK ' + (i + 1) + ' · 적합도 ' + item.fit + '%</div>' +
          '<h4>' + item.job.label_ko + '</h4>' +
          '<p>' + item.reason + '</p>' +
          '</div>';
      }).join('');
    }
    setText('pf-jobs-h2', majorName + ' 안에서, ' + PROFILE.givenName + ' 님에게 맞는 직무');
    if (top5.length) {
      const ranked1 = topAxesLabel(top5[0].job.pass_profile);
      setText('pf-jobs-combotag', '🔗 03번 [' + ranked1 + '] 패턴이 TOP 직무 순위의 핵심 근거예요');
    }
    return ranked;
  }
  function topAxesLabel(jobProfile) {
    const map = { planning:'계획력', attention:'주의력', simultaneous:'동시처리', successive:'순차처리' };
    return Object.keys(jobProfile).map(function(k){return {k:k,v:jobProfile[k]};})
      .sort(function(a,b){return b.v-a.v;}).slice(0,2)
      .map(function(x){return map[x.k];}).join('×');
  }

  /* ===== 학과 요구 인지패턴 (06/08번 "need" 회색 막대) =====
   * ★ dcas-major-requirements.js는 1차 추정치입니다 (attr_confidence 0.5).
   *   감수 전에는 화면에 노출하지 않도록 기능 플래그로 잠갔습니다.
   *   감수 완료 후 SHOW_MAJOR_REQUIREMENT를 true로 바꾸면 즉시 활성화됩니다.
   */
  const SHOW_MAJOR_REQUIREMENT = false;

  function applyMajorGauge() {
    const majorSelect = byId('majorSelect');
    const majorName = (majorSelect && majorSelect.value) || '컴퓨터공학과';
    const s = PROFILE.scores;

    // "내 정답률"(주황 막대·있음 마커)은 감수와 무관하게 항상 실데이터로 갱신
    ['Q', 'P', 'S', 'A'].forEach(function (k, i) {
      // 06번 4개 req-row: 순차·계획·동시·주의 순서 고정
    });
    const rows06 = document.querySelectorAll('#major .req-row');
    const order06 = ['Q', 'P', 'S', 'A']; // 원본 마크업 순서: 순차처리·계획력·동시처리·주의력
    rows06.forEach(function (row, i) {
      const k = order06[i]; if (!k) return;
      const have = row.querySelector('.have');
      const label = row.querySelector('b');
      if (have) have.style.left = s[k] + '%';
      if (label) label.textContent = s[k] + '%';
    });

    if (!SHOW_MAJOR_REQUIREMENT || typeof window.DCAS_MAJOR_REQUIREMENTS === 'undefined') return;
    const req = window.DCAS_MAJOR_REQUIREMENTS[majorName];
    if (!req) return;
    rows06.forEach(function (row, i) {
      const k = order06[i]; if (!k) return;
      const need = row.querySelector('.need');
      if (need) need.style.width = req[k] + '%';
    });
    // 적합도 게이지(87%) — 4축 평균 거리 기반 재계산
    const gaugeFit = DCasJobEngine ? DCasJobEngine.computeFit(
      { P: s.P, A: s.A, S: s.S, Q: s.Q },
      { planning: req.P, attention: req.A, simultaneous: req.S, successive: req.Q }
    ) : null;
    if (gaugeFit !== null) {
      const gaugeCircle = document.querySelector('#major .gauge-circle');
      const gaugeB = gaugeCircle && gaugeCircle.querySelector('b');
      const gaugeH4 = document.querySelector('#major .gauge-txt h4');
      if (gaugeCircle) gaugeCircle.style.setProperty('--pct', gaugeFit);
      if (gaugeB) gaugeB.textContent = gaugeFit + '%';
      if (gaugeH4) gaugeH4.textContent = majorName + ' 적합도 ' + gaugeFit + '%';
    }
  }

  function applyJobSkill(ranked) {
    const container = byId('pf-jobskillcards');
    if (!container || !ranked || !ranked.length) return;
    const s = PROFILE.scores;
    const top2 = ranked.slice(0, 2);
    container.innerHTML = top2.map(function (item, i) {
      const req = item.job.pass_profile;
      const rows = [
        { label: '계획력', need: req.planning, have: s.P },
        { label: '주의력', need: req.attention, have: s.A },
        { label: '동시처리', need: req.simultaneous, have: s.S },
        { label: '순차처리', need: req.successive, have: s.Q },
      ].sort(function (a, b) { return b.need - a.need; }).slice(0, 3); // 요구도 상위 3개 축만 표시(원본 형식 유지)
      const rowsHtml = rows.map(function (r) {
        return '<div class="req-row"><div class="rlabel">' + r.label + '</div><div class="req-dual">' +
          '<div class="need" style="width:' + r.need + '%"></div><div class="have" style="left:' + r.have + '%"></div></div>' +
          '<b style="font-size:12.5px;color:var(--orange)">' + r.have + '%</b></div>';
      }).join('');
      const meetsAll = rows.every(function (r) { return r.have >= r.need; });
      const gapRow = rows.find(function (r) { return r.have < r.need; });
      const verdict = meetsAll
        ? '<b style="color:#1E8A5F;">✓ 표시된 영역 모두 요구 수준 이상</b> — 신입 기준으로도 바로 실무 적응이 가능한 프로파일이에요.'
        : '<b style="color:#C25E00;">△ ' + josa(gapRow.label, '이가') + ' 요구 수준에 다소 미달</b> — 관련 훈련을 병행하면 좋아요.';
      return '<div class="card">' +
        '<h4 style="margin:0 0 4px;font-size:14.5px;color:var(--navy);">RANK ' + (i + 1) + ' · ' + item.job.label_ko + '</h4>' +
        '<p class="sub" style="margin-bottom:10px;">신입 채용공고 기준 요구 역량 프로파일 (추정치)</p>' +
        rowsHtml +
        '<div class="req-legend"><span><i style="background:#DCE4F6"></i>직무 요구 수준</span><span><i style="background:var(--orange)"></i>내 정답률</span></div>' +
        '<p style="margin:10px 0 0;font-size:13.5px;color:var(--ink);">' + verdict + '</p>' +
        '</div>';
    }).join('');
    if (top2.length) {
      const q = byId('pf-interviewcard');
      if (q) q.querySelector('.q2').textContent = top2[0].job.label_ko + ' 직무, 면접에서 이렇게 어필해보세요';
    }
  }

  function applyGrowthAndDocs(ranked) {
    if (typeof DCasAxisContent === 'undefined') return;
    const s = PROFILE.scores;
    const rankedAxes = [{k:'P',v:s.P},{k:'A',v:s.A},{k:'S',v:s.S},{k:'Q',v:s.Q}].sort(function(a,b){return b.v-a.v;});
    const weak2 = rankedAxes.slice(-2).map(function(r){return r.k;});
    const strong2 = rankedAxes.slice(0,2).map(function(r){return r.k;});

    // 09번 growth
    const checklistEl = byId('pf-growthchecklist');
    if (checklistEl) checklistEl.innerHTML = DCasAxisContent.buildChecklistHTML(rankedAxes);
    const missionsEl = byId('pf-missions');
    if (missionsEl) missionsEl.innerHTML = DCasAxisContent.buildMissionsHTML(weak2);
    const weakLabel = DCasAxisContent.AXIS_LABEL[weak2[weak2.length-1]];
    setText('pf-growthtip', '💡 체크가 유독 낮은 항목이 있다면, 이는 프로파일과도 일치해요 — ' + weakLabel + ' 요구가 높은 항목이기 때문이에요. 이런 항목은 "약점"이 아니라 "의식적 훈련이 더 필요한 영역"으로 접근하면 좋아요.');

    // 11번 docs
    const topJobName = (ranked && ranked.length) ? ranked[0].job.label_ko : '지원 직무';
    const step1El = byId('pf-docs-step1');
    if (step1El) {
      const s1 = strong2[0], s2 = strong2[1];
      step1El.innerHTML = '<b>STEP 1 · 핵심 강점 3개 선정</b>02·03번에서 확인한 ' +
        DCasAxisContent.AXIS_LABEL[s1] + '(' + s[s1] + '%)·' + DCasAxisContent.AXIS_LABEL[s2] + '(' + s[s2] + '%)·절차적 정밀함을 자소서 전체를 관통하는 핵심 키워드 3개로 확정해요.';
    }
    const docsTableEl = byId('pf-docs-table');
    if (docsTableEl) {
      const REASON = {
        P: '일정·태스크 분해 능력이 실행력의 증거가 돼요', A: '반복 검증 습관을 몰입력의 증거로 제시',
        S: '"보완 방식을 스스로 설계했다"는 성장형 스토리로 강점화', Q: '원인을 단계적으로 추적한 경험이 논리적으로 잘 드러나요',
      };
      const FIELD = { P:'목표달성 경험 / 입사 후 포부', A:'성실성·직무 전문성', S:'협업·갈등 경험', Q:'문제해결 경험 / 지원동기' };
      docsTableEl.innerHTML = '<tr><th>인지 강점</th><th>가장 잘 맞는 문항</th><th>이유</th></tr>' +
        rankedAxes.map(function (r, i) {
          const suffix = (i === rankedAxes.length - 1) ? ' (보완중)' : '';
          return '<tr><td>' + DCasAxisContent.AXIS_LABEL[r.k] + ' ' + s[r.k] + '%' + suffix + '</td><td>' + FIELD[r.k] + '</td><td>' + REASON[r.k] + '</td></tr>';
        }).join('');
    }
    const docCardsEl = byId('pf-doccards');
    if (docCardsEl) docCardsEl.innerHTML = DCasAxisContent.buildDocCardsHTML(strong2, topJobName);
    const es3 = document.querySelector('label[for="es3"]');
    if (es3) es3.textContent = '강점 키워드(' + DCasAxisContent.AXIS_LABEL[strong2[0]] + '·' + DCasAxisContent.AXIS_LABEL[strong2[1]] + ' 관련 표현)가 최소 2개 문항에 걸쳐 반복된다';
  }

  /* ===== roadmap 공용 뼈대 — entry_level 기반 톤 조절, 기술스택 세부는 미포함 ===== */
  const ENTRY_LEVEL_COPY = {
    direct: { tag: '신입 직행 가능', note: '이 직무는 신입 채용 비중이 높아요 — 아래 흐름을 따라가면 4학년 때 바로 지원할 수 있어요.' },
    bridge: { tag: '유관 경험 권장', note: '이 직무는 관련 인턴·프로젝트 경험이 있으면 유리해요 — 3학년부터 관련 활동을 의식적으로 쌓아보세요.' },
    retool: { tag: '추가 역량 필요', note: '이 직무는 전공 지식 외에 추가로 익혀야 할 도구·자격이 있을 수 있어요 — 학과 상담센터에서 구체적 요건을 확인해보세요.' },
  };
  function buildRoadmapSkeleton(topJob) {
    const entryLevel = topJob ? topJob.job.entry_level : 'bridge';
    const copy = ENTRY_LEVEL_COPY[entryLevel] || ENTRY_LEVEL_COPY.bridge;
    const jobName = topJob ? topJob.job.label_ko : '희망 직무';
    return {
      subtitle: '1순위 직무(' + jobName + ') 기준으로 설계했어요 · ' + copy.tag,
      years: [
        { tag: '1학년', title: '기초 체력 쌓기', items: [
          '전공 기초 과목을 탄탄히 다지기', '동아리·소모임에서 협업 도구 익히기', '작은 프로젝트로 "완주 경험" 만들기'
        ]},
        { tag: '2학년 (현재)', title: '전공 심화 + 직무 이해', items: [
          copy.note,
          jobName + ' 관련 과목·프로젝트를 의식적으로 선택하기',
          '06·07번에서 확인한 강점 축을 살릴 수 있는 소규모 프로젝트 시도'
        ]},
        { tag: '3학년', title: '실전 스펙 채우기', items: [
          jobName + ' 관련 심화 프로젝트 1개 완성',
          jobName + ' 인턴십 지원 시작 — 06번 학과적합도·07번 직무순위 근거를 자소서에 활용',
          '2·3순위 직무도 함께 살펴보고 겹치는 역량이 있다면 함께 준비'
        ]},
        { tag: '4학년', title: '취업 실전', items: [
          '포트폴리오 완성 — "강점을 발휘해 ' + jobName + ' 관련 문제를 해결한 과정"을 문서로 정리',
          jobName + ' 면접 대비: 강점이 드러난 구체 경험 정리',
          jobName + ' 채용공고 요구역량과 11번 자소서 설계 문구 매칭해 지원서 작성'
        ]},
      ],
    };
  }
  function applyRoadmap(ranked) {
    const topJob = ranked && ranked.length ? ranked[0] : null;
    const rm = buildRoadmapSkeleton(topJob);
    setText('pf-roadmap-sub', rm.subtitle);
    const timeline = byId('pf-roadmap-timeline');
    if (!timeline) return;
    timeline.innerHTML = rm.years.map(function (y) {
      return '<div class="yr-step"><div class="yr-tag">' + y.tag + '</div><h4>' + y.title + '</h4><ul>' +
        y.items.map(function (it) { return '<li>' + it + '</li>'; }).join('') + '</ul></div>';
    }).join('');
  }

  function applyEfficiency(d, ranked) {
    if (typeof DCasComboBank === 'undefined') return;
    const s = PROFILE.scores;
    const top2Keys = d.ranked.slice(0, 2).map(function (r) { return r.k; });
    const p1 = DCasComboBank.DIAG_PATTERN1[d.comboKey];
    const weakKey = d.ranked[d.ranked.length - 1].k;
    const p2 = DCasComboBank.DIAG_PATTERN2[weakKey];
    const AXIS_LABEL_CLASS = { P: 'p', A: 'a', S: 's', Q: 'q' };
    const AXIS_TO_JOBKEY_EFF = { P: 'planning', A: 'attention', S: 'simultaneous', Q: 'successive' };
    const topJob = (ranked && ranked.length) ? ranked[0] : null;
    if (p1) {
      setText('pf-eff-h2', '[' + AXIS_LABEL[top2Keys[0]] + '×' + AXIS_LABEL[top2Keys[1]] + '] 조합이 만드는 패턴');
      setHTML('pf-eff-pair1', top2Keys.map(function (k) {
        return '<span class="axis-tag ' + AXIS_LABEL_CLASS[k] + '">' + AXIS_LABEL[k] + ' ' + s[k] + '%</span>';
      }).join('<span class="vs">×</span>'));
      setText('pf-eff-title1', '① ' + p1.title);
      setHTML('pf-eff-sym1', '<b>이런 모습으로 나타나요 —</b> ' + p1.sym);
      /* ===== 패치: 활용법(rx)을 06·07번에서 선택한 학과/직무 기준으로 동적 생성.
       * 학과/직무를 아직 안 고른 상태(topJob 없음)에서는 기존 범용 문구로 폴백. ===== */
      const rx1Text = topJob
        ? ('07번에서 확인한 1순위 직무 <b>' + topJob.job.label_ko + '</b>에서 특히 강점이 돼요 — 이 직무는 ' +
           top2Keys.map(function (k) { return AXIS_LABEL[k]; }).join('·') + '을(를) 핵심으로 요구하는데, ' +
           PROFILE.givenName + ' 님의 ' + top2Keys.map(function (k) { return AXIS_LABEL[k] + ' ' + s[k] + '%'; }).join('×') +
           ' 조합과 정확히 맞닿아 있어요(적합도 ' + topJob.fit + '%). 지원 시 이 조합을 구체적 경험과 엮어서 어필해보세요.')
        : p1.rx;
      setHTML('pf-eff-rx1', '<b>이렇게 활용해보세요 —</b> ' + rx1Text);
    }
    if (p2) {
      setHTML('pf-eff-pair2', '<span class="axis-tag ' + AXIS_LABEL_CLASS[weakKey] + '">' + AXIS_LABEL[weakKey] + ' ' + s[weakKey] + '%</span><span class="vs">↓</span>');
      setText('pf-eff-title2', '② ' + p2.title);
      setHTML('pf-eff-sym2', '<b>이런 모습으로 나타나요 —</b> ' + p2.sym);
      let rx2Text = p2.rx;
      if (topJob) {
        const weakJobKey = AXIS_TO_JOBKEY_EFF[weakKey];
        const need = topJob.job.pass_profile ? topJob.job.pass_profile[weakJobKey] : null;
        const have = s[weakKey];
        if (typeof need === 'number' && have < need) {
          rx2Text = '<b>' + topJob.job.label_ko + '</b> 직무는 ' + josa(AXIS_LABEL[weakKey], '을를') + ' 평균 ' + need +
            '% 정도 요구해요 — 지금(' + have + '%)보다 끌어올려두면 실무 적응이 더 수월해질 거예요. ' + p2.rx;
        } else if (typeof need === 'number') {
          rx2Text = '<b>' + topJob.job.label_ko + '</b> 직무 기준으로는 ' + josa(AXIS_LABEL[weakKey], '이가') + ' 이미 충분한 수준(요구 ' + need +
            '% vs 보유 ' + have + '%)이에요. 다른 직무·상황을 대비해 이렇게 훈련해두면 더 좋아요 — ' + p2.rx;
        }
      }
      setHTML('pf-eff-rx2', '<b>이렇게 훈련해보세요 —</b> ' + rx2Text);
    }
    if (ranked && ranked.length) {
      const cpRows = byId('pf-eff-preview');
      if (cpRows) {
        const top1Job = ranked[0], lastJob = ranked[ranked.length - 1];
        const rows = cpRows.querySelectorAll('.cp-row');
        if (rows[0]) rows[0].querySelector('.cp-desc').textContent = '→ 07번 1순위(' + top1Job.job.label_ko + ') 근거';
        if (rows[1] && lastJob !== top1Job) rows[1].querySelector('.cp-desc').textContent = '→ 07번 ' + lastJob.job.label_ko + ' 후순위 이유';
      }
    }
  }

  function applyEmotional(d, ranked) {
    const s = PROFILE.scores;
    const topAxisKey = d.ranked[0].k;
    const weakAxisKey = d.ranked[d.ranked.length - 1].k;
    const statsEl = byId('pf-emo-stats');
    if (statsEl) {
      const jobCount = ranked ? ranked.length : 0;
      statsEl.innerHTML = '<div class="stat-chip"><b>' + s[topAxisKey] + '%</b><span>' + AXIS_LABEL[topAxisKey] + ' 상위권</span></div>' +
        '<div class="stat-chip"><b>' + jobCount + '개</b><span>학과 안 세부 직무</span></div>';
    }
    /* ===== 패치: p1·li2가 "컴퓨터공학과"·"동시처리"로 고정돼 있던 것을
     * 06번에서 선택한 학과명, 실제 최약 축으로 동적화 ===== */
    const majorSelect = byId('majorSelect');
    const majorName = (majorSelect && majorSelect.value && majorSelect.value !== '__custom__') ? majorSelect.value : '희망 학과';
    const p1El = byId('pf-emo-p1');
    if (p1El) {
      p1El.innerHTML = '다음 06번에서 보게 될 "학과 적합도"는 ' + PROFILE.givenName + ' 님이 ' +
        josa(majorName, '을를') + ' 잘 선택했는지 채점하는 점수가 아니에요. 같은 학과 안에서도 사람마다 다른 인지 프로파일을 가지고 있고, 그 차이가 "어떤 세부 직무가 더 잘 맞는지"를 알려줄 뿐이에요. 적합도가 낮게 나오는 영역이 있더라도, 그건 "학과를 잘못 골랐다"는 뜻이 결코 아니에요.';
    }
    const li2El = byId('pf-emo-li2');
    if (li2El) {
      li2El.innerHTML = '"동기들보다 점수가 낮으면 뒤처진 건가요" → 아니에요. ' + AXIS_LABEL[weakAxisKey] +
        '처럼 낮게 나온 영역도 훈련으로 충분히 성장해요. 09번 성장 트래커에서 구체적인 훈련법을 확인할 수 있어요';
    }
  }

  function applyExpert(d, ranked) {
    const s = PROFILE.scores;
    // 정답률·판정만 실데이터로 갱신. 원점수·종합지수·SS는 developer 연동 예정이라 손대지 않음.
    const tbody = byId('pf-expert-table');
    if (tbody) {
      const rows = tbody.querySelectorAll('tr');
      const order = ['Q', 'P', 'S', 'A']; // 표 순서: 순차·계획·동시·주의
      rows.forEach(function (row, i) {
        const k = order[i]; if (!k) return;
        const tds = row.querySelectorAll('td');
        if (tds[2]) tds[2].textContent = s[k] + '%'; // 정답률 칸 (원점수 칸은 손대지 않음 — developer 연동 예정)
        const judge = row.querySelector('.judge');
        if (judge) {
          // ★ 상/중/하 경계값(80/50)은 임시 추정치입니다. 실제 판정 기준을 확인해서 조정 필요.
          const level = s[k] >= 80 ? 'high' : (s[k] >= 50 ? 'mid' : 'low');
          judge.className = 'judge ' + level;
          judge.textContent = level === 'high' ? '상' : (level === 'mid' ? '중' : '하');
        }
      });
    }
    const compareEl = byId('pf-expert-compare');
    if (compareEl) {
      const circles = compareEl.querySelectorAll('.ds-circle b');
      const spans = compareEl.querySelectorAll('.ds-circle span');
      const topKey = d.ranked[0].k;
      if (circles[0]) circles[0].textContent = s[topKey] + '%';
      if (spans[0]) spans[0].textContent = AXIS_LABEL[topKey] + '·' + PROFILE.givenName;
      if (spans[1]) spans[1].textContent = AXIS_LABEL[topKey] + '·학과평균';
    }
  }

  function render() {
    applyIdentity();
    applyScores();
    applyCombo();
    const rankedJobs = applyJobs();
    applyJobSkill(rankedJobs);
    applyMajorGauge();
    applyGrowthAndDocs(rankedJobs);
    applyRoadmap(rankedJobs);
    if (typeof DCasComboBank !== 'undefined') {
      const d = DCasComboBank.getCombo(PROFILE.scores);
      applyEfficiency(d, rankedJobs);
      applyEmotional(d, rankedJobs);
      applyExpert(d, rankedJobs);
    }
  }

  // SECTIONS가 이미 DOM에 꽂힌 뒤(render() 호출 후) 실행되도록,
  // 리포트의 기존 render() 호출부 바로 다음에 이 스크립트가 실행되게 배치합니다.
  global.DCasAdultEngine = { render: render, PROFILE: PROFILE };

})(typeof window !== 'undefined' ? window : globalThis);
