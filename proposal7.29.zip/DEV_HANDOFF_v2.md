# 수정 요청 — FeelGood 제안서 페이지 (proposal/index.html)

## 파일 적용 방법 (중요)
첨부된 `index.html`을 저장소의 **`proposal/index.html`** 경로에 그대로 덮어쓰기 하세요.
- 파일명/경로 변경 금지 — 반드시 `proposal/` 폴더 안 기존 `index.html`을 대체
- 이 파일은 같은 폴더의 `assets/style.css`, `assets/inst.css`, `assets/app.js`, `i18n/*.js`,
  `images/img-*` 를 상대경로로 참조하므로, 다른 위치(저장소 루트 등)에 두면 CSS/JS/이미지가 깨짐

## 이번 변경 내용

### 1. 대학 파트너십 카드
- "홍남대학교 RISE 취업스쿨" → "동의대학교 RISE 취업스쿨" (alt/제목 텍스트 모두 수정)

### 2. "인지훈련 프로그램" 섹션 — 전면 개편
기존의 32회 커리큘럼(4 Phase), 연령별 핵심 포인트, 기존 SEL과의 차별점 콘텐츠를
**HomeAI(학부모용) / 교사용AI(기관교육용) / 기관·기업 맞춤 설계** 중심 구조로 교체했습니다.

새 구성 순서:
1. 인트로 (기존 유지)
2. 핵심 모델: "검사 → HomeAI(가정) + 교사용AI(학교) → 성장 리포트"
3. 문제 제기: "인지검사는 받았는데, 그 다음은?"
4. HomeAI / 교사용AI 카드 2개 (나란히 배치)
5. 기관·기업 맞춤 AI 인지훈련 프로그램 설계 (신규 섹션 — 예: 성경학교 교리학습 인지훈련 재설계)
6. 학교 도입 결정 포인트 (기존 유지)
7. MindCompass 교사 대시보드 v3 샘플 미리보기 (기존 유지)
8. 체험 CTA 버튼 2개 (기존 유지, 아래 3번 참고)

### 3. 체험 CTA 버튼
- 🎓 **교사용AI(기관교육용) 체험하기** → `https://goldensge22-design.github.io/feelgood-app/kpass-teacher-dashboard-demo.html` (연결 완료)
- 🏠 **HomeAI(학부모용) 체험하기** → **버튼만 생성, 링크는 아직 미연결**(`href="#"`)
  - id: `bm-cta-btn1`
  - 담당자가 별도로 안내 예정인 실제 HomeAI 데모 주소로 `href`만 교체하면 됩니다
  - 참고로 담당자가 전달한 후보 주소(→ 유효기간 있는 JWT 포함 URL이라 만료 여부 확인 필요):
    `https://service.feel-good.io/api/v1/kpass/admin/test-result/4/eyJhbGciOiJIUzUxMiJ9...` (전체 URL은 담당자에게 재확인)

## 확인 방법
배포 후 아래 주소에서 새 "인지훈련 프로그램" 섹션, 대학명 수정, 버튼 2개 상태 확인:
```
https://goldensge22-design.github.io/feelgood-app/proposal/index.html
```
