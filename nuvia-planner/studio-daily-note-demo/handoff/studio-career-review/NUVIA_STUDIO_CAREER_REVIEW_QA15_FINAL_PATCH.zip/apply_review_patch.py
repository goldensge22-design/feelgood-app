"""Default is read-only preflight. Review changes on a separate branch before --apply."""
from pathlib import Path
import argparse,hashlib,json,shutil
parser=argparse.ArgumentParser()
parser.add_argument('--target',required=True)
parser.add_argument('--apply',action='store_true')
parser.add_argument('--backup',help='Required NEW backup directory OUTSIDE the target repository for --apply')
a=parser.parse_args()
bundle=Path(__file__).resolve().parent;target=Path(a.target).resolve()
before=json.loads((bundle/'BEFORE_SHA256.json').read_text())
after=json.loads((bundle/'AFTER_SHA256.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if not target.is_dir():raise SystemExit('Target directory missing')
for rel,expected in before.items():
 p=target/rel
 if p.is_symlink() or any(x.is_symlink() for x in p.parents):raise SystemExit('Symlink conflict: '+rel)
 if expected is None:
  if p.exists():raise SystemExit('New path already exists; STOP: '+rel)
 elif not p.is_file() or sha(p)!=expected:raise SystemExit('Baseline hash mismatch; STOP: '+rel)
 src=bundle/'files'/rel
 if not src.is_file() or sha(src)!=after[rel]:raise SystemExit('Bundle hash mismatch: '+rel)
print('PASS: all baseline and new-path preconditions. No files changed yet.')
if not a.apply:raise SystemExit(0)
if not a.backup:raise SystemExit('--backup is required for --apply')
backup=Path(a.backup).resolve()
if backup==target or target in backup.parents or backup.exists():raise SystemExit('Backup must be a NEW directory outside target')
backup.mkdir(parents=True)
for rel,expected in before.items():
 if expected is not None:
  p=backup/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(target/rel,p)
(backup/'BEFORE_SHA256.json').write_text(json.dumps(before,indent=2))
(backup/'AFTER_SHA256.json').write_text(json.dumps(after,indent=2))
written=[]
try:
 for rel in before:
  dst=target/rel;dst.parent.mkdir(parents=True,exist_ok=True)
  written.append(rel);shutil.copy2(bundle/'files'/rel,dst)
 print('Applied review files only. Existing Studio records were not read or changed.')
except BaseException:
 for rel in reversed(written):
  dst=target/rel
  if before[rel] is None:dst.unlink(missing_ok=True)
  else:shutil.copy2(backup/rel,dst)
 raise
