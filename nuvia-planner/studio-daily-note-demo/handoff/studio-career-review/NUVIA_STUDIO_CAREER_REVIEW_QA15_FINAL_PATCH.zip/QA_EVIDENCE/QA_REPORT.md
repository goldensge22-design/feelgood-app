# Career Review browser QA

**Route tested:** `/career-review.html`  
**Environment:** isolated Playwright browser context on the requested preview domain  
**Scope:** changed Career Review unit only; no source code, publishing, GitHub, or Studio routes/storage were modified.

## Verdict

The principal synthetic adult journey passed through result, plan, run, experience, confirmation, preview, and JSON download. Revision and report-version invalidation/reconfirmation behaved as expected. The blank no-result custom-direction path also saved a task in a separate isolated context.

The requested 15-locale × 3-viewport × 5-tab UI matrix is complete (225/225 rows passed). The remaining browser checks—draft/timer persistence, backup and restore variants, duplicate-action idempotency, keyboard activation, reduced motion, and scoped storage failure—were completed in a separate synthetic context. In-scope browser QA is complete, with a persistence nuance documented below; native/physical language review remains outside browser verification.

## Executed checks and observations

1. Fresh blank route showed “No result loaded”; general Studio and youth demo links were present at `./studio.html` and `./studio.html?demo=school`. Neither link was followed.
2. Loaded the built-in synthetic adult fixture. Observed `review-fixture-adult` v1; ordered scores Planning 42/L, Attention 58/M, Simultaneous 76/H, Successive 65/M; ranks 1–5 and IDs `fixture-job-1`…`fixture-job-5`. Display names and fixture interpretations were localized for English; interpretation explicitly stated no interpretation.
3. Selected `fixture-job-1`; entered title, method, completion criteria, and planned evidence. Save produced task revision 1 without starting a run. Explicit Start created one run; Pause, Resume, and End transitioned the same run. Ended run was revision 1, elapsed 0:00:15.
4. Opened the experience. All six experience fields were initially blank; inclusion checkboxes were unchecked/disabled. Export remained unavailable before confirmation. Authored and selected only `action` and `learning`, confirmed them, and observed a single export preview with only those statements. JSON reported `delivery: local-file-only`, `externalVerification: false`, `user-confirmed-only`, original recommendation ID/rank/source, and no PASS scores or personal memo. Download event produced `nuvia-experience-52f014c3.json`.
5. Edited the ended task's method and saved revision 2. Revision history retained the original revision-1 method and the new revision-2 method; the run continued to reference revision 1. The old experience became stale and export was blocked until explicit reconfirmation. Experience history then showed confirmation versions 118/revision 1 and 119/revision 2. Export JSON retained `executedTaskVersion: 1`, `acknowledgedTaskVersion: 2`.
6. Imported a valid report version 2 with the same report ID and changed `source.name`. The report count became 2 and the new source was active. The non-canonical v2 report's imported English strings remained raw rather than being fixture-localized. A conflicting same-ID/version upload was rejected with “This file is not a valid review result.”; accepted v2 remained active and report count remained 2. Export was blocked until explicit reconfirmation. Final JSON preserved original report v1 and acknowledged report v2.
7. In a separate isolated context, seeded `nuvia:studio:v1:personal` with the exact sentinel `{"studio":{"locale":"en"},"sentinel":"keep-exact-4d7f"}`. Ran the blank custom-direction flow and saved a task. The sentinel value remained byte-identical and `nuvia:studio:v1:review` remained null.

## Responsive spot checks (English, populated finished export)

- **1440×1000:** Main workflow visually orderly; all five tabs and export preview visible in desktop screenshots.
- **768×1024:** `documentElement.scrollWidth=753` with `innerWidth=768`; after scrolling to top, language selector and brand were in separate header positions without apparent overlap. Export preview was single-column.
- **360×800:** `documentElement.scrollWidth=345` with `innerWidth=360`; language selector occupied the first header row at the right and brand the second row. Header did not visibly overlap. The tab strip is horizontally scrollable: only the first three tabs fit at once, while Experience and Export extend beyond the viewport; measured tab heights were 44px. This is a mobile navigation limitation to review, though document/body width did not exceed the viewport.

## Observed issue / verification limit

- A browser resource returned HTTP 404 after loading the sample fixture; no visible workflow failure was associated with it, but the failed resource was not identified.
- At 360px the five-step navigation needs horizontal scrolling and later tabs are outside the initial visible area.
- Screenshots are attached to the browser QA response by observation IDs; the browser tool did not expose a supported mechanism to save those screenshots as files in this directory.
- After reload, the timer UI recovered a running record as Paused and did not add offline time; however, the raw localStorage record remained `phase: "running"` with its prior `lastAt` until a later user action committed the recovered state. The UI remained paused and the elapsed value stayed frozen. This is a storage-normalization nuance, not an observed offline-time overcount.
- The actual downloaded backup was validated by JSON shape/counts and successful restore. Its pretty-printed download was not byte-equal to the compact localStorage string; restore cancellation, by contrast, was explicitly checked byte-for-byte against the pre-upload storage snapshot.
- All planned browser checks are now executed. Still outside verified scope: native/physical language review and identification of the earlier 404 resource.

## Screenshot evidence IDs

- Desktop populated export: `1p5ew3` (1440×1000)
- Tablet populated export, scrolled to top: `8q6ut6` (768×1024)
- Mobile populated export: `iddc5f` (360×800; scrollable tab strip visible)
- Matrix populated export: desktop `xspas3`, tablet `i15vio`, mobile `pejcmf`
- Matrix fixture result: desktop `e62b5p`, mobile `rbxsty`; Arabic RTL desktop `c7ib09`
- Blank result/custom form: `0dxhbl`, `v978ji`
- Saved custom task: `wl4gz6`
- Confirmed export JSON: `wg20rs`, `1p5ew3`


## Matrix continuation addendum

All 15 locales (`ko`, `en`, `ja`, `zh-CN`, `zh-TW`, `mn`, `th`, `vi`, `ar`, `ru`, `km`, `es`, `fr`, `it`, `az`) were actually selected in the browser at 360, 768, and 1440px across Result, Plan, Run, Experience, and Export (225 rows). Every row passed exact source-COPY checks for title/tab/aria/local notice, relevant form labels/placeholders, experience/export labels, fixture names/domains/note, and layout checks for document overflow, header/field overlap, physical-right selector placement, direction, and 44px target height. Exact English fallback scan returned 0 unexpected matches in 225 cases. Canonical fixture interpretation, localized source, score, original level, occupation ID/rank/source checks passed 45/45 Result-view locale×viewport rows. Full row evidence and per-locale counts are in matrix.json.

Desktop header alignment is relative to centered `.cr-head`; a first viewport-edge check was a measurement error and was corrected/rerun. Arabic RTL selector was physically right-aligned with a 0px gap to the header edge. Mobile 360px tabs remain horizontally scrollable.

## Persistence/timer, backup, idempotency, keyboard, and storage continuation

- In a conditional-seed context, an unsaved custom draft (direction, title, method, criteria, evidence) survived locale changes `az → ar → ko → en` while a run remained Running. The `?qa=keep#timer` URL was unchanged and the run elapsed value advanced.
- Pausing froze stored elapsed time at 71,147ms across a 2.5-second wait (`lastAt:null`). Resume advanced elapsed to 72,151ms. After reload, the UI recovered the same run as Paused at 82,151ms; elapsed was identical to the pre-reload value and remained unchanged for another 2.5 seconds. The raw stored record still read Running/non-null `lastAt` until a subsequent End action persisted the terminal state; the ended duration remained 82,151ms (displayed `0:01:22`). A second keyboard-started run was paused with Space and also remained frozen at 68,885ms across 2.5 seconds.
- Save backup produced a real `nuvia-career-review-backup-2026-10-23.json` download (4,989 bytes; 1 report, 1 task, 2 runs, 1 experience). Restore preview showed those counts. Cancel closed the preview with exact byte identity for the Career Review storage key. Valid confirmation restored the backup state from a deliberately changed Arabic locale to English.
- Corrupt JSON and a broken `runs[0].taskId` were rejected as `invalidBackup` (“This backup cannot be read.”); a valid-looking foreign owner was rejected as `wrongOwner` (“This backup belongs to another local profile.”). All three showed no preview and left review bytes and owner token unchanged.
- Rapid double-clicks produced one record each: Save created one task (count 1→2, one Revision 1); Start created one run (2→3); Record experience created one experience (1→2); Confirm created one history entry (0→1). Each test used synthetic fixture data.
- Keyboard checks: native select ArrowUp changed English to Korean; Tab traversed the header tabs; Enter activated Plan/Run and Start; Space activated Pause; the timer remained frozen while paused. The initial focus was seeded on the language selector for the keyboard route. Reduced-motion emulation yielded `transition:0s`, `animation:none`, `transform:none` even on hover; the browser preference was restored to no-preference.
- A page-only, key-scoped synthetic `QuotaExceededError` on Career Review `localStorage.setItem` caused the UI error `storageError` / “Could not save in this browser.”, hid Saved status, and disabled Save backup. The review bytes, owner token, and Studio sentinel remained byte-identical; the native method was restored and reload returned to saved state.
- The final browser mock was restored from the valid synthetic checkpoint saved before idempotency cases: 1 report, 1 task, 2 ended runs, 1 experience, no active run. The Studio personal sentinel remained `{"studio":{"locale":"en"},"sentinel":"persistence-case-73ba"}` and the Studio review key remained null. No app source was changed.
