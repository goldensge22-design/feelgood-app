# Detailed findings — Career Review browser run

## Pass: adult synthetic plan and execution

- Fixture v1 was loaded in a fresh isolated browser context.
- All required score/domain and five occupation ID/rank values were visible in original order.
- Recommended fixture-job-1 was selected. Required plan fields were filled and saved as revision 1.
- Save left the Start action available and did not create an active run.
- Explicit Start opened one run; Pause, Resume, and End were usable. The ended run retained task revision 1.

## Pass: actual experience and export safeguards

- Experience fields started blank and include controls were disabled until text was entered.
- Only two authored statements (`action`, `learning`) were selected. Other fields were blank/unselected.
- No export preview/download was available before confirmation.
- Preview and downloaded JSON contained only selected statements, local-file-only delivery, no external verification, user-confirmed-only verification, and source/run/task provenance. No full pass scores or memo were included.
- Download event filename: `nuvia-experience-52f014c3.json`.

## Pass: task revision behavior

- Editing the ended task's method created revision 2. Revision 1 remained intact in history; run still referenced revision 1.
- The earlier confirmation became stale and export was blocked.
- Reconfirmation appended a second history record; export payload held executed task version 1 and acknowledged version 2.

## Pass: source report version behavior

- Imported a v2 report with the same ID and modified source name. Both v1 and v2 were retained (visible report count 2), with v2 active.
- The non-canonical v2 source strings were displayed raw, not translated as if the report were the canonical fixture.
- Re-uploading modified content under the same ID/version was rejected; accepted v2 remained active and report count remained 2.
- Export was blocked while acknowledged report v1 differed from active v2. After explicit reconfirmation, JSON retained original report v1 and reconfirmed report v2, while the original run and task execution still referenced revision 1.

## Pass: blank no-result custom direction and Studio isolation

- In a separate isolated context, the no-result screen offered the own-career action and the existing general/youth links. The Studio links were not followed.
- The custom direction was selected by default; a custom name and required task details were saved successfully. Save did not start a run.
- Seeded Studio personal storage sentinel stayed byte-identical after the custom flow; Studio review storage remained null.

## Finding: mobile tab strip

At 360×800, the language selector was in the right side of the first header row and the brand on the second row. The page document width did not exceed viewport width, and the visible tab targets were 44px high. However, the five-tab strip is horizontally scrollable and only its first three tabs fit initially; Experience and Export are off-screen until the strip is scrolled.

## Unresolved coverage

The complete 225-case locale/viewport/tab matrix and all remaining in-scope browser checks have since passed. Native/physical language research remains outside browser verification; the earlier unidentified HTTP 404 and mobile tab-strip scroll limitation remain noted above. Timer recovery has a storage-normalization nuance: the UI recovers to Paused and excludes offline time, while the raw localStorage phase remains `running` until the next user action commits.

## Browser evidence references

`rzf9nm` blank desktop; `btbj5h` loaded fixture; `rtnbef` saved recommended task; `cp52ny` running; `yuzty3` paused; `b8g3sr` ended; `624hxo` new blank experience; `w435fl` export blocked before confirmation; `3v8cc7` confirmed JSON; `2g9nys` stale task revision; `nzjlkv` export blocked after revision; `hi45m5` confirmation history; `wg20rs` executed/acknowledged task-version JSON; `868291` report v2; `4afghf` rejected conflicting report; `s9dgtx` report-change export block; `1p5ew3` final export JSON; `8q6ut6` 768px; `iddc5f` 360px; `0dxhbl` blank custom entry; `wl4gz6` saved custom task.


## 15-locale visual/copy matrix continuation

All 225 locale × viewport × tab rows passed corrected checks at 360/768/1440px; each of 15 locales has 15 UI rows, 3 canonical fixture Result checks, and 15 no-unexpected-English-fallback scans. Exact details are in `matrix.json`. Checks included source-copy labels/placeholders, user/source string exemptions, Hangul exclusion from locale options, RTL direction, physical header-right alignment (Arabic included), document overflow, header/form overlap, and minimum 44px interactive target height.

## Persistence, timer, backup/restore, idempotency, keyboard, motion, and storage checks

- The conditional-seed context preserved a synthetic unsaved custom plan draft across locale changes `az → ar → ko → en` while a run stayed active; the `?qa=keep#timer` URL stayed unchanged and elapsed time advanced.
- Pause froze elapsed at 71,147ms across 2.5 seconds (`lastAt:null`); Resume advanced to 72,151ms. Reload recovered the same run in the UI as Paused at 82,151ms with no elapsed/offline delta; the UI remained frozen during a further 2.5 seconds. Raw storage remained `phase:"running"` with its previous `lastAt` until End committed an ended record at the same 82,151ms. A keyboard-started run paused with Space likewise held 68,885ms over 2.5 seconds.
- A real Save backup download produced `nuvia-career-review-backup-2026-10-23.json` (4,989 bytes; 1 report, 1 task, 2 runs, 1 experience). Restore preview matched those counts. Cancel closed the preview and the Career Review storage string was byte-identical to the exact pre-upload snapshot. Confirming a valid restore replaced a deliberately changed Arabic locale with the downloaded English state.
- Corrupt JSON and a backup with a missing `runs[0].taskId` were rejected as `invalidBackup` with “This backup cannot be read.” A valid-looking backup with a changed owner token was rejected as `wrongOwner` with “This backup belongs to another local profile.” Each invalid file yielded no preview and preserved raw review data and the local-owner token.
- Double-click checks were idempotent: Save increased task count 1→2 with one new Revision 1; Start increased run count 2→3 with one open run; Record experience increased experience count 1→2 with one record for the run; Confirm appended exactly one history entry (0→1) and disabled the confirmed control.
- Keyboard route: focus was seeded on the header’s native locale select, ArrowUp changed English to Korean, Tab traversed Result→Plan→Run, Enter activated Plan and Run, sequential Tab reached Start, and Enter started one run. Backward Tab reached Pause; Space paused it; Tab/Enter ended it. Reduced-motion emulation reported `transition:0s`, `animation:none`, `transform:none` on the backup button, including hover. `no-preference` was restored afterward.
- A page-only test shim made `localStorage.setItem` throw `QuotaExceededError` only for the Career Review key. The UI surfaced `storageError` (“Could not save in this browser.”), removed Saved status, and disabled Save backup; review bytes, local owner, and Studio sentinel remained unchanged. The native method was restored and reload returned to saved state.
- At the end, the browser was restored from the valid synthetic pre-idempotency checkpoint: 1 report, 1 task, 2 ended runs, 1 experience, no open run. The Studio sentinel remained `{"studio":{"locale":"en"},"sentinel":"persistence-case-73ba"}` and Studio review storage stayed null. No app source files were changed.

## Additional browser evidence

Timer recovery and paused UI: `rnbta8`, `ja2sgm`; restore preview/cancel: `orz5ei`, `ry15jt`; invalid backup rejections: `wn1x7a`, `kswc2g`, `chk614`; double-click task/run/experience/confirm: `p6wdgj`, `mdja7j`, `v9q6u9`, `7xtv2p`; keyboard Run controls: `xicm7x`, `uhokql`, `yx5vb0`; reduced-motion hover: `q0h01m`; quota failure and recovery: `7sgbmg`, `7sniys`; final restored checkpoint: `hbzvc4`.
