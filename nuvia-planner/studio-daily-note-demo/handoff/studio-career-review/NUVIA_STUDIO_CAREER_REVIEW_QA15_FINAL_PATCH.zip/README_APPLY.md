# NUVIA Studio 결과→직업→경험 검토 패치

검토 실행: /career-review.html (기존 Studio와 독립 저장소).
기준 로컬 커밋: 9dde34203ddc92c225c3420174a62b0bc6876c13
포장 시점 로컬 HEAD: 5bb9b1209f9aa717f39213cc25245eecb094322d
GitHub/공식 최신 서버 브랜치는 조회·검증하지 않았습니다.

## 구성
files/ 아래 신규 화면/모델/97키×15언어/검사/개발자 인계·QA 문서와
기존 vite.config.ts의 HTML 입력 한 줄 추가분이 있습니다.
PATCH.diff는 동일 변경의 unified diff이며 AFTER/BEFORE_SHA256.json으로 사전조건을 확인합니다.
PAYLOAD_SHA256SUMS.txt는 files/ 각 파일 해시입니다.
QA_EVIDENCE/는 실제 실행한 합성 브라우저 QA와 자동 검사 기록입니다.
환경 파일·비밀·사용자 백업/DB·의존성·캐시·빌드 결과·.git는 포함하지 않습니다.

## 안전 적용
먼저 별도 작업 브랜치를 만들고 인계 문서를 읽으세요. 스크립트는 Git에 접근하지 않습니다.
ZIP을 대상 저장소 밖에 풀고:

    python apply_review_patch.py --target /path/to/repository

기본은 읽기 전용 사전검사입니다. 신규 경로 충돌/기존 설정 해시 차이가 있으면 중단합니다.
개발자의 최신 연동 브랜치에서 해시가 다르면 강제 덮어쓰지 말고 수동 병합·재검수하세요.
검토 후 명시적으로 적용할 경우 새 외부 백업 경로를 지정합니다:

    python apply_review_patch.py --target /path/to/repository --apply --backup /outside/new-backup

원래 앱에서 사용한 pnpm 환경을 그대로 사용해 typecheck/build 및
node tools/nuvia-studio/run-career-review-check.mjs를 실행하세요.
PORT/BASE_PATH는 기존 서비스 설정대로 지정합니다.
이 ZIP은 전체 저장소/설치용 전체 소스가 아닌 추가형 패치입니다.
PATCH.diff에 git apply --check를 먼저 수행하는 대안도 있습니다.

## 되돌리기
별도 브랜치의 적용 전 커밋으로 되돌리는 방법을 우선합니다.
수동 복구는 AFTER 해시가 여전히 일치하는지 확인한 뒤, BEFORE=null인 추가 파일만 제거하고
기존 vite.config.ts를 외부 백업본에서 복구합니다. 사용자 후속 변경이 있으면 중단해 수동 대조하세요.
검토/기존 Studio의 localStorage를 자동 삭제하지 마세요.

## 실제 서버와 한계
공식 성인 결과지 TOP5 wire contract는 확보되지 않았습니다. 로컬 검토 어댑터이지 공식 연동 완료가 아닙니다.
직업 추천 순위/검사 점수는 계산하지 않습니다. 자소서 서버 전송·AI 생성·동기화는 없습니다.
사용자가 확인한 선택 문장만 로컬 소재로 내보냅니다. 외국어 신규 번역은 AI 초안입니다.
구체적인 검수/미검증/기존 경고는 files/docs/STUDIO_CAREER_REVIEW_QA.md를 보세요.
공개 재게시·main 병합·GitHub push는 하지 않았습니다.
