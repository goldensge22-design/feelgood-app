# 테스트 결과 보고서

생성일: 2026-07-14
실행 환경: Linux (Ubuntu, Python 3.12.3), ffmpeg 설치됨, Xvfb(가상 디스플레이)로 GUI 검증

## 1. 자동화 테스트 (pytest) 결과

```
53 passed, 1 warning in 5.53s
```

| 테스트 파일 | 항목 수 | 결과 | 커버 내용 |
|---|---|---|---|
| test_role_detector.py | 6 | ✅ | 파일명→Role 추출, alias 매핑, Narration→Narrator 규칙, Unknown 처리, Code 추출 |
| test_audio_scanner.py | 6 | ✅ | MP3/WAV 검색, Unknown 분류, 너무 짧은/손상 파일 처리, Role 그룹화, 원본 보존 |
| test_audio_processor.py | 7 | ✅ | 병합, 원본 보존, 짧은 파일 제외, 중복 제거, 손상 파일 비중단 처리, 무음제거/정규화/모노 변환 |
| test_clone_sample_builder.py | 2 | ✅ | Role별 샘플/매니페스트 생성, Unknown Role 스킵 |
| test_clone_quality_checker.py | 3 | ✅ | 샘플 없음/짧음/충분함 각각의 품질 판정 |
| test_elevenlabs_clone_service.py | 6 | ✅ | API Clone 성공/403 불가 안내/파일없음/네트워크 오류(모두 mock), Voice ID 검증 |
| test_elevenlabs_tts_service.py | 7 | ✅ | 언어별 폴더 저장, Voice ID 누락 처리, 기존 파일 스킵, dry-run, 우선순위 기반 Voice 조회, Speed 보정 |
| test_review_service.py | 6 | ✅ | 검수 상태 저장/복원, 재생성 대상 필터링, 동의 로그 기록/조회(최신값 우선) |
| test_spreadsheet_reader.py | 4 | ✅ | 레거시/신규 포맷 파싱, Code 매칭, 누락 파일 예외 |

## 2. 수동 통합(스모크) 테스트 - CLI

첨부된 실제 샘플 음성 5개(`data/korean_audio_sample/`)와 신규 포맷 샘플 스크립트
(`data/sample_script.csv`)로 파이프라인 전체를 실행하여 검증했습니다.

```
$ python cli.py scan --folder data/korean_audio_sample
총 5개 파일 스캔 완료 (Role 4개)
  - Darkmong: 2개 / Mole: 1개 / Narrator: 1개 / Piece: 1개

$ python cli.py build-samples --folder data/korean_audio_sample
4개 캐릭터의 Clone 샘플 생성 완료 (병합/정규화/무음제거 정상 동작 확인)

$ python cli.py check-quality
Role별 "사용 부적합"(샘플 길이 부족, 실제 대표 샘플이 몇 초 분량이므로 정상적 결과) 표시 확인

$ python cli.py register-voice --role Darkmong --voice-id TEST_VOICE_DARKMONG
Voice ID 저장 확인 (config/voice_config.json)

$ python cli.py generate --csv data/sample_script.csv --languages English,Thai --dry-run
생성 대상 10건 정상 계산, Dry-run으로 API 미호출 확인
```

## 3. 수동 통합(스모크) 테스트 - GUI

Linux + Xvfb 가상 디스플레이 환경에서 `gui.main_window.MainWindow` 를 생성하여
6개 페이지(project/korean_audio/clone_sample/voice_registration/generation/review)가
모두 예외 없이 생성되는 것을 확인했습니다.

```
GUI constructed OK, pages: ['project', 'korean_audio', 'clone_sample',
                             'voice_registration', 'generation', 'review']
```

## 4. 수동 검증이 필요한 항목 (실제 Windows 환경에서 확인 필요)

- `run.bat` / `build.bat` 실제 Windows 10/11에서의 실행 (본 환경은 Linux 샌드박스)
- PyInstaller로 빌드된 단일 EXE의 실제 배포/실행
- 실제 ElevenLabs 계정으로 API Voice Clone(방식 B) 성공 여부 (요금제에 따라 다름 - 계정
  권한이 없을 경우 방식 A로 자동 안내되는 로직은 mock 테스트로 검증 완료)
- 실제 247개 전체 음성 파일에서의 대용량 스캔/병합 성능

## 5. 알려진 제한 사항

- 다중 화자 혼입 감지는 정밀한 화자 분리 모델이 아닌 구간별 음량 편차 기반 휴리스틱이므로
  참고용 경고로만 활용해야 합니다.
- ElevenLabs API의 실제 요금제/쿼터에 따라 Voice Clone API(POST /v1/voices/add) 가능 여부가
  달라지므로, 실제 계정으로 최종 검증이 필요합니다.
