@echo off
REM ============================================
REM K-PASS Voice Generator - Windows EXE 빌드 스크립트
REM PyInstaller를 사용하여 app.py 를 단일 실행파일(exe)로 빌드합니다.
REM ============================================
setlocal

cd /d "%~dp0"

if not exist ".venv" (
    echo [INFO] 가상환경이 없어 새로 생성합니다...
    python -m venv .venv
)

call .venv\Scripts\activate.bat

echo [INFO] 필요한 패키지를 설치/업데이트합니다...
pip install -r requirements.txt

echo [INFO] PyInstaller로 EXE 빌드를 시작합니다...
pyinstaller --noconfirm --onefile --windowed ^
    --name "KPASS_VoiceGenerator" ^
    --add-data "config;config" ^
    --add-data "data;data" ^
    app.py

echo.
echo [완료] dist\KPASS_VoiceGenerator.exe 파일이 생성되었습니다.
echo [안내] 배포 시 .env.example, README.md, 사용자 매뉴얼도 함께 전달하세요.
pause
