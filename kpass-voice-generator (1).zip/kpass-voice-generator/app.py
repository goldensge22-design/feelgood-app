#!/usr/bin/env python3
"""
app.py
======
K-PASS 다국어 Voice Clone 생성기 - GUI 실행 진입점.

사용법:
    python app.py

CLI로 실행하려면 cli.py 를 사용하세요:
    python cli.py --help
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))


def main() -> None:
    try:
        from gui.main_window import run_app
    except ImportError as exc:
        print("[오류] GUI 실행에 필요한 모듈을 불러올 수 없습니다.")
        print(f"       {exc}")
        print("       requirements.txt 의 패키지가 설치되어 있는지 확인하세요: pip install -r requirements.txt")
        sys.exit(1)

    run_app()


if __name__ == "__main__":
    main()
