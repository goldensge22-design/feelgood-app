# 개발자 매뉴얼 - K-PASS 다국어 Voice Clone 생성기

## 1. 프로젝트 구조

```
kpass-voice-generator/
├── app.py                     # GUI 실행 진입점
├── cli.py                     # CLI 실행 진입점 (신규 Voice Clone 파이프라인)
├── legacy_generate_voice.py   # 기존 고정 Voice 방식 CLI (그대로 유지)
├── legacy_config.py           # 기존 CLI가 사용하는 설정 모듈 (그대로 유지)
├── legacy_list_voices.py      # 기존 Voice 목록 조회 스크립트 (그대로 유지)
├── sample_legacy.csv          # 기존 CLI용 샘플 CSV
├── gui/
│   ├── app_state.py           # 6단계 위저드가 공유하는 상태(AppState)
│   ├── main_window.py         # ttk.Notebook 기반 메인 윈도우/컨트롤러
│   ├── project_page.py        # 1단계
│   ├── korean_audio_page.py   # 2단계
│   ├── clone_sample_page.py   # 3단계
│   ├── voice_registration_page.py  # 4단계
│   ├── generation_page.py     # 5단계
│   └── review_page.py         # 6단계
├── services/
│   ├── role_detector.py           # 파일명 -> Role 추출 (alias 매핑 지원)
│   ├── audio_scanner.py           # 폴더 스캔, 길이 계산, 상태 판정 (원본 미변경)
│   ├── audio_processor.py         # 무음제거/정규화/모노/리샘플/병합/중복제거
│   ├── clone_sample_builder.py    # Role별 샘플 생성 + manifest.json 작성
│   ├── clone_quality_checker.py   # Clone 샘플 품질 판정 (사용 가능/보완 권장/부적합)
│   ├── elevenlabs_clone_service.py# Voice Clone 생성 (수동 확인 + API 방식), 실패해도 비중단
│   ├── elevenlabs_tts_service.py  # 다국어 TTS 생성, 우선순위 기반 Voice ID 조회, 속도 보정
│   ├── voice_config_manager.py    # config/voice_config.json 로드/저장/우선순위 해석
│   ├── spreadsheet_reader.py      # 레거시/신규 CSV·XLSX 자동 감지 및 파싱
│   ├── review_service.py          # 검수 상태 저장, Voice Clone 동의 로그
│   └── app_settings.py            # .env/settings.json 로드, API Key 마스킹, 임시파일 정리
├── config/
│   ├── voice_config.json      # Role/언어별 Voice ID 매핑 (예시)
│   ├── role_mapping.json      # Role 별칭(alias) 매핑 (예시)
│   └── settings.json          # 폴더 경로, 재시도 정책, 로그 노출 정책
├── data/
│   ├── korean_audio_sample/   # 개발/테스트용 대표 샘플 (실제 247개 파일 불필요)
│   ├── voice_clone_samples/   # (레거시 호환용 빈 폴더)
│   ├── voice_clone_ready/     # 병합된 Clone Sample(.wav) 출력 위치
│   ├── manifests/             # <Role>_clone_manifest.json 출력 위치
│   └── sample_script.csv      # 개발/테스트용 신규 와이드 포맷 샘플 번역 스크립트
├── output/                    # 언어별 생성 결과 (<언어>/<Code>.mp3)
├── logs/                      # generate.log, scan_report.json, consent_log.json, review_state.json
├── tests/                     # pytest 테스트 (53개)
├── requirements.txt
├── .env.example
├── run.bat / build.bat
└── README.md / DEVELOPER.md
```

## 2. 아키텍처 원칙

1. **원본 불변성**: `services/audio_scanner.py`, `services/audio_processor.py` 는
   어떤 경우에도 원본 한국어 음성 파일을 열기(읽기) 전용으로만 다룹니다. 병합/가공 결과는
   항상 `data/voice_clone_ready/` 등 별도 경로에 새로 씁니다.
2. **API 실패 격리**: `elevenlabs_clone_service.create_voice_clone_via_api()` 는 모든
   예외(`requests.exceptions.RequestException`, HTTP 4xx 등)를 잡아 `CloneApiResult`로
   반환하므로, 계정 권한/요금제 문제로 API Clone이 불가능해도 프로그램 전체가 죽지 않습니다.
3. **Voice ID 우선순위**: `voice_config_manager.VoiceConfig.resolve_voice_id(role, language)`
   가 "언어별 Role Voice ID > 공통 Role Voice ID > 언어 기본 Voice ID > 전체 기본 Voice ID"
   순서로 조회합니다. GUI/CLI 모두 이 함수를 통해서만 Voice ID를 가져옵니다.
4. **레거시 호환**: 기존 `generate_voice.py`/`config.py`/`list_voices.py` 는 각각
   `legacy_generate_voice.py`/`legacy_config.py`/`legacy_list_voices.py` 로 이름만 바꿔
   그대로 보존했습니다 (신규 `config/` 폴더와 이름 충돌을 피하기 위함). 동작 방식은
   전혀 변경하지 않았습니다.
5. **동의 없는 Clone 차단**: GUI의 `voice_registration_page.py` 는 `consent_var` 가
   체크되지 않으면 Voice Clone 관련 버튼 로직(`_require_role_and_consent`)에서 즉시
   경고를 띄우고 실행을 막습니다. 동의 여부/시각은 `review_service.record_consent()` 로
   `logs/consent_log.json` 에 append 방식으로 기록됩니다.

## 3. 데이터 흐름

```
한국어 음성 폴더
   │  scan_korean_audio_folder()
   ▼
ScannedAudioFile[] ──(role_detector)──> Role별 그룹
   │  build_all_clone_samples()
   ▼
data/voice_clone_ready/<Role>_clone_sample.wav
data/manifests/<Role>_clone_manifest.json
   │  check_role_sample_quality()
   ▼
품질 리포트 (사용 가능 / 보완 권장 / 사용 부적합)
   │  (사용자가 ElevenLabs 웹사이트 업로드 OR API Clone 시도)
   ▼
config/voice_config.json 에 Voice ID 저장
   │  spreadsheet_reader.load_dialogue_entries() + build_tasks_from_entries()
   ▼
TtsGenerationTask[] (code, role, language, text, voice_id)
   │  generate_task() -> ElevenLabs TTS API
   ▼
output/<Language>/<Code>.mp3
   │  review_service.ReviewStore
   ▼
검수 상태(logs/review_state.json) - 승인 / 재생성 필요 / 메모
```

## 4. 테스트

```bash
pip install -r requirements.txt
pytest tests/ -v
```

53개 테스트가 다음 항목을 커버합니다 (상세 결과는 `TEST_REPORT.md` 참고):
- MP3/WAV 파일 검색, Role 자동 추출/별칭 매핑, Unknown 처리
- 동일 Role 음성 병합, 원본 파일 보존, 정규화/무음 제거/중복 제거/손상 파일 처리
- Code-스프레드시트 매칭 (레거시/신규 포맷), Voice ID 등록/우선순위/누락 처리
- API Voice Clone 불가 시 비중단 처리 (mock 기반)
- TTS 생성(mock), 언어별 폴더 저장, 한국어-외국어 길이 비교, Speed 보정
- 검수 상태 저장/복원, 재생성 대상 필터링, 동의 로그 기록/조회

**Windows 실행 테스트**: 본 개발 환경은 Linux 샌드박스이므로 `run.bat`/`build.bat`는
실제 Windows에서 별도로 검증이 필요합니다 (`TEST_REPORT.md` 의 "수동 검증 필요" 항목 참고).
GUI는 Linux + Xvfb(가상 디스플레이) 환경에서 6개 페이지 모두 정상 생성되는 것을 확인했습니다.

## 5. 확장 포인트

- **신규 언어 추가**: `services/spreadsheet_reader.KNOWN_LANGUAGE_COLUMNS` 에 언어명을
  추가하거나, 스프레드시트에 새 언어 컬럼을 추가하면 별도 코드 수정 없이 자동 인식됩니다
  (Code/Role/Korean/Voice* 를 제외한 컬럼은 모두 언어로 간주).
- **화자 분리/노이즈 판정 고도화**: 현재 `clone_quality_checker.py` 의 다중 화자 감지는
  구간별 dBFS 편차 기반 휴리스틱입니다. 정밀한 판정이 필요하면 별도 화자 분리 모델(예:
  pyannote.audio)을 연동하는 모듈을 `services/` 에 추가하고 `check_role_sample_quality()`
  에서 호출하도록 확장하세요.
- **다른 TTS 프로바이더 지원**: `elevenlabs_tts_service.py` 의 `request_tts_audio()` 를
  프로바이더 인터페이스로 추상화하면 다른 TTS 서비스도 쉽게 추가할 수 있습니다.
