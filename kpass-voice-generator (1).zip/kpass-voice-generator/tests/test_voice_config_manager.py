from __future__ import annotations

from services.voice_config_manager import VoiceConfig, load_voice_config, save_voice_config


def test_priority_language_specific_role_voice_id():
    config = VoiceConfig(
        default_voice_id="DEFAULT",
        language_default_voice_id={"English": "LANG_DEFAULT_EN"},
        roles={"Darkmong": {"voice_id": "ROLE_COMMON", "language_voice_id": {"English": "ROLE_EN"}}},
    )
    assert config.resolve_voice_id("Darkmong", "English") == "ROLE_EN"


def test_priority_falls_back_to_common_role_voice_id():
    config = VoiceConfig(roles={"Darkmong": {"voice_id": "ROLE_COMMON", "language_voice_id": {}}})
    assert config.resolve_voice_id("Darkmong", "Thai") == "ROLE_COMMON"


def test_priority_falls_back_to_language_default():
    config = VoiceConfig(language_default_voice_id={"Thai": "LANG_DEFAULT_TH"}, roles={})
    assert config.resolve_voice_id("Unknown", "Thai") == "LANG_DEFAULT_TH"


def test_priority_falls_back_to_overall_default():
    config = VoiceConfig(default_voice_id="GLOBAL")
    assert config.resolve_voice_id("NoRole", "NoLang") == "GLOBAL"


def test_missing_voice_id_returns_none():
    config = VoiceConfig()
    assert config.resolve_voice_id("NoRole", "NoLang") is None


def test_save_and_load_roundtrip(tmp_path):
    path = tmp_path / "voice_config.json"
    config = VoiceConfig(default_voice_id="X")
    config.upsert_role("Darkmong", voice_id="ABC", sample_file="a.wav")
    save_voice_config(config, path)

    loaded = load_voice_config(path)
    assert loaded.default_voice_id == "X"
    assert loaded.roles["Darkmong"]["voice_id"] == "ABC"
