from __future__ import annotations

from services.spreadsheet_reader import load_dialogue_entries


def test_legacy_format_groups_by_code(tmp_path):
    csv_path = tmp_path / "legacy.csv"
    csv_path.write_text(
        "Code,Language,Voice,Text\n"
        "Intro.Darkmong.One,Thai,Adam,สวัสดี\n"
        "Intro.Darkmong.One,English,Adam,Hello\n"
        "Intro.Darkmong.One,Korean,Adam,안녕\n",
        encoding="utf-8",
    )
    entries = load_dialogue_entries(csv_path)
    assert len(entries) == 1
    entry = entries[0]
    assert entry.korean_text == "안녕"
    assert entry.translations["Thai"] == "สวัสดี"
    assert entry.translations["English"] == "Hello"


def test_wide_format_parses_role_and_languages(tmp_path):
    csv_path = tmp_path / "wide.csv"
    csv_path.write_text(
        "Code,Role,Korean,Thai,English\n"
        "Intro.Darkmong.One,Darkmong,저 아이가 마지막 조각을 가지고 있구나.,"
        "เด็กคนนั้นมีชิ้นส่วนสุดท้าย,That child has the final piece.\n",
        encoding="utf-8",
    )
    entries = load_dialogue_entries(csv_path)
    assert len(entries) == 1
    entry = entries[0]
    assert entry.role == "Darkmong"
    assert entry.translations["English"] == "That child has the final piece."


def test_code_matching_with_korean_audio_index(tmp_path):
    csv_path = tmp_path / "wide.csv"
    csv_path.write_text(
        "Code,Role,Korean,English\nIntro.Max.One,Max,안녕,Hello\n",
        encoding="utf-8",
    )
    entries = load_dialogue_entries(csv_path)
    korean_index = {"Intro.Max.One": "/fake/path/Intro.Max.One.mp3"}
    assert entries[0].code in korean_index


def test_missing_file_raises():
    import pytest

    with pytest.raises(FileNotFoundError):
        load_dialogue_entries("/no/such/file.csv")
