from __future__ import annotations

from pydub import AudioSegment

from services.audio_processor import merge_role_samples, normalize_volume, remove_silence, to_mono


def test_merge_produces_wav_and_preserves_originals(tmp_path, make_wav):
    f1 = make_wav("a.wav", duration_ms=1500)
    f2 = make_wav("b.wav", duration_ms=1500)
    original_1 = f1.read_bytes()
    original_2 = f2.read_bytes()

    output_path = tmp_path / "out" / "Role_clone_sample.wav"
    result = merge_role_samples("Role", [f1, f2], output_path)

    assert result.output_path is not None
    assert output_path.exists()
    assert result.total_duration_seconds > 0
    # 원본 보존 확인
    assert f1.read_bytes() == original_1
    assert f2.read_bytes() == original_2


def test_merge_excludes_too_short_file(tmp_path, make_wav):
    f1 = make_wav("a.wav", duration_ms=1500)
    f2 = make_wav("tiny.wav", duration_ms=100)

    result = merge_role_samples("Role", [f1, f2], tmp_path / "out.wav", min_file_seconds=0.5)
    assert len(result.used_files) == 1
    assert len(result.excluded_files) == 1


def test_merge_deduplicates_identical_files(tmp_path, make_wav):
    f1 = make_wav("a.wav", duration_ms=1500)
    # 동일 파일 복사본 (동일 바이트) -> 중복으로 제외되어야 함
    f2 = tmp_path / "a_copy.wav"
    f2.write_bytes(f1.read_bytes())

    result = merge_role_samples("Role", [f1, f2], tmp_path / "out" / "sample.wav")
    assert len(result.used_files) == 1
    assert any("중복" in reason for _, reason in result.excluded_files)


def test_merge_handles_corrupt_file_without_crash(tmp_path, make_wav):
    f1 = make_wav("a.wav", duration_ms=1500)
    corrupt = tmp_path / "corrupt.wav"
    corrupt.write_bytes(b"not a real wav file")

    result = merge_role_samples("Role", [f1, corrupt], tmp_path / "out.wav")
    assert len(result.used_files) == 1
    assert len(result.excluded_files) == 1


def test_remove_silence_shrinks_or_keeps_length():
    silent = AudioSegment.silent(duration=3000)
    trimmed = remove_silence(silent)
    # 완전 무음은 그대로 유지하는 안전장치가 있어야 함(과도 삭제 방지)
    assert len(trimmed) >= 0


def test_normalize_volume_changes_gain():
    from pydub.generators import Sine

    seg = Sine(440).to_audio_segment(duration=1000).apply_gain(-30)
    normalized = normalize_volume(seg, target_dbfs=-20.0)
    assert abs(normalized.dBFS - (-20.0)) < 1.0


def test_to_mono_converts_channels():
    from pydub.generators import Sine

    seg = Sine(440).to_audio_segment(duration=500)
    stereo = AudioSegment.from_mono_audiosegments(seg, seg)
    assert stereo.channels == 2
    mono = to_mono(stereo)
    assert mono.channels == 1
