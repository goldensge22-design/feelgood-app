from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest
from pydub import AudioSegment
from pydub.generators import Sine


@pytest.fixture
def make_wav(tmp_path):
    """지정한 길이(ms)의 사인파 WAV 파일을 만들어 경로를 반환하는 팩토리 픽스처."""

    def _make(name: str, duration_ms: int = 2000, freq: int = 440, silent: bool = False) -> Path:
        if silent:
            seg = AudioSegment.silent(duration=duration_ms)
        else:
            seg = Sine(freq).to_audio_segment(duration=duration_ms).apply_gain(-10)
        path = tmp_path / name
        seg.export(str(path), format="wav")
        return path

    return _make
