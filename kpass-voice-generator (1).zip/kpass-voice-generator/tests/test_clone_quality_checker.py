from __future__ import annotations

from pydub.generators import Sine

from services.clone_quality_checker import check_role_sample_quality


def test_missing_sample_is_unusable(tmp_path):
    report = check_role_sample_quality("Darkmong", tmp_path / "missing.wav", 0, 0)
    assert report.status == "사용 부적합"


def test_short_sample_flagged_unusable(tmp_path):
    path = tmp_path / "short.wav"
    Sine(440).to_audio_segment(duration=3000).export(str(path), format="wav")
    report = check_role_sample_quality("Darkmong", path, used_file_count=1, excluded_file_count=0)
    assert report.status == "사용 부적합"
    assert report.total_duration_seconds < 60


def test_long_clean_sample_usable(tmp_path):
    path = tmp_path / "long.wav"
    Sine(440).to_audio_segment(duration=65000).apply_gain(-15).export(str(path), format="wav")
    report = check_role_sample_quality("Darkmong", path, used_file_count=5, excluded_file_count=0)
    assert report.status in ("사용 가능", "보완 권장")
