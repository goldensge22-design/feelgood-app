from __future__ import annotations

from services.audio_scanner import group_by_role, scan_korean_audio_folder


def test_scan_finds_mp3_and_wav(tmp_path, make_wav):
    make_wav("Intro.Darkmong.One.wav", duration_ms=2000)
    make_wav("Intro.Crow.One.wav", duration_ms=2500)

    files = scan_korean_audio_folder(tmp_path)
    names = {f.file_name for f in files}
    assert "Intro.Darkmong.One.wav" in names
    assert "Intro.Crow.One.wav" in names


def test_scan_flags_unknown_role(tmp_path, make_wav):
    make_wav("randomfile123.wav", duration_ms=1500)
    files = scan_korean_audio_folder(tmp_path)
    assert len(files) == 1


def test_scan_flags_too_short_file(tmp_path, make_wav):
    make_wav("Intro.Max.One.wav", duration_ms=100)  # 0.1초
    files = scan_korean_audio_folder(tmp_path, min_duration_seconds=0.3)
    assert files[0].status == "too_short"
    assert files[0].excluded is True


def test_scan_flags_corrupt_zero_byte_file(tmp_path):
    bad = tmp_path / "Intro.Max.Two.mp3"
    bad.write_bytes(b"")
    files = scan_korean_audio_folder(tmp_path)
    assert files[0].status == "corrupt"
    assert files[0].excluded is True


def test_group_by_role(tmp_path, make_wav):
    make_wav("Intro.Darkmong.One.wav", duration_ms=2000)
    make_wav("Intro.Darkmong.Two.wav", duration_ms=2000)
    make_wav("Intro.Crow.One.wav", duration_ms=2000)

    files = scan_korean_audio_folder(tmp_path)
    groups = group_by_role(files)
    assert len(groups["Darkmong"]) == 2
    assert len(groups["Crow"]) == 1


def test_original_files_untouched(tmp_path, make_wav):
    path = make_wav("Intro.Max.One.wav", duration_ms=2000)
    original_bytes = path.read_bytes()
    scan_korean_audio_folder(tmp_path)
    assert path.read_bytes() == original_bytes
