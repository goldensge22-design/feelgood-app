from __future__ import annotations

from services.audio_scanner import group_by_role, scan_korean_audio_folder
from services.clone_sample_builder import build_all_clone_samples, build_clone_sample_for_role


def test_build_clone_sample_for_role(tmp_path, make_wav):
    audio_dir = tmp_path / "korean_audio"
    audio_dir.mkdir()
    make_wav("Intro.Darkmong.One.wav", duration_ms=2000)
    make_wav("Intro.Darkmong.Two.wav", duration_ms=2000)

    # make_wav writes into tmp_path (the fixture's own tmp_path), so re-create directly here
    from pydub.generators import Sine

    for i, name in enumerate(["Intro.Darkmong.One.wav", "Intro.Darkmong.Two.wav"]):
        seg = Sine(440 + i * 20).to_audio_segment(duration=2000).apply_gain(-10)
        seg.export(str(audio_dir / name), format="wav")

    files = scan_korean_audio_folder(audio_dir)
    groups = group_by_role(files)

    manifest = build_clone_sample_for_role(
        "Darkmong", groups["Darkmong"], tmp_path / "ready", tmp_path / "manifests"
    )

    assert manifest["role"] == "Darkmong"
    assert manifest["output_sample_path"] is not None
    assert (tmp_path / "manifests" / "Darkmong_clone_manifest.json").exists()


def test_build_all_clone_samples_skips_unknown(tmp_path):
    from pydub.generators import Sine

    audio_dir = tmp_path / "korean_audio"
    audio_dir.mkdir()
    Sine(440).to_audio_segment(duration=2000).export(str(audio_dir / "randomfile.wav"), format="wav")
    Sine(440).to_audio_segment(duration=2000).export(str(audio_dir / "Intro.Crow.One.wav"), format="wav")

    files = scan_korean_audio_folder(audio_dir)
    groups = group_by_role(files)

    results = build_all_clone_samples(groups, tmp_path / "ready", tmp_path / "manifests")
    assert "Crow" in results
    assert "Unknown" not in results
