from __future__ import annotations

from services.role_detector import build_code_from_filename, detect_role_from_filename


def test_role_extraction_standard_pattern():
    r = detect_role_from_filename("Intro.Darkmong.One.mp3")
    assert r.role == "Darkmong"
    assert r.category == "Intro"
    assert not r.is_unknown


def test_role_extraction_crow():
    r = detect_role_from_filename("Intro.Crow.One.mp3")
    assert r.role == "Crow"


def test_narration_maps_to_narrator():
    r = detect_role_from_filename("Narration.Intro.One.mp3")
    assert r.role == "Narrator"
    assert not r.is_unknown


def test_alias_mapping_normalizes_role(tmp_path):
    import json

    mapping_path = tmp_path / "role_mapping.json"
    mapping_path.write_text(json.dumps({"Linky": ["Linky", "Linkey", "Lingky"]}), encoding="utf-8")

    from services.role_detector import load_role_mapping

    mapping = load_role_mapping(mapping_path)
    r = detect_role_from_filename("Intro.Linkey.One.mp3", mapping)
    assert r.role == "Linky"


def test_unknown_role_for_empty_filename():
    r = detect_role_from_filename("")
    assert r.is_unknown


def test_build_code_from_filename_strips_extension():
    assert build_code_from_filename("Intro.Darkmong.One.mp3") == "Intro.Darkmong.One"
