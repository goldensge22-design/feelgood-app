from __future__ import annotations

from services.review_service import ReviewStore, has_valid_consent, record_consent


def test_review_store_set_and_get_status(tmp_path):
    store = ReviewStore(tmp_path / "review.json")
    store.set_status("Intro.Darkmong.One", "English", "Darkmong", "approved", "good take")
    entry = store.get_status("Intro.Darkmong.One", "English")
    assert entry.status == "approved"
    assert entry.note == "good take"


def test_review_store_persists_across_instances(tmp_path):
    path = tmp_path / "review.json"
    store1 = ReviewStore(path)
    store1.set_status("C1", "Thai", "Max", "needs_regeneration")

    store2 = ReviewStore(path)
    entry = store2.get_status("C1", "Thai")
    assert entry.status == "needs_regeneration"


def test_failed_or_pending_filters_correctly(tmp_path):
    store = ReviewStore(tmp_path / "review.json")
    store.set_status("C1", "English", "Max", "approved")
    store.set_status("C2", "English", "Max", "needs_regeneration")
    store.set_status("C3", "English", "Max", "pending")

    pending = store.failed_or_pending()
    codes = {e.code for e in pending}
    assert codes == {"C2", "C3"}


def test_consent_recorded_and_checked(tmp_path):
    record_consent(tmp_path, "Darkmong", True)
    assert has_valid_consent(tmp_path, "Darkmong") is True


def test_consent_false_blocks_usage(tmp_path):
    record_consent(tmp_path, "Darkmong", False)
    assert has_valid_consent(tmp_path, "Darkmong") is False


def test_consent_uses_latest_record(tmp_path):
    record_consent(tmp_path, "Darkmong", True)
    record_consent(tmp_path, "Darkmong", False)
    assert has_valid_consent(tmp_path, "Darkmong") is False
