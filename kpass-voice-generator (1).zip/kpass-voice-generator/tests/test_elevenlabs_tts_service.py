from __future__ import annotations

from services import elevenlabs_tts_service as svc
from services.voice_config_manager import VoiceConfig


class FakeResponse:
    def __init__(self, status_code: int, content: bytes = b"", json_data=None, text: str = ""):
        self.status_code = status_code
        self.content = content
        self._json_data = json_data or {}
        self.text = text

    def json(self):
        return self._json_data


def test_generate_task_creates_language_folder(tmp_path, monkeypatch):
    def fake_post(url, headers=None, json=None, timeout=None):
        return FakeResponse(200, content=b"FAKE_MP3_BYTES")

    monkeypatch.setattr(svc.requests, "post", fake_post)

    task = svc.TtsGenerationTask(code="Intro.Darkmong.One", role="Darkmong", language="English",
                                  text="Hello", voice_id="vid_123")
    result = svc.generate_task("api-key", task, tmp_path)

    assert result.success is True
    out_path = tmp_path / "English" / "Intro.Darkmong.One.mp3"
    assert out_path.exists()
    assert out_path.read_bytes() == b"FAKE_MP3_BYTES"


def test_generate_task_missing_voice_id_fails(tmp_path):
    task = svc.TtsGenerationTask(code="X", role="Unknown", language="English", text="Hi", voice_id=None)
    result = svc.generate_task("api-key", task, tmp_path)
    assert result.success is False
    assert "Voice ID" in result.error


def test_generate_task_skips_existing_file(tmp_path):
    lang_dir = tmp_path / "English"
    lang_dir.mkdir()
    (lang_dir / "X.mp3").write_bytes(b"already there")

    task = svc.TtsGenerationTask(code="X", role="Role", language="English", text="Hi", voice_id="vid")
    result = svc.generate_task("api-key", task, tmp_path, skip_existing=True)
    assert result.success is True
    assert "SKIP" in result.error


def test_dry_run_does_not_call_api(tmp_path, monkeypatch):
    called = {"count": 0}

    def fake_post(*args, **kwargs):
        called["count"] += 1
        return FakeResponse(200, content=b"x")

    monkeypatch.setattr(svc.requests, "post", fake_post)
    task = svc.TtsGenerationTask(code="X", role="Role", language="English", text="Hi", voice_id="vid")
    result = svc.generate_task("api-key", task, tmp_path, dry_run=True)
    assert result.success is True
    assert called["count"] == 0


def test_build_tasks_from_entries_uses_voice_config_priority():
    from services.spreadsheet_reader import DialogueEntry

    entries = [DialogueEntry(code="C1", role="Darkmong", korean_text="안녕", translations={"English": "Hi", "Thai": "สวัสดี"})]
    config = VoiceConfig(roles={"Darkmong": {"voice_id": "ROLE_VOICE"}})
    tasks = svc.build_tasks_from_entries(entries, config, ["English", "Thai"])
    assert len(tasks) == 2
    assert all(t.voice_id == "ROLE_VOICE" for t in tasks)


def test_suggest_speed_natural_mode_keeps_current_speed():
    result = svc.suggest_speed_for_target_length(5.0, 6.0, current_speed=1.0, mode="natural")
    assert result["suggested_speed"] == 1.0


def test_suggest_speed_clamped_within_bounds():
    result = svc.suggest_speed_for_target_length(10.0, 2.0, current_speed=1.0, mode="match_korean")
    assert svc.SPEED_ADJUST_MIN <= result["suggested_speed"] <= svc.SPEED_ADJUST_MAX
