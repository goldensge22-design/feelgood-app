from __future__ import annotations

from types import SimpleNamespace

from services import elevenlabs_clone_service as svc


class FakeResponse:
    def __init__(self, status_code: int, json_data=None, text: str = ""):
        self.status_code = status_code
        self._json_data = json_data or {}
        self.text = text

    def json(self):
        return self._json_data


def test_create_voice_clone_via_api_success(tmp_path, monkeypatch):
    sample = tmp_path / "sample.wav"
    sample.write_bytes(b"RIFF....WAVEfmt ")

    def fake_post(url, headers=None, data=None, files=None, timeout=None):
        return FakeResponse(200, {"voice_id": "vid_123"})

    monkeypatch.setattr(svc.requests, "post", fake_post)
    result = svc.create_voice_clone_via_api("api-key", "Darkmong", sample)
    assert result.success is True
    assert result.voice_id == "vid_123"


def test_create_voice_clone_via_api_unavailable_403(tmp_path, monkeypatch):
    sample = tmp_path / "sample.wav"
    sample.write_bytes(b"RIFF....WAVEfmt ")

    def fake_post(url, headers=None, data=None, files=None, timeout=None):
        return FakeResponse(403, {}, "forbidden")

    monkeypatch.setattr(svc.requests, "post", fake_post)
    result = svc.create_voice_clone_via_api("api-key", "Darkmong", sample)
    assert result.success is False
    assert "지원되지 않습니다" in result.message


def test_create_voice_clone_via_api_missing_file():
    result = svc.create_voice_clone_via_api("api-key", "Darkmong", "/no/such/file.wav")
    assert result.success is False
    assert "찾을 수 없습니다" in result.message


def test_create_voice_clone_via_api_network_error(tmp_path, monkeypatch):
    sample = tmp_path / "sample.wav"
    sample.write_bytes(b"RIFF....WAVEfmt ")

    def fake_post(*args, **kwargs):
        raise svc.requests.exceptions.RequestException("boom")

    monkeypatch.setattr(svc.requests, "post", fake_post)
    result = svc.create_voice_clone_via_api("api-key", "Darkmong", sample)
    assert result.success is False
    assert "네트워크 오류" in result.message


def test_verify_voice_id_valid(monkeypatch):
    def fake_get(url, headers=None, timeout=None):
        return FakeResponse(200, {"name": "Darkmong Clone"})

    monkeypatch.setattr(svc.requests, "get", fake_get)
    result = svc.verify_voice_id("api-key", "vid_123")
    assert result.valid is True
    assert result.name == "Darkmong Clone"


def test_verify_voice_id_not_found(monkeypatch):
    def fake_get(url, headers=None, timeout=None):
        return FakeResponse(404)

    monkeypatch.setattr(svc.requests, "get", fake_get)
    result = svc.verify_voice_id("api-key", "vid_missing")
    assert result.valid is False
