#!/usr/bin/env python3
"""
cli.py
======
K-PASS 다국어 Voice Clone 생성기 - CLI.

기존 legacy_generate_voice.py(고정 Voice 이름 기반)의 기능은 그대로 유지되며,
이 CLI는 새로 추가된 Voice Clone 파이프라인(스캔 -> 샘플 생성 -> 등록 -> 다국어 생성)을
GUI 없이 커맨드라인에서 실행할 수 있도록 제공한다.

사용법:
    python cli.py scan --folder korean_audio
    python cli.py build-samples --folder korean_audio
    python cli.py check-quality
    python cli.py register-voice --role Darkmong --voice-id XXXXX
    python cli.py generate --csv script.xlsx --languages English,Thai --dry-run
    python cli.py generate --csv script.xlsx --languages English,Thai
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from services.app_settings import load_app_settings
from services.audio_scanner import group_by_role, save_scan_report, scan_korean_audio_folder
from services.clone_quality_checker import check_role_sample_quality
from services.clone_sample_builder import build_all_clone_samples
from services.elevenlabs_tts_service import (
    TtsVoiceSettings,
    build_tasks_from_entries,
    generate_task,
)
from services.spreadsheet_reader import load_dialogue_entries
from services.voice_config_manager import load_voice_config, save_voice_config


def cmd_scan(args: argparse.Namespace) -> None:
    settings = load_app_settings()
    files = scan_korean_audio_folder(Path(args.folder))
    save_scan_report(files, settings.log_folder / "scan_report.json")

    groups = group_by_role(files)
    print(f"총 {len(files)}개 파일 스캔 완료 (Role {len(groups)}개)")
    for role, items in sorted(groups.items()):
        print(f"  - {role}: {len(items)}개")
    print(f"\n상세 결과: {settings.log_folder / 'scan_report.json'}")


def cmd_build_samples(args: argparse.Namespace) -> None:
    settings = load_app_settings()
    files = scan_korean_audio_folder(Path(args.folder))
    groups = group_by_role(files)
    manifests = build_all_clone_samples(groups, settings.voice_clone_ready_folder, settings.manifest_folder)

    print(f"{len(manifests)}개 캐릭터의 Clone 샘플 생성 완료:")
    for role, manifest in manifests.items():
        print(f"  - {role}: {manifest['total_duration_seconds']}초 (사용 {len(manifest['source_files'])} / 제외 {len(manifest['excluded_files'])})")
        report = check_role_sample_quality(
            role, manifest.get("output_sample_path"), len(manifest["source_files"]), len(manifest["excluded_files"])
        )
        print(f"    품질: {report.status} - {'; '.join(report.messages)}")


def cmd_check_quality(args: argparse.Namespace) -> None:
    settings = load_app_settings()
    ready_dir = settings.voice_clone_ready_folder
    if not ready_dir.exists():
        print("먼저 build-samples 를 실행하세요.")
        return
    for wav_path in sorted(ready_dir.glob("*_clone_sample.wav")):
        role = wav_path.stem.replace("_clone_sample", "")
        report = check_role_sample_quality(role, wav_path, used_file_count=0, excluded_file_count=0)
        print(f"[{role}] {report.status} - 길이 {report.total_duration_seconds}초")
        for m in report.messages:
            print(f"    - {m}")


def cmd_register_voice(args: argparse.Namespace) -> None:
    config = load_voice_config()
    config.upsert_role(args.role, voice_id=args.voice_id, sample_file=args.sample_file or "")
    if args.language:
        config.set_language_voice_id(args.role, args.language, args.voice_id)
    save_voice_config(config)
    print(f"[{args.role}] Voice ID 등록 완료: {args.voice_id}")


def cmd_generate(args: argparse.Namespace) -> None:
    settings = load_app_settings()
    voice_config = load_voice_config()
    entries = load_dialogue_entries(Path(args.csv))
    languages = [x.strip() for x in args.languages.split(",") if x.strip()]

    korean_index = {}
    if args.korean_folder:
        files = scan_korean_audio_folder(Path(args.korean_folder))
        korean_index = {f.code: f.file_path for f in files}

    tasks = build_tasks_from_entries(entries, voice_config, languages, korean_index)
    print(f"생성 대상: {len(tasks)}건 (언어: {', '.join(languages)})")

    success, failed = 0, 0
    for i, task in enumerate(tasks, start=1):
        result = generate_task(
            settings.api_key, task, settings.output_folder, settings.model_id,
            TtsVoiceSettings(), settings.max_retries, settings.retry_delay, dry_run=args.dry_run,
        )
        tag = "OK" if result.success else "FAIL"
        print(f"[{i}/{len(tasks)}] {tag}  {task.language}/{task.code}  {result.error}")
        if result.success:
            success += 1
        else:
            failed += 1

    print(f"\n완료: 성공 {success} / 실패 {failed} / 전체 {len(tasks)}")
    sys.exit(1 if failed > 0 else 0)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="K-PASS 다국어 Voice Clone 생성기 CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    p_scan = sub.add_parser("scan", help="한국어 음성 폴더 스캔 및 Role 자동 분류")
    p_scan.add_argument("--folder", required=True, help="한국어 음성 폴더 경로")
    p_scan.set_defaults(func=cmd_scan)

    p_build = sub.add_parser("build-samples", help="캐릭터별 Voice Clone 샘플 생성")
    p_build.add_argument("--folder", required=True, help="한국어 음성 폴더 경로")
    p_build.set_defaults(func=cmd_build_samples)

    p_quality = sub.add_parser("check-quality", help="생성된 Clone 샘플 품질 검사")
    p_quality.set_defaults(func=cmd_check_quality)

    p_reg = sub.add_parser("register-voice", help="Role에 Voice ID 등록")
    p_reg.add_argument("--role", required=True)
    p_reg.add_argument("--voice-id", required=True)
    p_reg.add_argument("--sample-file", default="")
    p_reg.add_argument("--language", default="", help="언어별 Voice ID로 등록하려면 지정")
    p_reg.set_defaults(func=cmd_register_voice)

    p_gen = sub.add_parser("generate", help="다국어 음성 생성")
    p_gen.add_argument("--csv", required=True, help="번역 스크립트 CSV/XLSX 경로")
    p_gen.add_argument("--languages", required=True, help="쉼표로 구분된 언어 목록 (예: English,Thai)")
    p_gen.add_argument("--korean-folder", default="", help="원본 길이 비교용 한국어 음성 폴더 (선택)")
    p_gen.add_argument("--dry-run", action="store_true")
    p_gen.set_defaults(func=cmd_generate)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
