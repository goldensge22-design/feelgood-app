"""
config.py
=========
K-PASS Multilingual Voice Generator - 설정 모듈

.env 파일에서 다음을 읽어들여 다른 모듈에서 사용할 수 있도록 제공한다:
  - ElevenLabs API 인증 정보 / 모델 ID / 출력 폴더
  - Voice 이름(Adam, Liam, Jessica, Laura, Brian, Bella...) -> Voice ID 매핑
  - Voice Settings (stability, similarity_boost, style, speed, speaker_boost)
  - Retry 정책

CSV 파일에는 사람이 읽기 쉬운 Voice 이름(Adam, Liam 등)만 적으면 되고,
실제 ElevenLabs Voice ID로의 변환은 이 모듈이 담당한다.
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict

from dotenv import load_dotenv

# .env 파일 로드 (스크립트 실행 위치와 무관하게 이 파일 기준 경로에서 로드)
BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")


def _get_bool(value: str | None, default: bool = True) -> bool:
    if value is None:
        return default
    return value.strip().lower() in ("1", "true", "yes", "y", "on")


def _get_float(value: str | None, default: float) -> float:
    if value is None or value.strip() == "":
        return default
    try:
        return float(value)
    except ValueError:
        return default


def _get_int(value: str | None, default: int) -> int:
    if value is None or value.strip() == "":
        return default
    try:
        return int(value)
    except ValueError:
        return default


@dataclass
class VoiceSettings:
    """ElevenLabs voice_settings 파라미터. .env 에서 자유롭게 조정 가능."""

    stability: float = 0.5
    similarity_boost: float = 0.75
    style: float = 0.0
    speed: float = 1.0
    use_speaker_boost: bool = True

    def to_api_dict(self) -> dict:
        """ElevenLabs API에 보낼 voice_settings 딕셔너리로 변환."""
        return {
            "stability": self.stability,
            "similarity_boost": self.similarity_boost,
            "style": self.style,
            "speed": self.speed,
            "use_speaker_boost": self.use_speaker_boost,
        }


@dataclass
class Settings:
    api_key: str
    model_id: str
    output_folder: Path
    log_folder: Path
    voice_map: Dict[str, str]
    voice_settings: VoiceSettings
    max_retries: int
    retry_delay: float

    def resolve_voice_id(self, voice_name: str) -> str | None:
        """CSV의 Voice 이름(예: Adam)을 Voice ID로 변환. 대소문자 무시."""
        if not voice_name:
            return None
        return self.voice_map.get(voice_name.strip().lower())


def _build_voice_map() -> Dict[str, str]:
    """
    .env에 정의된 VOICE_* 항목을 모두 스캔하여 {이름(소문자): voice_id} 매핑을 만든다.
    예: VOICE_ADAM=xxxx  ->  {"adam": "xxxx"}

    새로운 목소리를 추가하고 싶으면 .env에 VOICE_NEWNAME=voice_id 를 추가하고
    CSV의 Voice 컬럼에 NewName 이라고 적으면 자동으로 인식된다.
    """
    voice_map: Dict[str, str] = {}
    for key, value in os.environ.items():
        if key.startswith("VOICE_") and value.strip():
            name = key[len("VOICE_"):].lower()
            voice_map[name] = value.strip()
    return voice_map


def load_settings() -> Settings:
    api_key = os.environ.get("API_KEY", "").strip()
    if not api_key:
        print("[오류] .env 파일에 API_KEY가 설정되어 있지 않습니다.")
        print("       .env.example을 복사하여 .env를 만들고 API_KEY를 입력하세요.")
        sys.exit(1)

    model_id = os.environ.get("MODEL_ID", "eleven_multilingual_v2").strip() or "eleven_multilingual_v2"
    output_folder = Path(os.environ.get("OUTPUT_FOLDER", "output").strip() or "output")
    log_folder = Path(os.environ.get("LOG_FOLDER", "logs").strip() or "logs")

    voice_map = _build_voice_map()
    if not voice_map:
        print("[오류] .env 파일에 VOICE_* 항목이 하나도 없습니다. (예: VOICE_ADAM=voice_id)")
        sys.exit(1)

    voice_settings = VoiceSettings(
        stability=_get_float(os.environ.get("STABILITY"), 0.5),
        similarity_boost=_get_float(os.environ.get("SIMILARITY_BOOST"), 0.75),
        style=_get_float(os.environ.get("STYLE"), 0.0),
        speed=_get_float(os.environ.get("SPEED"), 1.0),
        use_speaker_boost=_get_bool(os.environ.get("SPEAKER_BOOST"), True),
    )

    max_retries = _get_int(os.environ.get("MAX_RETRIES"), 3)
    retry_delay = _get_float(os.environ.get("RETRY_DELAY"), 2.0)

    return Settings(
        api_key=api_key,
        model_id=model_id,
        output_folder=output_folder,
        log_folder=log_folder,
        voice_map=voice_map,
        voice_settings=voice_settings,
        max_retries=max_retries,
        retry_delay=retry_delay,
    )


# ElevenLabs API 관련 상수
ELEVENLABS_BASE_URL = "https://api.elevenlabs.io/v1"
TTS_ENDPOINT_TEMPLATE = ELEVENLABS_BASE_URL + "/text-to-speech/{voice_id}"
REQUEST_TIMEOUT_SECONDS = 60
