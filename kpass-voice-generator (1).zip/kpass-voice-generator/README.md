# K-PASS 다국어 Voice Clone 생성기

K-PASS 게임의 한국어 원본 음성을 기반으로 캐릭터별 **ElevenLabs Voice Clone**을 만들고,
등록된 Voice로 **태국어/영어/일본어/중국어/러시아어** 등 다국어 대사 음성을 자동 생성하는 프로그램입니다.

기존 "고정 Voice 이름 기반" 다국어 생성기(`legacy_generate_voice.py`)의 기능은 그대로 남아있고,
이 프로그램은 그 위에 **① 한국어 음성 자동 분류 → ② Voice Clone 샘플 생성 → ③ Voice 등록 →
④ 다국어 생성 → ⑤ 검수** 파이프라인을 추가한 확장판입니다.

---

## 1. 설치

### Windows (권장)
1. Python 3.10 이상 설치 ( https://www.python.org/downloads/ , 설치 시 "Add to PATH" 체크)
2. 이 프로젝트 폴더를 원하는 위치에 압축 해제
3. `run.bat` 더블클릭 → 가상환경 생성 + 패키지 설치 + 프로그램 실행이 자동으로 진행됩니다.

### macOS / Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # API_KEY 입력
python app.py
```

> **ffmpeg 필요**: 오디오 처리(pydub)를 위해 시스템에 ffmpeg가 설치되어 있어야 합니다.
> Windows: https://ffmpeg.org/download.html 에서 다운로드 후 PATH에 추가
> macOS: `brew install ffmpeg`
> Ubuntu: `sudo apt install ffmpeg`

---

## 2. 최초 설정

1. `.env.example` 파일을 복사해 `.env` 로 이름을 바꾸고 `API_KEY=` 뒤에 ElevenLabs API Key를 입력합니다.
   - API Key는 https://elevenlabs.io → Profile → API Keys 에서 발급받을 수 있습니다.
   - API Key는 절대 코드나 화면에 그대로 노출되지 않으며, 입력란은 기본적으로 마스킹(●●●●)되어 표시됩니다.
2. 프로그램 실행 후 **1단계: 프로젝트 설정** 화면에서 API Key, Model ID, 출력 폴더, 번역 파일(CSV/XLSX)을 지정합니다.

---

## 3. 6단계 사용 흐름 (GUI)

### 1단계 - 프로젝트 설정
- 프로젝트 이름, API Key, Model ID, 출력 폴더, 번역 CSV/XLSX 파일을 지정합니다.
- 번역 파일은 두 가지 형식을 지원합니다.
  - **레거시 형식**: `Code,Language,Voice,Text` (언어별로 행이 분리됨, 기존 방식과 100% 호환)
  - **신규 형식**: `Code,Role,Korean,Thai,English,Japanese,Chinese,Russian` (한 행에 모든 언어)

### 2단계 - 한국어 음성 불러오기
- 한국어 음성 파일이 들어 있는 폴더를 선택하면 자동으로 스캔합니다.
- 파일명 규칙 `Category.Role.Index.mp3` (예: `Intro.Darkmong.One.mp3`)을 기반으로 Role을 자동 추출합니다.
- `Narration.*` 파일은 자동으로 `Narrator` Role로 분류됩니다.
- Role을 알 수 없는 파일은 `Unknown`으로 표시되며, 목록에서 파일을 선택 후 하단의
  "선택한 파일의 Role 변경" 콤보박스로 직접 지정할 수 있습니다.
- 목록에서 파일을 더블클릭하면 시스템 기본 플레이어로 음성을 재생해 확인할 수 있습니다.
- 손상된 파일(0바이트)이나 너무 짧은 파일은 자동으로 "제외됨"으로 표시됩니다. 필요 시
  "포함으로 복원" 버튼으로 되돌릴 수 있습니다.
- **원본 음성 파일은 이 프로그램에 의해 절대 이동/수정/삭제되지 않습니다.**

### 3단계 - Clone 샘플 준비
- "캐릭터별 Clone 샘플 생성" 버튼을 누르면 Role별로 여러 한국어 음성을 자동 병합합니다.
  - 무음 구간 제거, 음량 정규화, 모노 변환, 샘플레이트 통일, 짧은 파일/중복 파일 제외,
    파일 사이 짧은 무음 삽입이 자동으로 적용됩니다.
- 병합된 샘플은 `data/voice_clone_ready/<Role>_clone_sample.wav` 에 저장되고,
  사용된 원본 파일 목록은 `data/manifests/<Role>_clone_manifest.json` 에 기록됩니다.
- 목록에서 Role을 클릭하면 하단에 품질 검사 결과("사용 가능"/"보완 권장"/"사용 부적합")와
  상세 메시지(클리핑, 배경 잡음 의심, 무음 비율, 여러 화자 혼입 의심 등)가 표시됩니다.
  - ElevenLabs Voice Clone은 통상 60초 이상의 깨끗한 음성을 권장합니다.

### 4단계 - Voice 등록
- Role을 선택하면 3단계에서 만든 Clone Sample 경로가 표시됩니다.
- **먼저 동의 체크박스**("본인은 해당 음성의 사용 및 AI 음성 복제에 필요한 권리와 동의를
  확보했습니다.")를 체크해야 아래 Voice Clone 관련 기능을 사용할 수 있습니다.
  동의 여부와 시각은 `logs/consent_log.json` 에 자동 기록됩니다.
- **방식 A (수동)**: Clone Sample 파일을 ElevenLabs 웹사이트에 직접 업로드해 Voice Clone을
  만든 후, 발급된 Voice ID를 입력하고 "Voice ID 저장"을 누릅니다.
  "Voice 연결 상태 확인"으로 유효성을, "테스트 음성 생성"으로 실제 음질을 확인할 수 있습니다.
- **방식 B (API)**: "API로 Voice Clone 생성 시도" 버튼으로 프로그램이 직접 Voice Clone
  생성을 시도합니다. 계정 요금제가 API Clone을 지원하지 않으면 오류로 프로그램이 멈추지 않고
  안내 메시지가 표시되며, 이 경우 방식 A를 이용하면 됩니다.
- 언어별로 다른 Voice ID를 쓰고 싶다면(예: 영어는 A Voice, 태국어는 B Voice) 추후
  `config/voice_config.json` 을 직접 편집하거나 CLI의 `register-voice --language` 옵션을 사용하세요.

### 5단계 - 다국어 생성
- 생성할 언어를 체크박스로 선택합니다.
- **생성 대상 확인(Dry Run)**: 실제 API를 호출하지 않고 어떤 파일이 생성될지 미리 확인합니다.
- **테스트 1개 생성**: 실제로 1건만 생성해 결과를 빠르게 확인합니다.
- **전체 생성**: 선택한 모든 언어 x 모든 대사에 대해 음성을 생성합니다. 이미 생성된 파일은
  자동으로 건너뜁니다(SKIP).
- 결과는 `output/<언어>/<Code>.mp3` 로 저장되며, 파일명은 원본 Code와 동일하게 유지됩니다.

### 6단계 - 검수
- 각 대사(Code x 언어)별로 한국어 원본과 생성된 다국어 음성을 각각 재생해 비교할 수 있습니다.
- "승인" / "재생성 필요 표시" 버튼으로 검수 상태를 기록하고, 검수 메모를 남길 수 있습니다.
- "선택 항목 재생성" 또는 "실패/대기 항목 일괄 재생성"으로 문제가 있는 음성만 다시 생성할 수 있습니다.
- 검수 상태는 `logs/review_state.json` 에 저장되어 다음 실행 시에도 유지됩니다.

---

## 4. CLI (커맨드라인) 사용법

GUI 없이도 동일한 파이프라인을 커맨드라인에서 실행할 수 있습니다.

```bash
# 1) 한국어 음성 폴더 스캔
python cli.py scan --folder korean_audio

# 2) 캐릭터별 Clone 샘플 생성 + 품질 검사
python cli.py build-samples --folder korean_audio

# 3) 이미 만든 샘플의 품질만 다시 확인
python cli.py check-quality

# 4) Voice ID 등록 (방식 A로 웹사이트에서 만든 Voice ID를 등록할 때)
python cli.py register-voice --role Darkmong --voice-id XXXXXXXX

# 5) 다국어 생성 (Dry Run으로 먼저 확인)
python cli.py generate --csv script.xlsx --languages English,Thai,Japanese --dry-run

# 6) 실제 생성
python cli.py generate --csv script.xlsx --languages English,Thai,Japanese --korean-folder korean_audio
```

### 기존(레거시) CLI 그대로 사용하기
`legacy_generate_voice.py` 는 기존 고정 Voice 이름(Adam, Liam 등) 방식 그대로 동작합니다.

```bash
python legacy_generate_voice.py --csv sample_legacy.csv
python legacy_list_voices.py
```

---

## 5. 개발 중 테스트(실제 음성 247개 없이도 개발 가능)

`data/korean_audio_sample/` 폴더에 몇 개의 대표 샘플 파일이 포함되어 있어,
전체 음성 파일이 없어도 구조/기능을 바로 테스트할 수 있습니다. 실제 운영 시에는
2단계에서 실제 한국어 음성 전체 폴더(247개)를 선택하면 자동으로 인식됩니다.
코드에는 실제 운영 경로가 고정되어 있지 않습니다.

---

## 6. 개인정보 및 보안

- 한국어 원본 음성은 기본적으로 사용자의 로컬 컴퓨터에만 보관됩니다.
- Voice Clone 생성 또는 다국어 음성 생성을 실제로 실행할 때만 필요한 음성/텍스트가
  ElevenLabs API로 전송됩니다.
- API Key는 `.env` 파일 또는 GUI 입력창에만 저장되며, 화면에는 기본적으로 마스킹되어
  표시되고 로그 파일에도 기록되지 않습니다.
- 오류 로그에 대본 전체를 남길지 여부는 `config/settings.json` 의
  `expose_full_text_in_error_logs` 값으로 제어할 수 있습니다(기본값: false).
- 원본 음성 파일은 어떤 기능을 실행해도 자동으로 삭제되지 않습니다.

---

## 7. 문제 해결 (FAQ)

**Q. "API를 통한 Voice Clone 생성이 지원되지 않습니다" 메시지가 나옵니다.**
A. 사용 중인 ElevenLabs 요금제가 API를 통한 Voice Clone 생성(POST /v1/voices/add)을
지원하지 않는 경우입니다. 4단계의 "방식 A (수동)"를 이용해 웹사이트에서 직접 Voice Clone을
만든 후 Voice ID를 입력하세요.

**Q. Clone 샘플 품질이 "사용 부적합"으로 나옵니다.**
A. 대부분 전체 음성 길이가 부족(60초 미만)하거나 배경 잡음/클리핑이 감지된 경우입니다.
2단계에서 해당 캐릭터의 한국어 음성 파일을 더 추가한 뒤 3단계를 다시 실행하세요.

**Q. 오디오 처리 중 오류가 발생합니다.**
A. ffmpeg가 설치되어 있는지, PATH에 등록되어 있는지 확인하세요.

**Q. Voice ID를 언어별로 다르게 쓰고 싶습니다.**
A. `config/voice_config.json` 의 `roles.<Role>.language_voice_id.<Language>` 값을
설정하면 해당 언어에서는 이 Voice ID가 공통 Voice ID보다 우선 적용됩니다.
(우선순위: 언어별 Role Voice ID > 공통 Role Voice ID > 언어 기본 Voice ID > 전체 기본 Voice ID)

더 자세한 내부 구조는 `DEVELOPER.md` 를 참고하세요.
