#!/usr/bin/env python3
"""
generate_voice.py
==================
K-PASS Game Multilingual Voice Generator

CSV 파일(Code,Language,Voice,Text)을 읽어 ElevenLabs Text-to-Speech API로
게임 대사를 언어별 MP3 파일로 자동 생성하는 운영용 스크립트.

사용법:
    python generate_voice.py
    python generate_voice.py --csv sample.csv
    python generate_voice.py --csv dialogue_english.csv --dry-run

자세한 사용법은 README.md 참고.
"""

from __future__ import annotations

import argparse
import csv
import logging
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import requests

from legacy_config import (
    REQUEST_TIMEOUT_SECONDS,
    TTS_ENDPOINT_TEMPLATE,
    Settings,
    load_settings,
)

REQUIRED_CSV_COLUMNS = {"Code", "Language", "Voice", "Text"}


# --------------------------------------------------------------------------
# 데이터 구조
# --------------------------------------------------------------------------

@dataclass
class DialogueRow:
    code: str
    language: str
    voice: str
    text: str
    row_number: int  # CSV 내 실제 행 번호 (헤더 제외, 2부터 시작)


@dataclass
class RunStats:
    total: int = 0
    success: int = 0
    failed: int = 0
    skipped: int = 0
    failed_rows: list = field(default_factory=list)


# --------------------------------------------------------------------------
# 로깅 설정
# --------------------------------------------------------------------------

def setup_logger(log_folder: Path) -> logging.Logger:
    log_folder.mkdir(parents=True, exist_ok=True)
    log_path = log_folder / "generate.log"

    logger = logging.getLogger("kpass_voice_gen")
    logger.setLevel(logging.DEBUG)
    logger.handlers.clear()

    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_formatter = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    )
    file_handler.setFormatter(file_formatter)
    logger.addHandler(file_handler)

    return logger


# --------------------------------------------------------------------------
# CSV 로딩
# --------------------------------------------------------------------------

def load_dialogue_rows(csv_path: Path, logger: logging.Logger) -> list[DialogueRow]:
    if not csv_path.exists():
        print(f"[오류] CSV 파일을 찾을 수 없습니다: {csv_path}")
        sys.exit(1)

    rows: list[DialogueRow] = []
    with csv_path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)

        if reader.fieldnames is None:
            print("[오류] CSV 파일이 비어 있습니다.")
            sys.exit(1)

        missing_columns = REQUIRED_CSV_COLUMNS - set(reader.fieldnames)
        if missing_columns:
            print(f"[오류] CSV에 필수 컬럼이 없습니다: {', '.join(sorted(missing_columns))}")
            print(f"       필수 컬럼: {', '.join(sorted(REQUIRED_CSV_COLUMNS))}")
            sys.exit(1)

        for i, raw_row in enumerate(reader, start=2):  # 헤더가 1행이므로 데이터는 2행부터
            code = (raw_row.get("Code") or "").strip()
            language = (raw_row.get("Language") or "").strip()
            voice = (raw_row.get("Voice") or "").strip()
            text = (raw_row.get("Text") or "").strip()

            if not code or not language or not voice or not text:
                logger.warning(
                    "%d행: 필수 값 누락으로 건너뜀 (Code=%r, Language=%r, Voice=%r, Text 길이=%d)",
                    i, code, language, voice, len(text),
                )
                continue

            rows.append(DialogueRow(code=code, language=language, voice=voice, text=text, row_number=i))

    return rows


# --------------------------------------------------------------------------
# ElevenLabs API 호출
# --------------------------------------------------------------------------

def request_tts_audio(
    settings: Settings,
    voice_id: str,
    text: str,
    logger: logging.Logger,
    row_label: str,
) -> Optional[bytes]:
    """
    ElevenLabs Text-to-Speech API(POST /v1/text-to-speech/{voice_id})를 호출하여
    성공 시 MP3 바이트를, 실패 시 None을 반환한다. 최대 max_retries 회 재시도.
    """
    url = TTS_ENDPOINT_TEMPLATE.format(voice_id=voice_id)
    headers = {
        "xi-api-key": settings.api_key,
        "Content-Type": "application/json",
        "Accept": "audio/mpeg",
    }
    payload = {
        "text": text,
        "model_id": settings.model_id,
        "voice_settings": settings.voice_settings.to_api_dict(),
    }

    last_error = ""
    for attempt in range(1, settings.max_retries + 1):
        try:
            response = requests.post(
                url, headers=headers, json=payload, timeout=REQUEST_TIMEOUT_SECONDS
            )
        except requests.exceptions.RequestException as exc:
            last_error = f"네트워크 오류: {exc}"
            logger.warning("%s - 시도 %d/%d 실패: %s", row_label, attempt, settings.max_retries, last_error)
        else:
            if response.status_code == 200:
                return response.content

            # 실패 응답 처리
            try:
                error_detail = response.json()
            except ValueError:
                error_detail = response.text[:500]
            last_error = f"HTTP {response.status_code}: {error_detail}"
            logger.warning("%s - 시도 %d/%d 실패: %s", row_label, attempt, settings.max_retries, last_error)

            # 인증 오류(401)나 잘못된 요청(400)은 재시도해도 동일하게 실패할 가능성이 높지만,
            # 명세에 따라 그래도 최대 재시도 횟수까지는 시도한다.

        if attempt < settings.max_retries:
            time.sleep(settings.retry_delay)

    logger.error("%s - 최종 실패 (재시도 %d회 소진): %s", row_label, settings.max_retries, last_error)
    return None


# --------------------------------------------------------------------------
# 메인 처리 로직
# --------------------------------------------------------------------------

def process_rows(
    rows: list[DialogueRow],
    settings: Settings,
    logger: logging.Logger,
    dry_run: bool = False,
) -> RunStats:
    stats = RunStats(total=len(rows))

    for idx, row in enumerate(rows, start=1):
        row_label = f"[{row.row_number}행] {row.code} ({row.language}/{row.voice})"
        progress_prefix = f"{idx} / {stats.total}"

        # 언어별 출력 폴더
        language_folder = settings.output_folder / row.language
        language_folder.mkdir(parents=True, exist_ok=True)
        output_path = language_folder / f"{row.code}.mp3"

        # 이미 존재하면 skip
        if output_path.exists():
            stats.skipped += 1
            print(f"{progress_prefix}  [SKIP] {row.language}/{row.code}.mp3 (이미 존재)")
            logger.info("%s - SKIP (이미 존재: %s)", row_label, output_path)
            continue

        # Voice 이름 -> Voice ID 매핑
        voice_id = settings.resolve_voice_id(row.voice)
        if not voice_id:
            stats.failed += 1
            stats.failed_rows.append(row_label)
            print(f"{progress_prefix}  [FAIL] {row.language}/{row.code}.mp3 (알 수 없는 Voice: {row.voice})")
            logger.error("%s - FAIL (Voice '%s'에 대한 Voice ID가 .env에 없음)", row_label, row.voice)
            continue

        if dry_run:
            stats.success += 1
            print(f"{progress_prefix}  [DRY-RUN] {row.language}/{row.code}.mp3 생성 예정 (Voice ID={voice_id})")
            continue

        audio_bytes = request_tts_audio(settings, voice_id, row.text, logger, row_label)

        if audio_bytes is None:
            stats.failed += 1
            stats.failed_rows.append(row_label)
            print(f"{progress_prefix}  [FAIL] {row.language}/{row.code}.mp3 (API 호출 실패, 로그 확인)")
            continue

        try:
            output_path.write_bytes(audio_bytes)
        except OSError as exc:
            stats.failed += 1
            stats.failed_rows.append(row_label)
            print(f"{progress_prefix}  [FAIL] {row.language}/{row.code}.mp3 (파일 저장 실패: {exc})")
            logger.error("%s - FAIL (파일 저장 실패: %s)", row_label, exc)
            continue

        stats.success += 1
        print(f"{progress_prefix}  [OK]   {row.language}/{row.code}.mp3")
        logger.info("%s - SUCCESS (%s, %d bytes)", row_label, output_path, len(audio_bytes))

    return stats


def print_summary(stats: RunStats, elapsed_seconds: float) -> None:
    print()
    print("=" * 50)
    print("K-PASS Voice Generation 완료")
    print("=" * 50)
    print(f"총 대상       : {stats.total}")
    print(f"Success       : {stats.success}")
    print(f"Failed        : {stats.failed}")
    print(f"Skipped       : {stats.skipped}")
    print(f"총 소요 시간  : {elapsed_seconds:.1f}초")
    if stats.failed_rows:
        print()
        print("실패 목록 (자세한 원인은 logs/generate.log 참고):")
        for row_label in stats.failed_rows:
            print(f"  - {row_label}")
    print("=" * 50)


# --------------------------------------------------------------------------
# 엔트리 포인트
# --------------------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="K-PASS 게임 대사 CSV를 ElevenLabs TTS로 변환하여 언어별 MP3로 생성합니다."
    )
    parser.add_argument(
        "--csv",
        default="sample.csv",
        help="입력 CSV 파일 경로 (기본값: sample.csv)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="실제 API를 호출하지 않고 처리 대상만 미리 확인합니다.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    settings = load_settings()
    logger = setup_logger(settings.log_folder)

    csv_path = Path(args.csv)
    logger.info("=== K-PASS Voice Generation 시작 (CSV=%s, dry_run=%s) ===", csv_path, args.dry_run)

    rows = load_dialogue_rows(csv_path, logger)
    if not rows:
        print("[알림] 처리할 대사가 없습니다. CSV 내용을 확인하세요.")
        sys.exit(0)

    print(f"CSV 로드 완료: {len(rows)}개 대사 (파일: {csv_path})")
    print(f"모델: {settings.model_id} | 출력 폴더: {settings.output_folder}")
    print(f"등록된 Voice: {', '.join(sorted(settings.voice_map.keys()))}")
    print()

    start_time = time.time()
    stats = process_rows(rows, settings, logger, dry_run=args.dry_run)
    elapsed = time.time() - start_time

    print_summary(stats, elapsed)
    logger.info(
        "=== 완료: total=%d success=%d failed=%d skipped=%d elapsed=%.1fs ===",
        stats.total, stats.success, stats.failed, stats.skipped, elapsed,
    )

    # 실패가 있으면 종료 코드 1로 (CI/자동화 파이프라인에서 감지 가능하도록)
    sys.exit(1 if stats.failed > 0 else 0)


if __name__ == "__main__":
    main()
