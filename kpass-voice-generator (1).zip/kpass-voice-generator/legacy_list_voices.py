#!/usr/bin/env python3
"""
list_voices.py
===============
ElevenLabs 계정에서 사용 가능한 Voice 목록(이름, Voice ID)을 조회하는 보조 스크립트.

.env의 VOICE_ADAM, VOICE_LIAM 등에 어떤 값을 넣어야 할지 확인할 때 사용한다.

사용법:
    python list_voices.py
"""

from __future__ import annotations

import os
import sys

import requests
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.environ.get("API_KEY", "").strip()
VOICES_ENDPOINT = "https://api.elevenlabs.io/v1/voices"


def main() -> None:
    if not API_KEY:
        print("[오류] .env 파일에 API_KEY가 설정되어 있지 않습니다.")
        sys.exit(1)

    try:
        response = requests.get(
            VOICES_ENDPOINT, headers={"xi-api-key": API_KEY}, timeout=30
        )
    except requests.exceptions.RequestException as exc:
        print(f"[오류] API 호출 실패: {exc}")
        sys.exit(1)

    if response.status_code != 200:
        print(f"[오류] HTTP {response.status_code}: {response.text[:500]}")
        sys.exit(1)

    data = response.json()
    voices = data.get("voices", [])

    if not voices:
        print("등록된 목소리가 없습니다.")
        return

    print(f"총 {len(voices)}개의 목소리를 찾았습니다.\n")
    print(f"{'이름':20} {'Voice ID':30} {'카테고리'}")
    print("-" * 70)
    for v in voices:
        name = v.get("name", "?")
        voice_id = v.get("voice_id", "?")
        category = v.get("category", "?")
        print(f"{name:20} {voice_id:30} {category}")

    print()
    print("위 Voice ID를 .env 파일의 VOICE_<이름> 항목에 복사하세요.")
    print("예: VOICE_ADAM=" + (voices[0].get("voice_id", "") if voices else ""))


if __name__ == "__main__":
    main()
