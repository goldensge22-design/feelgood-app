@echo off
REM ============================================
REM K-PASS Voice Generator - Windows 실행 스크립트
REM ============================================
setlocal

cd /d "%~dp0"

if not exist ".venv" (
    echo [INFO] 가상환경이 없어 새로 생성합니다...
    python -m venv .venv
)

call .venv\Scripts\activate.bat

echo [INFO] 필요한 패키지를 설치/업데이트합니다...
pip install -r requirements.txt

if not exist ".env" (
    echo [INFO] .env 파일이 없어 .env.example 을 복사합니다.
    copy .env.example .env
    echo [경고] .env 파일에 API_KEY 를 입력한 후 다시 실행하세요.
)

echo [INFO] K-PASS Voice Generator GUI 를 실행합니다...
python app.py

pause
