"""
role_detector.py
=================
한국어 음성 파일명(K-PASS 게임 Code)에서 등장인물(Role)을 자동으로 추출한다.

파일명 규칙 (기존 게임 Code 형식):
    <Category>.<Role>.<Index>.<ext>
    예: Intro.Darkmong.One.mp3      -> Role = Darkmong
        Intro.Crow.One.mp3         -> Role = Crow
        Narration.Intro.One.mp3    -> Role = Narrator (특수 규칙)

규칙만으로 판단이 애매한 파일은 Role="Unknown"으로 반환하고,
GUI에서 사용자가 직접 지정할 수 있도록 한다.

role_mapping.json 을 통해 별칭(alias) -> 표준 Role 이름 매핑을 관리할 수 있다.
예: "Linky": "Linky", "Linkey": "Linky", "Lingky": "Linky"
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional

DEFAULT_ROLE_MAPPING_PATH = Path(__file__).resolve().parent.parent / "config" / "role_mapping.json"

# Narration/Narrator 계열 Category는 Role 대신 고정 Narrator 로 취급한다.
NARRATION_CATEGORY_PATTERN = re.compile(r"^(narration|narrator)$", re.IGNORECASE)


@dataclass
class RoleDetectionResult:
    file_name: str
    category: Optional[str]
    role_raw: Optional[str]
    role: str  # 최종 정규화된 Role (Unknown 포함)
    index_token: Optional[str]
    is_unknown: bool
    reason: str


def load_role_mapping(path: Path = DEFAULT_ROLE_MAPPING_PATH) -> Dict[str, str]:
    """alias(소문자) -> 표준 Role 이름 매핑을 로드한다. 파일이 없으면 빈 dict."""
    if not path.exists():
        return {}
    try:
        with path.open("r", encoding="utf-8") as f:
            raw = json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}

    mapping: Dict[str, str] = {}
    for standard_name, aliases in raw.items():
        # 표준 이름 자기 자신도 매핑에 포함
        mapping[standard_name.strip().lower()] = standard_name
        if isinstance(aliases, list):
            for alias in aliases:
                mapping[str(alias).strip().lower()] = standard_name
    return mapping


def normalize_role(role_raw: str, role_mapping: Dict[str, str]) -> str:
    """alias 매핑을 적용하여 표준 Role 이름으로 정규화한다. 매핑이 없으면 원본을 그대로 사용(첫 글자 대문자화)."""
    key = role_raw.strip().lower()
    if key in role_mapping:
        return role_mapping[key]
    # 매핑에 없으면 원본 표기를 그대로 사용 (대소문자만 다듬는다)
    return role_raw.strip()


def detect_role_from_filename(
    file_name: str,
    role_mapping: Optional[Dict[str, str]] = None,
) -> RoleDetectionResult:
    """
    파일명(확장자 포함/미포함 모두 허용)에서 Role을 추출한다.

    지원 패턴:
      1) Category.Role.Index  (예: Intro.Darkmong.One.mp3)
      2) Category.Role        (예: Ending.Piece.mp3)
      3) Narration/Narrator 로 시작하는 파일 -> Role = "Narrator"
      4) 위 패턴에 맞지 않으면 Unknown 처리
    """
    if role_mapping is None:
        role_mapping = load_role_mapping()

    stem = Path(file_name).stem  # 확장자 제거
    parts = [p for p in stem.split(".") if p != ""]

    if not parts:
        return RoleDetectionResult(
            file_name=file_name, category=None, role_raw=None, role="Unknown",
            index_token=None, is_unknown=True, reason="파일명이 비어 있음",
        )

    category = parts[0]

    # Narration/Narrator 특수 규칙: Narration.Intro.One.mp3 -> Narrator
    if NARRATION_CATEGORY_PATTERN.match(category):
        return RoleDetectionResult(
            file_name=file_name, category=category, role_raw="Narrator",
            role="Narrator", index_token=parts[-1] if len(parts) > 1 else None,
            is_unknown=False, reason="Narration Category 규칙 적용",
        )

    if len(parts) >= 2:
        role_raw = parts[1]
        index_token = parts[2] if len(parts) >= 3 else None
        role = normalize_role(role_raw, role_mapping)
        if not role:
            return RoleDetectionResult(
                file_name=file_name, category=category, role_raw=role_raw, role="Unknown",
                index_token=index_token, is_unknown=True, reason="Role 토큰이 비어 있음",
            )
        return RoleDetectionResult(
            file_name=file_name, category=category, role_raw=role_raw, role=role,
            index_token=index_token, is_unknown=False, reason="Category.Role[.Index] 패턴 매칭",
        )

    # Category 하나뿐인 경우 (예: "Mole.wav") -> Category 자체를 Role 후보로 사용
    role = normalize_role(category, role_mapping)
    return RoleDetectionResult(
        file_name=file_name, category=None, role_raw=category, role=role,
        index_token=None, is_unknown=False,
        reason="단일 토큰 파일명 - Category를 Role로 간주",
    )


def build_code_from_filename(file_name: str) -> str:
    """스프레드시트 Code 매칭에 사용할 Code(확장자 제외 파일명)를 반환한다."""
    return Path(file_name).stem
