"""
voice_config_manager.py
=========================
config/voice_config.json 을 읽고 쓰며, Role/언어별 Voice ID를 관리한다.

voice_config.json 예시:
{
  "default_voice_id": "",
  "language_default_voice_id": { "English": "", "Thai": "" },
  "roles": {
    "Darkmong": {
      "voice_id": "xxxx",
      "sample_file": "voice_clone_ready/Darkmong_clone_sample.wav",
      "status": "registered",
      "language_voice_id": { "English": "yyyy", "Thai": "zzzz" }
    }
  }
}

Voice ID 조회 우선순위 (섹션 7):
  1. 언어별 Role Voice ID   (roles[role].language_voice_id[language])
  2. 공통 Role Voice ID     (roles[role].voice_id)
  3. 언어 기본 Voice ID     (language_default_voice_id[language])
  4. 전체 기본 Voice ID     (default_voice_id)
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional

DEFAULT_VOICE_CONFIG_PATH = Path(__file__).resolve().parent.parent / "config" / "voice_config.json"


@dataclass
class VoiceConfig:
    default_voice_id: str = ""
    language_default_voice_id: Dict[str, str] = field(default_factory=dict)
    roles: Dict[str, dict] = field(default_factory=dict)

    def resolve_voice_id(self, role: str, language: str) -> Optional[str]:
        role_entry = self.roles.get(role, {})

        lang_voice_map = role_entry.get("language_voice_id", {}) or {}
        if language in lang_voice_map and lang_voice_map[language]:
            return lang_voice_map[language]

        if role_entry.get("voice_id"):
            return role_entry["voice_id"]

        if language in self.language_default_voice_id and self.language_default_voice_id[language]:
            return self.language_default_voice_id[language]

        if self.default_voice_id:
            return self.default_voice_id

        return None

    def upsert_role(
        self,
        role: str,
        voice_id: str = "",
        sample_file: str = "",
        status: str = "registered",
    ) -> None:
        entry = self.roles.setdefault(role, {})
        if voice_id:
            entry["voice_id"] = voice_id
        if sample_file:
            entry["sample_file"] = sample_file
        entry["status"] = status
        entry.setdefault("language_voice_id", {})

    def set_language_voice_id(self, role: str, language: str, voice_id: str) -> None:
        entry = self.roles.setdefault(role, {})
        entry.setdefault("language_voice_id", {})
        entry["language_voice_id"][language] = voice_id

    def to_dict(self) -> dict:
        return {
            "default_voice_id": self.default_voice_id,
            "language_default_voice_id": self.language_default_voice_id,
            "roles": self.roles,
        }


def load_voice_config(path: Path = DEFAULT_VOICE_CONFIG_PATH) -> VoiceConfig:
    path = Path(path)
    if not path.exists():
        return VoiceConfig()
    try:
        with path.open("r", encoding="utf-8") as f:
            raw = json.load(f)
    except (json.JSONDecodeError, OSError):
        return VoiceConfig()
    return VoiceConfig(
        default_voice_id=raw.get("default_voice_id", ""),
        language_default_voice_id=raw.get("language_default_voice_id", {}) or {},
        roles=raw.get("roles", {}) or {},
    )


def save_voice_config(config: VoiceConfig, path: Path = DEFAULT_VOICE_CONFIG_PATH) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(config.to_dict(), f, ensure_ascii=False, indent=2)
