"""
audio_processor.py
===================
Voice Clone용 샘플을 만들기 위한 오디오 가공 유틸리티.

- 무음 구간 제거
- 음량 정규화 / 지나치게 작은 음량 보정
- 모노 변환 / 샘플레이트 통일
- 여러 파일을 하나로 병합 (파일 간 짧은 무음 삽입)
- 중복 파일 제거 (파일 해시 기준)
- WAV 변환

원본 파일은 절대 변경/삭제하지 않는다. 모든 결과물은 별도 출력 경로에 저장한다.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple

from pydub import AudioSegment
from pydub.silence import detect_nonsilent

DEFAULT_SAMPLE_RATE = 44100
DEFAULT_CHANNELS = 1  # mono
DEFAULT_TARGET_DBFS = -20.0
DEFAULT_SILENCE_THRESH_OFFSET = 16  # dBFS below average -> considered silence
DEFAULT_MIN_SILENCE_LEN_MS = 350
DEFAULT_GAP_BETWEEN_FILES_MS = 400
MIN_CLONE_SAMPLE_FILE_SECONDS = 1.0


@dataclass
class ProcessedFileResult:
    source_path: str
    included: bool
    reason: str
    original_duration_seconds: float = 0.0
    processed_duration_seconds: float = 0.0
    file_hash: Optional[str] = None


@dataclass
class MergeResult:
    role: str
    output_path: Optional[str]
    used_files: List[str] = field(default_factory=list)
    excluded_files: List[Tuple[str, str]] = field(default_factory=list)  # (path, reason)
    total_duration_seconds: float = 0.0
    file_details: List[ProcessedFileResult] = field(default_factory=list)


def _file_hash(path: Path) -> str:
    """중복 파일 판별용 해시 (파일 바이트 기준 SHA-1)."""
    h = hashlib.sha1()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def load_audio(path: Path) -> AudioSegment:
    return AudioSegment.from_file(str(path))


def remove_silence(
    segment: AudioSegment,
    min_silence_len_ms: int = DEFAULT_MIN_SILENCE_LEN_MS,
    silence_thresh_offset: float = DEFAULT_SILENCE_THRESH_OFFSET,
    keep_padding_ms: int = 80,
) -> AudioSegment:
    """무음 구간을 제거하고 음성이 있는 구간만 이어붙인다."""
    if len(segment) == 0:
        return segment
    silence_thresh = segment.dBFS - silence_thresh_offset if segment.dBFS != float("-inf") else -50.0
    nonsilent_ranges = detect_nonsilent(
        segment, min_silence_len=min_silence_len_ms, silence_thresh=silence_thresh
    )
    if not nonsilent_ranges:
        return segment  # 전부 무음으로 판정되면 원본 유지 (과도한 삭제 방지)

    trimmed = AudioSegment.empty()
    for start, end in nonsilent_ranges:
        start = max(0, start - keep_padding_ms)
        end = min(len(segment), end + keep_padding_ms)
        trimmed += segment[start:end]
    return trimmed


def normalize_volume(segment: AudioSegment, target_dbfs: float = DEFAULT_TARGET_DBFS) -> AudioSegment:
    """평균 음량을 target_dbfs 로 맞춘다 (지나치게 작은 음량 보정 포함)."""
    if segment.dBFS == float("-inf"):
        return segment  # 완전 무음 -> 정규화 불가
    change = target_dbfs - segment.dBFS
    return segment.apply_gain(change)


def to_mono(segment: AudioSegment) -> AudioSegment:
    return segment.set_channels(DEFAULT_CHANNELS)


def resample(segment: AudioSegment, sample_rate: int = DEFAULT_SAMPLE_RATE) -> AudioSegment:
    return segment.set_frame_rate(sample_rate)


def prepare_segment(path: Path) -> AudioSegment:
    """단일 파일을 병합에 적합한 형태(모노/샘플레이트/정규화/무음제거)로 가공한다."""
    seg = load_audio(path)
    seg = to_mono(seg)
    seg = resample(seg)
    seg = remove_silence(seg)
    seg = normalize_volume(seg)
    return seg


def is_clipping(segment: AudioSegment, threshold: float = -0.1) -> bool:
    """0dBFS 근접 샘플이 많아 클리핑이 의심되는지 간이 판정."""
    try:
        return segment.max_dBFS >= threshold
    except Exception:
        return False


def merge_role_samples(
    role: str,
    file_paths: List[Path],
    output_path: Path,
    min_file_seconds: float = 0.5,
    max_file_seconds: float = 30.0,
    gap_ms: int = DEFAULT_GAP_BETWEEN_FILES_MS,
    dedup: bool = True,
) -> MergeResult:
    """
    캐릭터(role)의 여러 한국어 음성파일을 하나의 Voice Clone 샘플(WAV)로 병합한다.
    - 무음 제거 / 음량 정규화 / 모노 변환 / 샘플레이트 통일 적용
    - 너무 짧은 파일 제외
    - 중복 파일(동일 해시) 제외
    - 원본 파일은 절대 변경하지 않음
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    result = MergeResult(role=role, output_path=None)
    seen_hashes: set[str] = set()
    combined = AudioSegment.empty()
    gap = AudioSegment.silent(duration=gap_ms)

    for path in file_paths:
        path = Path(path)
        detail = ProcessedFileResult(source_path=str(path), included=False, reason="")

        if not path.exists():
            detail.reason = "파일이 존재하지 않음"
            result.excluded_files.append((str(path), detail.reason))
            result.file_details.append(detail)
            continue

        try:
            file_hash = _file_hash(path)
        except OSError as exc:
            detail.reason = f"파일 읽기 오류: {exc}"
            result.excluded_files.append((str(path), detail.reason))
            result.file_details.append(detail)
            continue

        detail.file_hash = file_hash
        if dedup and file_hash in seen_hashes:
            detail.reason = "중복 파일 (이미 포함된 파일과 동일)"
            result.excluded_files.append((str(path), detail.reason))
            result.file_details.append(detail)
            continue

        try:
            raw = load_audio(path)
        except Exception as exc:
            detail.reason = f"오디오 디코딩 실패 (손상된 파일로 추정): {exc}"
            result.excluded_files.append((str(path), detail.reason))
            result.file_details.append(detail)
            continue

        detail.original_duration_seconds = round(len(raw) / 1000.0, 3)

        if detail.original_duration_seconds < min_file_seconds:
            detail.reason = f"너무 짧음 ({detail.original_duration_seconds:.2f}초 < {min_file_seconds}초)"
            result.excluded_files.append((str(path), detail.reason))
            result.file_details.append(detail)
            continue

        if detail.original_duration_seconds > max_file_seconds:
            detail.reason = f"너무 김 ({detail.original_duration_seconds:.2f}초 > {max_file_seconds}초) - 확인 필요"
            result.excluded_files.append((str(path), detail.reason))
            result.file_details.append(detail)
            continue

        processed = to_mono(raw)
        processed = resample(processed)
        processed = remove_silence(processed)
        processed = normalize_volume(processed)

        if len(processed) / 1000.0 < min_file_seconds:
            detail.reason = "무음 제거 후 길이가 너무 짧아짐"
            result.excluded_files.append((str(path), detail.reason))
            result.file_details.append(detail)
            continue

        if len(combined) > 0:
            combined += gap
        combined += processed

        detail.included = True
        detail.reason = "포함됨"
        detail.processed_duration_seconds = round(len(processed) / 1000.0, 3)
        seen_hashes.add(file_hash)
        result.used_files.append(str(path))
        result.file_details.append(detail)

    if len(combined) == 0:
        result.total_duration_seconds = 0.0
        return result

    combined.export(str(output_path), format="wav")
    result.output_path = str(output_path)
    result.total_duration_seconds = round(len(combined) / 1000.0, 3)
    return result
