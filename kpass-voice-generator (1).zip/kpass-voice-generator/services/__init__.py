"""K-PASS Voice Generator - services package."""
