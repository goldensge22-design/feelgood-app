"""
elevenlabs_tts_service.py
===========================
등록된 Role별 Voice ID를 이용해 번역된 대사를 ElevenLabs TTS API로 생성한다.
기존 generate_voice.py(고정 Voice 이름 기반)의 기능을 유지하면서,
Voice Clone으로 등록된 Role Voice ID / 언어별 우선순위(voice_config_manager)를
함께 지원하도록 확장한 버전이다.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import requests

from services.voice_config_manager import VoiceConfig

ELEVENLABS_BASE_URL = "https://api.elevenlabs.io/v1"
TTS_ENDPOINT_TEMPLATE = ELEVENLABS_BASE_URL + "/text-to-speech/{voice_id}"
REQUEST_TIMEOUT_SECONDS = 60


@dataclass
class TtsVoiceSettings:
    stability: float = 0.5
    similarity_boost: float = 0.75
    style: float = 0.0
    speed: float = 1.0
    use_speaker_boost: bool = True

    def to_api_dict(self) -> dict:
        return {
            "stability": self.stability,
            "similarity_boost": self.similarity_boost,
            "style": self.style,
            "speed": self.speed,
            "use_speaker_boost": self.use_speaker_boost,
        }


@dataclass
class TtsGenerationTask:
    code: str
    role: str
    language: str
    text: str
    voice_id: Optional[str]
    korean_reference_path: Optional[str] = None


@dataclass
class TtsGenerationResult:
    task: TtsGenerationTask
    success: bool
    output_path: Optional[str] = None
    error: str = ""
    generated_duration_seconds: Optional[float] = None
    korean_duration_seconds: Optional[float] = None
    duration_ratio: Optional[float] = None


def request_tts_audio(
    api_key: str,
    voice_id: str,
    text: str,
    model_id: str = "eleven_multilingual_v2",
    voice_settings: Optional[TtsVoiceSettings] = None,
    max_retries: int = 3,
    retry_delay: float = 2.0,
    logger: Optional[logging.Logger] = None,
) -> Optional[bytes]:
    """ElevenLabs TTS API 호출. 성공 시 오디오 바이트, 실패 시 None."""
    url = TTS_ENDPOINT_TEMPLATE.format(voice_id=voice_id)
    headers = {"xi-api-key": api_key, "Content-Type": "application/json", "Accept": "audio/mpeg"}
    payload = {
        "text": text,
        "model_id": model_id,
        "voice_settings": (voice_settings or TtsVoiceSettings()).to_api_dict(),
    }

    last_error = ""
    for attempt in range(1, max_retries + 1):
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=REQUEST_TIMEOUT_SECONDS)
        except requests.exceptions.RequestException as exc:
            last_error = f"네트워크 오류: {exc}"
        else:
            if response.status_code == 200:
                return response.content
            try:
                detail = response.json()
            except ValueError:
                detail = response.text[:300]
            last_error = f"HTTP {response.status_code}: {detail}"

        if logger:
            logger.warning("TTS 시도 %d/%d 실패: %s", attempt, max_retries, last_error)
        if attempt < max_retries:
            time.sleep(retry_delay)

    if logger:
        logger.error("TTS 최종 실패: %s", last_error)
    return None


def build_tasks_from_entries(
    entries,
    voice_config: VoiceConfig,
    languages: list[str],
    korean_audio_index: Optional[dict] = None,
) -> list[TtsGenerationTask]:
    """DialogueEntry 리스트로부터 언어별 TtsGenerationTask 목록을 만든다."""
    tasks: list[TtsGenerationTask] = []
    korean_audio_index = korean_audio_index or {}

    for entry in entries:
        role = entry.role or "Unknown"
        for language in languages:
            text = entry.translations.get(language)
            if not text:
                continue
            voice_id = voice_config.resolve_voice_id(role, language)
            korean_path = korean_audio_index.get(entry.code)
            tasks.append(
                TtsGenerationTask(
                    code=entry.code,
                    role=role,
                    language=language,
                    text=text,
                    voice_id=voice_id,
                    korean_reference_path=korean_path,
                )
            )
    return tasks


def _get_duration_seconds(path: Path) -> Optional[float]:
    try:
        from pydub.utils import mediainfo

        info = mediainfo(str(path))
        d = info.get("duration")
        return float(d) if d else None
    except Exception:
        return None


def generate_task(
    api_key: str,
    task: TtsGenerationTask,
    output_folder: Path,
    model_id: str = "eleven_multilingual_v2",
    voice_settings: Optional[TtsVoiceSettings] = None,
    max_retries: int = 3,
    retry_delay: float = 2.0,
    logger: Optional[logging.Logger] = None,
    dry_run: bool = False,
    skip_existing: bool = True,
) -> TtsGenerationResult:
    language_folder = Path(output_folder) / task.language
    language_folder.mkdir(parents=True, exist_ok=True)
    output_path = language_folder / f"{task.code}.mp3"

    if skip_existing and output_path.exists():
        return TtsGenerationResult(task=task, success=True, output_path=str(output_path), error="이미 존재 (SKIP)")

    if not task.voice_id:
        return TtsGenerationResult(task=task, success=False, error=f"Voice ID를 찾을 수 없음 (Role={task.role})")

    if dry_run:
        return TtsGenerationResult(task=task, success=True, output_path=str(output_path), error="DRY-RUN")

    audio_bytes = request_tts_audio(
        api_key, task.voice_id, task.text, model_id, voice_settings, max_retries, retry_delay, logger
    )
    if audio_bytes is None:
        return TtsGenerationResult(task=task, success=False, error="API 호출 실패 (로그 확인)")

    output_path.write_bytes(audio_bytes)

    generated_duration = _get_duration_seconds(output_path)
    korean_duration = _get_duration_seconds(Path(task.korean_reference_path)) if task.korean_reference_path else None
    ratio = None
    if generated_duration and korean_duration:
        ratio = round(generated_duration / korean_duration, 3)

    return TtsGenerationResult(
        task=task,
        success=True,
        output_path=str(output_path),
        generated_duration_seconds=generated_duration,
        korean_duration_seconds=korean_duration,
        duration_ratio=ratio,
    )


# ---------------------------------------------------------------------------
# 섹션 11: 문장 길이/속도 보정
# ---------------------------------------------------------------------------

SPEED_ADJUST_MIN = 0.85
SPEED_ADJUST_MAX = 1.2


def suggest_speed_for_target_length(
    korean_duration_seconds: float,
    generated_duration_seconds: float,
    current_speed: float = 1.0,
    mode: str = "natural",  # "natural" | "match_korean" | "custom"
    target_duration_seconds: Optional[float] = None,
) -> dict:
    """
    목표 길이에 맞추기 위한 권장 Speed 값을 계산한다.
    음질 손상이 심할 정도의 극단적인 조정은 피하고, 허용 범위를 벗어나면 경고를 포함한다.
    """
    if mode == "natural" or generated_duration_seconds <= 0:
        return {"suggested_speed": current_speed, "clamped": False, "warning": None}

    if mode == "match_korean":
        target = korean_duration_seconds
    elif mode == "custom" and target_duration_seconds:
        target = target_duration_seconds
    else:
        target = korean_duration_seconds

    if target <= 0:
        return {"suggested_speed": current_speed, "clamped": False, "warning": "목표 길이가 유효하지 않습니다."}

    ratio = generated_duration_seconds / target
    raw_suggested_speed = round(current_speed * ratio, 3)

    clamped = False
    suggested = raw_suggested_speed
    if suggested < SPEED_ADJUST_MIN:
        suggested = SPEED_ADJUST_MIN
        clamped = True
    elif suggested > SPEED_ADJUST_MAX:
        suggested = SPEED_ADJUST_MAX
        clamped = True

    warning = None
    if clamped:
        warning = (
            f"목표 길이에 맞추려면 Speed={raw_suggested_speed}가 필요하지만, "
            f"음질 손상을 방지하기 위해 {SPEED_ADJUST_MIN}~{SPEED_ADJUST_MAX} 범위로 제한했습니다."
        )

    return {"suggested_speed": suggested, "clamped": clamped, "warning": warning}
