"""
audio_scanner.py
=================
사용자가 선택한 한국어 음성 폴더를 스캔하여 mp3/wav 파일 목록을 만들고,
각 파일에 대해 Role 추정, 길이 계산, Code 추출을 수행한다.

원본 파일은 어떤 경우에도 이동/수정/삭제하지 않는다 (읽기 전용 스캔).
"""

from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Optional

from services.role_detector import (
    RoleDetectionResult,
    build_code_from_filename,
    detect_role_from_filename,
    load_role_mapping,
)

SUPPORTED_EXTENSIONS = {".mp3", ".wav", ".m4a", ".flac", ".ogg"}


@dataclass
class ScannedAudioFile:
    file_name: str
    file_path: str
    code: str
    role: str
    role_raw: Optional[str]
    is_unknown: bool
    duration_seconds: float
    file_size_bytes: int
    status: str  # "ok" | "corrupt" | "too_short"
    excluded: bool = False
    selected: bool = True
    user_role_override: Optional[str] = None
    note: str = ""

    def effective_role(self) -> str:
        return self.user_role_override or self.role

    def to_dict(self) -> dict:
        return asdict(self)


def _get_duration_seconds(path: Path) -> float:
    """오디오 길이를 계산한다. pydub(ffmpeg)를 사용하며 실패 시 0.0을 반환한다."""
    try:
        from pydub import AudioSegment
        from pydub.utils import mediainfo

        info = mediainfo(str(path))
        duration = info.get("duration")
        if duration:
            return float(duration)
        # fallback: 실제 로드
        seg = AudioSegment.from_file(str(path))
        return len(seg) / 1000.0
    except Exception:
        return 0.0


def scan_korean_audio_folder(
    folder: Path,
    role_mapping_path: Optional[Path] = None,
    min_duration_seconds: float = 0.3,
) -> List[ScannedAudioFile]:
    """
    폴더(하위 폴더 포함)를 재귀적으로 스캔하여 지원되는 오디오 파일 목록을 반환한다.
    파일은 절대 수정/이동/삭제하지 않는다.
    """
    folder = Path(folder)
    if not folder.exists() or not folder.is_dir():
        raise FileNotFoundError(f"폴더를 찾을 수 없습니다: {folder}")

    role_mapping: Dict[str, str] = load_role_mapping(role_mapping_path) if role_mapping_path else load_role_mapping()

    results: List[ScannedAudioFile] = []
    for path in sorted(folder.rglob("*")):
        if not path.is_file():
            continue
        if path.suffix.lower() not in SUPPORTED_EXTENSIONS:
            continue

        detection: RoleDetectionResult = detect_role_from_filename(path.name, role_mapping)
        code = build_code_from_filename(path.name)

        try:
            size_bytes = path.stat().st_size
        except OSError:
            size_bytes = 0

        if size_bytes == 0:
            results.append(
                ScannedAudioFile(
                    file_name=path.name, file_path=str(path), code=code,
                    role=detection.role, role_raw=detection.role_raw,
                    is_unknown=detection.is_unknown, duration_seconds=0.0,
                    file_size_bytes=0, status="corrupt", excluded=True,
                    selected=False, note="파일 크기 0바이트 (손상 또는 업로드 실패로 추정)",
                )
            )
            continue

        duration = _get_duration_seconds(path)
        status = "ok"
        note = ""
        if duration <= 0.0:
            status = "corrupt"
            note = "오디오 길이를 읽을 수 없음 (손상된 파일일 수 있음)"
        elif duration < min_duration_seconds:
            status = "too_short"
            note = f"길이가 너무 짧음 ({duration:.2f}초 < {min_duration_seconds}초)"

        results.append(
            ScannedAudioFile(
                file_name=path.name,
                file_path=str(path),
                code=code,
                role=detection.role,
                role_raw=detection.role_raw,
                is_unknown=detection.is_unknown,
                duration_seconds=round(duration, 3),
                file_size_bytes=size_bytes,
                status=status,
                excluded=(status != "ok"),
                selected=(status == "ok"),
                note=note,
            )
        )

    return results


def group_by_role(files: List[ScannedAudioFile]) -> Dict[str, List[ScannedAudioFile]]:
    """Role 기준으로 파일 목록을 그룹화한다 (Unknown 포함)."""
    groups: Dict[str, List[ScannedAudioFile]] = {}
    for f in files:
        role = f.effective_role() or "Unknown"
        groups.setdefault(role, []).append(f)
    return groups


def save_scan_report(files: List[ScannedAudioFile], output_path: Path) -> None:
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as f:
        json.dump([x.to_dict() for x in files], f, ensure_ascii=False, indent=2)
