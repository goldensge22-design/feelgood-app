"""
elevenlabs_clone_service.py
=============================
Voice Clone 생성을 지원하는 두 가지 방식.

방식 A (수동): 프로그램은 Clone용 샘플 파일만 생성하고, 사용자가
    ElevenLabs 웹사이트에서 직접 Voice Clone을 만든 뒤 Voice ID를 입력한다.
    -> 이 모듈에서는 "Voice가 유효한지 확인"과 "테스트 음성 생성" 기능만 제공.

방식 B (API): 계정이 API를 통한 Voice Clone 생성(Instant/Professional Voice
    Cloning, POST /v1/voices/add)을 지원하는 경우 여기서 직접 호출한다.
    권한/요금제 문제로 실패해도 프로그램 전체가 중단되지 않도록
    모든 예외를 잡아 CloneApiResult로 반환한다.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import requests

ELEVENLABS_BASE_URL = "https://api.elevenlabs.io/v1"
VOICES_ADD_ENDPOINT = ELEVENLABS_BASE_URL + "/voices/add"
VOICES_ENDPOINT = ELEVENLABS_BASE_URL + "/voices"
TTS_ENDPOINT_TEMPLATE = ELEVENLABS_BASE_URL + "/text-to-speech/{voice_id}"

API_CLONE_UNAVAILABLE_MESSAGE = (
    "현재 계정에서는 API를 통한 Voice Clone 생성이 지원되지 않습니다. "
    "생성된 샘플 파일을 ElevenLabs 웹사이트에 업로드한 후 Voice ID를 등록해 주세요."
)


@dataclass
class CloneApiResult:
    success: bool
    voice_id: Optional[str] = None
    message: str = ""
    raw_response: Optional[dict] = None


@dataclass
class VoiceCheckResult:
    valid: bool
    voice_id: str
    name: Optional[str] = None
    message: str = ""


def create_voice_clone_via_api(
    api_key: str,
    role: str,
    sample_file_path: Path,
    description: str = "",
    timeout: int = 60,
) -> CloneApiResult:
    """
    ElevenLabs API로 Voice Clone 생성을 시도한다 (POST /v1/voices/add).
    계정 권한/요금제 제한으로 실패해도 예외를 던지지 않고 CloneApiResult로 안내한다.
    """
    sample_file_path = Path(sample_file_path)
    if not sample_file_path.exists():
        return CloneApiResult(success=False, message=f"샘플 파일을 찾을 수 없습니다: {sample_file_path}")

    try:
        with sample_file_path.open("rb") as f:
            files = {"files": (sample_file_path.name, f, "audio/wav")}
            data = {"name": role, "description": description or f"K-PASS Role: {role}"}
            headers = {"xi-api-key": api_key}
            response = requests.post(
                VOICES_ADD_ENDPOINT, headers=headers, data=data, files=files, timeout=timeout
            )
    except requests.exceptions.RequestException as exc:
        return CloneApiResult(success=False, message=f"네트워크 오류: {exc}")

    if response.status_code == 200:
        try:
            body = response.json()
        except ValueError:
            body = {}
        voice_id = body.get("voice_id")
        if voice_id:
            return CloneApiResult(success=True, voice_id=voice_id, message="Voice Clone 생성 성공", raw_response=body)
        return CloneApiResult(success=False, message="응답에 voice_id가 없습니다.", raw_response=body)

    if response.status_code in (401, 403):
        return CloneApiResult(success=False, message=API_CLONE_UNAVAILABLE_MESSAGE)

    if response.status_code == 422:
        return CloneApiResult(
            success=False,
            message=f"요청 형식 오류(422) - 계정 요금제에서 Voice Clone API를 지원하지 않을 수 있습니다. {API_CLONE_UNAVAILABLE_MESSAGE}",
        )

    try:
        detail = response.json()
    except ValueError:
        detail = response.text[:300]
    return CloneApiResult(success=False, message=f"HTTP {response.status_code}: {detail}")


def verify_voice_id(api_key: str, voice_id: str, timeout: int = 30) -> VoiceCheckResult:
    """등록된 Voice ID가 실제 계정에 존재하는지 확인한다."""
    if not voice_id:
        return VoiceCheckResult(valid=False, voice_id=voice_id, message="Voice ID가 비어 있습니다.")
    try:
        response = requests.get(
            f"{VOICES_ENDPOINT}/{voice_id}", headers={"xi-api-key": api_key}, timeout=timeout
        )
    except requests.exceptions.RequestException as exc:
        return VoiceCheckResult(valid=False, voice_id=voice_id, message=f"네트워크 오류: {exc}")

    if response.status_code == 200:
        body = response.json()
        return VoiceCheckResult(valid=True, voice_id=voice_id, name=body.get("name"), message="연결 확인됨")
    if response.status_code == 404:
        return VoiceCheckResult(valid=False, voice_id=voice_id, message="해당 Voice ID를 계정에서 찾을 수 없습니다.")
    return VoiceCheckResult(valid=False, voice_id=voice_id, message=f"HTTP {response.status_code}")


def generate_test_audio(
    api_key: str,
    voice_id: str,
    text: str,
    model_id: str = "eleven_multilingual_v2",
    output_path: Optional[Path] = None,
    timeout: int = 60,
) -> Optional[Path]:
    """등록된 Voice ID로 짧은 테스트 문장을 생성하여 파일로 저장한다. 실패 시 None."""
    url = TTS_ENDPOINT_TEMPLATE.format(voice_id=voice_id)
    headers = {"xi-api-key": api_key, "Content-Type": "application/json", "Accept": "audio/mpeg"}
    payload = {"text": text, "model_id": model_id}
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=timeout)
    except requests.exceptions.RequestException:
        return None
    if response.status_code != 200:
        return None
    if output_path is None:
        output_path = Path("logs") / f"voice_test_{voice_id}.mp3"
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_bytes(response.content)
    return output_path
