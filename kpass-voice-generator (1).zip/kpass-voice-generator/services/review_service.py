"""
review_service.py
===================
검수 단계(승인/재생성/검수 메모)의 상태를 JSON 파일로 관리하고,
Voice Clone 실행 전 동의(체크박스) 확인 로그를 기록한다.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional


@dataclass
class ReviewEntry:
    code: str
    language: str
    role: str
    status: str = "pending"  # "pending" | "approved" | "needs_regeneration"
    note: str = ""
    updated_at: str = ""

    def key(self) -> str:
        return f"{self.code}|{self.language}"


class ReviewStore:
    """검수 상태를 로컬 JSON 파일에 저장/로드한다."""

    def __init__(self, path: Path):
        self.path = Path(path)
        self.entries: Dict[str, ReviewEntry] = {}
        self._load()

    def _load(self) -> None:
        if not self.path.exists():
            return
        try:
            with self.path.open("r", encoding="utf-8") as f:
                raw = json.load(f)
            for item in raw.get("entries", []):
                entry = ReviewEntry(**item)
                self.entries[entry.key()] = entry
        except (json.JSONDecodeError, OSError, TypeError):
            self.entries = {}

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("w", encoding="utf-8") as f:
            json.dump({"entries": [e.__dict__ for e in self.entries.values()]}, f, ensure_ascii=False, indent=2)

    def set_status(self, code: str, language: str, role: str, status: str, note: str = "") -> ReviewEntry:
        key = f"{code}|{language}"
        entry = self.entries.get(key) or ReviewEntry(code=code, language=language, role=role)
        entry.status = status
        if note:
            entry.note = note
        entry.updated_at = datetime.now().isoformat(timespec="seconds")
        self.entries[key] = entry
        self.save()
        return entry

    def get_status(self, code: str, language: str) -> Optional[ReviewEntry]:
        return self.entries.get(f"{code}|{language}")

    def failed_or_pending(self) -> List[ReviewEntry]:
        return [e for e in self.entries.values() if e.status in ("pending", "needs_regeneration")]


# ---------------------------------------------------------------------------
# Voice Clone 동의 로그 (섹션 6)
# ---------------------------------------------------------------------------

CONSENT_LOG_FILENAME = "consent_log.json"


def record_consent(log_folder: Path, role: str, agreed: bool) -> dict:
    """
    Voice Clone 실행 전 동의 여부와 시각을 로컬 로그에 기록한다.
    체크박스가 해제된 상태(agreed=False)에서는 호출부에서 애초에 실행을 막아야 한다.
    """
    log_folder = Path(log_folder)
    log_folder.mkdir(parents=True, exist_ok=True)
    log_path = log_folder / CONSENT_LOG_FILENAME

    records = []
    if log_path.exists():
        try:
            with log_path.open("r", encoding="utf-8") as f:
                records = json.load(f)
        except (json.JSONDecodeError, OSError):
            records = []

    record = {
        "role": role,
        "agreed": agreed,
        "timestamp": datetime.now().isoformat(timespec="seconds"),
    }
    records.append(record)

    with log_path.open("w", encoding="utf-8") as f:
        json.dump(records, f, ensure_ascii=False, indent=2)

    return record


def has_valid_consent(log_folder: Path, role: str) -> bool:
    """해당 role에 대해 마지막으로 기록된 동의 상태가 True인지 확인한다."""
    log_path = Path(log_folder) / CONSENT_LOG_FILENAME
    if not log_path.exists():
        return False
    try:
        with log_path.open("r", encoding="utf-8") as f:
            records = json.load(f)
    except (json.JSONDecodeError, OSError):
        return False

    role_records = [r for r in records if r.get("role") == role]
    if not role_records:
        return False
    return bool(role_records[-1].get("agreed"))
