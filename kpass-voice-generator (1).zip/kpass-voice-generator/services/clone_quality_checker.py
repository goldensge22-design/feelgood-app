"""
clone_quality_checker.py
=========================
Voice Clone 생성 전, 캐릭터별 병합 샘플의 품질을 점검한다.

ElevenLabs는 Voice Clone에 최소 약 1분(권장 2~3분 이상, 잡음 없는 음성)을 권장하므로
이를 기준으로 "사용 가능 / 보완 권장 / 사용 부적합"을 판정한다.
완벽한 화자 분리/노이즈 분석은 별도 ML 모델이 필요하므로, 여기서는 신호 레벨 기반의
실용적인 휴리스틱을 사용한다 (완전 자동 판정이 아닌 "참고용 경고"로 취급할 것).
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

from pydub import AudioSegment
from pydub.silence import detect_nonsilent

MIN_DURATION_FOR_USABLE = 60.0     # 60초 이상 -> 사용 가능
MIN_DURATION_FOR_ACCEPTABLE = 25.0  # 25~60초 -> 보완 권장
# 25초 미만 -> 사용 부적합

CLIPPING_DBFS_THRESHOLD = -0.1
LOW_VOLUME_DBFS_THRESHOLD = -35.0
HIGH_SILENCE_RATIO_THRESHOLD = 0.35


@dataclass
class QualityReport:
    role: str
    sample_path: Optional[str]
    total_duration_seconds: float
    used_file_count: int
    excluded_file_count: int
    average_dbfs: Optional[float]
    silence_ratio: Optional[float]
    is_clipping: bool
    possible_heavy_noise: bool
    possible_multiple_speakers: bool
    status: str  # "사용 가능" | "보완 권장" | "사용 부적합"
    messages: List[str]


def _silence_ratio(segment: AudioSegment) -> float:
    if len(segment) == 0:
        return 1.0
    thresh = segment.dBFS - 16 if segment.dBFS != float("-inf") else -50.0
    nonsilent = detect_nonsilent(segment, min_silence_len=300, silence_thresh=thresh)
    voiced_ms = sum(end - start for start, end in nonsilent)
    return max(0.0, 1.0 - (voiced_ms / len(segment)))


def _possible_multiple_speakers(segment: AudioSegment, chunk_ms: int = 5000) -> bool:
    """
    간이 휴리스틱: 오디오를 여러 구간으로 나눠 평균 dBFS 편차가 매우 크면
    서로 다른 화자/녹음 환경이 섞였을 가능성을 경고한다. (정확한 화자 분리 아님)
    """
    if len(segment) < chunk_ms * 2:
        return False
    levels = []
    for start in range(0, len(segment), chunk_ms):
        chunk = segment[start:start + chunk_ms]
        if len(chunk) > 500 and chunk.dBFS != float("-inf"):
            levels.append(chunk.dBFS)
    if len(levels) < 3:
        return False
    spread = max(levels) - min(levels)
    return spread > 18.0


def check_role_sample_quality(
    role: str,
    sample_path: Optional[Path],
    used_file_count: int,
    excluded_file_count: int,
) -> QualityReport:
    messages: List[str] = []

    if not sample_path or not Path(sample_path).exists():
        return QualityReport(
            role=role, sample_path=None, total_duration_seconds=0.0,
            used_file_count=used_file_count, excluded_file_count=excluded_file_count,
            average_dbfs=None, silence_ratio=None, is_clipping=False,
            possible_heavy_noise=False, possible_multiple_speakers=False,
            status="사용 부적합",
            messages=["병합된 샘플 파일이 없습니다. 원본 음성을 확인하세요."],
        )

    segment = AudioSegment.from_file(str(sample_path))
    duration = len(segment) / 1000.0
    avg_dbfs = segment.dBFS if segment.dBFS != float("-inf") else None
    sil_ratio = _silence_ratio(segment)
    clipping = segment.max_dBFS >= CLIPPING_DBFS_THRESHOLD if segment.max_dBFS is not None else False
    heavy_noise = bool(avg_dbfs is not None and avg_dbfs < LOW_VOLUME_DBFS_THRESHOLD)
    multi_speaker = _possible_multiple_speakers(segment)

    if duration < MIN_DURATION_FOR_ACCEPTABLE:
        messages.append(f"전체 길이({duration:.1f}초)가 너무 짧습니다. 최소 {MIN_DURATION_FOR_ACCEPTABLE:.0f}초 이상 권장합니다.")
    if clipping:
        messages.append("클리핑(음량 과다)이 감지되었습니다. 원본 녹음 품질을 확인하세요.")
    if heavy_noise:
        messages.append("평균 음량이 매우 낮습니다. 배경 잡음이 심하거나 마이크 게인이 낮을 수 있습니다.")
    if sil_ratio is not None and sil_ratio > HIGH_SILENCE_RATIO_THRESHOLD:
        messages.append(f"무음 비율이 높습니다 ({sil_ratio * 100:.0f}%). 유효 음성 분량이 부족할 수 있습니다.")
    if multi_speaker:
        messages.append("구간별 음량/특성 편차가 커서 여러 화자 또는 다른 녹음 환경이 섞였을 가능성이 있습니다. 직접 청취 확인을 권장합니다.")
    if excluded_file_count > 0:
        messages.append(f"{excluded_file_count}개 파일이 병합에서 제외되었습니다. 상세 내용은 매니페스트를 확인하세요.")

    if duration >= MIN_DURATION_FOR_USABLE and not clipping and not heavy_noise:
        status = "사용 가능"
    elif duration >= MIN_DURATION_FOR_ACCEPTABLE:
        status = "보완 권장"
    else:
        status = "사용 부적합"

    if not messages:
        messages.append("특이사항이 발견되지 않았습니다.")

    return QualityReport(
        role=role,
        sample_path=str(sample_path),
        total_duration_seconds=round(duration, 2),
        used_file_count=used_file_count,
        excluded_file_count=excluded_file_count,
        average_dbfs=round(avg_dbfs, 2) if avg_dbfs is not None else None,
        silence_ratio=round(sil_ratio, 3) if sil_ratio is not None else None,
        is_clipping=clipping,
        possible_heavy_noise=heavy_noise,
        possible_multiple_speakers=multi_speaker,
        status=status,
        messages=messages,
    )
