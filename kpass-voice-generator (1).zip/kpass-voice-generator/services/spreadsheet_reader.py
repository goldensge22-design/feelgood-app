"""
spreadsheet_reader.py
=======================
번역 대본 CSV/XLSX를 읽어 Code 기준으로 한국어 원본 음성과 연결한다.

지원하는 두 가지 스프레드시트 형식:

1) 기존(레거시) 롱 포맷 - generate_voice.py 호환:
   Code,Language,Voice,Text
   (언어별로 행이 분리되어 있고 Voice 이름을 직접 지정)

2) 신규 와이드 포맷 (섹션 8):
   Code,Role,Korean,Thai,English,Japanese,Chinese,Russian, ...
   (하나의 행에 Code/Role/모든 언어의 번역이 함께 있음)

reader는 두 형식을 자동 감지하여 공통 DialogueEntry 리스트로 정규화한다.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

KNOWN_LANGUAGE_COLUMNS = ["Thai", "English", "Japanese", "Chinese", "Russian", "Korean"]
LEGACY_REQUIRED_COLUMNS = {"Code", "Language", "Voice", "Text"}


@dataclass
class DialogueEntry:
    code: str
    role: Optional[str]
    korean_text: Optional[str]
    translations: Dict[str, str] = field(default_factory=dict)  # {language: text}
    voice_override: Dict[str, str] = field(default_factory=dict)  # {language: voice name} (legacy)
    row_number: int = 0


def _read_rows(path: Path) -> List[dict]:
    path = Path(path)
    suffix = path.suffix.lower()

    if suffix in (".xlsx", ".xlsm"):
        import openpyxl

        wb = openpyxl.load_workbook(str(path), data_only=True)
        ws = wb.active
        rows_iter = ws.iter_rows(values_only=True)
        headers = [str(h).strip() if h is not None else "" for h in next(rows_iter)]
        rows: List[dict] = []
        for raw in rows_iter:
            if raw is None or all(v is None for v in raw):
                continue
            row = {headers[i]: (raw[i] if i < len(raw) else None) for i in range(len(headers))}
            rows.append({k: ("" if v is None else str(v)) for k, v in row.items()})
        return rows

    # CSV (기본)
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        return [dict(row) for row in reader]


def load_dialogue_entries(path: Path) -> List[DialogueEntry]:
    """CSV/XLSX를 자동 감지하여 DialogueEntry 리스트로 정규화한다."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"스프레드시트 파일을 찾을 수 없습니다: {path}")

    rows = _read_rows(path)
    if not rows:
        return []

    fieldnames = set(rows[0].keys())

    if LEGACY_REQUIRED_COLUMNS.issubset(fieldnames):
        return _parse_legacy_format(rows)
    return _parse_wide_format(rows)


def _parse_legacy_format(rows: List[dict]) -> List[DialogueEntry]:
    """Code,Language,Voice,Text 형식을 Code 기준으로 묶어 DialogueEntry로 변환."""
    by_code: Dict[str, DialogueEntry] = {}
    for i, raw in enumerate(rows, start=2):
        code = (raw.get("Code") or "").strip()
        language = (raw.get("Language") or "").strip()
        voice = (raw.get("Voice") or "").strip()
        text = (raw.get("Text") or "").strip()
        if not code or not language or not text:
            continue
        entry = by_code.setdefault(code, DialogueEntry(code=code, role=None, korean_text=None, row_number=i))
        if language.lower() in ("korean", "ko", "한국어"):
            entry.korean_text = text
        else:
            entry.translations[language] = text
        if voice:
            entry.voice_override[language] = voice
    return list(by_code.values())


def _parse_wide_format(rows: List[dict]) -> List[DialogueEntry]:
    """Code,Role,Korean,<Language1>,<Language2>... 형식을 파싱."""
    entries: List[DialogueEntry] = []
    if not rows:
        return entries

    columns = set(rows[0].keys())
    language_columns = [c for c in columns if c in KNOWN_LANGUAGE_COLUMNS and c != "Korean"]
    # 표준 목록에 없는 추가 언어 컬럼도 지원 (Code/Role/Korean/Voice* 제외 나머지는 언어로 간주)
    reserved = {"Code", "Role", "Korean", "Notes", "Memo"}
    extra_language_columns = [
        c for c in columns if c not in reserved and c not in language_columns and not c.startswith("Voice")
    ]
    language_columns = sorted(set(language_columns) | set(extra_language_columns))

    for i, raw in enumerate(rows, start=2):
        code = (raw.get("Code") or "").strip()
        if not code:
            continue
        role = (raw.get("Role") or "").strip() or None
        korean_text = (raw.get("Korean") or "").strip() or None
        translations = {}
        for lang in language_columns:
            val = (raw.get(lang) or "").strip()
            if val:
                translations[lang] = val
        entries.append(
            DialogueEntry(code=code, role=role, korean_text=korean_text, translations=translations, row_number=i)
        )
    return entries


def index_entries_by_code(entries: List[DialogueEntry]) -> Dict[str, DialogueEntry]:
    return {e.code: e for e in entries}
