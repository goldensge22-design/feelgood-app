"""
clone_sample_builder.py
========================
Role별로 분류된 한국어 음성파일들을 audio_processor를 이용해 병합하고,
Voice Clone용 샘플 파일과 매니페스트(JSON)를 생성한다.
"""

from __future__ import annotations

import json
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Dict, List

from services.audio_processor import MergeResult, merge_role_samples
from services.audio_scanner import ScannedAudioFile


def build_clone_sample_for_role(
    role: str,
    files: List[ScannedAudioFile],
    output_dir: Path,
    manifest_dir: Path,
) -> Dict:
    """
    한 캐릭터(role)에 대해:
      1) 선택되고 제외되지 않은 파일들만 병합
      2) voice_clone_ready/<role>_clone_sample.wav 생성
      3) voice_clone_ready/manifests/<role>_clone_manifest.json 생성
    """
    output_dir = Path(output_dir)
    manifest_dir = Path(manifest_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    manifest_dir.mkdir(parents=True, exist_ok=True)

    candidate_paths = [Path(f.file_path) for f in files if f.selected and not f.excluded]
    output_path = output_dir / f"{role}_clone_sample.wav"

    merge_result: MergeResult = merge_role_samples(role, candidate_paths, output_path)

    manifest = {
        "role": role,
        "source_files": merge_result.used_files,
        "excluded_files": [{"path": p, "reason": r} for p, r in merge_result.excluded_files],
        "total_duration_seconds": merge_result.total_duration_seconds,
        "output_sample_path": merge_result.output_path,
        "created_time": datetime.now().isoformat(timespec="seconds"),
        "file_details": [asdict(d) for d in merge_result.file_details],
    }

    manifest_path = manifest_dir / f"{role}_clone_manifest.json"
    with manifest_path.open("w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)

    manifest["manifest_path"] = str(manifest_path)
    return manifest


def build_all_clone_samples(
    role_groups: Dict[str, List[ScannedAudioFile]],
    output_dir: Path,
    manifest_dir: Path,
    skip_roles: tuple = ("Unknown",),
) -> Dict[str, Dict]:
    """Unknown을 제외한 모든 role에 대해 clone sample을 일괄 생성한다."""
    results: Dict[str, Dict] = {}
    for role, files in role_groups.items():
        if role in skip_roles:
            continue
        results[role] = build_clone_sample_for_role(role, files, output_dir, manifest_dir)
    return results
