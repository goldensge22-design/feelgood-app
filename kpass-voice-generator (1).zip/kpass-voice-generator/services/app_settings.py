"""
app_settings.py
=================
프로젝트 전역 설정을 관리한다.
- .env (API Key, Model ID 등 민감/환경 정보)
- config/settings.json (출력 폴더, 로그 노출 옵션 등 일반 설정)
- API Key 마스킹 유틸리티 (로그/화면 노출 방지)
"""

from __future__ import annotations

import json
import os
import shutil
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
DEFAULT_ENV_PATH = BASE_DIR / ".env"
DEFAULT_SETTINGS_PATH = BASE_DIR / "config" / "settings.json"


@dataclass
class AppSettings:
    api_key: str = ""
    model_id: str = "eleven_multilingual_v2"
    output_folder: Path = field(default_factory=lambda: BASE_DIR / "output")
    log_folder: Path = field(default_factory=lambda: BASE_DIR / "logs")
    voice_clone_ready_folder: Path = field(default_factory=lambda: BASE_DIR / "data" / "voice_clone_ready")
    voice_clone_samples_folder: Path = field(default_factory=lambda: BASE_DIR / "data" / "voice_clone_samples")
    manifest_folder: Path = field(default_factory=lambda: BASE_DIR / "data" / "manifests")
    max_retries: int = 3
    retry_delay: float = 2.0
    expose_full_text_in_error_logs: bool = False  # 오류 로그에 대본 전체 노출 여부 (기본: 비노출)
    local_storage_path: Optional[Path] = None

    def masked_api_key(self) -> str:
        return mask_api_key(self.api_key)


def mask_api_key(api_key: str) -> str:
    if not api_key:
        return "(설정되지 않음)"
    if len(api_key) <= 8:
        return "*" * len(api_key)
    return api_key[:4] + "*" * (len(api_key) - 8) + api_key[-4:]


def load_app_settings(
    env_path: Path = DEFAULT_ENV_PATH,
    settings_path: Path = DEFAULT_SETTINGS_PATH,
) -> AppSettings:
    load_dotenv(env_path)

    settings = AppSettings(
        api_key=os.environ.get("API_KEY", "").strip(),
        model_id=os.environ.get("MODEL_ID", "eleven_multilingual_v2").strip() or "eleven_multilingual_v2",
        output_folder=Path(os.environ.get("OUTPUT_FOLDER", str(BASE_DIR / "output"))),
        log_folder=Path(os.environ.get("LOG_FOLDER", str(BASE_DIR / "logs"))),
    )

    settings_path = Path(settings_path)
    if settings_path.exists():
        try:
            with settings_path.open("r", encoding="utf-8") as f:
                raw = json.load(f)
        except (json.JSONDecodeError, OSError):
            raw = {}
        settings.voice_clone_ready_folder = Path(raw.get("voice_clone_ready_folder", str(settings.voice_clone_ready_folder)))
        settings.voice_clone_samples_folder = Path(raw.get("voice_clone_samples_folder", str(settings.voice_clone_samples_folder)))
        settings.manifest_folder = Path(raw.get("manifest_folder", str(settings.manifest_folder)))
        settings.max_retries = int(raw.get("max_retries", settings.max_retries))
        settings.retry_delay = float(raw.get("retry_delay", settings.retry_delay))
        settings.expose_full_text_in_error_logs = bool(raw.get("expose_full_text_in_error_logs", False))
        local_storage = raw.get("local_storage_path")
        settings.local_storage_path = Path(local_storage) if local_storage else None

    return settings


def save_app_settings(settings: AppSettings, settings_path: Path = DEFAULT_SETTINGS_PATH) -> None:
    settings_path = Path(settings_path)
    settings_path.parent.mkdir(parents=True, exist_ok=True)
    data = {
        "voice_clone_ready_folder": str(settings.voice_clone_ready_folder),
        "voice_clone_samples_folder": str(settings.voice_clone_samples_folder),
        "manifest_folder": str(settings.manifest_folder),
        "max_retries": settings.max_retries,
        "retry_delay": settings.retry_delay,
        "expose_full_text_in_error_logs": settings.expose_full_text_in_error_logs,
        "local_storage_path": str(settings.local_storage_path) if settings.local_storage_path else None,
    }
    with settings_path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def cleanup_temp_files(temp_dir: Optional[Path] = None) -> int:
    """임시 파일 폴더를 정리한다. 삭제된 항목 수를 반환한다. (원본 음성 폴더는 절대 건드리지 않음)"""
    temp_dir = Path(temp_dir) if temp_dir else Path(tempfile.gettempdir()) / "kpass_voice_generator_tmp"
    if not temp_dir.exists():
        return 0
    count = 0
    for item in temp_dir.glob("*"):
        try:
            if item.is_file():
                item.unlink()
            else:
                shutil.rmtree(item, ignore_errors=True)
            count += 1
        except OSError:
            continue
    return count


def sanitize_text_for_log(text: str, expose_full_text: bool = False, max_len: int = 20) -> str:
    """오류 로그에 대본 전체를 남길지 여부를 설정에 따라 제어한다."""
    if expose_full_text:
        return text
    if len(text) <= max_len:
        return text
    return text[:max_len] + f"...(총 {len(text)}자, 설정에 의해 일부만 표시)"
