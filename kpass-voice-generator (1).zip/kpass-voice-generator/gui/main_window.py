"""main_window.py - 6단계 GUI 위저드를 조립하는 메인 컨트롤러."""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from gui.app_state import AppState
from gui.clone_sample_page import CloneSamplePage
from gui.generation_page import GenerationPage
from gui.korean_audio_page import KoreanAudioPage
from gui.project_page import ProjectPage
from gui.review_page import ReviewPage
from gui.voice_registration_page import VoiceRegistrationPage

PAGE_ORDER = [
    ("project", "1. 프로젝트 설정", ProjectPage),
    ("korean_audio", "2. 한국어 음성 불러오기", KoreanAudioPage),
    ("clone_sample", "3. Clone 샘플 준비", CloneSamplePage),
    ("voice_registration", "4. Voice 등록", VoiceRegistrationPage),
    ("generation", "5. 다국어 생성", GenerationPage),
    ("review", "6. 검수", ReviewPage),
]


class MainWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("K-PASS 다국어 Voice Clone 생성기")
        self.geometry("980x720")
        self.minsize(860, 620)

        self.state_ = AppState()

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True)

        self.pages = {}
        for key, title, page_cls in PAGE_ORDER:
            frame = page_cls(self.notebook, self)
            self.notebook.add(frame, text=title)
            self.pages[key] = frame

    # AppState는 외부에서 controller.state 로 접근한다.
    @property
    def state(self) -> AppState:
        return self.state_

    def show_page(self, key: str):
        frame = self.pages.get(key)
        if frame is not None:
            self.notebook.select(frame)
            if hasattr(frame, "_refresh_role_list"):
                frame._refresh_role_list()
            if hasattr(frame, "_refresh_list") and key == "review":
                frame._refresh_list()


def run_app():
    app = MainWindow()
    app.mainloop()
