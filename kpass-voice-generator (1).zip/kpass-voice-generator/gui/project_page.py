"""project_page.py - 단계 1: 프로젝트 설정"""

from __future__ import annotations

import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from services.spreadsheet_reader import load_dialogue_entries


class ProjectPage(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, padding=16)
        self.controller = controller
        state = controller.state

        ttk.Label(self, text="1단계: 프로젝트 설정", font=("Segoe UI", 14, "bold")).grid(
            row=0, column=0, columnspan=3, sticky="w", pady=(0, 12)
        )

        ttk.Label(self, text="프로젝트 이름").grid(row=1, column=0, sticky="w", pady=4)
        self.project_name_var = tk.StringVar(value=state.project_name)
        ttk.Entry(self, textvariable=self.project_name_var, width=45).grid(row=1, column=1, columnspan=2, sticky="w")

        ttk.Label(self, text="ElevenLabs API Key").grid(row=2, column=0, sticky="w", pady=4)
        self.api_key_var = tk.StringVar(value=state.settings.api_key)
        self.api_key_entry = ttk.Entry(self, textvariable=self.api_key_var, width=45, show="*")
        self.api_key_entry.grid(row=2, column=1, sticky="w")
        self.show_key_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(self, text="표시", variable=self.show_key_var, command=self._toggle_key_visibility).grid(
            row=2, column=2, sticky="w"
        )

        ttk.Label(self, text="Model ID").grid(row=3, column=0, sticky="w", pady=4)
        self.model_id_var = tk.StringVar(value=state.settings.model_id)
        ttk.Entry(self, textvariable=self.model_id_var, width=45).grid(row=3, column=1, columnspan=2, sticky="w")

        ttk.Label(self, text="출력 폴더").grid(row=4, column=0, sticky="w", pady=4)
        self.output_folder_var = tk.StringVar(value=str(state.settings.output_folder))
        ttk.Entry(self, textvariable=self.output_folder_var, width=45).grid(row=4, column=1, sticky="w")
        ttk.Button(self, text="찾아보기", command=self._browse_output_folder).grid(row=4, column=2, sticky="w")

        ttk.Label(self, text="번역 파일 (CSV/XLSX)").grid(row=5, column=0, sticky="w", pady=4)
        self.spreadsheet_var = tk.StringVar(value=str(state.spreadsheet_path or ""))
        ttk.Entry(self, textvariable=self.spreadsheet_var, width=45).grid(row=5, column=1, sticky="w")
        ttk.Button(self, text="파일 선택", command=self._browse_spreadsheet).grid(row=5, column=2, sticky="w")

        self.status_label = ttk.Label(self, text="", foreground="green")
        self.status_label.grid(row=6, column=0, columnspan=3, sticky="w", pady=(8, 0))

        btn_row = ttk.Frame(self)
        btn_row.grid(row=7, column=0, columnspan=3, sticky="w", pady=(16, 0))
        ttk.Button(btn_row, text="설정 저장", command=self.save_settings).pack(side="left", padx=(0, 8))
        ttk.Button(btn_row, text="다음: 한국어 음성 불러오기 >", command=self._go_next).pack(side="left")

    def _toggle_key_visibility(self):
        self.api_key_entry.configure(show="" if self.show_key_var.get() else "*")

    def _browse_output_folder(self):
        folder = filedialog.askdirectory(title="출력 폴더 선택")
        if folder:
            self.output_folder_var.set(folder)

    def _browse_spreadsheet(self):
        path = filedialog.askopenfilename(
            title="번역 파일 선택", filetypes=[("Spreadsheet", "*.csv *.xlsx *.xlsm"), ("All files", "*.*")]
        )
        if path:
            self.spreadsheet_var.set(path)
            self._load_spreadsheet(path)

    def _load_spreadsheet(self, path: str):
        try:
            entries = load_dialogue_entries(Path(path))
        except Exception as exc:
            messagebox.showerror("오류", f"번역 파일을 읽는 중 오류가 발생했습니다:\n{exc}")
            return
        self.controller.state.dialogue_entries = entries
        self.controller.state.spreadsheet_path = Path(path)
        self.status_label.configure(text=f"번역 파일 로드 완료: {len(entries)}개 대사 항목")

    def save_settings(self):
        state = self.controller.state
        state.project_name = self.project_name_var.get().strip() or state.project_name
        state.settings.api_key = self.api_key_var.get().strip()
        state.settings.model_id = self.model_id_var.get().strip() or "eleven_multilingual_v2"
        state.settings.output_folder = Path(self.output_folder_var.get().strip() or state.settings.output_folder)
        self.status_label.configure(text="설정이 저장되었습니다. (.env 저장은 '환경설정 내보내기'에서 가능)")

    def _go_next(self):
        self.save_settings()
        self.controller.show_page("korean_audio")
