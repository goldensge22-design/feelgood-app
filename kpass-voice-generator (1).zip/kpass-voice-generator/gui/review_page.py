"""review_page.py - 단계 6: 검수 (원본/생성 음성 비교, 승인, 재생성, 메모)"""

from __future__ import annotations

import subprocess
import sys
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk

from services.elevenlabs_tts_service import (
    TtsVoiceSettings,
    build_tasks_from_entries,
    generate_task,
)
from services.review_service import ReviewStore


class ReviewPage(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, padding=16)
        self.controller = controller
        self.review_store: ReviewStore | None = None

        ttk.Label(self, text="6단계: 검수", font=("Segoe UI", 14, "bold")).pack(anchor="w", pady=(0, 12))

        columns = ("code", "role", "language", "status", "note")
        self.tree = ttk.Treeview(self, columns=columns, show="headings", height=16)
        headers = {"code": "Code", "role": "Role", "language": "언어", "status": "검수 상태", "note": "검수 메모"}
        for col in columns:
            self.tree.heading(col, text=headers[col])
            self.tree.column(col, width=150, anchor="w")
        self.tree.pack(fill="both", expand=True, pady=(0, 8))
        self.tree.bind("<<TreeviewSelect>>", self._on_select)

        control_row = ttk.Frame(self)
        control_row.pack(fill="x")
        ttk.Button(control_row, text="목록 새로고침", command=self._refresh_list).pack(side="left")
        ttk.Button(control_row, text="한국어 원본 재생", command=self._play_korean).pack(side="left", padx=(8, 0))
        ttk.Button(control_row, text="생성 음성 재생", command=self._play_generated).pack(side="left", padx=(8, 0))
        ttk.Button(control_row, text="승인", command=lambda: self._set_status("approved")).pack(side="left", padx=(8, 0))
        ttk.Button(control_row, text="재생성 필요 표시", command=lambda: self._set_status("needs_regeneration")).pack(
            side="left", padx=(8, 0)
        )
        ttk.Button(control_row, text="선택 항목 재생성", command=self._regenerate_selected).pack(side="left", padx=(8, 0))
        ttk.Button(control_row, text="실패/대기 항목 일괄 재생성", command=self._regenerate_all_pending).pack(
            side="left", padx=(8, 0)
        )

        note_row = ttk.Frame(self)
        note_row.pack(fill="x", pady=(8, 0))
        ttk.Label(note_row, text="검수 메모:").pack(side="left")
        self.note_var = tk.StringVar()
        ttk.Entry(note_row, textvariable=self.note_var, width=60).pack(side="left", padx=(6, 6))
        ttk.Button(note_row, text="메모 저장", command=self._save_note).pack(side="left")

        nav_row = ttk.Frame(self)
        nav_row.pack(fill="x", pady=(12, 0))
        ttk.Button(nav_row, text="< 이전", command=lambda: controller.show_page("generation")).pack(side="left")

        self._entries_index = {}

    def _ensure_store(self):
        if self.review_store is None:
            path = self.controller.state.settings.log_folder / "review_state.json"
            self.review_store = ReviewStore(path)
        return self.review_store

    def _refresh_list(self):
        state = self.controller.state
        store = self._ensure_store()
        self._entries_index = {e.code: e for e in state.dialogue_entries}

        self.tree.delete(*self.tree.get_children())
        for entry in state.dialogue_entries:
            role = entry.role or "Unknown"
            for language in state.selected_languages:
                if language not in entry.translations:
                    continue
                key = f"{entry.code}|{language}"
                status = store.get_status(entry.code, language)
                status_text = status.status if status else "pending"
                note_text = status.note if status else ""
                self.tree.insert("", "end", iid=key, values=(entry.code, role, language, status_text, note_text))

    def _selected(self):
        sel = self.tree.selection()
        if not sel:
            return None
        code, language = sel[0].split("|", 1)
        return code, language

    def _on_select(self, _event):
        sel = self._selected()
        if not sel:
            return
        code, language = sel
        store = self._ensure_store()
        entry = store.get_status(code, language)
        self.note_var.set(entry.note if entry else "")

    def _play_korean(self):
        sel = self._selected()
        if not sel:
            return
        code, _ = sel
        state = self.controller.state
        match = next((f for f in state.scanned_files if f.code == code), None)
        if not match:
            messagebox.showinfo("알림", "해당 Code의 한국어 원본 파일을 찾을 수 없습니다.")
            return
        self._play_audio_file(match.file_path)

    def _play_generated(self):
        sel = self._selected()
        if not sel:
            return
        code, language = sel
        path = Path(self.controller.state.settings.output_folder) / language / f"{code}.mp3"
        if not path.exists():
            messagebox.showinfo("알림", "아직 생성된 음성이 없습니다. 5단계에서 먼저 생성하세요.")
            return
        self._play_audio_file(str(path))

    @staticmethod
    def _play_audio_file(path: str):
        try:
            if sys.platform.startswith("win"):
                import os
                os.startfile(path)  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["afplay", path])
            else:
                subprocess.Popen(["xdg-open", path])
        except Exception as exc:
            messagebox.showerror("재생 오류", str(exc))

    def _set_status(self, status: str):
        sel = self._selected()
        if not sel:
            return
        code, language = sel
        entry = self._entries_index.get(code)
        role = (entry.role if entry else None) or "Unknown"
        store = self._ensure_store()
        store.set_status(code, language, role, status, self.note_var.get())
        self._refresh_list()

    def _save_note(self):
        sel = self._selected()
        if not sel:
            return
        code, language = sel
        store = self._ensure_store()
        current = store.get_status(code, language)
        status = current.status if current else "pending"
        entry = self._entries_index.get(code)
        role = (entry.role if entry else None) or "Unknown"
        store.set_status(code, language, role, status, self.note_var.get())
        self._refresh_list()

    def _regenerate_one(self, code: str, language: str):
        state = self.controller.state
        entry = self._entries_index.get(code)
        if not entry or language not in entry.translations:
            return False
        korean_index = {f.code: f.file_path for f in state.scanned_files}
        tasks = build_tasks_from_entries([entry], state.voice_config, [language], korean_index)
        if not tasks:
            return False
        out_path = Path(state.settings.output_folder) / language / f"{code}.mp3"
        if out_path.exists():
            out_path.unlink()
        result = generate_task(
            state.settings.api_key, tasks[0], state.settings.output_folder, state.settings.model_id,
            TtsVoiceSettings(), state.settings.max_retries, state.settings.retry_delay, skip_existing=False,
        )
        return result.success

    def _regenerate_selected(self):
        sel = self._selected()
        if not sel:
            return
        code, language = sel
        ok = self._regenerate_one(code, language)
        messagebox.showinfo("재생성 결과", "재생성 완료" if ok else "재생성 실패 (로그 확인)")
        self._refresh_list()

    def _regenerate_all_pending(self):
        store = self._ensure_store()
        pending = store.failed_or_pending()
        if not pending:
            messagebox.showinfo("알림", "재생성이 필요한 항목이 없습니다.")
            return
        success = 0
        for entry in pending:
            if self._regenerate_one(entry.code, entry.language):
                success += 1
        messagebox.showinfo("재생성 결과", f"{success}/{len(pending)}개 재생성 완료")
        self._refresh_list()
