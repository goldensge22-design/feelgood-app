"""generation_page.py - 단계 5: 다국어 음성 생성"""

from __future__ import annotations

import threading
import tkinter as tk
from tkinter import messagebox, scrolledtext, ttk

from services.elevenlabs_tts_service import (
    TtsVoiceSettings,
    build_tasks_from_entries,
    generate_task,
)

ALL_LANGUAGES = ["English", "Thai", "Japanese", "Chinese", "Russian"]


class GenerationPage(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, padding=16)
        self.controller = controller

        ttk.Label(self, text="5단계: 다국어 음성 생성", font=("Segoe UI", 14, "bold")).pack(anchor="w", pady=(0, 12))

        lang_frame = ttk.LabelFrame(self, text="생성 언어 선택")
        lang_frame.pack(fill="x", pady=(0, 8))
        self.lang_vars = {}
        for i, lang in enumerate(ALL_LANGUAGES):
            var = tk.BooleanVar(value=lang in controller.state.selected_languages)
            ttk.Checkbutton(lang_frame, text=lang, variable=var).grid(row=0, column=i, padx=8, pady=6)
            self.lang_vars[lang] = var

        btn_row = ttk.Frame(self)
        btn_row.pack(fill="x", pady=(4, 8))
        ttk.Button(btn_row, text="생성 대상 확인 (Dry Run)", command=lambda: self._run(dry_run=True, one_only=False)).pack(
            side="left"
        )
        ttk.Button(btn_row, text="테스트 1개 생성", command=lambda: self._run(dry_run=False, one_only=True)).pack(
            side="left", padx=(8, 0)
        )
        ttk.Button(btn_row, text="전체 생성", command=lambda: self._run(dry_run=False, one_only=False)).pack(
            side="left", padx=(8, 0)
        )

        self.progress = ttk.Progressbar(self, mode="determinate")
        self.progress.pack(fill="x", pady=(4, 8))

        self.log_text = scrolledtext.ScrolledText(self, height=18, wrap="word")
        self.log_text.pack(fill="both", expand=True)

        nav_row = ttk.Frame(self)
        nav_row.pack(fill="x", pady=(8, 0))
        ttk.Button(nav_row, text="< 이전", command=lambda: controller.show_page("voice_registration")).pack(side="left")
        ttk.Button(nav_row, text="다음: 검수 >", command=lambda: controller.show_page("review")).pack(
            side="left", padx=(8, 0)
        )

    def _selected_languages(self):
        return [lang for lang, var in self.lang_vars.items() if var.get()]

    def _log(self, message: str):
        self.log_text.insert(tk.END, message + "\n")
        self.log_text.see(tk.END)
        self.controller.state.generation_log.append(message)

    def _run(self, dry_run: bool, one_only: bool):
        state = self.controller.state
        languages = self._selected_languages()
        if not languages:
            messagebox.showwarning("알림", "생성할 언어를 하나 이상 선택하세요.")
            return
        if not state.dialogue_entries:
            messagebox.showwarning("알림", "1단계에서 번역 파일을 먼저 불러오세요.")
            return

        state.selected_languages = languages
        korean_index = {f.code: f.file_path for f in state.scanned_files}
        tasks = build_tasks_from_entries(state.dialogue_entries, state.voice_config, languages, korean_index)
        if one_only:
            tasks = tasks[:1]

        if not tasks:
            messagebox.showinfo("알림", "생성할 대상이 없습니다.")
            return

        self.log_text.delete("1.0", tk.END)
        self.progress.configure(maximum=len(tasks), value=0)
        thread = threading.Thread(target=self._run_tasks, args=(tasks, dry_run), daemon=True)
        thread.start()

    def _run_tasks(self, tasks, dry_run: bool):
        state = self.controller.state
        api_key = state.settings.api_key
        voice_settings = TtsVoiceSettings()

        success, failed = 0, 0
        for i, task in enumerate(tasks, start=1):
            result = generate_task(
                api_key, task, state.settings.output_folder, state.settings.model_id,
                voice_settings, state.settings.max_retries, state.settings.retry_delay,
                dry_run=dry_run,
            )
            if result.success:
                success += 1
                msg = f"[{i}/{len(tasks)}] OK  {task.language}/{task.code} ({result.error or 'generated'})"
            else:
                failed += 1
                msg = f"[{i}/{len(tasks)}] FAIL  {task.language}/{task.code} - {result.error}"
            self.after(0, self._log, msg)
            self.after(0, lambda v=i: self.progress.configure(value=v))

        self.after(0, self._log, f"완료: 성공 {success} / 실패 {failed} / 전체 {len(tasks)}")
