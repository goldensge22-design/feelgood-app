"""korean_audio_page.py - 단계 2: 한국어 음성 불러오기 및 캐릭터 자동 분류"""

from __future__ import annotations

import subprocess
import sys
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from services.audio_scanner import save_scan_report, scan_korean_audio_folder

KNOWN_ROLE_CHOICES = ["Darkmong", "Crow", "Max", "Linky", "Mole", "Piece", "Narrator", "Unknown"]


class KoreanAudioPage(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, padding=16)
        self.controller = controller

        ttk.Label(self, text="2단계: 한국어 음성 불러오기 및 캐릭터 자동 분류", font=("Segoe UI", 14, "bold")).pack(
            anchor="w", pady=(0, 12)
        )

        top = ttk.Frame(self)
        top.pack(fill="x")
        self.folder_var = tk.StringVar(value=str(controller.state.korean_audio_folder or ""))
        ttk.Entry(top, textvariable=self.folder_var, width=60).pack(side="left", padx=(0, 8))
        ttk.Button(top, text="한국어 음성 폴더 선택", command=self._browse_folder).pack(side="left")
        ttk.Button(top, text="다시 스캔", command=self._scan).pack(side="left", padx=(8, 0))

        self.summary_label = ttk.Label(self, text="폴더를 선택하면 자동으로 스캔합니다.")
        self.summary_label.pack(anchor="w", pady=(8, 4))

        columns = ("file_name", "code", "role", "duration", "status", "selected")
        self.tree = ttk.Treeview(self, columns=columns, show="headings", height=16)
        headers = {
            "file_name": "파일명", "code": "Code", "role": "추정 Role",
            "duration": "길이(초)", "status": "파일 상태", "selected": "선택 여부",
        }
        widths = {"file_name": 260, "code": 160, "role": 110, "duration": 80, "status": 100, "selected": 80}
        for col in columns:
            self.tree.heading(col, text=headers[col])
            self.tree.column(col, width=widths[col], anchor="w")
        self.tree.pack(fill="both", expand=True, pady=(0, 8))
        self.tree.bind("<Double-1>", self._on_double_click)

        action_row = ttk.Frame(self)
        action_row.pack(fill="x")
        ttk.Label(action_row, text="선택한 파일의 Role 변경:").pack(side="left")
        self.role_override_var = tk.StringVar()
        self.role_combo = ttk.Combobox(action_row, textvariable=self.role_override_var, values=KNOWN_ROLE_CHOICES, width=15)
        self.role_combo.pack(side="left", padx=(6, 6))
        ttk.Button(action_row, text="적용", command=self._apply_role_override).pack(side="left")
        ttk.Button(action_row, text="제외 처리", command=self._exclude_selected).pack(side="left", padx=(8, 0))
        ttk.Button(action_row, text="포함으로 복원", command=self._include_selected).pack(side="left", padx=(8, 0))
        ttk.Button(action_row, text="음성 재생", command=self._play_selected).pack(side="left", padx=(8, 0))

        nav_row = ttk.Frame(self)
        nav_row.pack(fill="x", pady=(12, 0))
        ttk.Button(nav_row, text="< 이전", command=lambda: controller.show_page("project")).pack(side="left")
        ttk.Button(nav_row, text="다음: Clone 샘플 준비 >", command=self._go_next).pack(side="left", padx=(8, 0))

    # -- actions ----------------------------------------------------------
    def _browse_folder(self):
        folder = filedialog.askdirectory(title="한국어 음성 폴더 선택")
        if folder:
            self.folder_var.set(folder)
            self._scan()

    def _scan(self):
        folder_str = self.folder_var.get().strip()
        if not folder_str:
            messagebox.showwarning("알림", "먼저 한국어 음성 폴더를 선택하세요.")
            return
        folder = Path(folder_str)
        try:
            files = scan_korean_audio_folder(folder)
        except FileNotFoundError as exc:
            messagebox.showerror("오류", str(exc))
            return

        self.controller.state.korean_audio_folder = folder
        self.controller.state.scanned_files = files
        self._refresh_tree()

        unknown_count = sum(1 for f in files if f.effective_role() == "Unknown" or f.is_unknown)
        self.summary_label.configure(
            text=f"총 {len(files)}개 파일 스캔 완료 | Unknown {unknown_count}개 (직접 Role 지정 필요)"
        )

        try:
            save_scan_report(files, self.controller.state.settings.log_folder / "scan_report.json")
        except OSError:
            pass

    def _refresh_tree(self):
        self.tree.delete(*self.tree.get_children())
        for idx, f in enumerate(self.controller.state.scanned_files):
            selected_text = "선택됨" if (f.selected and not f.excluded) else "제외됨"
            self.tree.insert(
                "", "end", iid=str(idx),
                values=(f.file_name, f.code, f.effective_role(), f.duration_seconds, f.status, selected_text),
            )

    def _get_selected_indices(self):
        return [int(i) for i in self.tree.selection()]

    def _apply_role_override(self):
        role = self.role_override_var.get().strip()
        if not role:
            messagebox.showwarning("알림", "적용할 Role을 선택하거나 입력하세요.")
            return
        indices = self._get_selected_indices()
        if not indices:
            messagebox.showwarning("알림", "Role을 변경할 파일을 목록에서 선택하세요.")
            return
        for i in indices:
            f = self.controller.state.scanned_files[i]
            f.user_role_override = role
            f.is_unknown = False
        self._refresh_tree()

    def _exclude_selected(self):
        for i in self._get_selected_indices():
            f = self.controller.state.scanned_files[i]
            f.excluded = True
            f.selected = False
        self._refresh_tree()

    def _include_selected(self):
        for i in self._get_selected_indices():
            f = self.controller.state.scanned_files[i]
            f.excluded = False
            f.selected = True
        self._refresh_tree()

    def _on_double_click(self, _event):
        self._play_selected()

    def _play_selected(self):
        indices = self._get_selected_indices()
        if not indices:
            return
        path = self.controller.state.scanned_files[indices[0]].file_path
        self._play_audio_file(path)

    @staticmethod
    def _play_audio_file(path: str):
        try:
            if sys.platform.startswith("win"):
                import os
                os.startfile(path)  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["afplay", path])
            else:
                subprocess.Popen(["xdg-open", path])
        except Exception as exc:
            messagebox.showerror("재생 오류", f"파일을 재생할 수 없습니다:\n{exc}")

    def _go_next(self):
        if not self.controller.state.scanned_files:
            messagebox.showwarning("알림", "먼저 한국어 음성 폴더를 스캔하세요.")
            return
        self.controller.show_page("clone_sample")
