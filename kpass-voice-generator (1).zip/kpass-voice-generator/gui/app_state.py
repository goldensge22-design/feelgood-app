"""
app_state.py
=============
GUI 6단계 위저드가 공유하는 상태(AppState) 정의.
각 페이지는 이 객체를 읽고 씀으로써 단계 간 데이터를 주고받는다.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from services.app_settings import AppSettings, load_app_settings
from services.audio_scanner import ScannedAudioFile
from services.spreadsheet_reader import DialogueEntry
from services.voice_config_manager import VoiceConfig, load_voice_config


@dataclass
class AppState:
    # 단계 1: 프로젝트 설정
    project_name: str = "K-PASS Voice Project"
    settings: AppSettings = field(default_factory=load_app_settings)
    spreadsheet_path: Optional[Path] = None
    dialogue_entries: List[DialogueEntry] = field(default_factory=list)

    # 단계 2: 한국어 음성 불러오기
    korean_audio_folder: Optional[Path] = None
    scanned_files: List[ScannedAudioFile] = field(default_factory=list)

    # 단계 3: Clone 샘플 준비 (role -> manifest dict)
    clone_manifests: Dict[str, dict] = field(default_factory=dict)
    quality_reports: Dict[str, object] = field(default_factory=dict)

    # 단계 4: Voice 등록
    voice_config: VoiceConfig = field(default_factory=load_voice_config)
    consent_given_roles: Dict[str, bool] = field(default_factory=dict)

    # 단계 5: 다국어 생성
    selected_languages: List[str] = field(default_factory=lambda: ["English", "Thai", "Japanese", "Chinese", "Russian"])
    generation_log: List[str] = field(default_factory=list)

    # 단계 6: 검수
    review_store_path: Optional[Path] = None

    def role_groups(self):
        from services.audio_scanner import group_by_role
        return group_by_role(self.scanned_files)
