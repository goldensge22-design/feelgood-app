"""K-PASS Voice Generator - GUI package (Tkinter 기반)."""
