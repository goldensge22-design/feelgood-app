"""voice_registration_page.py - 단계 4: Voice 등록 (수동 방식 A / API 방식 B), 동의 확인"""

from __future__ import annotations

import subprocess
import sys
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from services.elevenlabs_clone_service import (
    create_voice_clone_via_api,
    generate_test_audio,
    verify_voice_id,
)
from services.review_service import record_consent
from services.voice_config_manager import save_voice_config

CONSENT_TEXT = "본인은 해당 음성의 사용 및 AI 음성 복제에 필요한 권리와 동의를 확보했습니다."


class VoiceRegistrationPage(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, padding=16)
        self.controller = controller

        ttk.Label(self, text="4단계: Voice 등록 (Voice Clone 생성 및 Voice ID 관리)", font=("Segoe UI", 14, "bold")).pack(
            anchor="w", pady=(0, 12)
        )

        role_row = ttk.Frame(self)
        role_row.pack(fill="x")
        ttk.Label(role_row, text="Role 선택:").pack(side="left")
        self.role_var = tk.StringVar()
        self.role_combo = ttk.Combobox(role_row, textvariable=self.role_var, state="readonly", width=20)
        self.role_combo.pack(side="left", padx=(6, 12))
        self.role_combo.bind("<<ComboboxSelected>>", self._on_role_selected)
        ttk.Button(role_row, text="목록 새로고침", command=self._refresh_role_list).pack(side="left")

        ttk.Label(self, text="Clone Sample 파일:").pack(anchor="w", pady=(10, 0))
        self.sample_path_var = tk.StringVar()
        sample_row = ttk.Frame(self)
        sample_row.pack(fill="x")
        ttk.Entry(sample_row, textvariable=self.sample_path_var, width=55, state="readonly").pack(side="left")
        ttk.Button(sample_row, text="파일 열기(재생)", command=self._open_sample).pack(side="left", padx=(8, 0))

        self.consent_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(self, text=CONSENT_TEXT, variable=self.consent_var, command=self._on_consent_changed).pack(
            anchor="w", pady=(12, 8)
        )

        # 방식 A: 수동
        manual_frame = ttk.LabelFrame(self, text="방식 A: 수동 Voice Clone (ElevenLabs 웹사이트에서 생성 후 Voice ID 입력)")
        manual_frame.pack(fill="x", pady=(4, 8))
        ttk.Label(manual_frame, text="Voice ID:").grid(row=0, column=0, sticky="w", padx=6, pady=6)
        self.voice_id_var = tk.StringVar()
        ttk.Entry(manual_frame, textvariable=self.voice_id_var, width=40).grid(row=0, column=1, sticky="w")
        ttk.Button(manual_frame, text="Voice ID 저장", command=self._save_voice_id).grid(row=0, column=2, padx=6)
        ttk.Button(manual_frame, text="Voice 연결 상태 확인", command=self._verify_voice).grid(row=0, column=3, padx=6)
        ttk.Button(manual_frame, text="테스트 음성 생성", command=self._generate_test_audio).grid(row=0, column=4, padx=6)

        # 방식 B: API
        api_frame = ttk.LabelFrame(self, text="방식 B: API Voice Clone (계정이 지원하는 경우)")
        api_frame.pack(fill="x", pady=(4, 8))
        ttk.Button(api_frame, text="API로 Voice Clone 생성 시도", command=self._create_via_api).grid(
            row=0, column=0, padx=6, pady=6
        )
        self.api_result_label = ttk.Label(api_frame, text="", wraplength=680, foreground="#444")
        self.api_result_label.grid(row=1, column=0, columnspan=4, sticky="w", padx=6, pady=(0, 6))

        self.status_label = ttk.Label(self, text="", foreground="green", wraplength=700)
        self.status_label.pack(anchor="w", pady=(4, 8))

        nav_row = ttk.Frame(self)
        nav_row.pack(fill="x", pady=(8, 0))
        ttk.Button(nav_row, text="< 이전", command=lambda: controller.show_page("clone_sample")).pack(side="left")
        ttk.Button(nav_row, text="다음: 다국어 생성 >", command=self._go_next).pack(side="left", padx=(8, 0))

    def _refresh_role_list(self):
        roles = sorted(self.controller.state.clone_manifests.keys())
        self.role_combo.configure(values=roles)
        if roles and not self.role_var.get():
            self.role_var.set(roles[0])
            self._on_role_selected()

    def _on_role_selected(self, _event=None):
        role = self.role_var.get()
        manifest = self.controller.state.clone_manifests.get(role, {})
        self.sample_path_var.set(manifest.get("output_sample_path", ""))

        entry = self.controller.state.voice_config.roles.get(role, {})
        self.voice_id_var.set(entry.get("voice_id", ""))
        self.consent_var.set(self.controller.state.consent_given_roles.get(role, False))
        self.api_result_label.configure(text="")
        self.status_label.configure(text="")

    def _open_sample(self):
        path = self.sample_path_var.get()
        if not path:
            messagebox.showwarning("알림", "먼저 Role을 선택하세요.")
            return
        try:
            if sys.platform.startswith("win"):
                import os
                os.startfile(path)  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["afplay", path])
            else:
                subprocess.Popen(["xdg-open", path])
        except Exception as exc:
            messagebox.showerror("재생 오류", str(exc))

    def _on_consent_changed(self):
        role = self.role_var.get()
        if not role:
            self.consent_var.set(False)
            return
        agreed = self.consent_var.get()
        self.controller.state.consent_given_roles[role] = agreed
        record_consent(self.controller.state.settings.log_folder, role, agreed)

    def _require_role_and_consent(self) -> str | None:
        role = self.role_var.get()
        if not role:
            messagebox.showwarning("알림", "Role을 먼저 선택하세요.")
            return None
        if not self.controller.state.consent_given_roles.get(role):
            messagebox.showwarning("동의 필요", "Voice Clone 관련 기능을 사용하려면 동의 체크박스를 먼저 선택하세요.")
            return None
        return role

    def _save_voice_id(self):
        role = self.role_var.get()
        if not role:
            messagebox.showwarning("알림", "Role을 먼저 선택하세요.")
            return
        voice_id = self.voice_id_var.get().strip()
        state = self.controller.state
        state.voice_config.upsert_role(role, voice_id=voice_id, sample_file=self.sample_path_var.get())
        save_voice_config(state.voice_config)
        self.status_label.configure(text=f"[{role}] Voice ID가 저장되었습니다.")

    def _verify_voice(self):
        role = self._require_role_and_consent()
        if not role:
            return
        api_key = self.controller.state.settings.api_key
        voice_id = self.voice_id_var.get().strip()
        if not api_key:
            messagebox.showwarning("알림", "1단계에서 API Key를 입력하세요.")
            return
        result = verify_voice_id(api_key, voice_id)
        color = "green" if result.valid else "red"
        self.status_label.configure(text=f"[{role}] {result.message}", foreground=color)

    def _generate_test_audio(self):
        role = self._require_role_and_consent()
        if not role:
            return
        api_key = self.controller.state.settings.api_key
        voice_id = self.voice_id_var.get().strip()
        if not api_key or not voice_id:
            messagebox.showwarning("알림", "API Key와 Voice ID를 모두 입력하세요.")
            return
        out = generate_test_audio(
            api_key, voice_id, f"{role} 테스트 음성입니다. This is a test voice for {role}.",
            self.controller.state.settings.model_id,
            output_path=self.controller.state.settings.log_folder / f"{role}_voice_test.mp3",
        )
        if out:
            self.status_label.configure(text=f"테스트 음성 생성 완료: {out}", foreground="green")
        else:
            self.status_label.configure(text="테스트 음성 생성에 실패했습니다. API Key/Voice ID를 확인하세요.", foreground="red")

    def _create_via_api(self):
        role = self._require_role_and_consent()
        if not role:
            return
        api_key = self.controller.state.settings.api_key
        sample_path = self.sample_path_var.get()
        if not api_key or not sample_path:
            messagebox.showwarning("알림", "API Key와 Clone Sample 파일이 필요합니다.")
            return
        result = create_voice_clone_via_api(api_key, role, Path(sample_path))
        self.api_result_label.configure(text=result.message)
        if result.success and result.voice_id:
            self.voice_id_var.set(result.voice_id)
            self._save_voice_id()

    def _go_next(self):
        state = self.controller.state
        if not state.voice_config.roles:
            messagebox.showwarning("알림", "적어도 하나의 Role에 Voice ID를 등록하세요.")
            return
        self.controller.show_page("generation")
