"""clone_sample_page.py - 단계 3: Clone 샘플 준비 및 품질 검사"""

from __future__ import annotations

import tkinter as tk
from tkinter import messagebox, scrolledtext, ttk

from services.clone_quality_checker import check_role_sample_quality
from services.clone_sample_builder import build_all_clone_samples


class CloneSamplePage(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, padding=16)
        self.controller = controller

        ttk.Label(self, text="3단계: Voice Clone용 샘플 준비 및 품질 검사", font=("Segoe UI", 14, "bold")).pack(
            anchor="w", pady=(0, 12)
        )

        ttk.Button(self, text="캐릭터별 Clone 샘플 생성 (병합/정규화/무음제거)", command=self._build_samples).pack(
            anchor="w"
        )

        columns = ("role", "duration", "used", "excluded", "status")
        self.tree = ttk.Treeview(self, columns=columns, show="headings", height=10)
        headers = {"role": "Role", "duration": "샘플 길이(초)", "used": "사용 파일 수", "excluded": "제외 파일 수", "status": "품질 상태"}
        for col in columns:
            self.tree.heading(col, text=headers[col])
            self.tree.column(col, width=140, anchor="w")
        self.tree.pack(fill="both", expand=True, pady=(10, 8))
        self.tree.bind("<<TreeviewSelect>>", self._on_select)

        ttk.Label(self, text="품질 검사 상세 메시지").pack(anchor="w")
        self.detail_text = scrolledtext.ScrolledText(self, height=8, wrap="word")
        self.detail_text.pack(fill="both", expand=False, pady=(4, 8))

        nav_row = ttk.Frame(self)
        nav_row.pack(fill="x", pady=(4, 0))
        ttk.Button(nav_row, text="< 이전", command=lambda: controller.show_page("korean_audio")).pack(side="left")
        ttk.Button(nav_row, text="다음: Voice 등록 >", command=self._go_next).pack(side="left", padx=(8, 0))

    def _build_samples(self):
        state = self.controller.state
        if not state.scanned_files:
            messagebox.showwarning("알림", "먼저 2단계에서 한국어 음성을 스캔하세요.")
            return

        role_groups = state.role_groups()
        output_dir = state.settings.voice_clone_ready_folder
        manifest_dir = state.settings.manifest_folder

        try:
            manifests = build_all_clone_samples(role_groups, output_dir, manifest_dir)
        except Exception as exc:
            messagebox.showerror("오류", f"Clone 샘플 생성 중 오류가 발생했습니다:\n{exc}")
            return

        state.clone_manifests = manifests
        state.quality_reports = {}

        for role, manifest in manifests.items():
            report = check_role_sample_quality(
                role,
                manifest.get("output_sample_path"),
                len(manifest.get("source_files", [])),
                len(manifest.get("excluded_files", [])),
            )
            state.quality_reports[role] = report

        self._refresh_tree()
        messagebox.showinfo("완료", f"{len(manifests)}개 캐릭터의 Clone 샘플 생성이 완료되었습니다.")

    def _refresh_tree(self):
        self.tree.delete(*self.tree.get_children())
        for role, manifest in self.controller.state.clone_manifests.items():
            report = self.controller.state.quality_reports.get(role)
            status = report.status if report else "-"
            self.tree.insert(
                "", "end", iid=role,
                values=(role, manifest.get("total_duration_seconds", 0.0), len(manifest.get("source_files", [])),
                        len(manifest.get("excluded_files", [])), status),
            )

    def _on_select(self, _event):
        sel = self.tree.selection()
        if not sel:
            return
        role = sel[0]
        report = self.controller.state.quality_reports.get(role)
        self.detail_text.delete("1.0", tk.END)
        if not report:
            self.detail_text.insert(tk.END, "품질 검사 결과가 없습니다.")
            return
        lines = [
            f"Role: {report.role}",
            f"상태: {report.status}",
            f"평균 음량(dBFS): {report.average_dbfs}",
            f"무음 비율: {report.silence_ratio}",
            f"클리핑 여부: {report.is_clipping}",
            f"배경 잡음 의심: {report.possible_heavy_noise}",
            f"여러 화자 혼입 의심: {report.possible_multiple_speakers}",
            "",
            "메시지:",
        ] + [f"  - {m}" for m in report.messages]
        self.detail_text.insert(tk.END, "\n".join(lines))

    def _go_next(self):
        if not self.controller.state.clone_manifests:
            messagebox.showwarning("알림", "먼저 Clone 샘플을 생성하세요.")
            return
        self.controller.show_page("voice_registration")
