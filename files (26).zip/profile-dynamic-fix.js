/**
 * A-1. 01~03번 페이지 동적화 — profile / strength / combo
 *
 * 확인된 문제: renderDynamic()이 이 세 섹션을 전혀 갱신하지 않음.
 * SECTIONS_KO.profile 등에 박힌 정적 HTML(박준서 예시)이 최초 1회
 * 꽂히고 끝. 세 함수를 새로 만들어 renderDynamic()에 추가해야 함.
 *
 * 주의: 원본 정적 SVG의 좌표 비율(예: 91%인데 반지름이 가장 작은 등)이
 * 서로 안 맞는 부분이 있어, 그 비율을 그대로 역산하지 않고 표준적인
 * "중심에서 값에 비례한 거리" 공식으로 새로 만들었습니다. 실제 배포
 * 전 디자인팀 확인 권장.
 */

/* ---------- 레이더 좌표 계산 ---------- */
const RADAR_CX = 150, RADAR_CY = 150, RADAR_MAXR = 95;
// 축 순서는 AXES=[q,p,s,a]와 무관하게, 화면 배치(상=계획력, 우=동시처리, 하=순차처리, 좌=주의력)를 고정
const RADAR_LAYOUT = [
  { k: 'p', label: '계획력', angle: 0 },     // 상단
  { k: 's', label: '동시처리', angle: 90 },  // 우측
  { k: 'q', label: '순차처리', angle: 180 }, // 하단
  { k: 'a', label: '주의력', angle: 270 },   // 좌측
];
function radarPoint(pct, angleDeg) {
  const r = (pct / 100) * RADAR_MAXR;
  const rad = (angleDeg * Math.PI) / 180;
  return { x: RADAR_CX + r * Math.sin(rad), y: RADAR_CY - r * Math.cos(rad) };
}
function buildRadarSVG() {
  const pts = RADAR_LAYOUT.map(function (ax) {
    const p = radarPoint(ME[ax.k], ax.angle);
    return p.x.toFixed(1) + ',' + p.y.toFixed(1);
  }).join(' ');
  const labelColors = { p: '#1B3B8C', s: '#1E8A5F', q: '#C25E00', a: '#6A3FBF' };
  const labelPos = {
    p: { x: 150, y: 42 }, s: { x: 268, y: 146 },
    q: { x: 150, y: 200 }, a: { x: 36, y: 146 },
  };
  const texts = RADAR_LAYOUT.map(function (ax) {
    const lp = labelPos[ax.k];
    return '<text x="' + lp.x + '" y="' + lp.y + '" text-anchor="middle" font-size="13" font-weight="800" fill="' +
      labelColors[ax.k] + '">' + ax.label + ' ' + ME[ax.k] + '%</text>';
  }).join('');
  return '<svg viewBox="0 0 300 300">' +
    '<circle cx="150" cy="150" r="95" fill="none" stroke="#E4E9F2" stroke-width="1"/>' +
    '<circle cx="150" cy="150" r="63" fill="none" stroke="#E4E9F2" stroke-width="1"/>' +
    '<circle cx="150" cy="150" r="32" fill="none" stroke="#E4E9F2" stroke-width="1"/>' +
    '<line x1="150" y1="55" x2="150" y2="245" stroke="#E4E9F2" stroke-width="1"/>' +
    '<line x1="55" y1="150" x2="245" y2="150" stroke="#E4E9F2" stroke-width="1"/>' +
    '<polygon points="' + pts + '" fill="#F5820A" fill-opacity="0.22" stroke="#F5820A" stroke-width="2.5"/>' +
    texts +
    '</svg>';
}

/* ---------- 01 인지 프로파일 ---------- */
function typeLabel() {
  // 상위 2축 조합으로 유형명 결정 — 기존 27/81유형 명칭 매트릭스가 있다면 그걸로 교체
  const ranked = AXES.map(function (ax) { return { k: ax[0], n: ax[1], v: ME[ax[0]] }; })
    .sort(function (a, b) { return b.v - a.v; });
  return ranked[0].n + '·' + ranked[1].n + ' 우세형';
}
function renderProfile() {
  const el = document.getElementById('profile');
  if (!el) return;
  const bars = AXES.map(function (ax) {
    return '<div class="bar-row"><div class="bar-label">' + ax[1] + '</div>' +
      '<div class="bar-track"><div class="bar-fill" style="width:' + ME[ax[0]] + '%"></div></div>' +
      '<div class="bar-val">' + ME[ax[0]] + '%</div></div>';
  }).join('');

  // 기존 hook-card 등 상단 고정 문구는 그대로 두고, 레이더·바만 교체 대상.
  // 실제 적용 시: SECTIONS_KO.profile의 <div class="radar-wrap">...</div> 와
  // 4개 하위척도 <div class="card">...</div> 블록을 아래 결과로 str_replace.
  const radarBlock =
    '<div class="radar-wrap"><h4 style="margin:0 0 10px;font-size:14px;color:var(--navy);">인지 나침반 — 4개 축</h4>' +
    buildRadarSVG() +
    '<div class="radar-legend"><span><i style="background:#F5820A"></i>내 프로파일 (정답률 기준)</span></div></div>';
  const barsBlock =
    '<div class="card"><h4 style="margin:0 0 10px;font-size:14px;color:var(--navy);">4개 하위척도</h4>' +
    bars + '<p class="sub" style="margin-top:10px;">원점수와 표준점수는 13번 전문가 데이터에서 확인할 수 있어요.</p></div>';

  const radarWrap = el.querySelector('.radar-wrap');
  if (radarWrap) radarWrap.outerHTML = radarBlock;
  // 4개 하위척도 카드는 구조상 두 번째 .card — 프로젝트 실제 DOM에 맞춰 선택자 조정 필요
}

/* ---------- 02 강점·보완 포인트 서류 키워드 표 ---------- */
function renderStrength() {
  const el = document.getElementById('strength');
  if (!el) return;
  const table = el.querySelector('.subject-table');
  if (!table) return;
  const KEYWORD = {
    q: { label: '정확성 · 문제추적력', ex: '"원인을 단계적으로 분석", "재현 절차를 문서화"' },
    p: { label: '일정관리 · 태스크 분해력', ex: '"작업을 세부 단위로 분해해 일정 내 완수"' },
    a: { label: '몰입 지속력', ex: '"장시간 집중이 필요한 작업을 완수"' },
    s: { label: '구조적 이해로 성장 중', ex: '"전체 구조를 먼저 그려보는 습관을 훈련"' },
  };
  const rows = AXES.map(function (ax) {
    const kw = KEYWORD[ax[0]];
    return '<tr><td>' + ax[1] + ' ' + ME[ax[0]] + '%</td><td>' + kw.label + '</td><td>' + kw.ex + '</td></tr>';
  }).join('');
  table.innerHTML = '<tr><th>인지영역</th><th>서류 키워드</th><th>서술 예시</th></tr>' + rows;
}

/* ---------- 03 인지 조합 진단 ---------- */
function renderCombo() {
  const el = document.getElementById('combo');
  if (!el) return;
  const ranked = AXES.map(function (ax) { return { k: ax[0], n: ax[1], v: ME[ax[0]] }; })
    .sort(function (a, b) { return b.v - a.v; });
  const top2 = ranked.slice(0, 2), bottomAxis = ranked[ranked.length - 1];
  const pairEl = el.querySelector('.pair');
  if (pairEl) {
    pairEl.innerHTML = '<span class="axis-tag">' + top2[0].n + ' ' + top2[0].v + '%</span>' +
      '<span class="vs">×</span><span class="axis-tag">' + top2[1].n + ' ' + top2[1].v + '%</span>';
  }
  // 두 번째 diag-card(약한 축 관련)도 동일하게 bottomAxis 기준으로 교체 필요 — 실제 DOM 구조에 맞춰 조정
}

/* renderDynamic()에 추가:
function renderDynamic(){
  renderInterest(); renderPicker(); renderFit();
  renderMatrix(); renderJobs(); renderSkill(); renderKeyAxis();
  renderSummary(); renderRoadmap(); renderDocs(); renderInterview(); renderRx();
  renderProfile(); renderStrength(); renderCombo();   // ← 추가
}
*/
