/**
 * 청소년용 "05 · 정서적 지지" 페이지 — 특정 학생 예시가 그대로 박힌 문제
 *
 * 실제 소스 확인된 문제:
 *   <h3>누구에게나 강점은 있어요.<br>이지훈 님에게는 이미 확실한 강점이 있어요.</h3>
 *   <div class="stat-chip"><b>80%</b><span>계획력 정답률</span></div>
 *   <div class="stat-chip"><b>89%</b><span>동시처리 정답률</span></div>
 *   ... (아래 self-mission 두 카드도 "계획력·동시처리"가 문자열로 고정)
 *
 * 설계 문서에서 "엔진·3층 구조는 성인용과 공유"라고 확인했으므로,
 * ME/AXIS_LABEL은 axis-utils.js를 그대로 재사용합니다.
 *
 * ★ 확인 필요: 학생 이름이 담긴 실제 변수명(STATE.name? STUDENT.name?)은
 *   이 조각만으로 확정할 수 없습니다. 아래 STATE.studentName은 자리표시자이니
 *   실제 변수명으로 바꿔주세요.
 */
function renderEmotionalAnchor() {
  const name = STATE.studentName || '학생';               // ★ 실제 변수명 확인 필요
  const top2 = myAxesRanked().slice(0, 2);                  // axis-utils.js

  const statChips = top2.map(a =>
    `<div class="stat-chip"><b>${a.val}%</b><span>${a.name} 정답률</span></div>`
  ).join('');

  return `
    <div class="anchor-card">
      <div class="eyebrow">05 · 정서적 지지</div>
      <h3>누구에게나 강점은 있어요.<br>${name} 님에게는 이미 확실한 강점이 있어요.</h3>
      <div class="stat-row">${statChips}</div>
      <p>정서적 안정은 약점을 없애는 데서 오지 않아요. 내가 가진 강점을 분명히 알고,
         그 강점을 써서 스스로 문제를 풀어본 경험에서 와요. 이번 섹션은 그 경험을 만드는 데 집중해요.</p>
    </div>`;
}

/** 강점-약점 짝짓기 미션 카드 — "계획력·동시처리" 고정 텍스트를 실제 상위 2축으로 교체 */
function renderStrengthMissionCards() {
  const top2 = myAxesRanked().slice(0, 2);
  const names = top2.map(a => a.name).join('·');

  return `
    <div class="self-mission">
      <span class="sm-tag">자기설계 미션 · 강점 기록</span>
      <h4>이번 주 내 강점을 "썼던 순간" 기록하기</h4>
      <p>${names}을 발휘했던 순간 하나를 떠올려 적어보세요.
         예: "<span class="blank">&nbsp;</span>에서 전체 상황을 먼저 파악하고 계획을 세워서
         <span class="blank">&nbsp;</span>을 해냈다." 작게라도 좋아요. 강점은 기록할수록 선명해져요.</p>
    </div>
    <div class="self-mission">
      <span class="sm-tag">자기설계 미션 · 강점-약점 짝짓기</span>
      <h4>약점이 드러난 순간, 도와줄 강점 1개 짝지어보기</h4>
      <p>순서를 놓쳤거나 디테일을 놓친 순간을 떠올려보세요. 그 순간 내 강점(${names})을
         어떻게 쓰면 도움이 될지 스스로 설계해보세요.
         예: "<span class="blank">&nbsp;</span>을 깜빡했을 때, 내 ${top2[0].name}으로
         <span class="blank">&nbsp;</span> 체크리스트를 직접 만들어봤다."</p>
    </div>`;
}

/**
 * 기존 호출부 교체:
 * BEFORE: emotionalArea.innerHTML = SECTIONS.ko.emotional;  // 정적 문자열
 * AFTER:  emotionalArea.innerHTML = renderEmotionalAnchor() + HOOK_CARD_STATIC_HTML
 *                                  + renderStrengthMissionCards() + DIAG_CARDS_STATIC_HTML;
 * (hook-card·diag-card 블록은 특정 학생 값이 없으므로 그대로 둬도 무방)
 */
