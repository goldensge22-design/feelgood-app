/**
 * D-CAS 확정 버그 5종 — 실제 소스(dcas_adult_report_v2.html) 기준 정확한 패치
 * 함수명·변수명이 실제 파일과 정확히 일치합니다. str_replace로 그대로 적용 가능.
 */

/* =====================================================================
   A-2. renderSummary() — SS 128/121 첫 문장 하드코딩
   ===================================================================== */
/*
BEFORE (실제 소스 그대로):
  '<p>순차처리(SS 128)와 계획력(SS 121)이 함께 상위권인 특화형 프로파일입니다. 구조가 명확한 과제에서 강점이 뚜렷하고, 동시처리는 규준 평균 수준이라 요구사항이 모호한 초기 기획 단계에서는 "먼저 구조를 잡아달라"고 요청하는 편이 유리합니다. '+
  align+'</p>'

AFTER — 아래 openingSentence() 함수를 renderSummary() 위에 추가하고,
       위 하드코딩 줄을 openingSentence()+' '+align+'</p>' 로 교체.
*/
function openingSentence() {
  // 내 4축 중 상위 2개, 하위 1개(요구사항 모호할 때 뒤처지는 축) 실제 계산
  const ranked = AXES.map(function (ax) {
    return { k: ax[0], n: ax[1], v: ME[ax[0]] };
  }).sort(function (a, b) { return b.v - a.v; });
  const top2 = ranked.slice(0, 2);
  const lowest = ranked[ranked.length - 1];

  // 정답률(%) → SS는 정식 규준표가 있어야 정확합니다.
  // 아래는 13번 페이지에 이미 있는 표준점수 표기 관례(SS 100 근방 기준)를 참고한 근사치이며,
  // ★ 정식 배포 전 문수백 교수 감수 필요 — 13번 전문가 데이터의 실제 SS 산출 로직과
  //   반드시 통일하세요(현재 13번은 표조차 정적이라 그 로직도 별도 확인 필요).
  function approxSS(pct) { return Math.round(70 + pct * 0.6); }

  return '<p>' + top2[0].n + '(SS ' + approxSS(top2[0].v) + ')와 ' + top2[1].n +
    '(SS ' + approxSS(top2[1].v) + ')이 함께 상위권인 특화형 프로파일입니다. ' +
    '구조가 명확한 과제에서 강점이 뚜렷하고, ' + lowest.n + '은 상대적으로 뒤따라오는 축이라 ' +
    '요구사항이 모호한 초기 단계에서는 "먼저 구조를 잡아달라"고 요청하는 편이 유리합니다. ';
}
// renderSummary() 안에서: openingSentence() + align + '</p>' 로 교체 (line은 그대로 별도 문단 유지)


/* =====================================================================
   A-3. renderRoadmap() — "60% 이상" 하드코딩
   ===================================================================== */
/*
BEFORE:
  '<div class="tip-box">2순위 직무는 1순위와 요구 역량이 대체로 60% 이상 겹쳐요. 도구 1~2개만 더 익히면 두 직무를 동시에 노려볼 수 있습니다.</div>';

AFTER — renderRoadmap() 안에 아래 두 함수를 이용해 교체.
*/
function axisOverlapPct(jobA, jobB) {
  const dot = jobA.r.reduce(function (s, v, i) { return s + v * jobB.r[i]; }, 0);
  const magA = Math.sqrt(jobA.r.reduce(function (s, v) { return s + v * v; }, 0));
  const magB = Math.sqrt(jobB.r.reduce(function (s, v) { return s + v * v; }, 0));
  if (!magA || !magB) return 0;
  return Math.round((dot / (magA * magB)) * 100);
}
function overlapCalloutHTML() {
  const jobs = rankedJobs();
  const job1 = jobs[0], job2 = jobs[1];
  if (!job2) return '<div class="tip-box">현재 영역에는 비교할 2순위 직무가 없어요. 7번에서 영역을 넓혀보세요.</div>';
  const pct = axisOverlapPct(job1, job2);
  if (pct >= 60) {
    return '<div class="tip-box">2순위 직무 <b>' + job2.n + '</b>는 <b>' + job1.n + '</b>와 요구 역량이 <b>' + pct + '%</b> 겹쳐요. 도구 1~2개만 더 익히면 두 직무를 동시에 노려볼 수 있습니다.</div>';
  }
  if (pct >= 35) {
    return '<div class="tip-box">2순위 직무 <b>' + job2.n + '</b>는 <b>' + job1.n + '</b>와 요구 역량이 <b>' + pct + '%</b> 정도 겹쳐요. 겹치지 않는 축은 별도 학습이 필요해서, 동시 준비보다는 순차 전환을 권합니다.</div>';
  }
  return '<div class="tip-box">2순위 직무 <b>' + job2.n + '</b>는 <b>' + job1.n + '</b>와 요구 역량 겹침이 <b>' + pct + '%</b>로 낮은 편이에요. 전환 시 처음부터 다시 준비한다는 마음이 필요합니다.</div>';
}
// renderRoadmap() 마지막 줄: ... + overlapCalloutHTML(); 로 교체


/* =====================================================================
   A-4. renderDocs() — employed 모드 괄호 미채움
   ===================================================================== */
/*
BEFORE (renderDocs 전체):
  function renderDocs(){
    const D = DOCS[STATE.mode];
    document.getElementById('docsTitle').textContent = D.title;
    document.getElementById('docsSub').textContent = D.sub;
    document.getElementById('docsArea').innerHTML = D.body;
    const top = rankedJobs()[0], dj = document.getElementById('docJob');
    if(dj && top) dj.textContent = top.n;
  }

AFTER — employed 모드일 때 D.body 대신 employedBodyDynamic() 사용.
*/
function employedBodyDynamic() {
  const jobs = rankedJobs();
  const target = jobs[0];
  const ranked = AXES.map(function (ax) {
    return { k: ax[0], n: ax[1], v: ME[ax[0]] };
  }).sort(function (a, b) { return b.v - a.v; });
  const myTop2 = ranked.slice(0, 2);
  const axisCombo = myTop2[0].n + '·' + myTop2[1].n;

  let reqAxis = '-', overlapWord = '거의 없이';
  if (target) {
    let bestIdx = 0;
    target.r.forEach(function (v, i) { if (v > target.r[bestIdx]) bestIdx = i; });
    reqAxis = AXES[bestIdx][1];
    const hit = myTop2.filter(function (a) {
      return a.n === reqAxis || target.r[AXES.findIndex(function (ax) { return ax[1] === a.n; })] >= 75;
    }).length;
    overlapWord = hit >= 2 ? '전부' : hit === 1 ? '일부' : '거의 없이';
  }
  const wantJob = target ? target.n : '-';

  function blank(id, ph, w) {
    return '<input class="fill-blank" id="' + id + '" placeholder="' + ph + '" ' +
      'style="border:none;border-bottom:1.5px dashed #b7bcd6;background:transparent;font:inherit;width:' + (w || '9em') + ';">';
  }

  return '<div class="doc-card"><span class="doc-tag">성과 기술서 · 인사평가용</span>' +
    '<p class="body">"' + blank('d1_task', '업무명') + '를 수행하며 ' + blank('d1_step', '몇 단계', '5em') +
    '의 검증 절차를 직접 설계해 ' + blank('d1_err', '오류·재작업 항목') + '을 ' + blank('d1_num', '정량 수치', '5em') +
    '만큼 줄였습니다. 반복 업무의 품질 편차를 낮추는 것이 제가 팀에 기여하는 방식입니다."</p>' +
    '<p class="tip"><b>Tip.</b> 재직자 평가에서는 "무엇을 했다"보다 "무엇이 줄었다·늘었다"가 설득력이 큽니다.</p></div>' +

    '<div class="doc-card"><span class="doc-tag">직무 전환 요청 논리</span>' +
    '<p class="body">"제 강점은 <b>' + axisCombo + '</b>이고, 현재 업무에서는 그중 <b>' + overlapWord + '</b>만 쓰이고 있습니다. ' +
    '<b>' + wantJob + '</b>는 <b>' + reqAxis + '</b>을 중심으로 하는 일이라, 같은 노력으로 더 큰 성과를 낼 수 있다고 판단합니다."</p>' +
    '<p class="tip"><b>Tip.</b> "지금 일이 안 맞는다"가 아니라 "강점 활용도를 높이겠다"는 프레임으로 말하는 게 안전합니다.</p></div>' +

    '<div class="doc-card"><span class="doc-tag">경력기술서 · 이직용</span>' +
    '<p class="body">"' + blank('d3_period', '기간', '8em') + ' 동안 ' + blank('d3_job', '직무명') +
    '를 수행하며 핵심 성과 ' + blank('d3_a1', '성과1', '6em') + '·' + blank('d3_a2', '성과2', '6em') + '·' + blank('d3_a3', '성과3', '6em') +
    '를 달성했습니다. 특히 절차 설계와 검증 영역에서 ' + blank('d3_result', '정량 결과') + '를 만들었고, ' +
    '이는 <b>' + wantJob + '</b>의 핵심 요구와 직접 연결됩니다."</p>' +
    '<p class="tip"><b>Tip.</b> ' + reqAxis + '이 충족으로 표시된 축이니, 그대로 경력기술서 소제목으로 쓰면 대응이 명확해집니다.</p></div>' +

    '<div class="tip-box">아래 면접 예상 질문은 경력직 면접에서도 그대로 나옵니다. 다만 경력자는 "대비 방식"이 아니라 <b>"실제로 그렇게 해서 무엇이 달라졌는지"</b>까지 답해야 합니다.</div>';
}
/*
renderDocs() 안에서:
  document.getElementById('docsArea').innerHTML = D.body;
를 아래로 교체:
  document.getElementById('docsArea').innerHTML =
    STATE.mode === 'employed' ? employedBodyDynamic() : D.body;
*/


/* =====================================================================
   A-5. renderMatrix() — "재고 필요" 콜아웃 무조건 출력
   ===================================================================== */
/*
BEFORE (renderMatrix 마지막 줄):
  '<div class="tip-box"><b>재고 필요</b> 칸에 있는 직무를 눈여겨보세요. 인지적으로는 잘 맞아서 초반에는 성과가 나지만 흥미가 낮아 오래 버티기 어려운 조합이에요. 유형검사만으로도, 인지검사만으로도 잡히지 않는 지점입니다.</div>';

AFTER — 아래 함수로 교체.
*/
function matrixCalloutHTML(q) {
  if (q.q3.length) {
    return '<div class="tip-box"><b>재고 필요</b> 칸에 있는 직무를 눈여겨보세요. 인지적으로는 잘 맞아서 초반에는 성과가 나지만 흥미가 낮아 오래 버티기 어려운 조합이에요. 유형검사만으로도, 인지검사만으로도 잡히지 않는 지점입니다.</div>';
  }
  if (q.q2.length) {
    return '<div class="tip-box"><b>성장 설계</b> 칸의 직무는 흥미가 이미 향해 있는 쪽이에요. 인지 축 중 부족한 부분만 보완하면 진입할 수 있습니다.</div>';
  }
  if (q.q1.length) {
    return '<div class="tip-box"><b>최우선</b> 칸의 직무부터 검토하세요. 인지와 흥미가 함께 높아 초반 적응과 지속 모두 유리한 조합입니다.</div>';
  }
  return '<div class="tip-box">이 영역의 직무는 현재 프로파일과 거리가 있습니다. 영역 내 1위는 아래 순위 목록에서 계속 강조되니, 이 영역을 유지한다면 그 직무부터 보세요.</div>';
}
/* renderMatrix() 안에서 area.innerHTML의 마지막 '+' 부분을 matrixCalloutHTML(q)로 교체 */
