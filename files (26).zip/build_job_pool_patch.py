#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
dcas-jobs-master.json(669건, 신규 표준 스키마)을
실제 결과지(dcas_adult_report_v2.html)의 내부 자료구조로 변환한다.

실제 결과지 자료구조(과거 세션 코드 확인 기준):
  JOB = { <id>: { n:'이름', r:[순차,계획,동시,주의], ria:['R','I'], k:'키워드·키워드' } }
  NCS = [ { c:'대분류코드', n:'대분류명',
            m:[ { c:'중분류코드', n:'중분류명', j:[ {id, r:[...]}, ... ] } ] } ]
  fitScore()/fitRaw()는 req[0..3] = ['q'(순차),'p'(계획),'s'(동시),'a'(주의)] 순서로 읽음.

★ 주의: 대분류/중분류 코드 문자열(L1.c, L2.c)의 정확한 표기는 실제 파일을
  열어봐야 확정된다. 코드 불일치로 병합이 실패하지 않도록, 이 스크립트는
  코드가 아니라 '이름' 기준으로 매칭하는 병합 함수(applyJobPoolPatch)를
  함께 생성한다. 이름 매칭도 실패하면 새 대분류/중분류를 만들도록 폴백한다.
"""
import json

BACSLO_TO_RIASEC = {"B": "R", "A": "I", "C": "A", "S": "S", "L": "E", "O": "C"}

def to_r(pass_profile):
    """production 순서: [순차처리, 계획력, 동시처리, 주의력]"""
    p = pass_profile
    return [p["successive"], p["planning"], p["simultaneous"], p["attention"]]

def to_ria(interest_code):
    """D-CAS 6유형 상위 2개 → RIASEC 상위 2개로 변환"""
    return [BACSLO_TO_RIASEC[c] for c in interest_code[:2]]

def to_k(job):
    """job-strip에 쓰이는 키워드 2개. 자리표시 값 — 실제 카피는 검수 후 교체 권장."""
    return f'{job["ncs"]["middle_name"]}·{job["interest_top1"]}'

def main():
    d = json.load(open("dcas-jobs-master.json", encoding="utf-8"))
    jobs = d["jobs"]

    job_patch = {}          # JOB 확장분
    ncs_groups = {}         # {대분류명: {중분류명: [id, ...]}}

    for job in jobs:
        jid = f'j{job["id"]}'
        job_patch[jid] = {
            "n": job["label_ko"],
            "r": to_r(job["pass_profile"]),
            "ria": to_ria(job["interest_code"]),
            "k": to_k(job),
            # 참고용 부가정보 — production 스키마엔 없지만 화면에서 안 쓰면 무해
            "entry": job["entry_level"],
            "isco": job["isco_code"],
        }
        maj = job["ncs"]["major_name"]
        mid = job["ncs"]["middle_name"]
        ncs_groups.setdefault(maj, {}).setdefault(mid, []).append(jid)

    # ---- 산출 1: JOB 확장 객체 ----
    job_js = "const JOB_PATCH = " + json.dumps(job_patch, ensure_ascii=False, indent=2) + ";\n"

    # ---- 산출 2: 대분류→중분류→id 목록 (이름 키) ----
    ncs_js = "const NCS_JOB_IDS_PATCH = " + json.dumps(ncs_groups, ensure_ascii=False, indent=2) + ";\n"

    # ---- 산출 3: 병합 함수 (이름 매칭, 코드 불일치에도 안전) ----
    merge_js = r"""
/**
 * 기존 JOB / NCS 객체에 JOB_PATCH / NCS_JOB_IDS_PATCH를 병합한다.
 * - JOB: Object.assign으로 확장 (기존 id와 겹치면 새 값이 이김 → 필요시 순서 조정)
 * - NCS: 대분류명·중분류명으로 매칭해 j[] 배열을 교체.
 *   매칭되는 대분류/중분류가 없으면 새로 만들어 붙인다(코드는 'X-<순번>'으로 임시 부여).
 *   기존에 남겨두고 싶은 수작업 직무가 있다면 REPLACE 대신 뒤에 append하도록
 *   mode:'append'로 바꿔 호출하면 된다.
 */
function applyJobPoolPatch(JOB, NCS, mode) {
  mode = mode || 'replace';           // 'replace' | 'append'
  Object.assign(JOB, JOB_PATCH);

  Object.keys(NCS_JOB_IDS_PATCH).forEach(function (majName) {
    var mids = NCS_JOB_IDS_PATCH[majName];
    var L1 = NCS.filter(function (x) { return x.n === majName; })[0];
    if (!L1) {
      L1 = { c: 'X-' + (NCS.length + 1), n: majName, m: [] };
      NCS.push(L1);
    }
    Object.keys(mids).forEach(function (midName) {
      var ids = mids[midName];
      var L2 = L1.m.filter(function (x) { return x.n === midName; })[0];
      if (!L2) {
        L2 = { c: L1.c + '-' + (L1.m.length + 1), n: midName, j: [] };
        L1.m.push(L2);
      }
      var stubs = ids.map(function (id) {
        return { id: id, r: JOB_PATCH[id].r };
      });
      if (mode === 'append') {
        var existingIds = L2.j.map(function (x) { return x.id; });
        stubs.forEach(function (s) {
          if (existingIds.indexOf(s.id) === -1) L2.j.push(s);
        });
      } else {
        L2.j = stubs;   // 기존 3개짜리 목록을 통째로 교체
      }
    });
  });
}
"""

    open("job-pool-patch.js", "w", encoding="utf-8").write(job_js + "\n" + ncs_js + "\n" + merge_js)

    print(f"직무 {len(job_patch)}건 / 대분류 {len(ncs_groups)}개 변환 완료 → job-pool-patch.js")
    for maj, mids in list(ncs_groups.items())[:3]:
        print(f"  {maj}: " + ", ".join(f"{k}({len(v)})" for k, v in mids.items()))

if __name__ == "__main__":
    main()
