# 검증된 최종 진단 — 09.07 실제 소스 확인본

## 이 문서가 이전 것들과 다른 점

**이전까지의 진단은 대화 기록 조각으로 재구성한 추정이었습니다.**
이번엔 실제 GitHub 저장소(goldensge22-design/feelgood-app)에서 원본
파일을 직접 받아 grep으로 검증했습니다. 그 결과 **일부는 확인됐고,
일부는 틀렸다는 게 밝혀졌습니다.** 틀린 건 취소합니다.

## ⚠️ 중요한 전제 — 반드시 개발자에게 전달하세요

이 저장소의 `dcas_adult_report_v2.html`이 **실제 service.feel-good.io에
배포된 파일과 100% 동일하다는 보장은 없습니다.** 저장소에 같은 이름의
버전이 여러 개(`(1)`, `(2)`, `(3)` 등) 있었고, 라이브 관리자 페이지는
URL이 너무 길어 직접 열어보지 못했습니다. **아래 진단은 "이 저장소
파일 기준"이며, 실제 배포 파일에서 grep으로 한 번 더 확인 후 적용하세요.**

---

## A. 확정된 버그 (grep 라인번호로 검증됨)

### A-1. 01~03번 페이지가 전체 검사자에게 100% 동일 — 최우선 처리 대상

**증상**: 인지 프로파일(레이더차트), 강점·보완 포인트, 인지 조합 진단
세 페이지 전체가 "박준서"라는 특정 인물의 값(순차91%·계획84%·주의71%·
동시66%)으로 완전히 고정. SVG 폴리곤 좌표까지 이 숫자로 박제됨.

**근거**: `renderDynamic()` 함수를 grep해보면 이 세 섹션(`profile`,
`strength`, `combo`)을 갱신하는 호출이 전혀 없습니다.
```js
function renderDynamic(){
  renderInterest(); renderPicker(); renderFit();
  renderMatrix(); renderJobs(); renderSkill(); renderKeyAxis();
  renderSummary(); renderRoadmap(); renderDocs(); renderInterview(); renderRx();
}
```
`profile`/`strength`/`combo`가 목록에 없습니다. 이 세 섹션은 최초 1회
`render()`에서 정적 HTML 문자열(`SECTIONS_KO.profile` 등)을 그대로
꽂아 넣고 끝입니다.

**왜 가장 급한가**: 8~14번 페이지의 개인화 버그들은 "일부 문장이 안
맞는" 수준이지만, 이건 **결과지 맨 앞 3페이지가 검사자 전원에게
똑같은 남의 데이터를 보여주는 것**입니다. 우선순위 1위로 올려야 합니다.

**해결 방향**: `renderProfile()`, `renderStrength()`, `renderCombo()`
세 함수를 새로 만들어 `renderDynamic()`에 추가해야 합니다. 레이더 SVG
좌표·막대 width%·강점 매트릭스 텍스트를 전부 `ME`, `AXES` 기준으로
계산하도록 바꿔야 합니다. **이건 패치 한 줄이 아니라 신규 구현이
필요한 작업**입니다 — `profile-dynamic-fix.js`에 뼈대를 만들어
드렸습니다.

---

### A-2. 05번 종합총평 — SS 점수 문장 하드코딩 (부분 확정)

**확인된 실제 코드** (`renderSummary()` 중):
```js
'<p>순차처리(SS 128)와 계획력(SS 121)이 함께 상위권인 특화형 프로파일입니다. ...' +
align + '</p>'
```
**중요**: `align` 변수는 실제로 `quadrants()` 결과에 따라 동적으로
계산되고 있었습니다 (이 부분은 정상). **하드코딩된 건 첫 문장뿐**입니다.

**해결**: `summary-fix.js` — 첫 문장만 `myAxisRank()` 기준으로 교체.
나머지(align, line)는 그대로 둡니다.

---

### A-3. 10번 로드맵 — "60% 이상" 하드코딩 (확정)

**확인된 실제 코드** (`renderRoadmap()` 중):
```js
'<div class="tip-box">2순위 직무는 1순위와 요구 역량이 대체로 60% 이상 겹쳐요. ...';
```
무조건 출력. **해결**: `roadmap-fix.js`.

---

### A-4. 11번 서류·면접 — employed 괄호 미채움 (확정)

**확인된 실제 코드** (`renderDocs()`):
```js
function renderDocs(){
  const D = DOCS[STATE.mode];
  document.getElementById('docsArea').innerHTML = D.body;
  const top = rankedJobs()[0], dj = document.getElementById('docJob');
  if(dj && top) dj.textContent = top.n;   // ← jobseeker 모드의 [이 직무]만 채워짐
}
```
`employed` 모드의 [축 조합], [희망 직무], [요구 축] 등은 채워주는
코드 자체가 없습니다. **해결**: `docs-fix.js`.

---

### A-5. 08번 매트릭스 콜아웃 — "재고 필요" 무조건 출력 (확정)

**확인된 실제 코드** (`renderMatrix()`):
```js
area.innerHTML = ... +
  '<div class="tip-box"><b>재고 필요</b> 칸에 있는 직무를 눈여겨보세요. ...</div>';
```
`q.q3.length` 체크 없이 항상 출력. **해결**: `matrix-callout-fix.js`.

---

### A-6. K-PASS 결과지 — "송서우" 하드코딩 (확정)

`report.kpass.final.html`에서 "송서우" 18회 확인. 이전 KPASS-STATUS.md
진단 그대로 유효합니다.

---

### A-7. 청소년 리포트 — "이지훈" 하드코딩 (확정, 예상보다 범위가 넓음)

`dcas_teen_report_v2.html`에서 "이지훈" 12회 확인. **05번 정서적 지지
페이지 하나가 아니라, 01번 프로필카드·학습패턴 설명·두뇌유형 설명·
PDF 다운로드 파일명까지 최소 6개 지점**에 흩어져 있었습니다.
`renderEmotional` 류의 동적 함수도 존재하지 않습니다 — A-1(성인 01~03
페이지)과 같은 계열의, **리포트 전체가 정적인** 문제입니다.

**해결 방향**: teen-emotional-fix.js 하나로는 부족합니다. 성인 A-1과
같은 수준의 재작업(이지훈 이름이 나오는 모든 지점을 실제 검사자
변수로 교체)이 필요합니다. 지점 목록만 우선 정리했습니다 — 실제 코드
패치는 청소년 리포트 전체 구조를 더 봐야 정확히 만들 수 있습니다.

---

## B. 취소합니다 — 제가 틀렸던 진단

### B-1. ~~quadrants-fix.js (사분면 절대임계값 버그)~~ → 적용 금지

실제 `quadrants()`:
```js
function quadrants(){
  const list = rankedJobs();
  const q = {q1:[],q2:[],q3:[],q4:[]};
  list.forEach(function(j){
    const cog = j.tier.t<=2, itr = j.il>=1;
    ...
```
`j.fit>=75`가 아니라 `j.tier.t<=2`입니다. `tier`는 `tierOf()`가
핵심/보조/무관 축 태깅(`reqTag`)을 기반으로 산출하는, **이미 상당히
정교한 상대적 분류**입니다. 제가 만든 quadrants-fix.js는 존재하지
않는 `j.fit` 절대기준을 가정하고 만든 것이라 **그대로 적용하면 안
됩니다.** 원래 화면에서 사분면이 비어 보였던 진짜 원인은 로직이
아니라 **직무 풀이 3개뿐이었던 것**(A-1과 무관, 이미 job-pool-patch.js
로 해결됨)이었을 가능성이 높습니다.

### B-2. ~~"영역 내 1위 강조가 최우선 칸에서만 걸린다"~~ → 취소

실제 `renderJobs()`:
```js
const rank1 = list[0].id;   // 전체 목록 1위 — 사분면과 무관
...
tierBox('b1', ..., t1, pool, rank1)   // 어느 tier든 rank1과 비교해 강조
```
이미 사분면·tier와 무관하게 전체 1위를 정확히 강조하고 있었습니다.
quadrant.ts, quadrants-fix.js에 있던 `isAreaTop` 관련 수정은 불필요합니다.

### B-3. ~~12번 보완축 훈련처방 "왜 주의력이냐" — 버그~~ → 재분류: 버그 아닐 가능성

실제 `renderRx()`의 AXES·ME·JOB.r 순서를 대조한 결과 **인덱스 밀림은
없었습니다.** 셋 다 `[q,p,s,a]` = `[순차,계획,동시,주의]`로 일관됩니다.

화면에 "동시처리·주의력" 카드가 뜬 건, `renderRx()`의 이 분기 때문일
가능성이 높습니다:
```js
const under = diffs.filter(x => x.gap<0)...   // 요구 미달 축
const targets = (under.length ? under : diffs.slice().sort((a,b)=>a.me-b.me))
                  .slice(0,2)...
```
**1순위 직무의 모든 요구를 이미 충족했다면**, "요구 대비 부족"이 아니라
**"내 전체 점수 중 가장 낮은 두 축"**으로 자동 전환됩니다. 이건 의도된
폴백이지 인덱스 버그가 아닐 수 있습니다. 다만 이 폴백이 사용자에게
"부족한 영역"이라는 오해를 준다면, **로직이 아니라 안내 문구
문제**입니다 — `head` 문구가 이미 "1순위 직무 요구는 모두 충족했어요"
라고 설명은 하고 있으니, 실제 화면에서 이 문구가 제대로 노출됐는지
확인이 먼저입니다.

### B-4. growth-tracker-fix.js → 이 파일 기준으로는 해당 코드 없음

"동시처리 보완 미션", "주의력 보완 미션" 문자열이 이 저장소 파일에는
없었습니다. 다른 버전 파일이나 실제 배포본에만 있을 가능성이 있습니다.
**적용 보류 — 배포 파일에서 먼저 grep으로 존재 여부 확인 필요.**

---

## C. 재검사 예시 표 — 애매한 케이스

12번 페이지의 재검사 예시 표(91→92, 84→86, 71→79, 66→75)는 실제로
**델타 계산이 정확합니다** (92-91=1, 86-84=2, 79-71=8, 75-66=9 — 전부
맞음). 사용자가 hwpx에서 보여준 화면(62→92인데 +1로 표시 등)과는 다른
숫자입니다. **이 저장소 파일과 실제 배포 파일이 다른 버전일 가능성이
여기서도 나타납니다.** 다만 이 표가 여전히 정적 예시라는 것 자체는
A-1과 같은 문제이므로, `axis-utils.js`의 `buildRetestRows()` 개념은
계속 유효합니다 — 실제 재검사 데이터로 계산되게 만들어야 합니다.

---

## D. 최종 적용 파일 목록 (수정본)

| 파일 | 상태 | 비고 |
|---|---|---|
| profile-dynamic-fix.js | 🆕 신규, 최우선 | 01~03번 페이지 동적화 — 가장 큰 작업 |
| summary-fix.js | ✅ 수정됨 | 05번, 첫 문장만 교체 |
| roadmap-fix.js | ✅ 수정됨 | 10번, "60%" 교체 |
| docs-fix.js | ✅ 수정됨 | 11번, employed 괄호 채움 |
| matrix-callout-fix.js | 🆕 신규 | 08번, 콜아웃 조건부 처리 |
| kpass-score-engine.js | 유지 | 기존 그대로 유효 |
| KPASS-STATUS.md | 유지 | 기존 그대로 유효 |
| ~~quadrants-fix.js~~ | ❌ 폐기 | 잘못된 가정. 적용 금지 |
| ~~growth-tracker-fix.js~~ | ⏸ 보류 | 이 파일 기준 해당 코드 없음 |
| axis-utils.js | ⚠️ 부분 유지 | buildRetestRows()만 유효, 나머지는 실사용처 재확인 필요 |
| teen-emotional-fix.js | ⚠️ 범위 부족 | "이지훈" 문제가 더 넓게 퍼져 있음, 재작업 필요 |
| job-pool-patch.js 외 직무 데이터 6종 | 유지 | 이번 검증과 무관, 그대로 유효 |

**개발자에게 이 문서를 가장 먼저 전달하세요.** 이전 00-MASTER-SUMMARY.md
는 이 문서로 대체됩니다.
