/**
 * axis-utils.js — 축 순서·강점/보완축 계산의 단일 출처
 *
 * 배경: 08(매트릭스)·10(로드맵)·12(훈련 처방) 페이지가 각자
 * ['순차','계획','동시','주의'] 순서를 따로 하드코딩해서 쓰다가
 * 어딘가에서 순서가 어긋난 것으로 보임 (재검사 예시 화면의 "변화" 열이
 * 실제 1차/2차 차이와 전혀 안 맞는 것으로 확인됨).
 *
 * 해결: 축 순서·이름·매핑을 이 파일 하나에서만 정의하고,
 * 다른 모든 페이지는 반드시 이 파일의 함수를 통해서만 축 데이터를 다룬다.
 * 페이지 안에 ['순차','계획','동시','주의'] 같은 배열을 새로 만들지 않는다.
 */

// ★ 이 순서가 전체 시스템의 유일한 기준. r 배열, ME 객체 키 순서와 반드시 일치.
const AXIS_ORDER = ['q', 'p', 's', 'a'];         // ME 객체 키
const AXIS_LABEL = {
  q: '순차처리',
  p: '계획력',
  s: '동시처리',
  a: '주의력',
};

/** r:[순차,계획,동시,주의] 배열의 i번째 값 ↔ AXIS_ORDER[i] 키가 항상 같은 축을 가리킨다. */
function axisName(i) { return AXIS_LABEL[AXIS_ORDER[i]]; }

/** 내 점수(ME) 전체를 [{key,name,val}] 내림차순으로 반환 */
function myAxesRanked() {
  return AXIS_ORDER
    .map((k, i) => ({ key: k, name: AXIS_LABEL[k], val: ME[k], idx: i }))
    .sort((x, y) => y.val - x.val);
}

/**
 * job(r 배열 보유) 기준, 요구-보유 격차가 큰 순서로 top-n 축 반환.
 * 08/10/12 페이지가 전부 이 함수 하나로 "보완축"을 결정한다.
 */
function weakAxesRanked(job, n) {
  n = n || AXIS_ORDER.length;
  const ranked = AXIS_ORDER.map((k, i) => ({
    key: k,
    name: AXIS_LABEL[k],
    idx: i,
    gap: Math.round(job.r[i] - ME[k]),   // 요구가 내 점수보다 얼마나 높은지
  })).sort((x, y) => y.gap - x.gap);
  return ranked.slice(0, n);
}

/** 재검사 비교 표(이미지 1)용 — 축과 값이 항상 같은 인덱스로 짝지어지도록 강제 */
function buildRetestRows(scoresBefore, scoresAfter) {
  // scoresBefore/After: AXIS_ORDER와 같은 순서의 숫자 배열, 또는 {q,p,s,a} 객체
  const get = (src, i) => Array.isArray(src) ? src[i] : src[AXIS_ORDER[i]];
  return AXIS_ORDER.map((k, i) => {
    const before = get(scoresBefore, i);
    const after = get(scoresAfter, i);
    return {
      axis: AXIS_LABEL[k],
      before,
      after,
      delta: Math.round(after - before),   // ← 반드시 이 계산으로만 만든다. 손으로 쓰지 않는다.
    };
  });
}
