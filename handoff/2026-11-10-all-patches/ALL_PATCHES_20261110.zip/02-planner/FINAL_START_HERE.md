> **최신 보정본:** [QA_CORRECTION_START_HERE.md](QA_CORRECTION_START_HERE.md)를 먼저 읽으세요. 아래는 수정 전 검수·인계 이력입니다.

# 개발자 시작 안내 — LAB 일일 진로 연습

> **추가 QA 갱신:** [연동 제외 QA 결과](NONINTEGRATION_QA_REPORT.md)에서 전체 화면 언어 혼용과 모바일 복원 레이아웃 P2 4종이 확인됐습니다. 이전 신규 LAB 패널 통과를 전체 제품 통과로 해석하지 마세요. 현재 소스 ZIP은 수정하지 않았고 전체 판정은 부분통과입니다.

2026-11-10. **검토 패키지 준비 완료. 운영 NUVIA 로그인·서버 연동은 개발자 작업입니다.** 기존 실행본에 적용하거나 공개 배포하지 않았습니다.

## 전달 자료

| 자료 | 용도 |
|---|---|
| [최종 패치](NUVIA_STUDIO_LAB_DAILY_REVIEW_PATCH.zip) | MANIFEST.json, changes.patch, payload 57개 소스, 적용 순서, 제작 측 QA 증거 |
| [전체 소스](NUVIA_PLANNER_STUDIO_FULL_SOURCE_LAB_DAILY.zip) | 비교·독립 실행 기준. 개발자 연동 브랜치를 통째로 덮어쓸 파일이 아님 |
| [최종 QA](FINAL_QA_REPORT.md) / [STATUS.json](STATUS.json) | 실제 완료 범위·미완료 |
| [수신 계약](CONTRACT_REVIEW.md) / [직무 계약 대조](JOB_CONTRACT_REVIEW.md) | 발신 형식과 운영 인증 경계 |
| [청소년 예시](YOUTH_CONTRACT_FIXTURES.json) / [직무 최종 예시](JOB_SENDER_FINAL_FIXTURES.json) | 실제 발신 생성기로 만든 합성 자료. 운영 실적·인증 증거 아님 |
| [해시 대조](FINAL_SOURCE_CROSSCHECK.json) | 패치/전체 소스 57개 일치, 선행 요약 파일 5개 연결, 제작 측 로그 확인 |

INITIAL/THIRD/FOURTH/FIFTH 파일은 이전 후보의 검사 이력입니다. 원본 ZIP 안 INCOMPLETE.md의 일부 브라우저 미검증 문장은 제작 당시 상태이며, 이후 독립 검수 범위만 FINAL_QA_REPORT.md가 보충합니다. 원본 ZIP을 수정하지 않았습니다.

## 적용 순서

1. 개발자의 최신 결과지·서버 연동 브랜치를 보존하고 별도 검토 브랜치에서 작업합니다.
2. [일상 추천](NUVIA_STUDIO_DAILY_PRACTICE_REVIEW_PATCH.zip) → [간단히 요약하기](NUVIA_STUDIO_EXECUTION_SUMMARY_REVIEW_PATCH.zip) → [이번 LAB 패치](NUVIA_STUDIO_LAB_DAILY_REVIEW_PATCH.zip) 순서로 비교합니다.
3. manifest 파일별 BEFORE 해시를 확인합니다. 추천→요약의 중복 5개, 요약→이번 패치의 중복 5개는 각각 일치합니다. **개발자 브랜치 전체의 호환 보증이 아닙니다.** 기존 GitHub 실행본과의 14개 차이(3개 없음, 11개 상이)는 병합 검토가 필요합니다.
4. 전체 소스는 비교·독립 실행용입니다. 기존 adapter/API/저장 키와 개발자 변경을 지우며 덮어쓰지 않습니다. 충돌은 파일별로 해결하고 회귀 검사합니다.
5. Git 기준: `codex/nuvia-planner-library-integration` / `567e6b51dc4372fca647745db3166ab540058673`. Replit 패치 BEFORE 기준: `3a38bbb29bfeca813c4f772e8c07bf44103ef45d`.

[선행 GitHub 개발자 안내](https://github.com/goldensge22-design/feelgood-app/blob/codex/nuvia-planner-library-integration/nuvia-planner/docs/DAILY_PRACTICE_DEVELOPER_START_HERE_2026-11-09.md). 이전 기준 문서이며 이번 패치를 push했다는 뜻이 아닙니다.

## 지킬 기능 규칙

- LAB에서 사용자가 확인한 강점·관심사·탐색 방향을 받아 5~10분 일상 연습을 제안합니다. 매번 LAB에 돌아갈 필요가 없습니다.
- 첫 제안 1개, 추가 요청마다 1개씩 최대 2개 더. 실제 수락은 하루 최대 3개입니다. 제안 열람·교체는 수락·실행·완료와 다릅니다. 기존 자유 과제·메모·일정·옛 추천에는 상한을 소급하지 않습니다.
- 명시적 수락 후 일반 과제가 생깁니다. 질문·분량은 본인이 바꾸며 답·결과·성찰을 대신 작성하지 않습니다. 작업대에 놓아도 자동 시작하지 않습니다.
- 방향 전환·철회는 해당 LAB 출처에만 적용합니다. 다른 LAB 방향과 과거 활동을 지우지 않습니다.
- PASS는 도움 표현만 바꾸며 새 점수·진단·인지 향상률을 만들지 않습니다. 일상 연습, 모의 상황, 실제 활동, 자기보고, 외부 확인을 분리합니다. 자소서는 승인된 실제 근거만 사용합니다.
- 기존 15언어·메모·요약·일정·복귀·백업·로드맵을 보존합니다. 신규 AI 호출과 HISTORY 외부 연동은 없습니다.

## 운영 서버 연결 필수 항목

공유 묶음의 `../shared/NUVIA_통합로그인_필수규칙_20261110.txt`와 기존 중앙 NUVIA 인증체계를 따릅니다. 별도 가입·로그인 서버·중복 회원을 만들지 않습니다. 이메일이나 localStorage ID만으로 신원을 확정하지 않습니다.

1. 인증 사용자, 캠프 소유·서비스 권한, 현재 플래너 연결 동의, 현재 세션·서버 순서를 adapter에 연결합니다. JSON 필드 자체는 인증이 아닙니다.
2. 청소년 `daily-exploration-direction/1`와 직무 `direction-handoff/1.0`을 별도로 해석합니다. 직무는 전체 스냅샷이며 createdVia는 과거 생성 이유입니다. 같은 버전의 상태 전환·순서 역전·철회·재전송을 구분합니다.
3. 검토 UI의 유효 JSON은 `connection_pending`으로만 보관합니다. 합성 verified context 통과는 운영 인증 구현이 아닙니다. UI에서 임의 인증 맥락을 만들지 않습니다.
4. 계정의 고정 IANA 시간대와 서버 시각으로 하루 경계를 정합니다. 여러 LAB/탭/기기의 수락 합계 3개를 서버 트랜잭션으로 보장하고 requestId 멱등성, 재시도·취소·재접속·자정을 검증합니다.
5. 계정 전환·로그아웃·만료 후 늦은 응답과 이전 사용자 캐시를 차단합니다. 직접 링크 로그인 후 원래 목적지로 복귀하게 합니다. 기존 MyNuviaHub/MyNuviaFlowMount 등 연결점을 대조합니다.
6. 결과지 단위·연령·검사/사용자 ID 계약을 유지합니다. 이번 패치로 결과지·다른 LAB 원본을 수정하지 않습니다.

## 실행·검수

전체 소스 압축 해제 후 Node 24 / pnpm 10 계열에서 `pnpm install --frozen-lockfile`, `pnpm run typecheck`, `pnpm run build`, `pnpm --filter @workspace/nuvia-ui-review run build:library-public`을 실행합니다. PORT와 BASE_PATH는 환경에 맞춥니다. 깨끗한 설치 증거는 ZIP의 qa-evidence에 있으며 최종 소스 해시와 대조했습니다.

`node tools/nuvia-studio/run-lab-daily-check.mjs` 및 해당 run-*-check.mjs를 실행합니다. Windows 원본 i18n 실행기는 경로 문제가 남아 있습니다. [Windows 검수용 실행기](run-i18n-windows-compat.mjs)를 추출 소스 `tools/nuvia-studio/`에 복사한 뒤 루트에서 실행하면 같은 439개 단언을 경로만 보정해 검사합니다. 제품 소스·번역값을 바꾸지 않습니다.

실제 SSO·DB 동시성과 기존 4개 실패·17개 미검증 여정·좁은 설정 화면 P2·원어민 번역 검수는 인수 목록에서 지우지 마세요. 최종 QA의 통과는 해당 검수 범위에 한정합니다. 적용·배포는 사용자 검토 후 별도 승인으로 진행합니다. 이번 전달에는 GitHub push/main 병합/공개 URL 교체가 없습니다.
