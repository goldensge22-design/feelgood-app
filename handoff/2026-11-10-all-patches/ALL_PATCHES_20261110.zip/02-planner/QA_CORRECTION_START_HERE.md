# 개발자 전달 — 연동 제외 QA 보정 최종본

2026-11-10. 이 문서가 이전 FINAL_START_HERE의 QA 상태를 갱신합니다. 운영 연동과 배포는 수행하지 않았습니다.

## 전달 파일

- [새 보정 패치](NUVIA_STUDIO_LAB_DAILY_QA_CORRECTED_V3_PATCH.zip)
- [동일 버전 전체 소스](NUVIA_PLANNER_STUDIO_FULL_SOURCE_LAB_DAILY_QA_CORRECTED_V3.zip)
- [검수 결과](QA_CORRECTION_FINAL_REPORT.md)
- [파일 해시 및 일치 검증](QA_FIX_FINAL_PACKAGE_VERIFICATION.json)

- NUVIA_STUDIO_LAB_DAILY_QA_CORRECTED_V3_PATCH.zip: SHA-256 `de5daf33de42d3328564a4e6c8fcf6e525f7ab62e744ad2312b41e5d39d249e6`
- NUVIA_PLANNER_STUDIO_FULL_SOURCE_LAB_DAILY_QA_CORRECTED_V3.zip: SHA-256 `42a38ac8886ea64f4d0454978f294382c1c8bdc2fd744bbbd24151230573147f`

기존 ZIP 및 V1/V2는 이력으로 보존합니다. 새로 전달할 파일은 위 두 파일입니다. 전체 소스는 독립 실행·비교용이며 개발자 연동 브랜치를 덮어쓰는 용도가 아닙니다.

전체 소스 안 SOURCE_NOTE의 Windows 대기 표시는 포장 당시 기록입니다. 검증한 소스 해시를 보존했으므로 원본을 다시 쓰지 않았습니다. 최신 상태는 이 문서, QA_CORRECTION_FINAL_REPORT 및 패치 안 qa-evidence/FINAL_QA_NOTES를 우선합니다.

## 적용 순서

1. 개발자 최신 브랜치와 사용자 기록을 백업하고 별도 검토 브랜치에서 시작합니다.
2. 기존 Career Review/15언어 인계 → DAILY_PRACTICE → EXECUTION_SUMMARY → LAB_DAILY → 이번 QA 보정 순서를 대조합니다.
3. 패치의 MANIFEST와 CHECK_AND_APPLY를 먼저 읽기 전용으로 실행합니다. 기준이 다르면 적용을 중단하고 파일별 병합합니다. 선행 GitHub 기준과 14개 파일 차이가 있었으며 운영 개발자 브랜치 호환을 확인했다는 뜻이 아닙니다.
4. 패치 APPLY_GUIDE에 따라 별도 백업을 지정하고 적용합니다. 결과지 adapter/API/사용자 저장 키·인증을 임의 변경하지 않습니다.
5. 개발자 환경에서 자동검사·타입·일반/public 빌드와 핵심 여정을 실행합니다. 이번에 제외한 실제 결과지·SSO·LAB·DB·동시성 연동 QA를 별도로 수행합니다.

Windows에서는 Node 24를 사용하고 원본 i18n/demo-locale 검사도 바로 실행합니다. 이전 Windows 임시 shim은 더 이상 이 보정본의 필수 절차가 아닙니다. 외부 Vitest의 '%' 포함 루트 제한 때문에 프로젝트 폴더명에 '%' 문자는 피합니다. 공백·한글·퍼센트 인코딩 번역 모듈 참조 자체는 별도 검사했습니다.

Git 기준은 codex/nuvia-planner-library-integration / 567e6b51dc4372fca647745db3166ab540058673입니다. 이번 대화에서는 GitHub push, main 병합, 공개 URL 교체를 하지 않았습니다. 승인된 OneDrive planner 폴더에 새 파일과 이 문서를 전달합니다.
