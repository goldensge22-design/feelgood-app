# 선택 생성카드 등록 확장 계약 — scenario-planner-register/1.1

## 범위와 현재 상태
기업·직무 LAB에서 이미 생성한 카드 **하나**와 학생이 확인·승인한 **예정 계획**을 등록하는 발신 보강이다.
방향 추천 전달(direction-handoff/1.0), 새 활동 추천, 활동 수행 인증, 실적 생성이 아니다.
현재 기본 실행에는 수신 어댑터가 설치되어 있지 않다. 요청을 보존하되 `waiting_connection` / null 영수증이다.
중앙 SSO·실제 플래너·운영 도메인 연결과 다른 앱 수정·공개 배포는 이번 범위 밖이다.

## 한 가지 확장 규격, 두 가지 명시적 어댑터 경로
- 신규 발신 바깥 계약: `scenario-planner-register/1.1`.
- `source`: 기존 `scenario-handoff/1.0`를 변경하지 않은 전체 스냅샷.
  card의 정체성·의미/번역/규칙 버전·기업/직무 입력·공식 출처·자료·과제·대안·추가상황을 자르거나 바꾸지 않는다.
  등록 대상은 카드이며 학생의 연습 답안을 임의로 전송하지 않는다(`practiceDraft:null`).
- `sourceDigest`: canonical JSON으로 계산한 전체 source SHA256.
- `displayProjection`: **원본 계약이 아닌 별도 화면 표시본**, 버전 `scenario-display/1.0`.
  원본 ID/의미버전을 참조하고, 공개한 분기의 추가상황만 표시한다.
  미공개 항목은 표시본의 card.changes와 card.decisionPacket.changes에서 제외한다.
  원본 버전의 내용을 수정한 원본인 것처럼 취급하면 안 된다.
- `disclosure`: `historyStatus:recorded|legacy_unknown`, 공개 revision과 `{branch:A|B|custom,at:ISO8601}` 목록.
  새 카드의 명시적 빈 목록은 `recorded`이며 아직 공개되지 않은 상태다. 과거 카드에 이력이 없거나 provenance 필드가 없으면 `legacy_unknown`이다.
  두 경우 모두 확인되지 않은 분기는 화면에서 가린다. 답안 선택·완료 상태로 공개를 추정하지 않는다.
  과거 이력 미확인 카드에 새 공개 기록을 추가하더라도 전체 과거 이력이 확인된 것으로 바꾸지 않는다.

## 최종 보완과 이미 고정한 샘플의 호환성
- 앞서 전달한 1.0 ZIP·샘플은 변경하지 않는다. 사용자 측 독립 해시/서명 등 12개 통과는 **사용자 확인 결과**이며 당사 재실행이라고 쓰지 않는다.
- 최종 신규 발신 1.1은 공개 이력 provenance를 명시한다. 영수증은 `scenario-planner-receipt/1.0`, 원본은 `scenario-handoff/1.0` 그대로다.
- 수신 저장은 전체 원본과 승인 계획을 보존한다. 1.0의 provenance 누락은 `legacy_unknown`으로 읽고, 새로 기록된 미공개 상태로 단정하지 않는다.
- 이미 발신한 저장 packet을 재시도할 때는 그 packet/해시/요청 ID를 그대로 재사용한다. 과거 발신을 1.1로 몰래 재작성하지 않는다.
- 계획 제목·목표·단계·목표역량·성공기준·예정산출물은 공백만 있는 입력을 거절한다. 검사는 trim 결과를 **판정에만** 사용하며 원문의 앞뒤 공백·개행을 변환하거나 지우지 않는다.
- OpenAPI의 `pattern: \S`, 실제 Zod 검증, 독립 수신 fixture에서 같은 필수조건을 확인한다.
- 회사 근거의 원어가 다른 경우 `source.card.officialFacts[].language`가 원문 언어를 알린다. 수신은 원본 JSON의 선택 필드를 버리거나 재구성하지 않는다.
  기존 저장본에 공개 이력이 없으면 가림으로 시작하며 답안 선택만으로 공개를 추정하지 않는다.
  custom 분기를 공개하면 그 분기가 보여주는 비교 정보가 표시된다.
- **전체 source는 인증된 서버 간 전달·수신 서버 저장 전용**이다.
  수신 서버는 학생 화면 응답을 표시본으로 생성하고 전체 원본/숨김 영역을 브라우저 응답에 포함하지 않아야 한다.
  암호문 전용 전송·키 에스크로·향후 키 전달에 의존하지 않는다.
- `origin.kind:generated_scenario`, `recordKind:daily_practice|job_simulation|consented_roleplay`.
  “학생 조사”, 실제 수행/완료/성과로 변환하면 안 된다.
- `target.route:selected_card`: 신규 선택 생성카드 수신 보강용. 탐색 ID가 없어도 등록 가능하다.
  원본 전체와 승인한 계획을 별도 필드로 저장하는 수신 접점이다.
- `target.route:classroom_flow_v3`: 기존 조사 기반 활동생성 경로를 명시적으로 선택할 때만 사용.
  어댑터의 `resolveExploration`이 확인한 실제 저장 탐색 ID와 현재 탐색 버전이 필수다.
  없으면 `waiting_exploration`; 가짜 탐색 생성·카드 ID를 탐색 ID로 대체하지 않는다.
  원본 메타데이터는 Plan 필드에 추가하거나 설명 문자열에 JSON으로 숨기지 않는다.
  확장을 받지 못하는 기존 activities/new에 전체 확장 봉투를 그대로 POST하지 않는다.

## Plan 및 전달 필드
`activityRequest`: `{requestId,plan,accepted:true}`.
기존 v3 경로에 한해 `{explorationId,explorationRevision}`가 추가된다.
Plan은 아래 **8개 필드만**, 이 확장 DTO에서는 모두 문자열이다.

|필드|제약|
|---|---|
|title|1–500자|
|goal|1–8000자|
|steps|1–10000자|
|targetCapability|1–4000자|
|successCriteria|1–8000자|
|artifactPlan|1–4000자|
|date|빈 문자열 또는 실제 유효한 YYYY-MM-DD|
|status|내부 enum `planned`만; 한국어 화면에는 ‘예정’|

사용자가 실제 v3 검증 실행으로 확인해 전달한 경계는 `planned`, steps≤10000,
추가 Plan 필드 거부, 기존 조사 경로의 탐색 필수이다. 해당 외부 v3 소스/검증 실행을
이 저장소에서 직접 재실행했다고 주장하지 않는다.
기타 필드의 외부 원래 타입/길이 및 실제 응답은 미확인이다.
위 값들은 **명시적으로 버전 구분한 확장 DTO**이며 수신 담당이 실제 타입과 매핑·검증해야 한다.

## 인증·멱등·학생 버전 선택
발신 API는 기존 Clerk 계정·세션과 캠프 접근 및 X-Lab-Camp 일치를 확인한다.
전달 직전/후에는 어댑터 authorize로 현재 서비스/세션 권한을 재확인해야 한다.
운영 어댑터는 인증된 서버 간 통신·기존 계정 바인딩·실시간 세션/권한 확인을 구현해야 하며,
여기에 새 인증이나 서명 없는 인증 링크를 생성하는 기본 구현은 없다.

승인 시 원본, 계획, 공개 상태, 승인 대상 접점을 고정해 outbox를 먼저 저장한다.
사용자+캠프+공통 카드+의미버전이 등록 단위다. 번역/새 클릭 ID로 등록을 중복 생성하지 않는다.
같은 요청 ID의 내용 변경은 409; 이미 등록됐거나 수신 여부가 불확실한 요청의 계획을 덮어쓰지 않는다.
수신도 학생 바인딩+cardId+contentVersion 멱등키와 payloadHash 충돌을 검증해야 한다.
단순히 이전 영수증을 새 payloadHash/nonce로 바꾸어 서명하면 안 된다.

아직 발신되지 않은 연결 대기 요청의 재승인은 새 preview+승인+새 requestId가 필요하다.
기존 승인 원문/계획/요청 해시를 이력으로 남긴다. 연결이 설치됐다고 자동 발신하지 않는다.
새 의미버전은 같은 탐색 입력의 계보를 비교하여 학생에게 기존 계획/새 버전을 선택하게 하며
기존 과제와 학생 계획을 수정하지 않는다.
학생 동의 철회 후 늦은 응답을 적용하지 않으며 이미 수신 서버에서 생성한 과제를 삭제했다고 주장하지 않는다.
철회/응답유실은 수신 상태 조회·동일 요청 재조정이 필요한 상태로 취급한다.

## 검증할 수신영수증
`scenario-planner-receipt/1.0`의 정확한 필드:
`protocol,mode,requestId,payloadHash,cardId,contentVersion,subjectBinding,nonce,activityId,accepted,issuedAt,signature`.
mode는 `isolated_demo` 또는 `verified_service`, accepted는 true여야 한다.
서명은 signature를 제외한 canonical JSON의 Ed25519 서명(base64)이다.
canonical JSON은 객체 키를 `Object.keys(value).sort()`의 **UTF-16 코드유닛 문자열 순서**로 정렬한다.
localeCompare/Intl/운영체제 언어 설정을 사용하지 않는다. 키-값 쌍을 직접 직렬화하여 숫자처럼 생긴 키도 문자열 순서를 유지한다.
원시값은 JSON.stringify, 배열은 입력 순서이며 undefined 등 JSON이 아닌 입력은 계약 밖이다.
fixture는 발신 함수를 재사용하지 않는 독립 수신 구현과 숫자/영문/한글/악센트/이모지 키 벡터·SHA256을 대조한다.
수신 담당은 같은 canonical 규칙을 구현해야 한다.
발신은 별도로 신뢰 설정된 공개키로 검증하고 mode·요청·해시·카드·의미버전·학생/캠프 바인딩·nonce를 모두 비교한다.
추가 필드·잘못된 서명·다른 학생/요청 영수증·단순 2xx/빈 응답은 완료가 아니다.
영수증이 검증된 뒤에만 `registered` 또는 명확히 분리한 `demo_registered`를 기록한다.
외부 미설정/세션 만료/전송 실패/응답유실에는 원본과 고정 요청을 보존한다.
같은 payload로 재시도하여 **기존 수신 과제의 같은 영수증**을 받아 복구한다.

등록 성공과 과제 링크 준비는 별도다. `taskLinkStatus:unconfigured|unverified|ready`로 구분한다.
기존 과제 열기는 개발자가 실제 앱에 맞게 제공한 승인·검증된 HTTPS template의 `{activityId}` 자리만 치환한다.
특정 `/activities/...` 등의 경로를 추정하지 않는다. 미설정/미검증/안전하지 않은 링크는 null이고 등록 영수증의 성공을 취소하지 않는다.
인증 토큰·자동 로그인 서명 없는 링크를 URL에 넣지 않는다.
격리 데모에는 외부 과제 링크를 만들지 않는다. 격리 수신기의 별도 임시 DB 테이블에서 저장 과제를 실제 HTTP로 조회하고
학생용 응답이 표시본만 포함하는지 확인한다. 승인 경로에 따른 열기 버튼 조건은 별도 순수 fixture로 확인하며 운영 화면을 열었다고 보고하지 않는다.

## 격리 왕복과 인계 예시
`artifacts/api-server/tests/scenario-planner.integration.ts`는 127.0.0.1 수신기를 별도로 실행한다.
테스트 전용 identity fixture + 개발 DB를 쓰며 실제 로그인 검수와 구분한다.
선택 생성카드 원본 저장 → 서명 영수증 → 발신 검증, 내용 충돌,
수신 후 응답 유실/재시도, 잘못된 영수증, 공개 상태, 계정/캠프 격리,
현재 동의/세션/캠프 철회 뒤 늦은 응답을 점검한다.
운영 앱에 데모 라우트나 인증 우회를 설치하지 않는다.

실제 실행으로 생성되는 `outbound-example.json`, `expected-demo-receipt.json`,
`demo-receipt-public.pem`은 **테스트 데이터·테스트 공개키**다. 운영 신뢰키가 아니다.
운영 수신 결과·중앙 SSO 연결 증거로 사용하면 안 된다.

### 기존 규격과의 차이
기존 시나리오 JSON 다운로드/방향 snapshot은 그대로 남는다.
신규 봉투가 승인 계획·동의·표시본·수신영수증·재시도·버전 선택을 명시적으로 추가한다.
기존 시나리오 source 내부의 registration:not_connected는 원본 보관 시점의 값이며
새 등록 결과는 이 확장의 검증된 영수증/발신 원장 상태에서 판단한다.
수신 표시상태 후속 동기화, 실제 중앙 인증, 실제 플래너 수신/기존 과제 화면은 개발자 연결 작업으로 남는다.
